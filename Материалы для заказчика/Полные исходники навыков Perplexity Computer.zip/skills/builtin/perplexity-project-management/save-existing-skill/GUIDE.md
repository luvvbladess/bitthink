# Save an Existing Skill into a Project

Materialize one directly accessible, persisted, open-source Skill as an independent Project
snapshot. Signed download URLs are private runtime data. This workflow creates only: it never
overwrites or replaces a Skill, and it leaves the source unchanged.

1. Follow the parent Project-resolution rules for the destination and any source Project, resolving
   them independently. Continue only with exact returned UUIDs; when a Project reference cannot be
   resolved uniquely, ask for its UUID. Retain the destination UUID and, for a Project source,
   its distinct source UUID. Separately use unscoped `project_get({})` to inspect the current association, which may be absent.

2. Create one private staging directory with `umask 077`; capture every listing's stdout and stderr
   in mode-0600 files there instead of displaying it. Remove the entire directory after any terminal
   success, error, or declined consent.

   Resolve one eligible source: caller-owned `individual`, explicit
   `project --scope-id <source-project-uuid>`, `organization`, or eligible `global`/marketplace.
   Built-ins and personal Skills accessible only through sharing are ineligible. Use the fresh
   persisted source, never a loaded or edited workspace copy.

   A supplied canonical name or Skill UUID bypasses discovery. For a display name, search only the
   applicable scope: `individual`; the explicit source `project`; or both `organization` and
   `global` separately when marketplace scope is absent. Every Bash invocation that runs
   `pplx skill list`, including a loop or wrapper, must use
   `api_credentials=["pplx-sdk", "pplx-skill"]`. Build arguments with a Bash array or shell-quote
   every substituted value. The discovery command shape is:

   ```text
   pplx skill list --scope "<scope>" [--scope-id "<source-project-uuid>"] --query "<display-name>" --limit 100 [--cursor "<cursor>"]
   ```

   Validate that `skills` is an array and `next_cursor` is null or a
   string; fail closed on command, parse, malformed-response, or repeated-cursor errors. Paginate to
   `next_cursor == null`, preserving the scope and source Project UUID on every page. Match the
   requested display name exactly against canonical `name` or `display_name`. Continue with the sole
   candidate's UUID and exact scope; stop on zero, or stop and ask the user to choose on multiple
   matches.

3. Discovery is not validation. In one Bash invocation with
   `api_credentials=["pplx-sdk", "pplx-skill"]`, perform an unfiltered authoritative listing in the
   exact source scope, retaining `--scope-id <source-project-uuid>` on every Project-source page:

   ```text
   pplx skill list --scope "<scope>" [--scope-id "<source-project-uuid>"] --limit 100 [--cursor "<cursor>"]
   ```

   Apply the same response validation, fail-closed behavior, and full pagination. Across all pages,
   require exactly one item whose `name` or `id` equals the canonical name, supplied UUID, or
   discovered UUID. Require nonempty `id` and canonical `name`, `closed_source == false`, and a
   nonempty `file_url`; otherwise stop. In that same invocation, extract `file_url` without
   displaying it and run `skill-download "$file_url" "$staging_dir/source"`. Keep `file_url` quoted
   and runtime-only: never print, inspect, paste, or return it. The staged path and canonical name are
   the only outputs needed by later steps.

4. Only when the session must be reassociated, preflight the canonical source name against the
   destination before consent or reassociation. In a Bash invocation with
   `api_credentials=["pplx-sdk", "pplx-skill"]`, run the unfiltered command below through every page
   to `next_cursor == null`:

   ```text
   pplx skill list --scope project --scope-id "<destination-uuid>" --limit 100 [--cursor "<cursor>"]
   ```

   Keep responses private, validate them as in step 3, and fail closed. Compare exact canonical
   `name` values. On collision, stop before consent or reassociation and ask for explicit direction;
   do not rename, retry, overwrite, or edit the staged package. When already in the destination,
   skip this preflight and rely on the authoritative save to detect a collision or race.

5. Before reassociation, disclose that destination collaborators can list, search, retrieve, and
   download existing conversation content, and that future messages and the post-save session remain
   attached. Suggest a new empty session for sensitive content. When moving from another Project,
   name both Projects and disclose removal from the current one. A decline ends the workflow and
   triggers cleanup. After consent, follow the parent's add-versus-swap rule and wait for success.

6. Before saving, and after any required reassociation, separately run unscoped
   `project_get({})` to refresh current-session metadata. Continue only when it contains the
   exact destination UUID; an explicit `project_get({project_id: "<destination-uuid>"})` does not establish the session's association. If the current association has not updated, defer the save until it has.

7. Invoke `save_custom_skill` directly on the staged package with `scope="space"`, without
   `existing_skill_name` or `review`. This is a create-only save; do not load `create-skill`.

   Discover and invoke deferred tool `save_custom_skill` with:

   ```json
   {
     "file_path": "/home/user/workspace/<staging-directory>/source",
     "scope": "space"
   }
   ```

8. Report the authoritative save result. On success, state that the source is unchanged and the new
   Project Skill is an independent snapshot. On collision, conflict, permission failure, or any other
   error, stop and ask for explicit direction; never overwrite or retry under a new name. Clean up
   the staging directory after the terminal outcome, then offer the parent's current-session file
   migration.