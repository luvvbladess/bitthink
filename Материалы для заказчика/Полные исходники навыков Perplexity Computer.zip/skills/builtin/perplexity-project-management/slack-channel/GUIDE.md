
# Slack Channel Project Binding

Use this only for tasks originating from Slack. Call the available `project_*` tools
using the discovery and invocation guidance in the parent skill. Slack team/channel identity comes from
trusted session context, never tool arguments.

Resolve the exact Project before calling `project_slack_connect` or
`project_slack_disconnect`. Create a requested new Project first, retain its
returned ID and URL, then connect.

## Confirm Before Connecting

Connecting a Slack channel to a project has a side effect. Before running `project_slack_connect`, you MUST ask the user to confirm the exact project and connection action with `request_user_input`.

The confirmation must identify:

- The project being connected, preferably by URL when available.
- The current Slack channel being connected, using the Slack channel name from context when available.
- That approving will connect the current Slack channel to that project.

Do not run `project_slack_connect` until the user approves the confirmation. If the user provides only a project name, first resolve it to a specific project URL, id, or slug, then ask for confirmation before connecting.

Do not request this Slack connection confirmation before read-only lookups or before creating a new project. For the "create new project, then connect" flow, create the project first, read the created project URL, slug, or uuid from the command output, then ask for confirmation before running `project_slack_connect`.

## Project Brain Auto-Update Choice

When creating a new project for a Slack channel:

- **Ask whether Project Brain should update automatically.** Do not frame this as enabling or disabling a wiki; Project Brain exists independently of its automatic-update setting. Recommend automatic updates because they keep durable project context, decisions, and channel background current as eligible project activity accumulates. Offer clear choices such as "Yes, auto-update Project Brain" and "No, I'll update it manually."
- **Propose a focus area from channel context, don't ask for one cold.** Read the channel's recent messages, pinned items, and topic to infer the project's purpose, workstreams, decisions, and open questions, then offer a pre-filled focus for the user to confirm or tweak (via `request_user_input`). If the channel is sparse, say so and offer sensible defaults. A generic instruction produces a thin Project Brain — the value is in grounding it.
- **Build once the focus is confirmed.** No separate confirmation for the kickoff itself. If the user chose automatic updates, set `auto_update: true` at creation. Then connect to Slack and run the initial knowledge update built from the confirmed focus regardless of the automatic-update choice.

## Slack Context

Slack-origin tasks may include the current thread/channel context:

```xml
<thread_context>
<channel_context id="C0123456789" name="falcon-launch" />
</thread_context>
```

This means the current task came from Slack channel `C0123456789` named `falcon-launch`. Use it as context for the user's request, but do not pass the channel ID or name to `project_slack_*` tools; the tools infer the current channel from trusted session context.

Project context may also include channels already connected to the current project:

```xml
<bound_slack_channels>
<channel_context id="C0123456789" name="falcon-launch" />
<channel_context id="C0987654321" name="falcon-feedback" />
</bound_slack_channels>
```

These are Slack channels already connected to the project. If the user refers to "the connected Slack channel", use these IDs and names to understand which channel they mean. They are contextual references, not tool arguments.

## Existing Project

Use `project_slack_connect({project_id: "<uuid>"})` or
`project_slack_disconnect({project_id: "<uuid>"})`. Always supply the target Project ID, slug or supported URL. Do not ask for Slack team/channel IDs; the tools use the current
Slack-origin session.

If the user asks for a focused wiki edit and the target is already this session's current Project, load `project-knowledge` and follow its direct main-agent edit workflow. For a thorough update or full rebuild of the current Project, enqueue it with `pplx project knowledge update` and normally report the returned run id as in progress. Poll only when terminal confirmation is necessary, using `pplx project knowledge status <run-id>` after five-minute waits as described in the parent skill. Connecting a channel does not dynamically rebind the live session: when the connected target is not the session's current Project, use the explicit-id knowledge update command instead and report it as queued; if terminal confirmation is necessary, pass that same target to `pplx project knowledge status <run-id> <project-id-or-slug>`.

## New Project, Then Connect

When the user asks to create a new project from Slack, including with the former wording "Create new Space", do this as two steps:

1. Create the project.
2. Connect the current Slack channel to the created project.

Before creating a plain project, propose the project's name, description, and emoji from the channel context for the user to confirm or modify, including instructions only when the user asks for them — don't ask them to type each field cold. For session-seeded projects, prefer generated metadata by omitting the name/description/instructions unless the user already supplied or confirmed specific values; pass only confirmed fields as overrides.

Create a plain Project with `project_create({title: "<name>", ...})`, or seed
it with the current session using `project_create_from_session({})`. Supply only
confirmed metadata overrides. Set `auto_update: true` when the user chose automatic
Brain updates. Pass the returned `uuid` to `project_slack_connect`.

Prefer the session-seeded tool when the current Slack task should become part of
the Project. Use plain creation for a Project container connected to the channel.


After the Slack connection succeeds, run the explicit-target knowledge update with an `--instruction` built from the confirmed focus area (see Project Brain Auto-Update Choice), referencing the real channel name:

```bash
pplx project knowledge update <created-project-slug-or-uuid> --instruction "<focus area confirmed with the user, referencing #<channel-name>>"
```

Pass the created project's `uuid` explicitly here. Plain creation does not rebind this session; use the explicit Project UUID for this workflow. This fallback is queued through the backend; report the successful enqueue without claiming the wiki update has completed.

If the user hasn't confirmed the automatic-update choice or focus area yet, capture those first.

## Non-Slack Sessions

If this task did not originate from Slack, do not run `project_slack_connect` or `project_slack_disconnect`. Tell the user the command must be run from the Slack channel they want to connect, or use the in-product channel picker.