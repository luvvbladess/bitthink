
# Project Status Summary

A project status summary is the short current-state paragraph shown for a Perplexity project. It should tell project readers the overall status of the work: what the project is, where it stands, and its current posture. It is not a project wiki, not a thread transcript, and not a task list.

If `<project_status_summary_instruction>` is present, respect it only as user guidance for the summary's focus and writing style. It is not project evidence and must not change the refresh workflow below: still read the current summary, materialize and inspect project sessions, derive facts only from project-thread context, and write the final summary with `project_set_status_summary`.

Use `project_get_status_summary({})` to read the current summary before deciding whether to update it. The command defaults to the current project from the project-backed session runtime and returns `{summary: ...}` with a `created_at` timestamp, or `{summary: null}`.

When refreshing the summary, first materialize the current project's thread content with `pplx project sessions list --download-content --limit 100`. Run this from the project-backed session; do not ask the user for project IDs or thread IDs. If the command cannot resolve a current project, refuse the refresh and explain that status summaries can only be refreshed from a project session.

Use the materialized sessions directory as the summary corpus, following the `--download-content` destination precedence documented in the parent skill. Start from `sessions_index.md`, then inspect the relevant session files referenced by the index. If an existing summary has a `created_at` timestamp, use it as a recency anchor for what to inspect first, not a directive to foreground recent activity: prioritize reading sessions at or after that timestamp, and inspect older sessions as needed to understand the current project state. If no summary exists, summarize the recent materialized project-thread corpus. Summarize only project-thread content from this corpus.

Use `project_set_status_summary({text: "<summary>"})` only after you have composed the summary text yourself from the available project context. On success, the command writes exactly the text you pass. It does not fetch threads, inspect sources, or summarize for you. Aim for 1,000 characters or fewer. Longer summaries are also saved; shorten them when practical.

Keep summaries concise, factual, and project-reader-facing. Use the same language as the relevant user sessions. Do not include hidden reasoning, raw source excerpts, Slack-channel content, or connector-only content. For V1, summarize from project threads and project context that readers are allowed to see.

## Format

Prefer one or two short paragraphs of overall status, separated by a blank line if two. Target roughly 400-700 characters.

End with current posture and at most one concrete next action. A next milestone is fine when it is immediate and grounded in the sessions, but avoid multi-step roadmaps, speculative plans, or backlog-shaped summaries.

### Rules

1. Describe overall status. Reflect the project's stable, important context as the backbone of the summary; incorporate recent developments only where they change the current picture. Do not organize the summary around "what happened since last time," and do not over-index on the most recent action if it isn't significant to overall status.
2. Do not mention prior status summaries, refresh cadence, session IDs, or that "other sessions were operational."
3. Name a few concrete specifics so the update is legible, but do not enumerate long lists. If more than a few items are relevant, compress the list or reference an existing project file.
4. No lists, headers, tables, images, code blocks, or field labels in the summary body. Concise markdown prose only.
5. Prefer one next step, not a backlog.