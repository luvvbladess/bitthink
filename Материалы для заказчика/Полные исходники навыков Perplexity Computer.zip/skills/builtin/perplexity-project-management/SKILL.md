# Perplexity Project Management

Use the `pplx project files` and `pplx project knowledge` CLI families inside the
`bash` tool with `api_credentials=["pplx-sdk"]` for repository workflows. Users
may refer to Projects by the former name "Space".

Use the `project_*` tools for Project metadata.
Discover and invoke the deferred `project_*` tools.
They use the
session's authenticated identity and need no sandbox credential. Pass the returned
Project ID or slug as `project_id`; omit it for the current Project. Pin, join, Slack and session attachment also accept the supported Project URL forms. Resolve names with
`project_list({search: "..."})` and stop to disambiguate multiple matches. Do not
invent IDs. Never put search text in a URL.

## Read Projects

- `project_list({search?, limit?, offset?, main?, pinned?, invited?, org_shared?})`
  returns `sections`, each with `items`, `total_count`, and `next_cursor`. With no
  section selected it returns main and pinned; any selected flag limits the
  sections. Surface pinned Projects prominently. The default limit is 50 per
  section; offset applies only to main. A Project appears in one section. Do not
  sum counts across sections because their counts overlap. `next_cursor` signals
  more results but is not an input cursor; offer to show more instead of enumerating
  every Project. Link using returned `url` values.
- `project_get({project_id?, with_sessions?, with_contributors?})` reads metadata,
  instructions, skills and connectors. With no Project ID it reads the current Project from session context.
- `project_members_list({project_id?})` reads the owner and contributors. Check
  existing access before inviting people.
- `project_get_status_summary({project_id?})` returns `{summary: ...}` with text,
  creation time and author session, or `{summary: null}`.
- `project_sessions_list({project_id?, limit?, offset?, filter_by_user?, search?})`
  returns `{sessions: [...]}`. The default page size is 20 and maximum is 100.
  Search matches title/content across your own and shared readable sessions;
  `filter_by_user: true` limits it to your own.

Discover and invoke the deferred `skill_*` tools. Use
`skill_list({scope: "project", scope_id: "<project-uuid>"})` for Project Skills,
using the exact UUID returned by the Project tools.

For copying an existing Skill, follow [save-existing-skill/GUIDE.md](save-existing-skill/GUIDE.md).
That private workflow intentionally keeps CLI listing and `skill-download` in one
Bash invocation so the signed `file_url` stays a runtime variable and never enters
model context or tool arguments.

## Create and edit Projects

- `project_create({title, description?, emoji?, instructions?, access?, auto_update?})`
  creates one Project. Access defaults to private. Emoji accepts literal emoji or
  unified hex. `auto_update: true` enables automatic Project Brain updates.
- `project_create_from_session({session_id?, title?, description?, emoji?, instructions?, access?, auto_update?})`
  creates a Project seeded with the current session unless `session_id` is supplied.
  Omitted title, description and instructions are generated from that session;
  explicit values override generated fields.

- `project_edit({project_id?, title?, description?, emoji?, instructions?, auto_update?})`
  changes only supplied fields. Empty strings clear text; `auto_update: false`
  disables automatic Brain updates.
- Set instructions only when the user explicitly asks for them.

Creation returns the Project UUID and URL and renders a Project card. Create at
most once: if a later step fails, keep using the returned Project. An unknown
creation outcome requires inspecting `project_list` before retrying.

## Members and sessions

- `project_pin({project_id?})` pins an accessible Project for the current user.
- `project_join({project_id?})` persists the current user's inherited reader or
  writer access. Both are idempotent and do not change anyone else's access.
- `project_members_invite({project_id?, emails})` invites writers by email. Compose the list from the user's
  request. Invitees accept in-product; do not accept on their behalf. Report each
  `invited` entry's status and error code, including partial failures. Do not silently
  retry. There is no role selection, member removal or organization management.
- `project_sessions_add({project_id?, session_id?, urls?})` links a session. Both IDs
  default to current context. Use this when it is not in a different Project.
- `project_sessions_swap({project_id?, session_id?, urls?})` moves a session and removes
  its former Project memberships. Use it for an authorized move or after an add
  reports `THREAD_IN_ANOTHER_SPACE`.

Supply at least one Project/session reference when adding or moving. References may
be IDs, slugs or supported `/projects/`, `/spaces/`, `/computer/tasks/` and `/search/`
URLs. Duplicate references for the same side are rejected. Omitted sides use current
session context. These tools return the backend result; they do not refresh the
live session's Project context. Project-scoped resources may appear on the next
user message, as with the CLI workflow.

Session content materialization stays in Bash:
`pplx project sessions list [project-id-or-slug] --download-content --limit <n> --offset <n>`.
It downloads the listed page's readable conversations, indexes and assets. The
usual destination is `projects/<project-id-or-slug>/sessions`; `--download-path`
overrides it. Use `project_sessions_list` for metadata-only listing.

### Preserve current-session files

After `project_create_from_session`, `project_sessions_add` or `project_sessions_swap`
attaches the current session, offer to preserve its existing files in the Project
file repo. Do not ask again if already requested. Files are not moved automatically;
repo access may appear only after the next user message. Wait for the checkout path
in user-message context, move durable files there, exclude scratch files and submit.
Do not claim persistence before submission succeeds.

## Guides

- `skills/perplexity-project-management/save-existing-skill/GUIDE.md` — read when
  copying a persisted remote Skill into a Project, not for marketplace-only work.
- `skills/perplexity-project-management/slack-channel/GUIDE.md` — read for connecting
  or disconnecting the current Slack channel, including creating a Project for it.
- `skills/perplexity-project-management/project-status-summary/GUIDE.md` — read for
  composing, reading or refreshing a Project's short status summary.

## Project Repo

Sessions include a collaborative project file repo, the only storage that survives the session. When its checkout path appears in user-message context, run `pplx project files sync` before using it.

Manage it with the `pplx project files` CLI inside the `bash` tool.

- `pplx project files sync` creates or refreshes the local checkout at the path from user-message context. Read its output summary: it tells you whether every file is materialized or how many files are still LFS pointers.
- `pplx project files hydrate-lfs <path>...` materializes the real source bytes for specific Git LFS paths (see "Reading files" below).
- `pplx project files submit -m "<message>"` persists your changes for future sessions.

`sync`, `hydrate-lfs`, and `submit` share one sandbox-local checkout lock. A "workspace lock held" response means another operation is preparing files, not a repository failure or another user's lock. Wait briefly and retry once at most; if it is still locked, stop Project Files commands for the turn, use sufficient existing artifacts, or tell the user the checkout is not ready. Never chain sleeps or retries.

These verbs are the only way to move files between the checkout and the repo. Read-only git is fine for inspecting the checkout (`git status`, `git diff`, `git log`, `git show`, `git grep`); never run git commands that modify it (no `clone`, `pull`, `push`, `commit`, `add`, `mv`, `checkout`, `reset`) — change files with ordinary file tools and persist with submit. `sync` refuses to run while you have unsubmitted changes; submit or discard them first. `submit` rejects files over 100 MiB. If `submit` keeps failing with a conflict (HTTP 409) after a retry, copy your changed files to a temporary location outside the checkout, delete the checkout, re-run `sync`, re-apply your changes, and submit again.

Do your file work inside the checkout: match the repo's existing structure and the project's instructions (explore first), or create sensible folders if it is empty. Freeform scratch work inside the checkout is fine, but `submit` persists every change in the checkout — before submitting, delete intermediate files that are not worth keeping for future sessions. Submit at meaningful milestones rather than on every small change.

Submitting persists files for future sessions; it does not show them to the user. Before calling `share_file` for a local file, make the final file durable: if it is outside the checkout, move or copy only the final deliverable into the appropriate checkout path, remove intermediate files that should not persist, and run `pplx project files submit`. Then use `share_file` on the submitted checkout path for anything the user should see in the conversation. Re-share an updated file under the same `share_file` `name` to chain versions.

### Reading files

After `sync`, some paths hold real content while large or binary files may still be Git LFS **pointer stubs** — small text placeholders, not the source bytes. Work manifest-first and pointer-aware:

- **Prefer parsed artifacts.** Check `.pplx/project-files/parse/v1/manifest.json` for an entry before pulling source bytes. For a PDF, the parsed text is usually all you need — you rarely have to hydrate the PDF itself.
- **Recognize pointers on every read.** A file is an unhydrated LFS pointer when its first line is exactly `version https://git-lfs.github.com/spec/v1`. This can happen for large `.txt`/`.csv`/`.json`/`.md` files too, so a read that "succeeds" can still hand you a pointer instead of content. A missing manifest entry for a non-PDF file means "hydrate it if you need the source bytes," not "the file is empty."
- **Triage cost for free.** The pointer's `size` line plus the filename/extension tell you how big the real bytes are before you pull anything.
- **Hydrate only what you need, batched.** Collect every path you actually need and run `pplx project files hydrate-lfs <path>...` once for all of them, then re-read. Don't hydrate files you won't open, and don't try to bulk-materialize the whole checkout.
- **Retry once after a pointer read or a loud format-loader failure:** hydrate the path, then read it again.
- **Workspace lock means work is already in progress.** Never chain sleeps or retries. After at most one brief wait and retry, stop attempting Project Files commands for that turn and let the existing sandbox operation finish.
- **Stale-object recovery.** If `hydrate-lfs` fails because an LFS object is missing or stale, run `pplx project files sync`, then retry `hydrate-lfs`. In a batched call, one dead path no longer takes the healthy paths down with it: healthy paths still materialize, and the non-zero error names exactly which requested path(s) remain pointers. Read the materialized paths normally; only sync-and-retry the named dead ones. A zero exit still guarantees every requested path holds real bytes.

## Project Knowledge

The project knowledge repo (the project wiki) is an agent-maintained knowledge base for durable project context and status. Read it from its own checkout path from user-message context.

- `pplx project knowledge sync` creates or refreshes the local knowledge checkout (idempotent; run it before reading).

`sync`/`submit` follow the same rules as the file repo: read-only git only inside the checkout (change files with ordinary file tools; never `git commit`/`push`/`pull`/`reset`), `sync` refuses to run with unsubmitted changes, and a conflicting `submit` (HTTP 409) means sync and re-apply. The knowledge repo does not use Git LFS, so `submit` rejects files 3 MiB or larger — keep knowledge content small and textual.

For a focused edit or correction in the current Project, load `project-knowledge` and follow its direct main-agent workflow: sync, baseline validation, the smallest relevant edit, read-only diff review, and validated submit. Keep this work narrow; do not turn it into a refresh, connector sweep, session-wide extraction, unrelated cleanup, or an edit to a different Project.

For a thorough update or complete rebuild of the current Project memory, run `pplx project knowledge update --instruction "<requested scope>"` with `api_credentials=["pplx-sdk"]`. This enqueues the detached Project wiki root and returns its `run_id`; if a run is already active, it returns that run's id instead of starting a duplicate. Normally, report that the update is in progress and include the run id; do not poll immediately. Only when terminal confirmation is necessary, load `automations` and create a one-time automation with `--deliver source-thread` that checks `pplx project knowledge status <run-id>` in ten minutes using the same credential. Continue at ten-minute intervals as needed, with no fixed attempt limit. Report success only for post-publication `completed`; for `failed`, report the failure and run id because raw backend error text is intentionally omitted from agent tool output. Do not use `run_subagent` for this workflow.

For routine project file changes that the user has not asked to propagate immediately, let the scheduled Project wiki refresh handle normal drift.