# Overview

Use this skill to search Perplexity indexes, fetch full page content or query-dependent page excerpts from URLs, use LLM to postprocess search results and content, and orchestrate multi-step research workflows.

Access search capabilities via the pre-installed `pplx_sdk` Python library.

## How To Use

Example of simple web-search call:

```python
bash(
    user_description="Searching for Python release notes",
    command="python -m pplx_sdk.exec << 'PY'\nsave_and_print(pplx_sdk.search.web('python release notes'))\nPY",
)
```

`pplx_sdk.exec` is a lightweight helper for small snippets; it runs cells with `pplx_sdk` and `save_and_print` already bound. Call them bare; do not add `import pplx_sdk` or `from pplx_sdk.exec import save_and_print` in exec cells. Saved `.py` scripts are ordinary Python and still need `import pplx_sdk` (see `patterns/multi-step.md`).

## One-Off SDK Calls

Use `pplx_sdk.exec` for small search/fetch snippets that fit in one `bash()` call:

- **Web search** - `save_and_print(pplx_sdk.search.web("query"))`
- **Web search variants** - `save_and_print(pplx_sdk.search.web(["query variant one", "query variant two"]))` — a list is *one* request returning a single merged `list[WebHit]`; the result size scales with the number of variants (~10 per variant). A list is only for **reformulations of one query, capped at 5** — not a batch tool. To look up several *different* queries or entities, use `web_many([...], limit_per_query=...)` (one independent search each — always read `patterns/fanout.md` before calling it), not one long `web([...])`.
- **Domain filter** - `save_and_print(pplx_sdk.search.web("query", domains=["github.com", "stackoverflow.com"]))`
- **Exclude domains** - `save_and_print(pplx_sdk.search.web("query", excluded_domains=["pinterest.com", "quora.com"]))`
- **Academic / images / videos / shopping** - same shape as `save_and_print(pplx_sdk.search.academic("query"))`; replace `academic` with the needed index.
- **People search** - always read `recipes/people-research.md` for instructions on single person lookups or broad people searches.
- **Companies search** - always read `recipes/company-research.md` for instructions on named-company lookups or broad company searches.
- **Local / places search** - `save_and_print(pplx_sdk.search.local("best hotels in Punta Cana"))` for restaurants, hotels, shops, and other physical places — always read `recipes/local-places.md` before answering from local results: hits are a seed set to blend with web breadth, and their metadata needs verification before it enters the answer.
- **Patent-record search and analysis** - always read `recipes/patents-research.md` when the task requires finding or analyzing patent records, including the patent-record work needed for prior-art/patentability/invalidity, FTO, landscape, or pre-AIA interference research. Do not read it for general procedural or legal explanations that do not require patent records. The recipe covers filters, sparse metadata, legal-status verification, full-text fetches, and results presentation.

- **Fetch URL content** - `save_and_print(pplx_sdk.content.fetch(["https://example.com"], cache_enabled=False))`. Fetches the full content of an HTTP/HTTPS URL — use it to actually read web pages, docs, articles, or any public URL. Only `http://`/`https://` are supported; do NOT pass local/internal paths (e.g. `people/*.csv`, `notion://`) or private S3 URLs. Results are cached; retry with `cache_enabled=False` if cached content looks stale. This is the way to read a source in full — `search.*` only returns search-result excerpts.
- **Save an image to workspace** - `save_and_print(pplx_sdk.content.fetch_image("https://example.com/image.png", output="/home/user/workspace/image.png"))`. Use the image asset URL from `search.images`, not its source-page URL. The gateway verifies the response is an image before writing it; include the appropriate extension in the absolute output path.
- **Snippets from URL** - `save_and_print(pplx_sdk.content.snippets(query="query", urls=["https://example.com"]))`

Best practices for SDK web search:
- For web search, use `pplx_sdk.search.web(...)`. Pass a string for one query, or **at most 5** strings that are **reformulations of that same query**. For several *different* queries or entities (or more than 5), use `pplx_sdk.search.web_many(...)` instead — one independent search per query. It returns a plain `list[FanoutResult[list[WebHit]]]`, one envelope per query in input order (the returned list has no `.results` or other attributes); on each envelope check `.ok`, then unwrap `.result` to get that query's hits.
- For multi-entity questions, break them into separate, single-entity queries:
  - Preferred: `"Brand A protein powder review"`, `"Brand B protein powder review"`
  - Not recommended: `"Brand A vs Brand B protein powder review"`
- For simple queries, keep each query straightforward and focused:
  - Preferred: `"inflation rate Canada"`
  - Not recommended: `"What is the inflation rate in Canada?"`
- For time-sensitive questions, include the explicit date in the query text (e.g. `"CPI report March 2026"`).

Each query should be short (usually 2–5 meaningful words) and cover a single topic. Do not use quote marks, exact-phrase syntax, `site:`, or boolean `OR` / `AND`; use SDK args such as `domains` and `excluded_domains` instead. The search engine performs fuzzy matching, and exact matches can over-constrain results. Make sure all provided examples and generated queries follow this guideline.

**Reading sources: search finds URLs, `content.fetch` reads them.** `search.web` / `web_many` return query-relevant excerpts; to read, quote, verify, or extract a source's actual content, fetch the page. `pplx_sdk.content.fetch([url1, url2, ...])` takes a **list** and fetches them in one fan-out call, so reading several results costs a single call. When verifying a candidate answer or cross-checking several hits, one batched `content.fetch` call covers all their URLs at once. Fetch and use the content in the **same** exec cell or script: iterate the returned list and read each record's `content` directly, rather than saving to a file and reopening it in a later `bash()` call. After a fan-out search, read before you compile: search-result text helps rank sources but rarely contains the full list or the details being collected — pass the top hit URLs from each query into `fetch_many` (always read `patterns/fanout.md` before calling it) and work from each page's `content`.

Avoid these `pplx_sdk` footguns — each fails with a full traceback rather than a graceful error:
- **`[401] PPLX_SDK_API_KEY is not set`** means session credential provisioning failed — report the authentication failure.
- **`content.fetch(...)` returns a `list` of records** `{url, content?, error?, is_paywall, ...}`: iterate it and read `r.content` (check `r.error` on failure). There is no top-level `.url` on the fan-out result itself.
- **Don't reopen an auto-saved results file by path in a later cell.** A `.../.pplx/search/*.json` path from one call won't exist for another and raises `FileNotFoundError` — keep the returned value in the same script instead.
- **`pplx_sdk.llm.extract(...)` requires an `output_schema`** argument.

Keep one-off snippets to a single SDK expression wrapped in `save_and_print(...)`. Do not add imports, loops, manual JSON printing, or post-processing logic. If you need intermediate variables, joins, filtering, retries, or multiple SDK calls, write a saved Python script and use `patterns/multi-step.md`.

`save_and_print(...)` saves the full JSON response to an auto-generated file path and prints a JSON stdout object with `saved_to`. It writes under `$PPLX_OUTPUT_DIR`, then `$RD`, then the current directory. Never suppress stderr in `bash()` calls; do not redirect `2>/dev/null`, because it hides SDK/auth/fetch errors. Always quote every URL passed inside shell snippets.

One-off result shapes:

- Search methods (`web`, `academic`, ...) return lists of typed hit records (`WebHit`, `AcademicHit`, etc.); their `_many` twins return a plain `list[FanoutResult]` (one envelope per input, in input order) instead — always read `patterns/fanout.md` for the envelope contract before using any `_many` helper. Typed hit records support attribute access for field reads (`hit.url`, `hit.title`), `dict(hit)` for JSON-serializable rows, and a small mapping-compatible surface such as `{**hit}`, `hit["url"]`, and `hit.keys()`.
- `pplx_sdk.search.web(...)` → `list[WebHit]`; each hit has attributes `{url, title, domain, snippet, date?}`.
- `pplx_sdk.search.academic(...)` → `list[AcademicHit]`; each hit has attributes `{url, title, abstract?, doi?, authors?, published_date?}`. Use `abstract`, not `summary` or `content`.
- `pplx_sdk.search.images(...)` → `list[ImageHit]`; each hit has attributes `{url, title, thumbnail_url, width?, height?, source?}`. There is no text-summary field.
- `pplx_sdk.search.shopping(...)` → `list[ShoppingHit]`; each hit has attributes `{title, vendor, url, rating?, reviews_count?, images, offers, vendor_info?, attributes?, reviews?, options?}`. There is no text-summary field.
- `pplx_sdk.search.videos(...)` → `list[VideoHit]`; each hit has attributes `{url, title, snippet, source?, channel?, duration?}`.
- `pplx_sdk.search.companies(...)` → `list[CompanyHit]`; each hit has attributes `{url?, title?, snippet?, employee_count?, founded_year?, external_ids?}`. Every field is optional — guard reads on sparse hits. `title` is the company name; `url` is the company website.
- `pplx_sdk.search.local(...)` → `list[LocalPlaceHit]`; each hit has attributes `{title?, url?, url_source?, summary?, address?, phone?, coordinates?, rating?, reviews_count?, price_range?, categories?, place_id?}`. Every field is optional — guard reads on sparse hits. `url_source` is `"website"` when `url` is the place's own site and `"maps_listing"` when it is a synthesized Google Maps link.
- `pplx_sdk.search.people(...)` → `list[PeopleHit]`; each hit has attributes `{url, title, summary?}`. Use only for actual people/professionals, not companies, products, jobs, or reviews.
- `pplx_sdk.search.patents(...)` → `list[PatentHit]`; each hit requires `{url, title}` and may include `{snippet?, publication_number?, application_number?, assignee?, authors?, classifications?, n_cited_by?, family_id?, grant_date_ts?, application_filing_date_ts?, document_publication_date_ts?, lens_id?}`. Pass `include_text=True` for optional `abstract`/`description`/`claims`/`references`/`family_members`; read `recipes/patents-research.md` before use.
- Use `pplx_sdk.content.fetch(...)` for public page content and `pplx_sdk.content.fetch_image(...)` for image assets, especially user-provided URLs. Do not write custom Python `requests` / `urllib` / BeautifulSoup / browser-fetch code, do not shell out to `curl` / `wget`, and do not call API Gateway `/sdk/content/fetch` or `/sdk/content/fetch-image` directly from generated code — the SDK methods are the supported interfaces. `content.fetch` results have `{url, title?, description?, author?, hostname?, published_date?, is_paywall, is_cached, content?, error?, raw_html?}`. Escalate page-content fetches in this order:
  1. **Default — `content.fetch(urls)`**: read `content` (cleaned page text). When you only need specific information, pass `prompt="..."` — each page's `content` is replaced by an LLM extraction for that prompt (fetch + extract in one call, e.g. `pplx_sdk.content.fetch(urls, prompt="list every advisor with affiliation")`). Pass the whole list in one call instead of looping — `content.fetch` takes up to 50 URLs; for larger pools use `content.fetch_many` (always read `patterns/fanout.md` before calling it).
  2. **If the cleaned text is missing what you need** — specific tags, tables, embedded JSON/scripts, or page metadata — refetch with `return_html=True` and read `raw_html` (the unprocessed HTML source), e.g. `pplx_sdk.content.fetch(urls, return_html=True)`.
  3. **Only if the SDK fetch itself fails** (`error` is set): fall back to the browser, a source-specific tool, or your own fetching code as a last resort.
- `pplx_sdk.content.snippets(...)` results have `{url, text?, tokens_count?, error?}`; use `text`, not `content` or `summary`.

## Routing

### SDK Reference

- **Choose an index** - `pplx` provides the main `web` index plus specialized indexes such as `people`, `companies`, and `local`; see `reference/search.md` for the full list and details on how to use them.
- **Fetch content for URLs** - `content` provides full page fetches, query-focused snippets, and structured profile enrichment; see `reference/content.md` for details and examples.
- **Use LLM to postprocess results** - `llm` provides a flexible interface to run LLM extraction and transformation on search results and content; see `reference/llm.md` for details and examples.
- **Access low-level async API** - use `reference/async.md` for asynchronous version of the SDK & examples.
- **Search GitHub directly** - to find repos, code, issues, PRs, users, or commits _on GitHub_, use the `gh` CLI / GitHub REST search API via `bash` with `api_credentials=["github"]`; see `reference/github.md`. For general web results that happen to include GitHub pages, prefer `pplx_sdk.search.web(..., domains=["github.com"])`.

### Common Patterns

- **Send parallel independent requests** - always read `patterns/fanout.md` before running multiple search queries, URL fetches, or LLM extraction calls.
- **Build a multi-step pipeline** - use `patterns/multi-step.md` for JSONL artifacts and script discipline.
- **Long-running tasks** - use `patterns/checkpoint.md` when any step risks exceeding the `bash()` window or should persist intermediate results for debugging or reuse.

## Recipes

This skill includes recipes for specialized workflows:

- **People research** - Find people matching criteria for sourcing, alumni, experts, investors/partners, or named-person checks; see `recipes/people-research.md`.
- **Company research** - Find companies matching criteria for market mapping, competitor scans, or prospect lists, and verify named companies; see `recipes/company-research.md`.
- **Patent research** - Find, verify, fetch, extract, and cite patents by topic, assignee, inventor, number, jurisdiction, classification, or date; support prior-art, patentability, invalidity, FTO, landscape, and applicable pre-AIA interference research without overstating legal status; see `recipes/patents-research.md`.
