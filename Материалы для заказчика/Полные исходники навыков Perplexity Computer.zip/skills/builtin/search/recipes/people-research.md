# People research

End-to-end recipe for finding people meeting a set of criteria — hiring sourcing, alumni discovery, expert finding, investor / partner mapping, named-person verification. Composes `pplx_sdk.search.people` with the auxiliary content methods to get from a broad query to a precise, enriched list.

## Named person lookup (no pipeline)

When the task names a specific person — their profile, accounts, contact info, or employment/education facts ("what is the Twitter/Facebook/GitHub account of X?", "where does/did X work?") — skip the multi-variant pipeline:

1. Run `pplx_sdk.search.people("Jane Doe Acme Corp", limit=10)` and a concise `pplx_sdk.search.web(...)` query in parallel. When the task *supplies* an identifier (an email address or a GitHub/Twitter/Facebook handle), lead with `pplx_sdk.search.people("Jane Doe", external_id="github:janedoe")` — it exact-matches the one right profile with no disambiguation step. The identifier alone determines the match (the query string only affects ranking and cannot suppress the hit); the type prefix is case-insensitive and a leading `@` on a handle is stripped. If it returns 0 hits the identifier just isn't indexed (coverage is partial); continue with the name query, don't conclude the person doesn't exist.
2. Pick the hits that match the person — check name, company, and location; common names collide. If multiple plausible profiles return, disambiguate with `company` / `location` / `education` / `skills` filters, or web-search a canonical profile URL first.
3. Always run `pplx_sdk.content.fetch_people([...])` on the matching profile URL(s); see `reference/content.md` for the result shape.
4. Weigh all sources when answering — the structured fields (companies, education, `emails`, `github`, `twitter`, `facebook`), hit summaries, and web results. For account handles and emails the structured linkage fields are usually more reliable than inferring from the person's name. If the deliverable needs more than these facts, skip straight to dossier.

## Tool selection

The People index (`pplx_sdk.search.people`, see `reference/search.md`) is strongest on intersection queries (`company × role`, `role × company × location`). Supplement with `pplx_sdk.search.web` when:

- The query targets a specific org's team / about / partners page (VC partner lists, lab group pages, C-suite rosters).
- Criteria need temporal awareness ("currently at X", "left Y in 2024").
- The domain is niche academic (specific lab, conference community, thesis topic).
- `search.people` returns many results but few true matches after filtering.

For comprehensive searches, run both in parallel and merge.

## Variation axes

A single `search.people` query misses relevant people; run 3+ parallel variants (fan out via `patterns/fanout.md`) across:

- **Role titles + acronyms** — `PM` / `product manager` / `product lead`.
- **Company name forms** — acronym / full name / common abbreviations.
- **Industry terms** — acronym / expansion.
- **Scope slicing** — team, geography, seniority.

Skip the acronym/expansion pairing only when the company is best known by its acronym.

**Vary the role axis, not just company and location.** Fanning out only over place names (`"Acme London"`, `"Acme Manchester"`, …) with a fixed role searches one slice many times and misses differently-titled people. Move role/seniority terms across variants too. Worked example — engineers at Acme in Serbia:

```python
# Lead with plain-text variants that vary ROLE; add filtered variants as supplements.
variants = [
    {"query": "Acme software engineer Serbia"},          # role + company + location
    {"query": "Acme backend developer Belgrade"},        # role synonym + city
    {"query": "Acme infrastructure engineer Beograd"},   # role variant + local spelling
    {"query": "Acme engineering manager Serbia"},        # seniority slice
    {"query": "software engineer", "company": "Acme", "location": "Serbia"},    # filtered supplement
    {"query": "backend engineer", "company": "Acme", "location": "Belgrade"},
]
hits = pplx_sdk.search.people_many(variants, limit_per_query=50)
```

- Role terms move across variants (`software engineer` → `backend developer` → `infrastructure engineer` → `engineering manager`).
- Local spellings appear (`Belgrade` / `Beograd`).
- Filters (`company`, `location`) supplement plain-text queries — never replace them.
- Geography goes through `location`; there is no `country` filter.
- Keep each query to ~5–7 meaningful tokens. At 8+ the index can't match all terms — split into shorter queries.

## Field filters: supplement, not replacement

Filter kwargs scope results to people whose profile fields contain all provided tokens. Each filter is whitespace-tokenized and ANDed as `contains` clauses — `company="Google Maps"` requires both `"Google"` and `"Maps"`, not the literal phrase.

| Kwarg | Matches against |
|---|---|
| `name` | full name |
| `company` | current **OR** previous companies |
| `skills` | skills |
| `location` | profile location field — use for all geography (city, region, **or** country); there is no separate `country` filter |
| `education` | finished **OR** ongoing education institutions |
| `external_id` | linked identifiers — **exact match**, not tokenized: `<type>:<value>`, type ∈ `email`/`github`/`twitter`/`facebook` |

- `company` and `education` span current/previous and finished/ongoing, so a match does **not** imply a *current* job or *completed* degree — confirm current-vs-former / completion at the filter step against the enriched fields, not the filter alone.
- **Filters scope; the ranker handles fuzzy match.** Use them as extra fan-out variants *alongside* plain-text queries, not instead — filters hit a narrower slice and miss profiles plain-text finds.
- **Add a filter** for structural criteria (company, location, alumni status) when the plain-text query alone is too noisy.
- **Keep it in the query** for semantic criteria ("senior", "fintech", "AI safety") — the ranker matches what the filter index can't.
- Fan filtered variants alongside the plain-text query; dedup by URL after merge.
- **`external_id` is the exception to all of the above**: it's a deterministic single-person lookup (see Named person lookup), not a fan-out scoping filter. Use it when the task hands you an identifier; don't guess identifiers to fan out over.

## Pipeline

**Mandatory multi-step pipeline, not a single `search.people` call.** Always run search → dedup → **enrich → filter** before any deliverable; never present raw `search.people` hits (or an un-enriched, un-filtered list) — they are keyword matches, not vetted candidates. Only step 4 (dossier) is conditional.

Write each step as a script under `$RD/scripts/` (see `patterns/multi-step.md` → Script Discipline). **Before writing each script, read the file it points to — don't improvise SDK calls from memory** (skipping the read is what drops the enrich and filter steps):

- Step 1 → `patterns/fanout.md` (`search.people_many`) + `reference/search.md` (filter kwargs).
- Step 2 → `reference/content.md` (`content.fetch_people` fields).
- Step 3 → `patterns/checkpoint.md` (resumable **LLM** filter — **mandatory**; decision is the LLM's, never a substring test) + `reference/llm.md`.
- Step 4 → `reference/content.md` + `reference/llm.md`.

**1. Search + dedup** (`01_search.py`) — `search.people_many` over the variants above.

- Scale breadth: 3–5 variants for moderate searches, up to 10 for broad sweeps.
- `limit_per_query=50` — the default of 10 under-fetches and costs recall; raise to 100 for exploratory / critical sweeps (100 = max). Don't lower it to cut noise — the filter handles that.
- Dedup merged hits by URL, keeping the longest summary (`patterns/multi-step.md` → Dedup). Output: `$RD/deduped.jsonl`.
- **Every variant — the initial fan-out and any added later — merges into this one `deduped.jsonl` and flows through enrich + filter as one batch.** No query's hits skip enrichment or the filter; never append later-query results straight to the deliverable.

**2. Enrich** (`02_enrich.py`) — `pplx_sdk.content.fetch_people` in chunks of 50 over all deduped URLs. No LLM cost. Output: `$RD/enriched.jsonl`.

- Each row keeps its search fields **plus** `full_name`, `current_companies`, `previous_companies`, `education_ongoing`, `education_finished`, `skills`, and when present `github` (`{url, username, contributions_count}`) and `emails` (`[{email, order_of_priority}]`, real professional addresses).
- Rows where fetch returned `error: "not found"` keep just the search fields.
- **Not optional** — the filter and deliverable depend on these fielded values; they let the filter exclude against company history / education instead of the free-text summary alone.

**3. Filter** (`03_filter.py`) — resumable filter from `patterns/checkpoint.md` over `$RD/enriched.jsonl`.

- **The match decision MUST be an LLM classifier** — `pplx_sdk.llm.extract` (or `classify`) with a natural-language instruction + output schema per enriched row, batched through `Checkpoint`.
- **Never decide matches with deterministic Python** — no substring/`in` tests (`"perplexity" in current_companies`), hardcoded company/school allow-lists, or `==` on fields. String matching is brittle: it silently drops profiles whose field is empty, truncated, or phrased differently (`"Perplexity AI"` vs `"Perplexity"`, `"MIT"` vs `"Massachusetts Institute of Technology"`), tanking recall.
- Deterministic checks are allowed *only* as a cheap **prefilter to shrink the LLM batch** (e.g. drop rows with no companies at all), never as the decision.
- Anchor the instruction on `summary` **and** the enrichment fields that sharpen the call (`current_companies`, `education_finished`, …). Phrase exclusions ("drop if not X").
- Flatten `Checkpoint.read_all()` into `$RD/matches.jsonl` (matched rows + classifier output) and `$RD/errors.jsonl` for step 4. Re-running after a `bash()` timeout is safe — `Checkpoint` skips done batches.
- **Not optional**: `search.people` returns many loose matches, and a deterministic filter both leaves noise *and* drops true matches whose fields don't string-match. Let the LLM read `summary` + enrichment and decide.

**4. Dossier** (`04_dossier.py`, conditional) — only when the deliverable needs **publications, bio, exact tenure dates**, or any field outside `fetch_people`'s fixed set.

- Load `$RD/matches.jsonl`, `pplx_sdk.content.fetch_many` the URLs, then `pplx_sdk.llm.extract_many` against a richer schema (use `patterns/checkpoint.md` framing for large pools — see `reference/llm.md` → Larger Pools). Output: `$RD/dossiers.jsonl`.
- On a login wall / empty content, fall back to `pplx_sdk.search.people("<name> <company> <field>")` or a browser subagent if available. **Don't fill dossier fields from the search summary** — the model emits `"unknown"` and it ships.

Build the deliverable from `dossiers.jsonl` when step 4 ran, otherwise from `matches.jsonl`.

## Combined search (web → fetch → people)

When the target org has a public team / about / partners page that lists names directly:

1. `pplx_sdk.search.web("{company} {role} team", domains=["{company-domain}"])` — find team pages, directories, press releases.
2. `pplx_sdk.content.fetch_many(urls)` — read pages; extract names from `content` (often `pplx_sdk.llm.extract` with a `{names: [...]}` schema).
3. `pplx_sdk.search.people("{name} {company}", limit=10)` — enrich each named candidate.

Also useful when `search.people` alone has poor recall (very senior execs, public figures, niche academic).

## Deliverable conventions

- **Hyperlink the profile URL on the person's name** — never deliver names as bare text, in a separate "LinkedIn" column, or as a trailing URL. The name *is* the link: `- [Jane Doe](https://www.linkedin.com/in/janedoe) — Senior PM, Acme (London)`. Applies to prose, tables (link the name cell, drop any standalone URL column), and markdown deliverables. For CSV, keep a `linkedin_url` column since markdown doesn't render.
- **Propagate GitHub links and professional emails — don't drop them.** `fetch_people` returns `github.url` and `emails` on the enriched rows; carry them into the final answer rather than leaving them on disk. Append the GitHub link after the profile (`… · [GitHub](https://github.com/janedoe) — …`) and show the top email (lowest `order_of_priority`) when present. For CSV, add `github_url` and `email` columns. Copy both verbatim from pipeline output.
- **Never invent URLs — copy them verbatim from pipeline output.** Slugs that look predictable are usually arbitrary; a guessed URL ships a 404. Read URLs back from disk before composing the summary.

## Gotchas

- **Never fabricate email addresses from patterns.** `firstname.lastname@company.com` guesses are unverified and have reached deliverables in past audits. Use the real addresses `fetch_people` returns in `emails`; if those are empty, resolve via `pplx_sdk.content.snippets` on the profile URL, or deliver the profile URL only and label every row `email_verified: false`.
- **Names are often truncated** ("First L" instead of full name). Resolve via `pplx_sdk.content.snippets` on the profile URL — `snippets` returns focused extracts that often include the full name even when the search summary doesn't.
- **Don't treat `education_finished` / `previous_companies` as the canonical lists.** `fetch_people` splits schools and jobs by whether the LinkedIn entry has a `date_to`, not by whether the person actually graduated or left. A graduate with blank dates lands in `education_ongoing`; reading only `education_finished` silently drops them. Read both halves unless the task turns on completion or current-vs-former status.
- **Index coverage gaps.** Very senior executives, public figures, people without LinkedIn profiles, and recent job changes may be absent from the People index — fall back to `pplx_sdk.search.web` (see Combined search above).
- **`external_id` misses are common.** Identifier coverage is much sparser than profile coverage — a 0-hit `external_id` lookup says the identifier isn't indexed, not that the person or profile doesn't exist. Always follow up with a name/company query before reporting "not found".
- **High noise at `limit=100`.** Requesting 100 results returns 100 keyword-matched profiles, not 100 relevant ones. The filter step handles precision — don't tighten the search query to compensate.
