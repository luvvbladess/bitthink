# Local places research

Recipe for finding physical places and local businesses — recommendations near a location, discovery in a named city or neighborhood, and specific venue lookups — with `pplx_sdk.search.local` (see `reference/search.md` for hit fields and parameters). Query in the user's language.

## Named venue lookup

Single call with the venue name and its locality in the query text; read `address`, `rating`, `reviews_count`, `phone`, and `url` off the hit:

```python
save_and_print(pplx_sdk.search.local("Hôtel de la Monnaie Paris", limit=5))
```

Match the intended venue by `address` locality plus `categories`, not title alone — venue names collide across cities and chains. If the venue is absent from the index, fall back to `pplx_sdk.search.web` on the name plus its city.

## Area discovery

State the place type or need plus the geographic target in the query text, or pass explicit `latitude`/`longitude` (optional `zoom`) when the request centers on a point — the user's position, or a landmark you already resolved. Never drop hard constraints ("24 hour", "vegan", "wheelchair accessible", "with live music") when shortening the query — they are the request.

```python
variants = [
    {"query": "kid friendly restaurants Garden City Kansas"},
    {"query": "family restaurants", "latitude": 37.9717, "longitude": -100.8727, "zoom": 13},
]
save_and_print(pplx_sdk.search.local_many(variants, limit_per_query=10))
```

Dedup merged hits by `place_id`, falling back to (`title`, `address`). When the user's location is unknown and can't be inferred, state a reasonable assumption and answer for it (offering to adjust) instead of only asking for clarification.

## Deliver with the structured fields — and web breadth

Local hits are a seed set, not the full answer. On "best / top / things to do / list" requests, blend them with web-sourced candidates (`pplx_sdk.search.web` roundups, editorial lists) and match the breadth a good web answer would have — use `search.local` to add structured data to the list, not to shrink it. Carry each recommended hit's structured data into the answer — street `address`, `rating` with its `reviews_count`, `price_range` when relevant, and the hit `url` — and prefer hits with substantial review counts over sparsely reviewed ones. A recommendation without an address or rating is web-search output with extra steps; the structured fields are why this index exists.

## Verify before the deliverable

- Ratings and review counts are point-in-time index values and can undercount well-known venues. If a hit shows an implausibly low `reviews_count` or a missing `address` for a venue that should be established, verify those details with one `pplx_sdk.search.web` call; if a field still looks implausible after checking, omit it rather than print it — a wrong "5.0 (2 reviews)" costs more trust than no rating.
- The index does not carry opening hours, menus, or current status. When the request depends on them ("open now", "open Sunday"), confirm with a quick web check — one batched `pplx_sdk.content.snippets(query=<the constraint>, urls=[venue pages])` pass — and state what was confirmed vs. not.

## Gotchas

- Every hit field is optional — guard reads on sparse hits. `url_source` says whether `url` is the venue's own website (`"website"`) or a synthesized maps listing (`"maps_listing"`).
- Broad regional or activity queries ("best snorkeling Vietnam", "hiking near the Alps") return locality-scoped places; blend with `pplx_sdk.search.web` for region-level guides and rankings, then resolve specific venues through `search.local`.
- `country` is the caller locale, not a positioning filter — position with the query text or coordinates.
- For "similar to X" requests, resolve X first (one named lookup), then search its `categories` terms near its `coordinates`.
