# Patent research

End-to-end recipe for finding, verifying, fetching, extracting, and citing patent records, including prior-art, patentability, invalidity, freedom-to-operate (FTO), landscape, and pre-AIA interference research. Composes the `pplx_sdk.search.patents` index with `content`/`llm` helpers to get from a patent lookup to a precisely-cited answer.

## When to use

`pplx_sdk.search.patents` queries a patent index (lens.org-backed; USPTO/EPO/etc. records). Use it for patent lookup by topic, classification, assignee/company, inventor, publication or application number, jurisdiction, or filing/publication date range — and for any fact that lives in a patent (abstract, description, claims, citations, family members). Also use it as the patent-record leg of prior-art, patentability, invalidity, FTO, landscape, and applicable pre-AIA interference research; those workflows require the additional sources and checks below.

Use `pplx_sdk.search.web` or `pplx_sdk.search.academic` instead for general technology overviews, market analysis, or non-patent literature.

## The `search.patents` index

`search.patents(...)` returns `list[PatentHit]`. Only `url` and `title` are required; every other metadata field can be missing: `{snippet?, publication_number?, application_number?, assignee?, authors?, classifications?, n_cited_by?, family_id?, grant_date_ts?, application_filing_date_ts?, document_publication_date_ts?, lens_id?}`. `authors` is `list[str] | None`; date fields are Unix seconds when present. Never stringify missing values into identifiers, links, dates, counts, or table cells. Metadata-only responses (the default) are ~75% smaller than full-body; opt into the body only after picking a specific patent (see [Full body](#full-body-include_text)).

Keep queries short and topical (3–8 tokens).

```python
save_and_print(pplx_sdk.search.patents("solid state battery", limit=10))
```

Run 2–4 variants for important lookups and merge — fan out with `pplx_sdk.search.patents_many` (see `patterns/fanout.md`) rather than hand-rolling `asyncio.gather`:

```python
save_and_print(pplx_sdk.search.patents_many(
    [
        {"query": "solid state battery"},               # topical
        {"query": "lithium ion battery cathode"},        # technology variant
        {"query": "battery electrolyte separator"},      # adjacent
        {"query": "battery", "assignee": "Apple"},       # assignee-biased
    ],
    concurrency=4,
    limit_per_query=10,
))
```

`patents_many` is **sync** — never `await` it; `patterns/fanout.md` covers the `_many` mechanics and result handling. Dedup merged results with the first available stable key: `hit.publication_number or hit.lens_id or hit.url`; the required record URL is the final fallback when both optional identifiers are missing. For landscapes, use `hit.family_id or hit.publication_number or hit.lens_id or hit.url` so equivalent family members do not inflate counts and missing family IDs do not collapse unrelated records. See `patterns/multi-step.md` → Dedup.

## Filters

### Strict (results must match)

`jurisdiction` (ISO 3166-1 alpha-2: `US`, `EP`, `JP`…), `publication_number` (strict prefix), `application_number` (digits-only normalized), `classifications` (strict CPC/IPC prefix), `source`, and the date bounds `published_after`/`published_before`/`filed_after`/`filed_before` (ISO `YYYY-MM-DD`) **exclude** non-matching patents.

`include_expired=False` is the default retrieval policy. Pass `include_expired=True` when the search must include records that the index classifies as expired; this broadens retrieval but does not independently establish legal status.

```python
save_and_print(pplx_sdk.search.patents(
    "battery", limit=10,
    jurisdiction="US", classifications="H01M",
    published_after="2020-01-01", published_before="2024-12-31",
))
```

**The positional `query` is always required and must be non-empty — even for a pure number lookup.** A filter-only call (`patents(publication_number="US10000012")`) fails with `BadRequestError: [400] query is required`. For a bare number lookup, pass a **generic** query like `"patent"` and let the strict number filter match — do **not** pass the raw number as the query (it can suppress the match):

```python
save_and_print(pplx_sdk.search.patents("patent", publication_number="US10000012", limit=1))
save_and_print(pplx_sdk.search.patents("patent", application_number="17123467", limit=5))
```

Setting `publication_number` also suppresses the default US-only jurisdiction filter, so you can look up an `EP…` number directly.

### Ranking nudges (bias, do not exclude)

`assignee` and `authors` bias relevance ranking but do **not** filter — expect related companies/inventors in the results; post-filter on `hit.assignee` in Python for strict assignee matching.

```python
save_and_print(pplx_sdk.search.patents("battery", assignee="Apple", authors="John Goodenough"))
```

Request vs response shape: the `authors` **kwarg you pass in** is free-text `str` (`"Goodenough"`, `"Hinton Krizhevsky"`); the `authors` **field on each hit** is `list[str] | None` of inventors. `hit.authors.lower()` raises `AttributeError` — use `" ".join(hit.authors or []).lower()`. `assignee` is `str | None` on hits (comma-joined when a patent has multiple), so use `(hit.assignee or "").lower()` for strict post-filtering.

## Full body (`include_text`)

`include_text=True` adds `abstract`, `description`, `claims`, `references`, and `family_members`. Enable it only once you've picked the specific patent — re-run a narrowed query rather than asking for the body on a broad search:

```python
save_and_print(pplx_sdk.search.patents("battery", publication_number="US12345678B2", include_text=True, limit=1))
```

`abstract`/`description`/`claims` come back as lists of paragraph strings when present — join with `"\n\n"` before extraction. Missing fields are omitted on the wire (a patent without an abstract returns no `abstract` key, not an empty list), so use `"\n\n".join(hit.claims or [])`.

## Original document (PDF / office page)

For analysis use `include_text`, not the binary PDF — an LLM gets nothing from the PDF that the text body lacks. Reach for the source document only when the user asks for the document itself or to recover a section `include_text` omitted:

- **PDF link (when supported)** — only build the Perplexity patent proxy URL when `publication_number` is present and either `lens_id` is present or the publication number is US: `https://www.perplexity.ai/rest/file-repository/patents/{PUBLICATION_NUMBER}` (uppercase, e.g. `US11349904B2`). Append `?lens_id={lens_id}` only when `lens_id` is present; it enables non-US and family fallback, but `?lens_id=None` is invalid. Give the URL as a plain markdown link; clicking redirects the logged-in user straight to the PDF. Don't `content.fetch` this URL (it needs the user's session — you'll get an auth error) and don't download the PDF into the workspace. For a non-US hit without `lens_id`, give the record or patent-office page URL instead. If the publication number is missing, do not invent a proxy URL; give the hit's record URL instead.
- **US grant PDF, no login needed** — when the user wants a link that works outside Perplexity: `https://image-ppubs.uspto.gov/dirsearch-public/print/downloadPdf/{n}`, where `{n}` is the publication number stripped of the `US` prefix and kind suffix and zero-padded to 7 digits (`US11349904B2` → `11349904`); design patents use `D`+6 digits, plant patents `PP`+5. Some grants have no PDF there (it 404s, e.g. `US10000012`) — verify with `curl -s -o /dev/null -w '%{http_code}' <url>` in bash before handing it out. Don't `content.fetch` this URL either (USPTO rejects the fetcher — `http_code_server_error`).
- **Fallback: Google Patents page** — when `publication_number` is present, use `https://patents.google.com/patent/{publication_number}/en`, also fetchable for body text when `include_text` is missing a section: `save_and_print(pplx_sdk.content.fetch(["https://patents.google.com/patent/US11349904B2/en"]))`. The `gateway.api.lens.org/.../pdf` endpoint needs a server token you don't have — don't use it.

## Verify

Before extracting or citing, verify whichever identifying fields are present: `publication_number`/`application_number` (jurisdiction prefix matches your filter), `assignee` matches the expected company, filing/grant/publication dates are in range, and `classifications` overlap the technology area (CPC/IPC codes like `H01M10/052`). Missing metadata is unknown, not a negative match; use the record or official register to fill important gaps. Reject third-party patent-summary sites and machine-translated claims when the user wants the original.

### Indexed status versus legal status

The backing index's default `include_expired=False` policy is a retrieval filter, not proof that a returned patent is currently active, unexpired, enforceable, or safe to practice. Search hits and their dates do not establish maintenance-fee payment, adjusted term, terminal disclaimers, lapse or reinstatement, claim cancellation, ownership, or jurisdiction-specific legal effect.

For active/unexpired, infringement-risk, or FTO requests, verify the relevant family member and claims in the authoritative register for the requested jurisdiction as of the user's date. State the register and as-of date, distinguish indexed status from verified register status, and present research rather than a legal conclusion. If register verification is unavailable, say so explicitly; do not infer status from filing, publication, or grant dates.

Display hit timestamps in UTC, and only when present. In saved scripts, import `UTC` and `datetime` at the top and use `datetime.fromtimestamp(timestamp, tz=UTC).date().isoformat()`.

## Legal research workflows

These are research aids, not legal opinions. Preserve uncertainty and identify which claims, dates, jurisdictions, and sources support each statement.

### Prior art, patentability, and invalidity

1. Establish the critical date and whether the task concerns novelty, obviousness/inventive step, or another ground. Ask when the missing date would materially change the search.
2. Decompose each relevant claim into limitations; search the whole concept and distinctive limitation combinations with classification, citation, inventor, and assignee variants.
3. Search both patent records and non-patent literature with `search.web`/`search.academic`. A patent-only search is incomplete.
4. Verify priority and public-availability dates from primary records; a later publication cannot establish earlier public availability without supporting evidence.
5. Produce an evidence matrix with one row per claim limitation and columns for source, exact passage/figure/claim, verified date, and coverage. Distinguish one-source anticipation from multi-reference combinations and flag every uncovered limitation.

### Freedom to operate

1. Establish the product/process scope, jurisdiction, and as-of date. FTO is jurisdiction- and claim-specific.
2. Search relevant granted and pending family members, then inspect the actual independent claims and any dependent claims implicated by the product—not abstracts alone.
3. Map product features to claim limitations, deduplicate families, and verify ownership and legal status in authoritative registers for each relevant jurisdiction.
4. Report potentially relevant claims, contrary evidence, register status, and unresolved questions. Do not conclude that the user has freedom to operate or that no infringement risk exists; recommend qualified counsel for that determination.

### Patent landscapes

Deduplicate with `family_id or publication_number or lens_id or url`, choose a representative family member, and preserve jurisdiction/member counts separately. Normalize assignee variants before counting (case, punctuation, corporate suffixes, known renames/parents), retain the original names for auditability, and label missing assignees as unknown rather than dropping them. Report both family-level and document-level counts when they answer different questions.

### Interference

Do not treat “interference search” as a generic similarity-search synonym. US patent interference is principally a pre-AIA priority proceeding; establish the relevant filing/priority dates and whether the pre-AIA regime can apply. If the user instead means overlapping claims, competing priority, derivation, or general similar-art research, name that distinction and follow the corresponding claim-comparison or prior-art workflow.

## Extract

Don't pass full patent bodies into analysis when only a section matters — locate the section(s) in `description`/`claims`, bound the excerpt (e.g. the first 3 claims), and run `llm.extract` with an output schema; see `reference/llm.md`. Identify the record in the extraction instruction with the first available value: publication number, application number, or record URL.

## Cite

Cite the exact patent record URL (lens.org or the jurisdiction patent office) **inline**. Use the first available citation identifier: publication number, application number, Lens ID, then record URL; include the required title as the human-readable label when no optional identifier is present. Optionally append a present assignee for disambiguation. Never display `None`, `null`, or a fabricated identifier. For the patents the answer actually discusses, append a `[PDF](...)` link only when a valid proxy URL can be built from a present publication number plus either a Lens ID or US jurisdiction:

```markdown
A solid-state separator architecture is disclosed ([US12345678B2 (Apple)](https://www.lens.org/lens/patent/...), [PDF](https://www.perplexity.ai/rest/file-repository/patents/US12345678B2?lens_id=...)).
```

Keep the record URL as the citation — never swap it for the proxy URL — and don't add `[PDF]` to every row of a long hit list, only to the main patents. Don't cite intermediate search-result summaries — cite the patent record itself. For patent families, cite the representative member you actually inspected and mention the family size only when known.

## Gotchas

- `n_cited_by` is forward citations (patents that cite this one; high values signal foundational patents); `references` (body) is the reverse — patents this one cites.
- `family_id` groups the same invention across jurisdictions/continuations/divisionals; `family_members` (body) lists the publication numbers in that family.
- Treat missing `n_cited_by`, `family_id`, identifiers, classifications, and dates as unknown. Do not coerce missing citation counts to zero or missing family IDs into one shared bucket.
