# Company research

Recipe for finding companies meeting a set of criteria — market mapping, competitor scans, prospect lists, named-company verification — with `pplx_sdk.search.companies` (see `reference/search.md` for hit fields and filters).

## Named company lookup

Single call; verify identity by website domain (`url` or the `domain:` entry in `external_ids`), not by name — company names collide:

```python
save_and_print(pplx_sdk.search.companies("Sakana AI", limit=10))
```

If the company is absent from the index, fall back to `pplx_sdk.search.web` on the name plus a disambiguating term (industry or city).

## Broad search: fan out variants, with and without filters

A single query misses relevant companies. Fan out 3+ variants (see `patterns/fanout.md`) across industry terms, product vs. market phrasing, geography, and stage descriptors — and run variants both **with and without** the structured filters (`hq_country`, `sector`, `company_type`, `employee_count_*`, `founded_year_*`; see `reference/search.md`): filters scope strictly and drop companies whose indexed data is missing or mismatched, while unfiltered variants keep them reachable through the query text.

```python
variants = [
    {"query": "ai research startups japan"},                          # geography in the query text, no filter
    {"query": "ai research lab", "hq_country": ["jp"]},               # strict HQ-country filter (ISO2)
    {"query": "foundation model startups tokyo"},                     # product phrasing + city, no filter
    {"query": "ai startups", "hq_country": ["jp"],                    # broader term + stacked filters
     "sector": "technology", "founded_year_gte": 2018},
]
raw_results = pplx_sdk.search.companies_many(variants, limit_per_query=50)
```

Note `country` is the caller locale, not a result filter — HQ scoping goes through `hq_country`. Dedup the merged hits by website domain — prefer the `domain:` entry from `external_ids`, fall back to the hostname of `url`.

### Filter values

- `sector` (single value): `agriculture_food`, `business_services`, `construction_real_estate`, `education`, `energy_utilities`, `finance`, `government_nonprofit`, `healthcare`, `hospitality_travel`, `manufacturing`, `media_entertainment`, `retail_consumer`, `technology`, `transportation_logistics`. The sectors are broad — pick the closest one and put the niche in the query text ("gene therapy" → `sector="healthcare"` + query wording).
- `company_type` (single value): `private`, `public`, `nonprofit`, `government`, `education`.
- `hq_country`: ISO 3166-1 alpha-2 codes only (case-insensitive, max 10, OR) — names and regions are rejected.
- `employee_count_gte`/`_lte`, `founded_year_gte`/`_lte`: inclusive integer bounds.

## Filter results with the LLM API

Raw hits are keyword matches, not vetted companies — always run an LLM filter over the deduped hits before the deliverable. Use `pplx_sdk.llm.extract` with a natural-language instruction + output schema per hit (see `reference/llm.md`; batch via `patterns/checkpoint.md` for large pools). Anchor the instruction on `snippet` plus the structured fields (`employee_count`, `founded_year`), treating missing fields as unknown rather than failing the criterion. Never decide matches with substring tests on `title`/`snippet` — they silently drop true matches phrased differently.

## Gotchas

- Every hit field is optional — guard reads on sparse hits.
- **Filtered searches silently relax on zero matches**: when the filters match nothing, the service retries once without them and returns those results with no indicator. If filtered hits ignore your criteria, that is why — verify hits against the criteria (or the LLM filter catches them) rather than trusting the filter.
- `employee_count` / `founded_year` are point-in-time index values; the range filters and hit fields reflect the index, so when currency matters, confirm on the company site via `pplx_sdk.content.fetch` or `content.snippets`.
- For recent events (funding, launches, acquisitions) or curated lists/rankings, supplement with `pplx_sdk.search.web`; for a company's employees, use `pplx_sdk.search.people` (see `recipes/people-research.md`).
