# Search Reference

Use `pplx_sdk.search` to query Perplexity indexes. Prefer short keyword phrases, usually 3-7 meaningful tokens. Do not use boolean syntax; `AND`, `OR`, and `NOT` are treated as literal words.

Search methods return lists of typed hit records, such as `WebHit`, `AcademicHit`, `ImageHit`, `ShoppingHit`, `VideoHit`, `CompanyHit`, `LocalPlaceHit`, or `PeopleHit`. Typed hit records support attribute access for field reads (`hit.url`, `hit.title`), `dict(hit)` for JSON-serializable rows, and a small mapping-compatible surface such as `{**hit}`, `hit["url"]`, and `hit.keys()`.

## Indexes

### Web - `pplx_sdk.search.web`

General-purpose public web search. Use when the answer is likely on public pages, docs, articles, blogs, company pages, forums, or social pages.

**Hit fields:** `url`, `title`, `domain`, `snippet`, `date?`.

**Filters:** `limit`, `country`, `domains`, `excluded_domains`.

Simple:

```python
save_and_print(pplx_sdk.search.web("python 3.13 release notes"))
```

Multiple query variants:

```python
save_and_print(pplx_sdk.search.web([
    "python 3.13 release notes",
    "python 3.13 whats new",
]))
```

With filters:

```python
save_and_print(pplx_sdk.search.web(
    "python 3.13 release notes",
    limit=10,
    domains=["docs.python.org"],
    excluded_domains=["dev.to"],
    country="US",
))
```

Pass either one string or a list of up to 5 strings. A list sends one web-search request where the first string is the origin query and the rest are reformulations; the return shape stays a flat `list[WebHit]`. Use a list **only for reformulations of a single search intent**, and at most 5 — it is not a batch tool. Do not bundle several different questions or entities into one call. For several distinct queries (e.g. one lookup per entity in a list), or for more than 5, use `web_many([...], limit_per_query=...)`, which runs each as its own independent search with its own result list.

`limit` sets the total number of results the request returns (max 100). For a single-string query that is simply how many hits come back. For a list it is the total across the whole merged request — the origin plus all reformulations share that one budget, it is *not* counted per variant. So a small `limit` on a multi-variant list (e.g. `limit=5` on 5 variants) caps the merged list to ~5 hits total, leaving barely one per reformulation and defeating the point of reformulating. If you omit `limit` on a list, the total defaults to roughly the per-query default × the number of variants (~10 × variants), which keeps the merged list large enough for the reformulations to contribute — the result is still one combined, deduplicated list, not a separate list per variant. When you want an independent list of hits *per query*, use `web_many([...], limit_per_query=...)` instead (see `patterns/fanout.md`).

### People - `pplx_sdk.search.people`

Profile search, strongest for intersection queries such as `company x role` or `role x company x location` ("senior PM fintech London"). Use only for people or professionals, not companies, jobs, products, reviews, or business listings.

**Hit fields:** `url`, `title`, `summary?`.

**Filters:** `limit`, `country`, `name`, `company`, `skills`, `location`, `education`, `external_id`. `country` is a top-level region filter (ISO country code); `location` token-searches the profile location field.

Simple:

```python
save_and_print(pplx_sdk.search.people("product manager fintech London"))
```

With filters:

```python
save_and_print(pplx_sdk.search.people(
    "product manager fintech London",
    limit=50,
    company="Stripe",
    location="London",
    skills="fintech payments",
))
```

### Companies - `pplx_sdk.search.companies`

Company entity search over a dedicated companies index. Returns company records, not web pages — use it to discover or verify companies/businesses (industry × geography × size-style queries, competitor scans, prospect lists). For a company's news, funding, or team pages, use `web`; for its employees, use `people`.

**Hit fields:** `url?`, `title?`, `snippet?`, `employee_count?`, `founded_year?`, `external_ids?`. Every field is optional — guard reads on sparse hits. `title` is the company name and `url` is the company website. `external_ids` is a list of namespaced identifiers such as `"domain:example.com"`; the `domain:` entry is a stable dedup key when `url` is missing.

**Filters:** `limit` (1-100, default 10); `hq_country` (list of ISO 3166-1 alpha-2 codes, case-insensitive, max 10, OR — codes only, names rejected); `sector` and `company_type` (single enum values — full lists in `recipes/company-research.md`); `employee_count_gte`/`_lte` and `founded_year_gte`/`_lte` (inclusive integer bounds). `country` is the caller locale, **not** a result filter — use `hq_country` for that. Bad enum or ISO2 values raise immediately, naming the allowed values.

**Zero-match relaxation:** if the filtered query matches no documents, the service retries once without filters and returns those results with no indicator — sanity-check hits against your criteria instead of trusting the filter.

Full filter set:

```python
save_and_print(pplx_sdk.search.companies(
    "battery cell manufacturers",
    limit=25,
    hq_country=["de", "pl"],       # HQ in Germany or Poland (ISO2)
    sector="manufacturing",
    company_type="private",
    employee_count_gte=100,
    employee_count_lte=5000,
    founded_year_gte=2010,
))
```

### Local - `pplx_sdk.search.local`

Local places search over a maps index — restaurants, hotels, shops, venues, services. Returns place records (address, coordinates, rating), not web pages. For a place's reviews, articles, or news, use `web`.

**Hit fields:** `title?`, `url?`, `url_source?`, `summary?`, `address?`, `phone?`, `coordinates?`, `rating?`, `reviews_count?`, `price_range?`, `categories?`, `place_id?`. Every field is optional — guard reads on sparse hits. `url_source` is `"website"` when `url` is the place's own site and `"maps_listing"` when it is a synthesized Google Maps link (common for query-only searches); `coordinates` has `latitude`/`longitude`.

**Filters:** `limit` (1-20, default 10); `latitude`/`longitude` (search center — pass both or neither); `zoom` (0-22, default 14, roughly town level; larger is narrower; requires coordinates). `country` is the caller locale, **not** a result filter.

Two ways to position the search:

- **Query-only** (no coordinates): the geographic target is resolved from the query text, so name the area in the query ("best restaurants in Lisbon").
- **Point** (`latitude`/`longitude` + optional `zoom`): centers the search at that point. Coordinates bias results toward the point but do not strictly bound distance — dense queries stay local, sparse ones widen. When radius matters, sanity-check hit `coordinates`/`address` instead of trusting the viewport.

Query-only:

```python
save_and_print(pplx_sdk.search.local("best seafood restaurants in Lisbon"))
```

Around a point:

```python
save_and_print(pplx_sdk.search.local(
    "family resort with lazy river",
    latitude=18.560076,
    longitude=-68.372535,
    zoom=14,
    limit=10,
))
```

## Independent Fan-Out

Use `_many` helpers only when you intentionally need independent concurrent requests with per-query `FanoutResult` envelopes and error isolation:

```python
raw_results = pplx_sdk.search.web_many(
    [
        {"query": "python 3.13 release notes"},
        {"query": "python 3.13 whats new", "domains": ["docs.python.org"]},
    ],
    limit_per_query=10,
)
```

See `patterns/fanout.md`.
