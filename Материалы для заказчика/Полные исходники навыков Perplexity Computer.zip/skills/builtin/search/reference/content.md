# Content Reference

Use `pplx_sdk.content` after search when you need more than a hit title or search-result text.

## Full Page Fetch - `content.fetch`

Fetch full page content for URLs. Use `cache_enabled=False` when freshness matters.

Simple:

```python
save_and_print(pplx_sdk.content.fetch(["https://example.com"]))
```

With options:

```python
save_and_print(pplx_sdk.content.fetch(
    ["https://example.com/a", "https://example.com/b"],
    cache_enabled=False,
    prompt="list every advisor with affiliation",
    return_html=True,
))
```

`prompt` runs LLM extraction per page and replaces each result's `content` with the prompt-specific output. `return_html=True` includes the unprocessed page source in `raw_html`; use it when cleaned content omits needed tags, tables, embedded JSON/scripts, or metadata. These options can be passed independently.

`PageResult` fields: `url`, `title?`, `description?`, `author?`, `hostname?`, `published_date?`, `is_paywall`, `is_cached`, `content?`, `error?`, `raw_html?`.

Use `fetch` for a small single request. Use `fetch_many` for arbitrary-size URL pools; it auto-chunks and returns one `FanoutResult` per input URL. See `patterns/fanout.md`.

## Image Download - `content.fetch_image`

Download one public image URL directly to the workspace:

```python
save_and_print(pplx_sdk.content.fetch_image(
    "https://example.com/image.png",
    output="/home/user/workspace/image.png",
))
```

Use the image asset URL from `search.images` (`ImageHit.thumbnail_url`), not the source page in `ImageHit.url`. The gateway returns bytes only after verifying that the fetched body is an image. With `output`, the SDK writes those bytes and returns the saved path. Use an absolute path under `/home/user/workspace` and include the appropriate image extension. An exception means the URL could not be fetched, the body was not an image, or the file could not be written.

## Structured Profile Fetch - `content.fetch_people`

Fetch fielded people/profile data from profile URLs. Use this before LLM filtering when criteria can be expressed against company history, education, skills, location, current role, or linked profiles. Prefer `fetch_people` over full-page `content.fetch` when these fixed fields answer the question.

Simple:

```python
save_and_print(pplx_sdk.content.fetch_people(["https://example.com/profile"]))
```

From search hits:

```python
save_and_print(pplx_sdk.content.fetch_people([hit.url for hit in deduped[:50]]))
```

`PeopleFetchResult` fields: `url`, `full_name`, `people_headline`, `location`, `country`, `current_companies`, `previous_companies`, `education_ongoing`, `education_finished`, `skills`, `emails`, `github`, `facebook`, `twitter`, `update_times`, `error`.

Nested fields: `emails` → `[{email, order_of_priority}]`; `github` → `{url, username, contributions_count}`; `facebook` → `{url}`; `twitter` → `{url}`; `update_times` → `{category_name: unix_seconds}`.

Accepts 1-50 URLs per call. Order is preserved. URLs the crawler cannot parse as profiles return `error: "not found"` while other entries succeed independently. Loop in chunks of 50 for larger pools.

## Query-Focused Snippets - `content.snippets`

Use snippets when search-result text does not disambiguate a specific claim, or when you need a focused excerpt from known URLs.

Simple:

```python
save_and_print(pplx_sdk.content.snippets(
    query="specific expertise query",
    urls=["https://example.com/profile"],
))
```

Multiple URLs:

```python
save_and_print(pplx_sdk.content.snippets(
    query="specific expertise query",
    urls=urls[:20],
))
```

`SnippetResult` fields: `url`, `text`, `tokens_count`, `error`.

## When To Use Each

- Use `content.fetch` / `fetch_many` for full page text, dossier extraction, or page-level evidence.
- Use `content.fetch_image` to validate and save an image asset in the workspace.
- Use `content.fetch_people` for people/profile enrichment before filtering.
- Use `content.snippets` for targeted evidence from known URLs without fetching full pages.
