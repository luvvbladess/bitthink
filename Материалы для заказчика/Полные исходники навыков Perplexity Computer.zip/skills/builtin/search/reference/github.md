# GitHub Search Reference

Search GitHub (code, repos, issues, PRs, users, commits) from `bash` with `api_credentials=["github"]`, using `gh search …` or `gh api search/…`. Use this to find things _on GitHub specifically_; for general web results that merely include GitHub pages, use `pplx_sdk.search.web(..., domains=["github.com"])` instead.

## Credentials

- Pass `api_credentials=["github"]` on the `bash()` call to inject credentials.
- `gh` runs under the user's **connected** GitHub token, so results respect their visibility — private repos/code require a connected account with access.
- The injected credential is a Perplexity **proxy** token (`agp_…`) applied server-side on the `gh` rail.

### Safety

- Do **not** inspect or echo the token (`gh auth status`, env dumps).
- Do **not** hit `api.github.com` directly with `curl` — always go through `gh`.
- Read-only: never create, edit, or delete from a search workflow.

### Gotchas

- Unauthenticated `gh` (missing `api_credentials`, or GitHub not connected) returns 401/403 → prompt the user to connect `source_id="github"`.

## Rate limits

GitHub meters search far more tightly than the proxy's 600 req/min/session cap:

- **search = 30/min**
- **code search = 10/min** (the tightest — budget code-search workflows around it)
- **core REST = 5000/hr**

Check GitHub's remaining budget with `gh api rate_limit`; this does not report the proxy budget. On rate-limit 403/429 responses, honor `Retry-After` / `X-RateLimit-Reset` and pause the whole batch, not just one parallel request. If no retry timing is available, wait at least 60 seconds before a bounded retry. Don't redirect stderr to `/dev/null`; rate-limit and auth errors surface there.

For bulk commit ancestry checks, fetch once with GitHub credentials and use local Git for available commits. Missing commits are unknown, not proof of non-ancestry: fetch the missing refs or use compare API calls only for unresolved pairs. Deduplicate pairs and pace API requests across the whole batch; limiting parallel workers alone does not limit requests per minute.

## Pagination

Search returns at most 100 results/page and **1000 results total** per query — narrow with qualifiers (`repo:`, `path:`, date ranges) rather than paging deep; the API won't return past result 1000.
