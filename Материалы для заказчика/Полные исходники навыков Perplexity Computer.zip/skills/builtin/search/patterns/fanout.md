# Fan-Out

Use `_many` helpers to send many parallel SDK requests without managing concurrency yourself.

Each `_many` helper returns one `FanoutResult` per input query/item/URL. `extract_many` returns one `FanoutResult[ExtractResult]` per input item. One failed query/item does not fail the batch — the failure is isolated in that entry's `FanoutResult`.

## Available Helpers

- `pplx_sdk.search.<index>_many(queries, limit_per_query=..., concurrency=...)` — every search index has a `_many` twin: `web`, `people`, `images`, `videos`, `academic`, `secgov`, `shopping`, `patents`, `local`.
- `pplx_sdk.content.fetch_many(urls, chunk_size=10, concurrency=..., ...)`
- `pplx_sdk.llm.extract_many(items, instruction=..., output_schema=..., chunk_size=10, concurrency=..., max_tokens=16384)`

Defaults: `concurrency=5`; `fetch_many` / `extract_many` use `chunk_size=10`; `extract_many` defaults to `max_tokens=16384`.

## Web Search

The two options below differ in the breadth of the intent (a single intent, possibly reworded into several query variants, vs. several distinct intents) and in output format — choose by the breadth of intent:

- **`web([...])`** — one search for a *single* intent, where the extra strings are reformulations of the same question. Returns one merged, deduped `list[WebHit]`. At most 5 variants.
- **`web_many([...], limit_per_query=...)`** — *several independent* searches (distinct questions or entities), run concurrently, each with its own result list, `limit_per_query`, and error isolation (one `FanoutResult` per query).

Rule of thumb: reformulating one question → `web`; looking up many *different* things → `web_many`. `web([...])` takes **at most 5** variants; for more than 5 queries, or any set of distinct entities, use `web_many`.

Independent queries — distinct intents, one search each:

```python
save_and_print(pplx_sdk.search.web_many(
    [
        "Yellowstone National Park 2023 visitor numbers",
        "Zion National Park entrance fee 2024",
        "Acadia National Park camping reservations",
    ],
    limit_per_query=10,
))
```

Per-query kwargs:

```python
save_and_print(pplx_sdk.search.web_many(
    [
        {"query": "python 3.13 release notes"},
        {"query": "python 3.13 whats new", "domains": ["docs.python.org"]},
    ],
    limit_per_query=10,
    concurrency=5,
))
```

Search `_many` helpers accept either query strings or kwargs dicts forwarded to the single-call method. Specs accept **only** kwargs the single-call method accepts — keep caller-side metadata in a side dict keyed by `spec["query"]`, don't smuggle it into the spec. Prefer `limit_per_query` at the `_many` call site because `limit` is per query, not a batch-wide cap.

## Content Fetch

```python
save_and_print(pplx_sdk.content.fetch_many(
    [
        "https://example.com/a",
        "https://example.com/b",
    ],
    cache_enabled=False,
))
```

`fetch_many` accepts a flat list of URL strings. It auto-chunks past the upstream per-call cap and returns one `FanoutResult` per input URL, so `output[i]` corresponds to `urls[i]`.

## LLM Extract

```python
ROWS = [
    {"url": "https://example.com/a", "title": "Example A", "content": "..."},
    {"url": "https://example.com/b", "title": "Example B", "content": "..."},
]

INSTRUCTION = """Decide if each record is relevant.
Return matches=true only when the record contains useful evidence."""

SCHEMA = {
    "type": "object",
    "properties": {
        "matches": {"type": "boolean"},
        "reason": {"type": "string"},
    },
    "required": ["matches"],
}

save_and_print(pplx_sdk.llm.extract_many(
    items=ROWS,
    instruction=INSTRUCTION,
    output_schema=SCHEMA,
))
```

For classifier schemas with boolean `matches`, `pplx_sdk.utils.get_extract_matches(raw_results)` can collect matching rows and error envelopes. Use a custom loop over raw results when downstream code needs flat classifier rows or structured `ExtractError.code`.

## Result Shape

Every `_many` helper returns one `FanoutResult` envelope per input, in input order — e.g. `web_many(...)` → `list[FanoutResult[list[WebHit]]]`:

- `result.ok` - true when the call/chunk succeeded.
- `result.spec` - the request provenance for that result.
- `result.result` - the SDK result on success.
- `result.error` - the isolated exception on fanout-level failure.

A `FanoutResult` is an envelope, not a result list — never iterate, index, or `dict()` it directly. Check `.ok`, then unwrap `.result`:

```python
for entry in pplx_sdk.search.web_many(queries, limit_per_query=10):
    if not entry.ok:
        continue  # or record entry.error — don't discard failures silently
    for hit in entry.result:
        ...
```

For artifact-producing workflows, split successes and errors, flatten rows, write JSONL, and preview output as described in `patterns/multi-step.md`.

## Custom Async Fan-Out

If you need more complex logic with explicit async control, see `reference/async.md`
