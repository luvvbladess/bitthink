# Accounting Skills

- `skills/accounting/audit-support/GUIDE.md` — Support SOX 404 compliance with control testing methodology, sample selection, and documentation standards.
- `skills/accounting/close-management/GUIDE.md` — Manage the month-end close process with task sequencing, dependencies, and status tracking.
- `skills/accounting/financial-statements/GUIDE.md` — Generate income statements, balance sheets, and cash flow statements with GAAP presentation and period-over-period comparison.
- `skills/accounting/journal-entry-prep/GUIDE.md` — Prepare journal entries with proper debits, credits, and supporting documentation for month-end close.
- `skills/accounting/reconciliation/GUIDE.md` — Reconcile accounts by comparing GL balances to subledgers, bank statements, or third-party data.
- `skills/accounting/variance-analysis/GUIDE.md` — Decompose financial variances into drivers with narrative explanations and waterfall analysis.

Read the matching guide at `skills/accounting/<guide-name>/GUIDE.md`.