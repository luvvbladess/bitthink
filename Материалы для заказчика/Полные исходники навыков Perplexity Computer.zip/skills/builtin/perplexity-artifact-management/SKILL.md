# Perplexity Artifact Management

Perplexity Computer artifacts (also called assets) are generated or uploaded files in the caller's artifact library. Work with them through the `pplx artifact` command group inside the `bash` tool with `api_credentials=["pplx-sdk"]` (the `pplx-asset` credential attaches automatically). `list`, `resolve`, and `get` are read-only; `publish` changes an artifact's visibility. None of these commands create, edit, or delete artifact content — if the task is to create an artifact, use the appropriate creation capability instead.

Discover the command surface with `--help` rather than memorized flags: `pplx artifact --help` lists the subcommands, and each subcommand's `--help` documents its current options (caption search, type filters, pagination, version collapse, collection or session scoping, download paths). Commands print the backend JSON response unchanged.

Routing: `list` to discover artifacts and their ids/slugs, `resolve` to turn a reference into canonical identifiers, `get` for content, and `publish` only when the user asks to make an artifact public or wants a shareable public link. A reference is a raw artifact UUID, a slug, or a `/computer/a/<uuid>` permalink — short links are unsupported; use an explicit reference from the user or a `list` result, never a guessed or inferred one. Refer to artifacts in answers by caption, id, or `/computer/a/<uuid>` permalink. Do not confuse this library with Project files (`pplx project files`) or files attached to the conversation (`pplx session get --download-content`). To update a website or app artifact in place, run `get` for it in this session, then pass its id as `update_asset_id` to deferred tool `deploy_website`.

## Read artifact content

To read content, always run `pplx artifact get <ref> --download` and read the downloaded file. Bare `get` prints sanitized metadata with no content URL.

- `--download` fetches through a server-built content plan; the signed URL is consumed by the download and never printed. Non-file-backed artifacts (for example external links) are refused server-side — open those through browsing or fetch tooling instead.
- Content can be unavailable for artifacts that are not URL-addressable (for example digest shares); say so instead of fabricating the content — the error is explicit.

## Publish an artifact

`pplx artifact publish <ref>` makes an artifact the user owns world-readable at a durable public URL, and there is no unpublish command — reverting requires the user to change the artifact's access in Perplexity. Confirm with the user exactly which artifact to publish before running it; never publish unprompted, and only publish an artifact the user named.