# Personal Finance Tools

Tools for accessing private financial data through Personal CFO and Plaid. These return **private user data**, not public market data.


## How to call personal-finance tools — read first

**IMPORTANT:** These tools are **NOT in your tool list** and will never appear there directly. They are reached through the connector bridge. Do **NOT** conclude they are unavailable just because you do not see them in your tools — that is expected. To use them:

1. Discover the whole personal-finance surface with `list_external_tools` using `queries=["select:personal_cfo", "select:plaid"]`.
2. `describe_external_tools` with the source ID and returned tool names you need — fetch schemas (required before calling).
3. `call_external_tool` with the same source ID, tool name, and arguments — execute.

Use `personal_cfo` for aggregate tools and `plaid` for provider-owned account data. Only use tools returned by `list_external_tools`; a connected source may not expose every tool yet.


## Bootstrap


Discover Personal CFO and Plaid together using the exact-source query above.


For broad net-worth, portfolio, or financial-picture requests, treat the available sources as complementary. Start with the Personal CFO aggregate when its tool is returned, then use relevant Plaid tools for deeper account, holdings, or transaction detail. Do not stop after the aggregate tool when provider tools can materially improve the answer.


For narrow requests, use only the relevant returned provider tools. If no connector skill is hinted, follow the patterns below for the default Plaid tools.


## Available Personal Finance Tools

Only call tools returned for their canonical source.

| Source | Tool | Purpose |
| --- | --- | --- |
| `personal_cfo` | `net_worth_history` | Aggregate net-worth history across connected providers |
| `plaid` | `portfolio_holdings` | Brokerage positions and performance |
| `plaid` | `account_balance`, `transaction_history`, `liabilities` | Bank, card, transaction, and debt data |
| `plaid` | `financial_profile`, `recurring_streams` | Personalization profile and recurring cash flow |

## Execution Pattern


You **must** call `describe_external_tools` before `call_external_tool` — the system enforces this.



The sequence:

1. Discover Personal CFO and Plaid together using the exact-source query above.
2. Describe and call relevant returned tools from both sources.
3. Use returned Personal CFO aggregate tools as the baseline, then use Plaid for account-level detail.
4. Synthesize aggregate and provider detail without counting the same assets twice.

If the needed provider is not connected, the tool call will return an `auth_required` error. Surface this to the user rather than falling back to fabricated data.


## CSV Files

Personal-finance tools that return tabular data (`net_worth_history`, `portfolio_holdings`, `transaction_history`, `account_balance`, `liabilities`, `recurring_streams`) return `csv_files` in the tool result. Each entry has a source label `name`, a `filename`, a local `workspace_path`, and a `metadata_s3_key` for cited-data provenance. The CSV is already downloaded into the workspace when the tool returns. The result's `content` is a preview of the same data, not a separate provenance source.

Row-key columns are lookup-only provenance. Holdings use readable asset/provider keys and add `:2`, `:3`, and so on only when labels collide. Use the exact CSV value for `row_key`; do not expose or explain row keys in the answer.

```python
import pandas as pd
df = pd.read_csv(csv_files[0]["workspace_path"])
```

When citing values from a CSV, pass `file=csv_files[i]["filename"]` and `metadata_s3_key=csv_files[i]["metadata_s3_key"]` to `cite()`.

## Gotchas

- Market-calendar packages (`pandas_market_calendars`, `exchange_calendars`, `yfinance`) are optional in cron/scheduled finance tasks. If unavailable, or even if the task names one and import fails, use finance/tool data or another market-status source instead of `wake_parent`/`system_diagnostic`.

## Citations

Use one mechanical rule: when a personal-finance result has a non-empty `csv_files` list, every private value reported from that result — whether read from `content`, read from `csv_files[].workspace_path`, or derived from either — must pass through `cite()` from the shared `pplx_citations` runtime and appear as `[value](claim:N)`, including in tables. The `csv_files` list governs the whole result. Brevity, follow-up status, obviousness, and direct versus derived values do not relax the rule.

Claim links provide personal-finance masking, so an uncited covered value can leak when a thread is shared. Do not call `cite()` when `csv_files` is absent or empty, or for web data or fabricated values. Never fabricate claim markers; use only IDs produced by `cite()`.

Run citation work with Python through the Bash tool. For multi-step or reusable
analysis, write a `.py` file and run it with `python3 -P path/to/script.py`. A
`python3 -P << 'PYEOF'` heredoc is also valid for short, one-off work.

```python
from pplx_citations import cite, load_citations, save_citations
load_citations()
```

Every covered source value requires `source`, `file`, `metadata_s3_key`, `row_key`, and `col`. Use `content` only when it provides the exact value and unambiguous row/column identity; otherwise read `csv_files[].workspace_path`. Pass the matching entry's `filename` as `file`, and use its `metadata_s3_key`. `source` must match the CSV-producing tool you called. The `name` is shown in the UI, so use a human-readable label such as "AAPL Position Value".

Copy the matching CSV's `filename` and `metadata_s3_key` from the tool response before citing:

```python
csv_filename = "<filename from the portfolio_holdings csv_files entry>"
metadata_s3_key = "<metadata_s3_key from the portfolio_holdings csv_files entry>"

holdings_df = pd.read_csv("<workspace_path from the portfolio_holdings csv_files entry>")
aapl_position_key = holdings_df.loc[holdings_df["Ticker"] == "AAPL", "Position Key"].iloc[0]
aapl_value = cite(45_000.00, "AAPL Position Value", source="portfolio_holdings", file=csv_filename, metadata_s3_key=metadata_s3_key, row_key=aapl_position_key, col="Value")
aapl_qty = cite(100, "AAPL Quantity", source="portfolio_holdings", file=csv_filename, metadata_s3_key=metadata_s3_key, row_key=aapl_position_key, col="Quantity")

# For transactions, use the transaction-history CSV and keep its opaque ID out
# of the human-readable claim name.
transaction_csv_filename = "<filename from the transaction_history csv_files entry>"
transaction_metadata_s3_key = "<metadata_s3_key from the transaction_history csv_files entry>"
txn_amount = cite(87.43, "Whole Foods 2026-03-12 Amount", source="transaction_history", file=transaction_csv_filename, metadata_s3_key=transaction_metadata_s3_key, row_key="<transaction_id>", col="Amount")
```

### Citing Derived Values

Every covered computed value you present MUST be cited with `formula` and `derived_from`. Both are required for the derivation chain.

**Portfolio weights:**

```python
currency_summary_csv_filename = "<filename from the portfolio_holdings currency_summary csv_files entry>"
currency_summary_metadata_s3_key = "<metadata_s3_key from the portfolio_holdings currency_summary csv_files entry>"
currency_summary_df = pd.read_csv("<workspace_path from the portfolio_holdings currency_summary csv_files entry>")
usd_summary_row = currency_summary_df.loc[currency_summary_df["Currency Key"] == "USD"].iloc[0]
usd_total_value = cite(usd_summary_row["Total Value"], "USD Portfolio Total Value", source="portfolio_holdings", file=currency_summary_csv_filename, metadata_s3_key=currency_summary_metadata_s3_key, row_key="USD", col="Total Value")
weight = cite(aapl_value / usd_total_value * 100, "AAPL Portfolio Weight", formula="aapl_value / usd_total_value * 100", derived_from=["AAPL Position Value", "USD Portfolio Total Value"])
```

The `derived_from` names must **exactly match** the `name` argument of the parent `cite()` calls. Unknown names are rejected by `cite()`.

**Save at the end** of your script:

```python
save_citations()
```

Keep `save_citations()` stderr unredirected and out of filtered pipelines (for
example, do not use `2>&1 | ...`), so Bash receives the structured claim
update. Stdout may be piped or redirected when the script's printed text is not
needed for the response.

**In Python code**, `CitedValue` auto-formats with provenance links. When you use a cited value in an f-string or `print()`, it emits `[value](claim:N)` automatically — do NOT manually wrap or read `citation_id`:

```python
print(f"AAPL is worth ${aapl_value:,.0f}")
# → "AAPL is worth $[45,000](claim:2)"

# NOTE: Python format specs do NOT accept $ as a prefix. `f"{aapl_value:$,.0f}"` raises ValueError.
# Keep currency/unit symbols outside the Python-emitted claim marker. In the final
# natural-language response, re-wrap the full display value using the claim IDs
# emitted in Bash output. Do not read `citation_id` or construct claim links inside Python.
```

Example — after running a script that cited AAPL value (claim:2) and AAPL weight (claim:5):

```
| Ticker | Value | Weight |
|--------|-------|--------|
| AAPL   | [$45,000](claim:2) | [36.0%](claim:5) |

Your AAPL position is worth [$45,000](claim:2), [36.0%](claim:5) of the portfolio.
```

Every covered private value from a CSV-backed personal-finance result that appears in a thread response MUST be wrapped as `[value](claim:N)`, **including every covered cell inside every markdown table**. Unwrapped private values cannot be masked when sharing.

#### Rules

- Run citation work with Python through the Bash tool. Saved scripts and PYEOF heredocs are both valid.
- Call `load_citations()` at the start and `save_citations()` at the end of every script that uses citations.
- Cite values you **present to the user** — including every covered cell in any table you render.
- Every derived value must list its `derived_from` parent names.
- `source` must match the CSV-producing tool you called.
- A cited numeric value can be rescaled for display with a plain scalar (for example, `value / 1e6`) and retain its marker. Cite a value derived from two cited inputs with `formula=` and `derived_from=`.
- In Python code, use f-strings to apply numeric formatting. Do not call `float()` before output because it strips the claim marker; `str()` preserves the current display without applying a numeric format.
- In Python code, do NOT read `.citation_id`, `.name`, or any other citation internals from cited objects.
- In Python code, do NOT manually wrap in `[text](claim:N)` — `CitedValue.__format__` handles this in printed output.
- In thread response text, ALWAYS wrap cited values as `[value](claim:N)` using the IDs from script output.
- Use `cite()` for every covered personal-finance value shown in a thread response, including simple lookups.

### Aggregations

Use the aggregate view the tool exposes when available: `transaction_history` supports `group_by`, and `portfolio_holdings` supports `view="currency_summary"`. Cite the returned aggregate row directly.

`account_balance` returns only account/currency-grain rows. Derive totals separately per currency from `Balance`: add `cash` and `investment` rows as assets, report `liability` rows as positive debt and subtract them for net balance, and exclude `other` rows from totals. Cite every source row; for more than 8 rows, build cited subtotals with at most 8 parents each, then combine those subtotals.

**Correct:**

```python
monthly_spend = cite(category_total_row.amount, "March Groceries Total", source="transaction_history", file=transaction_csv_filename, metadata_s3_key=transaction_metadata_s3_key, row_key="FOOD_AND_DRINK:outflow:USD", col="Total")
```

**Incorrect:**

```python
monthly_spend = cite(sum(t.amount for t in groceries), "March Groceries Total", formula="sum(grocery_transactions)", derived_from=[t.name for t in groceries])
```

### Preserving Citations in Thread Responses

When your code outputs `[value](claim:N)` markers for a thread response, you MUST preserve them in your response text. Reformat the display text for readability but never drop the `[...](claim:N)` wrapper. The claim link must always surround the **full display value** including currency symbols, signs, units, and suffixes.

**Correct:**

```
"Your AAPL position is worth **[$45,000](claim:2)**."
"Portfolio total is **[$1.25M](claim:1)**." — reformatted from [1,250,000](claim:1)
"AAPL is **[36.0%](claim:5)** of your portfolio."
"You spent [$412.55](claim:20) on groceries in March."
```

**Incorrect:**

```
"Your AAPL position is worth $45,000." — dropped the citation, value cannot be masked
"Your AAPL position is worth $45,000 [claim:2]." — must use link syntax, not bracket
"Your AAPL position is worth $[45,000](claim:2)." — currency symbol must be inside brackets → [$45,000](claim:2)
"AAPL is [**36.0%**](claim:5) of your portfolio." — markdown inside brackets breaks rendering
"Portfolio total is **$1.25M** (claim:1)." — citation must use link syntax, not bare text
"| AAPL | $45,000 | 36.0% |" — table cells MUST contain `[value](claim:N)` wrappers, not raw values
```

### Gotchas

- `derived_from` names must **exactly match** parent `name` arguments; unknown names are rejected by `cite()`
- `source`, `file`, `metadata_s3_key`, `row_key`, and `col` are required on personal-finance source values for provenance; use the matching CSV's `filename` and `metadata_s3_key`
- Cite only values you report to the user — but in tables and summaries, that means **every covered cell**, not just the highlights
- Use f-strings with `CitedValue` (`f"{value:,.0f}"`) for numeric formatting. `float()` removes the claim marker; `str()` preserves the current display.
- In thread response text, re-wrap the full display value including currency symbols, signs, units, and suffixes inside the link brackets — `[$45,000](claim:2)` not `$[45,000](claim:2)` and not `[45,000](claim:2)`
- Claim markers render as clean clickable pills; never skip them for readability.
- **Tables are the #1 failure mode**: in net-worth, holdings, and transaction tables backed by `csv_files`, every reported private value must retain its claim link.
- NEVER create `cite()` calls from web search results or invented values; they lack tool-cell provenance
- NEVER narrate citation plumbing — do not mention the citations module, `cite()`, `save_citations`, `load_citations`, PYEOF, "I'll cite this", "I need to wrap as claim", or any other mechanics-level description in your thought process or response prose. Talk about _what the numbers mean_, never _how they're cited_.
- For chart-first queries (chart / graph / plot / "show me"), pass `csv_files[i].workspace_path` to `visualize.sources`.

## Detailed Guides

- **website-building.md** - Personal-finance guidance for serving portfolio data in a website. Read only when building or editing a website, and also load the canonical `website-building` skill.