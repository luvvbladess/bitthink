# Finance Stock Screener

Use `finance_stock_screener` for read-only PostgreSQL discovery and analysis over
server-approved public-equity relations. Its `information_schema` views expose
live column metadata only for allowlisted relations; the table list itself is
also allowlisted. A missing table may be unavailable or outside that allowlist.

## When to use

- Screen or rank the full available stock universe when no purpose-built finance
  tool directly supports the requested universe and metric.
- Compare multiple fundamentals, joins, or derived ratios.
- Identify and report candidates, then use purpose-built tools for deeper
  research or enrichment when useful.

Purpose-built tools win when they answer the request directly. Use
`finance_market_gainers`, `finance_market_losers`, or
`finance_market_most_active` for those current market rankings;
`finance_etf_holdings` for an explicitly ETF-scoped universe; and narrower
finance tools for a named ticker or fixed ticker list.

## Access the tool


1. Reuse a current finance catalog result when it already established that
   `finance_stock_screener` is available. Otherwise, call `list_external_tools`
   with `queries=["select:finance"]`.
2. If the catalog does not include `finance_stock_screener`, do not describe or
   call it. Use a purpose-built tool or explain that full-universe screening is
   unavailable.
3. Call `describe_external_tools` with
   `source_id="finance"` and `tool_names=["finance_stock_screener"]`.
4. Call `call_external_tool` with one read-only PostgreSQL query:


```json
{

  "source_id": "finance",
  "tool_name": "finance_stock_screener",
  "arguments": {
    "query": "<the user's human-readable stock screening request>",
    "sql": "<one SELECT or WITH ... SELECT statement>"
  }

}
```

Pass the original human-readable screen request in `query` on every call. Do
not replace it with SQL or a schema-discovery description. The persisted result
page uses `query` in its input box and shows `sql` separately as generated SQL.

Non-empty results include a bounded row preview and `csv_files`. Computer
materializes each CSV at `workspace_path`.

## Discover before analysis

Do not guess table or column names. Before the first analytical query in a
session, inspect the approved schema and reuse the result for later questions.

List approved public tables:

```sql
SELECT table_name
FROM information_schema.tables
WHERE table_schema = 'public'
  AND table_type = 'BASE TABLE'
ORDER BY table_name
```

Inspect only the relevant columns:

```sql
SELECT table_name, column_name, data_type, is_nullable, ordinal_position
FROM information_schema.columns
WHERE table_schema = 'public'
  AND table_name IN ('<table_1>', '<table_2>')
ORDER BY table_name, ordinal_position
```

Before joining, inspect local constraint columns:

```sql
SELECT
  tc.table_name,
  tc.constraint_name,
  tc.constraint_type,
  kcu.column_name,
  kcu.ordinal_position
FROM information_schema.table_constraints AS tc
JOIN information_schema.key_column_usage AS kcu
  ON tc.constraint_schema = kcu.constraint_schema
 AND tc.constraint_name = kcu.constraint_name
 AND tc.table_schema = kcu.table_schema
 AND tc.table_name = kcu.table_name
WHERE tc.table_schema = 'public'
  AND tc.table_name IN ('<table_1>', '<table_2>')
ORDER BY tc.table_name, tc.constraint_name, kcu.ordinal_position
```

These views do not expose an unambiguous local-to-referenced foreign-key map.
Confirm candidate keys against both tables' grain before joining. Query distinct
values before relying on categorical filters such as country, currency, period,
sector, or exchange.

## Query rules

- Default broad screens to U.S.-listed, actively trading operating companies;
  exclude ETFs and funds unless the user requests otherwise.
- For rankings by raw monetary values, filter to the user's requested reporting
  currency before ordering; if none is specified, filter to USD. Never rank
  mixed currencies. Do not currency-filter dimensionless metrics such as
  margins or growth rates.
- When selecting monetary values, also select their authoritative `currency` or
  `reported_currency` column. The result page uses that returned value to format
  each row; do not invent a currency argument or constant display label.
- Inspect table grain and periods before aggregation. Build TTM flows from the
  latest four quarters and use the latest observation for point-in-time values.
- Enumerate columns, put `symbol` first, and avoid `SELECT *`.
- For an intentional top/bottom-N result, use an integer `LIMIT` no greater than
  the described `max_rows` bound. For exhaustive filter screens, omit `LIMIT` so
  the tool can detect overflow and set `truncated`; if truncated, tighten the
  screen instead of treating the result as complete.
- For complex screens, narrow the universe early and avoid repeated broad scans,
  sorts, or aggregations. After a `timeout` error ("Finance SQL query timed
  out."), simplify the query rather than retrying the same SQL.

Only one `SELECT` or `WITH ... SELECT` statement is accepted. The tool rejects
writes, DDL, session commands, psql metacommands, multiple statements,
unapproved functions, arbitrary schemas, and unapproved system catalogs. Follow
the structured error and hint when a query is rejected.

## Present results

- Show the requested table, values, and key findings directly in the answer.
- Use purpose-built finance tools for deeper research, validation, or
  enrichment when useful. Do not re-query them solely to display values already
  returned by the screener.
- State the universe, filters, reporting period, currency, assumptions, and
  whether `truncated` is true. Do not print the SQL unless the user asks for it.

Use the CSV from the final analytical query as provenance for the companies you
present. When the result has a ticker column, select it exactly once as
`symbol`; citation identity does not depend on it. Do not call `cite()` for
schema discovery, validation queries, or intermediate analytical results that
do not appear in the answer.
Prefer one final query that selects the exact rows and columns needed for the
answer.

The returned CSV includes a zero-based `__row_index` for citation coordinates.
Omit it from the displayed table. For each displayed row, call `cite()` for its
`symbol` when present and for every numeric value you report, using
`source="finance_stock_screener"`, the CSV's `filename` and `metadata_s3_key`,
that row's `__row_index`, and the exact sanitized CSV column name. Other text
cells may remain plain text unless they directly support a claim.

Generate claim links through the citation runtime; never hand-write
`[cite:N]` definitions, `pplx://tool/...` URLs, or `[value](claim:N)` links.
After reading the final CSV, run a Python script through Bash that loads the
existing registry, calls `cite()` for the displayed values, and saves the
registry:

```python
from pplx_citations import cite, load_citations, save_citations

load_citations()
row_key = row["__row_index"]
symbol = cite(row["symbol"], "NVDA symbol", source="finance_stock_screener", file=csv_filename, metadata_s3_key=metadata_s3_key, row_key=row_key, col="symbol")
price = cite(row["price"], "NVDA price", source="finance_stock_screener", file=csv_filename, metadata_s3_key=metadata_s3_key, row_key=row_key, col="price")
market_cap = cite(row["market_cap"], "NVDA market cap", source="finance_stock_screener", file=csv_filename, metadata_s3_key=metadata_s3_key, row_key=row_key, col="market_cap")
print(f"| {symbol} | {price} | {market_cap} |")
save_citations()
```

Keep `save_citations()` stderr unredirected so Bash can register the claims.
Use only the `claim:N` IDs emitted by that script in the final response. Keep
each full formatted display value inside its link, for example
`[$214.72](claim:2)` and `[$5.20T](claim:3)`, without markdown inside the link.
Do not expose the citation script or narrate this plumbing in the answer.

Every data cell in a row carries the same public screener-result destination
and, when that row has a resolvable `symbol`, best-effort ticker icon metadata.
Missing or unresolved symbols do not affect citation resolution. The
`__row_index` cell is intentionally uncitable.

This tool supports financial analysis, not investment advice.