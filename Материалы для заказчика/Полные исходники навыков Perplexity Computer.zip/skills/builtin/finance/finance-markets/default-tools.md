# Default Finance Tools

Perplexity's default `finance_*` tools belong to the `finance` connector.

**Do NOT retrieve stock prices, financial data, or company fundamentals from the open web — by any tool, shell command, URL fetch, or scraping path.** Financial data is highly specific, quantitative, and frequently revised — open-web retrieval returns stale, unstructured snippets that may reflect pre-revision figures. Default finance tools return structured, point-in-time accurate data directly from market data providers. Only fall back to open-web retrieval if these tools lack the specific data needed.

## Discovering Finance Tools


Discover available default finance tools: list connectors with the exact-source query `select:finance`.


## Available Finance Tools

| Tool | Purpose | When to Use |
|------|---------|-------------|
| `finance_tickers_lookup` | Resolve ticker symbols (stocks, ETFs, indexes, commodities, crypto, international) | Always use first—standard tickers may not resolve, handles format variations (BRK.B vs BRK-B) and fuzzy names |
| `finance_quotes` | Real-time quotes for stocks, crypto, ETFs, indices | Current price, P/E, market cap, dividend yield. Returns csv_files. |
| `finance_ohlcv_histories` | Historical OHLCV data for stocks, ETFs, crypto, indices in csv_files | Price history, charts, technical indicators. Do NOT web search for historical prices—use this tool |
| `finance_company_financials` | Income statement, balance sheet, cash flow | Fundamental analysis, valuation, growth calculations, derived metrics |
| `finance_etf_holdings` | ETF constituent holdings | ETF constituents, what stocks are in an ETF, ETF breakdown |
| `finance_institutional_holders` | Institutional holders (hedge funds, mutual funds, banks) for a US ticker. US-lis |  |
| `finance_insider_transactions` | Insider transactions (Form 4 buys and sells by officers and directors) for a US  |  |
| `finance_earnings_history` | Historical earnings actuals vs consensus estimates, beat/miss data, post-earnings price moves (returns csv_files) | EPS history, revenue beat/miss, earnings surprise metrics |
| `finance_earnings_schedule` | Earnings release dates | When companies report, upcoming/past earnings calendar |
| `finance_earnings_transcript` | Earnings call transcript excerpts or optional full verbatim content | Earnings call transcripts, management commentary, segment KPIs, non-GAAP metrics, and guidance |
| `finance_company_profile` | Basic company info: industry, sector, CEO, employees, website, description | Company overview, who's the CEO, what industry, employee count. Does NOT include market cap (use quotes) |
| `finance_company_peers` | Peer/comparable companies for a given ticker | Competitors, similar companies, peer comparisons, alternative investments |
| `finance_market_gainers` | Top gaining stocks/crypto today | Top gainers, what's up the most, biggest risers |
| `finance_market_losers` | Top losing stocks/crypto today | Top losers, biggest drops, what's down the most |
| `finance_market_most_active` | Most actively traded stocks today | Most active stocks, highest volume, most traded |
| `finance_politician_list` | List all tracked politicians with stock activity | Which politicians trade stocks, list of tracked congress members |
| `finance_politician_holdings` | A specific politician's full stock portfolio | What stocks does [politician] own, politician's portfolio |
| `finance_politician_trades` | Recent congressional stock transactions | Recent politician trades, congressional stock transactions |
| `finance_politician_ticker_holders` | Which politicians hold a specific stock | Which politicians own [ticker], congressional holders of a stock |
| `finance_watchlist_fetch` | User's Perplexity Finance watchlist (stocks they're *tracking*, not actual brokerage holdings). | User asks about their watchlist or what stocks they're tracking. **Not for actual portfolio holdings** — use the `portfolio_holdings` connected tool for real brokerage positions. |
| `finance_segments` | Segment-level breakdowns and operating KPIs not in financial statements | Revenue models, revenue builds, unit economics, P*Q analysis, key drivers, segment growth, ARPU, GMV, take rate, store count, DAU/MAU |
| `finance_estimates` | Consensus analyst estimates and forward projections | Estimated EPS, revenue, EBITDA for future periods, consensus forecasts |
| `finance_adjusted_metrics` | Adjusted (non-GAAP) financial metrics | Adjusted EPS, adjusted EBITDA, free cash flow, management-reported metrics for valuation and peer comparison |
| `finance_analyst_research` | Analyst consensus price targets and rating changes | Price targets (avg/median/high/low), analyst ratings, upgrades/downgrades, bullish/bearish breakdown |
| `finance_company_ratios` | Company financial ratios as annual time-series | Valuation (P/E, EV/EBITDA, P/S), margins (gross, operating, net, FCF), returns (ROE, ROA, ROIC), financial health (D/E, current ratio), per-share metrics, dividends |
| `finance_macro_snapshot` | Latest values for macroeconomic indicators by country (GDP, inflation, unemployment, interest rates, trade, housing, etc.) | Current macro indicator levels and period-over-period change for one or more countries. Do NOT web search for macro data—use this tool |
| `finance_macro_history` | Historical time series for macroeconomic indicators by country, one CSV per series | Macro trends over time, charting GDP/inflation/unemployment history, comparing countries' macro trajectories |

## Execution Pattern


All finance tools are called via the connector tool call with `source_id="finance"`. You **must** describe each connector tool before calling it — the system enforces this.

The sequence:

1. List connectors with the exact-source query `select:finance` — discover finance tools.
2. Describe `finance_quotes`, `finance_company_financials`, and any other connector tools you intend to call from `source_id="finance"` — fetch schemas (required before calling).
3. Use the connector tool call with `tool_name="<tool_name>"`, `source_id="finance"`, and the appropriate `arguments` — always use `source_id="finance"`.
4. Follow the Citations section for any result with a non-empty `csv_files` list, including when computing or reporting derived metrics.


## CSV Files

Structured finance tools (financials, quotes, OHLCV, earnings history and schedules, company profiles, politician lookup, estimates, etc.) return `csv_files` in the tool result. Each entry has a source label `name`, a `filename`, a local `workspace_path`, and a `metadata_s3_key` for cited-data provenance. The CSV is already downloaded into the workspace when the tool returns.

```python
import pandas as pd
df = pd.read_csv(csv_files[0]["workspace_path"])
```

When citing values from a CSV, pass `file=csv_files[i]["filename"]` and `metadata_s3_key=csv_files[i]["metadata_s3_key"]` to `cite()`. Do not derive or hand-write citation metadata.

### Gotchas

- Treat explicit charting language as chart-first; generic finance lookups stay text/table-first. For chart-first queries, pass `csv_files[i].workspace_path` to `visualize.sources`.

## Workflow: Always Resolve Tickers First

Never assume ticker symbols. Always use `finance_tickers_lookup` before other tools:

Connector tool: `finance_tickers_lookup`

```json
{
    "queries": [
        "Tesla"
    ]
}
```

Then fetch data with the confirmed symbol:

Connector tool: `finance_quotes`

```json
{
    "ticker_symbols": [
        "AAPL"
    ],
    "fields": [
        "price",
        "change",
        "changesPercentage"
    ]
}
```

## Reference Date

Most time-sensitive finance tools (`company_financials`, `earnings`, `earnings_schedule`, `ohlcv_histories`) take a **reference date** that determines what data to fetch. ALWAYS derive `as_of` parameters from this date — never omit them.

### Step 1: Identify the Reference Date

- If the user specifies an explicit date (e.g., "as of March 2024"), use that date
- If the user's question implies a time period (e.g., "Q4 2024 results", "last year's revenue", "2023 earnings call"), infer the closest reference date that would return the relevant data
- Otherwise, use the current date/time from the `<context>` block

### Step 2: Map to Fiscal Parameters

`as_of_fiscal_year` and `as_of_fiscal_quarter` use the **company's fiscal calendar** — pass the fiscal period the user is asking about, not a calendar-mapped equivalent.

- If the user specifies a fiscal period directly, pass it as-is
- Otherwise, determine the company's fiscal calendar and map the reference date to the correct fiscal period

Do NOT assume Jan–Dec fiscal years.

### Rules

- **NEVER** omit `as_of` parameters — "latest" is ambiguous and non-reproducible
- For historical price lookups, use the reference date as the explicit end date on OHLCV-style tools

## Precision

Use exact finance-tool values for citations and calculations. You may rescale or format them for display (for example, `$1.50T`), but do not hedge precise results with words such as "approximately", "roughly", or "around" — say "trading at $21.09/share," not "approximately $21/share" or "around $21.09/share."

## Gotchas

- Market-calendar packages (`pandas_market_calendars`, `exchange_calendars`, `yfinance`) are optional in cron/scheduled finance tasks. If unavailable, or even if the task names one and import fails, use finance/tool data or another market-status source instead of `wake_parent`/`system_diagnostic`.
- **Earnings-transcript citation density:** Keep the answer readable. Cite the shortest useful evidence span, not whole sentences or paragraphs and not every clause. For a normal summary, select only the few claims needed to answer; prefer one non-numeric claim marker per takeaway and add another only for materially distinct evidence. Separate markers may reuse one row. Never replace inline evidence with a trailing `passage` or `commentary` label.

## Citations

Use one mechanical rule: when a default `finance_*` result has a non-empty `csv_files` list, every numeric value reported from that result — whether read from `content`, read from `csv_files[].workspace_path`, or derived from either — must pass through `cite()` from the shared `pplx_citations` runtime and appear as `[value](claim:N)`. The `csv_files` list governs the whole result; `content` is a preview, not an uncited alternative. Brevity, follow-up status, obviousness, and direct versus derived values do not relax the rule.

`finance_stock_screener` follows this rule only for its final analytical result: cite every displayed `symbol` cell and every numeric value reported from that final CSV. Do not cite schema-discovery, validation, or discarded intermediate query outputs.

Do not call `cite()` when `csv_files` is absent or empty, or for BYOL or web data. Never fabricate claim markers; use only IDs produced by `cite()`.

### Setup

Run citation work with Python through the Bash tool. For multi-step or reusable
analysis, write a `.py` file and run it with `python3 -P path/to/script.py`. A
`python3 -P << 'PYEOF'` heredoc is also valid for short, one-off work.

```python
from pplx_citations import cite, load_citations, save_citations
load_citations()
```

### Source values

Every covered source value requires `source`, `file`, `metadata_s3_key`, `row_key`, and `col`. Use the result's `content` preview only when it provides the exact value and unambiguous row/column identity; otherwise read `csv_files[].workspace_path`. In either case, pass the matching CSV's `filename` as `file` and its `metadata_s3_key` separately. The `name` argument is shown in the UI; use a human-readable label such as `"AAPL FY2024 Revenue"`.

Copy the matching CSV's `filename` and `metadata_s3_key` from the tool response before citing:

```python
csv_filename = "AAPL_quarterly_financials.csv"
metadata_s3_key = "web/direct-files/<entry-md5>/<upload-uuid>/csv/<hash>_AAPL_quarterly_financials.csv.metadata.json"

revenue = cite(383_285_000_000, "AAPL FY2024 Revenue", source="finance_company_financials", file=csv_filename, metadata_s3_key=metadata_s3_key, row_key="2024-Q4", col="income_statement_total_revenues")
net_income = cite(96_995_000_000, "AAPL FY2024 Net Income", source="finance_company_financials", file=csv_filename, metadata_s3_key=metadata_s3_key, row_key="2024-Q4", col="income_statement_consolidated_net_income")
```

### Derived values

Every covered computed value you present (margins, growth rates, ratios, per-share metrics) **must** be cited with `formula` and `derived_from`. The names in `derived_from` must **exactly match** the parent `cite()` `name` arguments; unknown names are rejected by `cite()`.

```python
margin = cite(net_income / revenue * 100, "AAPL FY2024 Net Margin", formula="net_income / revenue * 100", derived_from=["AAPL FY2024 Net Income", "AAPL FY2024 Revenue"])
growth = cite((rev_2024 - rev_2023) / rev_2023 * 100, "AAPL Revenue Growth YoY", formula="(rev_2024 - rev_2023) / rev_2023 * 100", derived_from=["AAPL FY2024 Revenue", "AAPL FY2023 Revenue"])
```

Save at the end:

```python
save_citations()
```

Keep `save_citations()` stderr unredirected and out of filtered pipelines (for
example, do not use `2>&1 | ...`), so Bash receives the structured claim
update. Stdout may be piped or redirected when the script's printed text is not
needed for the response.

### Emitting claim links

`CitedValue` auto-formats with claim markers in f-strings — do NOT manually
wrap. `float()` removes the marker; `str()` preserves it but cannot apply a
numeric format:

```python
print(f"Net margin was {margin:.1f}%")          # → "Net margin was [25.3](claim:3)%"
print(f"| Revenue | ${revenue / 1e9:.1f}B |")   # → "| Revenue | $[95.4](claim:1)B |"
```

F-string literals are formatted separately from `CitedValue`, so Bash stdout may show `$[95.4](claim:1)B`. That is expected intermediate output. In final response text, place the full rendered value inside one link, as shown below.

The IDs in your script's stdout are the ones you reuse in your response prose. **Never fabricate `claim:N` or `pplx://action/claim` links by hand** — only use IDs the citation flow actually generated.

### Response text — preserving citations

Your response text MUST contain `[value](claim:N)` links for every cited value. Claim links are inline data provenance, not source-name citations: the link text must be the value or claim span itself, never a publication, tool, passage, section, or source label. Reformat the display text for readability, but never drop the wrapper, and keep the link wrapper around the **full display value** including currency symbols, signs, units, and suffixes:

**Correct:**

```
"Apple's revenue was **[$383.3B](claim:1)**."
"Market cap is **[$1.50T](claim:5)**."          (reformatted from [1,498,102,183,132](claim:5))
"Analysts rate it [Strong Buy](claim:12) with a target of **[$236](claim:13)**."
"representing a **[-55.8%](claim:2)** downside"
"Net margin was [50%](claim:80) in 2024."
```

**Incorrect:**

```
"Apple's revenue was $383.3B."                       — dropped the link
"Apple's revenue was $383.3B [claim:1]."             — must use markdown link, not bracket suffix
"Apple's revenue was $[383.3](claim:1)B."            — unit must be inside brackets → [$383.3B](claim:1)
"representing a [**-55.8%**](claim:2) downside"      — markdown inside link text breaks rendering
"Net margin was [50%](claim:80) in 2024 [claim:80]." — claim: doesn't take bracket-only syntax
"Market cap is **$1.50T** (claim:5)."                — must be markdown link, not bare text
"Revenue rose ([finance tool](claim:1))."           — link text must be the value or claim, not a source label
```

Claim markers render as clean clickable links in the UI — never skip them "for readability," even in large tables.

### Rules summary

- Cite covered values you **present** to the user — skip purely intermediate variables
- `source` must match the CSV-producing tool name (for example, `finance_company_financials` or `finance_quotes`)
- A cited value can be rescaled for display with a plain scalar (for example, `revenue / 1e9`) and retain its marker. Cite a value derived from two cited inputs with `formula=` and `derived_from=`.
- Use f-strings to format `CitedValue` (`f"{revenue:.1f}"`). Avoid `float()` before output because it loses the marker; `str()` preserves the current display without applying a numeric format.
- **Never narrate citation plumbing** — do not mention the citations module, `cite()`, `save_citations`, `load_citations`, PYEOF, "I'll cite this," "I need to wrap as claim," or any other mechanic-level description in your response prose. Talk about _what the numbers mean_, never _how they're cited_.

## Data Source Routing

### Decision Tree

Follow this order for EVERY public company question. Stop at the first source that answers it:

1. **`finance_company_financials`** — Standardized income statement, balance sheet, cash flow. Use for: revenue, net income, margins, EPS, debt, cash, inventory, capex, FCF, SBC, dividends, shares outstanding, tax rates, and any ratio derivable from these (ROE, D/E, inventory turnover, payout ratio, FCF margin, CAGR, etc.)
   - **International fallback**: For tickers not covered by the primary data provider (mostly non-US exchanges), the tool automatically falls back to an alternate source. When this happens, CSV column names may use camelCase (e.g. `revenue`, `netIncome`, `totalDebt`) instead of the standard snake_case names. Read the actual CSV headers — do not assume column names match the described schema.

2. **`finance_earnings_transcript`** — Earnings call transcripts contain FAR more than just EPS. Use for:
   - **Forward guidance**: revenue ranges, margin targets, capex plans, growth outlook
   - **Non-GAAP metrics**: adjusted EBITDA, non-GAAP gross margin, organic growth
   - **Company-specific KPIs**: ARPU, take rate, GBV, same-store sales, nights booked, loan originations, payment volume, retention rates, subscriber counts, ASMs/RPMs, load factor
   - **Beat/miss analysis**: comparing guidance from quarter N to actuals in quarter N+1
   - **Segment breakdowns**: revenue by geography, product line, or business unit
   - **Strategic commentary**: M&A rationale, restructuring progress, competitive dynamics
   - **Adjusted EBITDA reconciliations**: line-item adjustments from net income
   - **Management Q&A**: analyst questions often surface specific data points

3. **Web search** — Only after finance tools are insufficient. Required for:
   - 10-K/10-Q footnotes (debt maturity schedules, lease obligations, acquisition details)
   - Proxy statements (director compensation, board nominations, executive pay)
   - Prospectus/8-K filings (offering terms, convertible note details, M&A consideration)
   - Risk factor narratives
   - Employee headcount/geographic data
   - Channel/vendor concentration disclosures

### Rules

- Do NOT default to open-web retrieval (search tools, shell commands, URL fetches, scraping) for public company analysis
- ALWAYS try `finance_earnings_transcript` before any open-web retrieval — transcripts answer ~50% of questions that seem like they need filings
- For questions about guidance vs. actuals, pull transcripts from BOTH the guidance quarter and the results quarter
- For hybrid questions (e.g., take rate = revenue / GBV), combine `finance_company_financials` for standardized data with `finance_earnings_transcript` for company-specific KPIs

## Per-tool reference

### Reference Date → Parameter Mapping

| Tool                          | Parameter(s) from Reference Date                                                                                            |
| ----------------------------- | --------------------------------------------------------------------------------------------------------------------------- |
| `finance_quotes`             | None — only use when reference date is today. Use `finance_ohlcv_histories` for past dates                                 |
| `finance_ohlcv_histories`    | `end_date_yyyy_mm_dd` = reference date                                                                                      |
| `finance_company_financials` | `as_of_fiscal_year` (always required); `as_of_fiscal_quarter` (required for `period="quarter"`, omit for `period="annual"`) |
| `finance_earnings_transcript` | `as_of_fiscal_year`, `as_of_fiscal_quarter` (always required)                                                              |
| `finance_earnings_schedule`  | `as_of_fiscal_year`, `as_of_fiscal_quarter` (always required, unless using calendar date mode)                              |

### Ticker Lookup

Always resolve company names to tickers before fetching data using `finance_tickers_lookup`. Resolves company names, user-provided tickers, stocks, ETFs, indexes, commodities, and crypto. Handles format variations (BRK.B vs BRK-B) and partial/fuzzy names. Full support for international exchanges (.F, .L, .KS, etc.). Standard market tickers may not resolve correctly—always use this tool first.

#### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `queries` | `list[str]` | Yes | - | Array of search queries for any financial instrument. Pass through user's phrasing when possible. Example: for query 'what is the price of NVDA, Re... |

#### Examples

Connector tool: `finance_tickers_lookup`

```json
{
    "queries": [
        "Tesla"
    ]
}
```

Connector tool: `finance_tickers_lookup`

```json
{
    "queries": [
        "Apple",
        "Microsoft",
        "Meta"
    ]
}
```

**Handling ambiguity:** When lookup returns multiple results, present options to user or use context to disambiguate (e.g., "Meta the social media company" → META).

### Real-Time Quotes

Get current real-time quotes for stocks, cryptocurrencies, ETFs, or indices. Returns `csv_files` with one row per symbol containing only the requested fields.

**Only use `finance_quotes` when the reference date is today.** For past reference dates, use `finance_ohlcv_histories` to get the closing price as of that date.

**Extended hours:** `price`, `change`, and `changesPercentage` stay regular-session values. Use `afterHoursPrice`, `afterHoursChange`, and `afterHoursPercentChange` for the active premarket or after-hours session.

#### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `ticker_symbols` | `list[str]` | Yes | - | Array of ticker symbols from a prior tool call (prefer finance_tickers_lookup for ticker resolution). Examples: ["AAPL"], ["GOOGL", "META", "SNAP"]... |
| `fields` | `list[str]` | Yes | - | Required list of quote fields to include. Only request fields needed for the analysis. |

**Valid values:**

**`fields`** (QuoteField): `price`, `currency`, `change`, `changesPercentage`, `marketCap`, `pe`, `eps`, `volume`, `avgVolume`, `dayLow`, `dayHigh`, `yearLow`, `yearHigh`, `previousClose`, `open`, `dividendYieldTTM`, `afterHoursPrice`, `afterHoursChange`, `afterHoursPercentChange`

#### Examples

**Basic quote:**
Connector tool: `finance_quotes`

```json
{
    "ticker_symbols": [
        "AAPL"
    ],
    "fields": [
        "price",
        "change",
        "changesPercentage"
    ]
}
```

**Valuation snapshot:**
Connector tool: `finance_quotes`

```json
{
    "ticker_symbols": [
        "AAPL",
        "MSFT",
        "GOOGL"
    ],
    "fields": [
        "price",
        "marketCap",
        "pe",
        "eps",
        "dividendYieldTTM"
    ]
}
```

**Trading activity:**
Connector tool: `finance_quotes`

```json
{
    "ticker_symbols": [
        "AAPL"
    ],
    "fields": [
        "price",
        "volume",
        "avgVolume",
        "dayLow",
        "dayHigh"
    ]
}
```

### Historical Data (OHLCV)

Get historical price data for stocks, ETFs, crypto, or indices. Returns `csv_files` containing OHLCV (open, high, low, close, volume) for any date range. Use this for price history, candlestick charts, and as input for technical indicator calculations. Do NOT search for historical prices—this tool provides them directly.

**Always use the reference date as `end_date_yyyy_mm_dd`.** For past reference dates, this tool replaces `finance_quotes` for price lookups.

#### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `ticker_symbols` | `list[str]` | Yes | - | Array of ticker symbols from a prior tool call (prefer finance_tickers_lookup for ticker resolution). Examples: ["MSFT"], ["AAPL", "GOOGL", "MSFT"]... |
| `query` | `str` | Yes | - | Human-readable query describing what price history to fetch (e.g. "Apple stock price history" or "Compare AAPL and MSFT prices"). |
| `start_date_yyyy_mm_dd` | `str` | Yes | - | Start date in YYYY-MM-DD format (e.g. "2024-01-01"). |
| `end_date_yyyy_mm_dd` | `str` | Yes | - | End date in YYYY-MM-DD format (e.g. "2024-12-31"). |
| `time_interval` | `str` | No | None | Optional—omit this field to use daily bars for date ranges under 180 days, or monthly bars for longer ranges. Only specify if user explicitly reque... |
| `fields` | `list[str]` | Yes | - | Required list of OHLCV price fields to include in the CSV. Only request fields needed for the analysis. |
| `extended_hours` | `bool` | No | False | Set to true to include pre-market and after-hours trading data. Requires an explicit intraday time_interval. Only enable if the user specifically a... |

**Valid values:**

**`time_interval`** (time_interval): `1min`, `5min`, `15min`, `30min`, `1hour`, `4hour`, `1day`, `1week`, `1month`

**`fields`** (PriceField): `open`, `high`, `low`, `close`, `volume`

**`time_interval` values must match the enum exactly.** Common mistakes:

- `"weekly"` → use `"1week"`
- `"monthly"` → use `"1month"`
- `"daily"` → use `"1day"`
- `"hourly"` → use `"1hour"`

#### Date Formats

Use ISO format: `YYYY-MM-DD`

#### Examples

**Specific date range:**
Connector tool: `finance_ohlcv_histories`

```json
{
    "ticker_symbols": [
        "AAPL"
    ],
    "start_date_yyyy_mm_dd": "2024-01-01",
    "end_date_yyyy_mm_dd": "2024-06-30"
}
```

**Multiple tickers comparison:**
Connector tool: `finance_ohlcv_histories`

```json
{
    "ticker_symbols": [
        "AAPL",
        "MSFT",
        "GOOGL"
    ],
    "query": "Compare AAPL, MSFT, GOOGL prices",
    "start_date_yyyy_mm_dd": "2024-01-01",
    "end_date_yyyy_mm_dd": "2024-12-31",
    "fields": [
        "close"
    ]
}
```

**YTD performance:**
Connector tool: `finance_ohlcv_histories`

```json
{
    "ticker_symbols": [
        "SPY",
        "AAPL"
    ],
    "query": "SPY and AAPL YTD performance",
    "start_date_yyyy_mm_dd": "2024-01-01",
    "end_date_yyyy_mm_dd": "2024-12-31",
    "fields": [
        "close"
    ]
}
```

```
# Calculate: (current_close - first_close) / first_close * 100
```

**Volatility analysis:**

```python
# Fetch daily data, then calculate:
# - Daily returns: (close[i] - close[i-1]) / close[i-1]
# - Annualized volatility: std(daily_returns) * sqrt(252)
```

### ETF Holdings

Get ETF constituent holdings using `finance_etf_holdings`.

#### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `ticker_symbols` | `list[str]` | Yes | - | Array of ticker symbols from a prior tool call (prefer finance_tickers_lookup for ticker resolution). Examples: ["QQQ"], ["SPY", "IWM", "DIA"], ["A... |
| `ticker_names` | `list[str]` | Yes | - | Array of ETF names corresponding to ticker_symbols (e.g., ['KraneShares CSI China Internet ETF']). |
| `query` | `str` | Yes | - | The original user query requesting ETF holdings information. |

#### Examples

Connector tool: `finance_etf_holdings`

```json
{
    "ticker_symbols": [
        "SPY",
        "QQQ"
    ],
    "ticker_names": [
        "SPDR S&P 500 ETF",
        "Invesco QQQ Trust"
    ],
    "query": "What are the top holdings in SPY and QQQ?"
}
```

### Financial Statements

Fetch financial statements (income statement, balance sheet, cash flow) using `finance_company_financials`. Specify metrics by statement type—only statements with requested metrics are fetched.

#### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `ticker_symbols` | `list[str]` | Yes | - | Array of ticker symbols from a prior tool call (prefer finance_tickers_lookup for ticker resolution). Examples: ["MSFT"], ["JNJ", "PFE", "ABT"], ["... |
| `period` | `str` | Yes | - | Reporting period. |
| `as_of_fiscal_year` | `int` | No | None | The most recent fiscal year to include. Data goes backward from this year. Omit to use most recent available data. |
| `as_of_fiscal_quarter` | `int` | No | None | The most recent fiscal quarter to include (1-4). Data goes backward from this quarter. Only used with quarter period. |
| `limit` | `int` | No | 1 | Number of periods to fetch going backward from as_of_fiscal_year (or from most recent if omitted) |
| `income_statement_metrics` | `list[str]` | No | [] | Revenue, profitability, and earnings metrics. |
| `balance_sheet_metrics` | `list[str]` | No | [] | Assets, liabilities, and equity metrics. |
| `cash_flow_metrics` | `list[str]` | No | [] | Operating, investing, and financing cash flows. |

**Valid values:**

**`period`** (StatementPeriod): `annual`, `quarter`, `ttm`

**`income_statement_metrics`** (IncomeStatementFieldsV3): `income_statement_total_revenues`, `income_statement_cost_of_sales`, `income_statement_gross_profit`, `income_statement_selling_general_and_administrative_expenses`, `income_statement_general_and_administrative_expenses`, `income_statement_selling_and_marketing_expenses`, `income_statement_research_and_development_expenses`, `income_statement_operating_profit`, `income_statement_interest_income`, `income_statement_interest_expense`, `income_statement_income_before_provision_for_income_taxes`, `income_statement_provision_for_income_taxes`, `income_statement_consolidated_net_income`, `income_statement_net_income_attributable_to_minority_interests_and_other`, `income_statement_net_income_attributable_to_common_shareholders`, `income_statement_basic_eps`, `income_statement_diluted_eps`, `income_statement_basic_weighted_average_shares_outstanding`, `income_statement_diluted_weighted_average_shares_outstanding`, `income_statement_non_operating_income`, `income_statement_non_operating_income_or_expense`, `income_statement_benefits_and_claims`, `income_statement_compensation_expenses`, `income_statement_depreciation_and_amortization_expenses`, `income_statement_investment_expense`, `income_statement_investment_income`, `income_statement_net_gains_losses_on_investments`, `income_statement_net_income_attributable_to_discontinued_operations`, `income_statement_net_income_attributable_to_preferred_dividends`, `income_statement_net_interest_income`, `income_statement_net_premiums_earned`, `income_statement_non_interest_income`, `income_statement_other_non_interest_expenses`, `income_statement_other_operating_expenses`, `income_statement_other_revenues`, `income_statement_policy_amortization_costs`, `income_statement_provision_for_credit_losses`, `income_statement_total_non_interest_expense`, `income_statement_total_other_revenues`, `income_statement_total_revenues_after_provision_for_credit_losses`, `income_statement_total_revenues_before_provision_for_credit_losses`, `income_statement_transaction_based_revenues`, `ratio_gross_profit_margin`, `ratio_operating_margin`, `ratio_ebitda_margin`, `ratio_net_profit_margin`, `ratio_effective_tax_rate`, `ratio_pre_tax_profit_margin`

**`balance_sheet_metrics`** (BalanceSheetFieldsV3): `balance_sheet_cash_and_cash_equivalents`, `balance_sheet_short_term_investments`, `balance_sheet_accounts_receivable`, `balance_sheet_total_trade_receivables`, `balance_sheet_inventories`, `balance_sheet_other_current_assets`, `balance_sheet_total_current_assets`, `balance_sheet_net_property_plant_and_equipment`, `balance_sheet_goodwill`, `balance_sheet_net_intangible_assets`, `balance_sheet_long_term_investments`, `balance_sheet_other_non_current_assets`, `balance_sheet_other_non_earning_assets`, `balance_sheet_other_assets`, `balance_sheet_total_assets`, `balance_sheet_accounts_payable`, `balance_sheet_short_term_debt`, `balance_sheet_unearned_revenue`, `balance_sheet_other_current_liabilities`, `balance_sheet_total_current_liabilities`, `balance_sheet_long_term_debt`, `balance_sheet_other_long_term_liabilities`, `balance_sheet_total_long_term_liabilities`, `balance_sheet_other_liabilities`, `balance_sheet_total_liabilities`, `balance_sheet_preferred_stock`, `balance_sheet_common_stock`, `balance_sheet_retained_earnings`, `balance_sheet_accumulated_other_comprehensive_income`, `balance_sheet_total_shareholders_equity`, `balance_sheet_total_common_shareholders_equity`, `balance_sheet_total_investments`, `balance_sheet_total_debt`, `balance_sheet_total_cash_and_cash_equivalents`, `balance_sheet_total_liabilities_and_shareholders_equity`, `balance_sheet_accrued_expenses`, `balance_sheet_additional_paid_in_capital`, `balance_sheet_current_portion_of_leases`, `balance_sheet_leases`, `balance_sheet_other_long_term_assets`, `balance_sheet_accrued_interest_and_accounts_receivable`, `balance_sheet_claims_reserves`, `balance_sheet_current_portion_of_long_term_debt`, `balance_sheet_debt_securities`, `balance_sheet_deferred_acquisition_costs`, `balance_sheet_equity_and_preferred_securities`, `balance_sheet_gross_loans`, `balance_sheet_interest_bearing_deposits`, `balance_sheet_less_allowance_for_loan_losses`, `balance_sheet_minority_interests_and_other`, `balance_sheet_net_loans`, `balance_sheet_noninterest_bearing_deposits`, `balance_sheet_other_investments`, `balance_sheet_other_receivables`, `balance_sheet_recontract_assets`, `balance_sheet_restricted_cash_and_segregated_assets`, `balance_sheet_securities_and_investments`, `balance_sheet_securities_borrowed`, `balance_sheet_securities_loaned`, `balance_sheet_short_term_borrowings`, `balance_sheet_short_term_interbank_borrowing_and_repurchase_agreements`, `balance_sheet_short_term_interbank_lending_and_reverse_repurchase_agreements`, `balance_sheet_total_deposits`, `balance_sheet_trading_assets`, `balance_sheet_trading_liabilities`, `balance_sheet_treasury_stock`, `balance_sheet_unearned_premiums`

**`cash_flow_metrics`** (CashFlowFieldsV3): `cash_flow_statement_net_income`, `cash_flow_statement_depreciation_and_amortization`, `cash_flow_statement_share_based_compensation_expense`, `cash_flow_statement_other_adjustments`, `cash_flow_statement_changes_in_trade_receivables`, `cash_flow_statement_changes_in_accounts_payable`, `cash_flow_statement_changes_in_accrued_expenses`, `cash_flow_statement_changes_in_unearned_revenue`, `cash_flow_statement_changes_in_other_operating_activities`, `cash_flow_statement_cash_from_operating_activities`, `cash_flow_statement_purchases_of_property_plant_and_equipment`, `cash_flow_statement_proceeds_from_sale_of_property_plant_and_equipment`, `cash_flow_statement_purchases_of_investments`, `cash_flow_statement_proceeds_from_sale_of_investments`, `cash_flow_statement_payments_for_business_acquisitions`, `cash_flow_statement_other_investing_activities`, `cash_flow_statement_cash_from_investing_activities`, `cash_flow_statement_issuance_of_long_term_debt`, `cash_flow_statement_repayments_of_long_term_debt`, `cash_flow_statement_net_issuance_or_repayments_of_long_term_debt`, `cash_flow_statement_issuance_of_common_shares`, `cash_flow_statement_repurchases_of_common_shares`, `cash_flow_statement_net_issuance_or_repurchases_of_common_shares`, `cash_flow_statement_issuance_of_preferred_shares`, `cash_flow_statement_net_issuance_or_repurchases_of_preferred_shares`, `cash_flow_statement_common_share_dividends_paid`, `cash_flow_statement_other_financing_activities`, `cash_flow_statement_cash_from_financing_activities`, `cash_flow_statement_effect_of_exchange_rate_changes_on_cash_and_cash_equivalents`, `cash_flow_statement_increase_or_decrease_in_cash_cash_equivalents_and_restricted_cash`, `cash_flow_statement_cash_cash_equivalents_and_restricted_cash_at_beginning_of_period`, `cash_flow_statement_changes_in_accrued_interest_and_accounts_receivable`, `cash_flow_statement_changes_in_claims_reserves`, `cash_flow_statement_changes_in_deferred_acquisition_costs`, `cash_flow_statement_changes_in_income_taxes_payable`, `cash_flow_statement_changes_in_inventories`, `cash_flow_statement_changes_in_receivables`, `cash_flow_statement_changes_in_recontract_assets`, `cash_flow_statement_changes_in_restricted_cash_and_segregated_assets`, `cash_flow_statement_changes_in_securities_borrowed`, `cash_flow_statement_changes_in_trading_assets`, `cash_flow_statement_changes_in_trading_liabilities`, `cash_flow_statement_changes_in_unearned_premiums`, `cash_flow_statement_issuance_of_short_term_debt`, `cash_flow_statement_net_change_in_deposits`, `cash_flow_statement_net_change_in_loans_held_for_investment`, `cash_flow_statement_net_change_in_loans_held_for_sale`, `cash_flow_statement_net_change_in_securities_and_investments`, `cash_flow_statement_net_change_in_short_term_interbank_borrowing_and_repurchase_agreements`, `cash_flow_statement_net_change_in_short_term_interbank_lending_and_reverse_repurchase_agreements`, `cash_flow_statement_net_issuance_or_repayments_of_short_term_debt`, `cash_flow_statement_preferred_share_dividends_paid`, `cash_flow_statement_proceeds_from_business_divestments`, `cash_flow_statement_purchases_of_intangible_assets`, `cash_flow_statement_repayments_of_short_term_debt`, `cash_flow_statement_repurchases_of_preferred_shares`

**Metric names must match the enum exactly.** Common mistakes:

- `weightedAverageShsOut` → use `weightedAverageSharesOutstanding`
- `weightedAverageShsOutDil` → use `weightedAverageSharesOutstandingDiluted`
- `accountPayables` → use `accountsPayables`
- `dividendsPaid` → use `netDividendsPaid`, `commonDividendsPaid`, or `preferredDividendsPaid`

#### Field Formats

- Ratio fields (`ebitdaRatio`, etc.) are decimals: 0.65 = 65%
- `eps`/`epsDiluted` are currency per share: 0.39 = $0.39
- `weightedAverageSharesOutstanding` fields are raw counts
- All other numeric fields are raw currency in `reportedCurrency` (not abbreviated)

#### Examples

**Current Data (always pass as_of from reference date):**
Connector tool: `finance_company_financials`

```json
{
    "ticker_symbols": [
        "TSLA"
    ],
    "period": "quarter",
    "as_of_fiscal_year": 2025,
    "as_of_fiscal_quarter": 1,
    "limit": 1,
    "income_statement_metrics": [
        "income_statement_total_revenues"
    ]
}
```

**Apple's last 5 years FCF:**
Connector tool: `finance_company_financials`

```json
{
    "ticker_symbols": [
        "AAPL"
    ],
    "period": "annual",
    "as_of_fiscal_year": 2025,
    "limit": 5,
    "cash_flow_metrics": [
        "cash_flow_statement_cash_from_operating_activities",
        "cash_flow_statement_purchases_of_property_plant_and_equipment"
    ]
}
```

**Historical Data (as_of from explicit past reference date):**
Connector tool: `finance_company_financials`

```json
{
    "ticker_symbols": [
        "RIVN"
    ],
    "period": "quarter",
    "as_of_fiscal_year": 2023,
    "as_of_fiscal_quarter": 3,
    "limit": 4,
    "income_statement_metrics": [
        "income_statement_total_revenues"
    ]
}
```

**Cross-Statement:**
Connector tool: `finance_company_financials`

```json
{
    "ticker_symbols": [
        "AAPL"
    ],
    "period": "annual",
    "as_of_fiscal_year": 2025,
    "limit": 1,
    "income_statement_metrics": [
        "income_statement_consolidated_net_income"
    ],
    "balance_sheet_metrics": [
        "balance_sheet_cash_and_cash_equivalents"
    ],
    "cash_flow_metrics": [
        "cash_flow_statement_cash_from_operating_activities"
    ]
}
```

**TTM (Trailing Twelve Months):**
Connector tool: `finance_company_financials`

```json
{
    "ticker_symbols": [
        "NVDA"
    ],
    "period": "ttm",
    "income_statement_metrics": [
        "income_statement_gross_profit"
    ]
}
```

**Growth Calculations (fetch multiple periods to compare):**
Connector tool: `finance_company_financials`

```json
{
    "ticker_symbols": [
        "AAPL"
    ],
    "period": "annual",
    "as_of_fiscal_year": 2025,
    "limit": 2,
    "income_statement_metrics": [
        "income_statement_total_revenues"
    ]
}
```

```
# Calculate: (current - previous) / previous
```

**Derived Metrics (fetch component fields for calculation):**
Connector tool: `finance_company_financials`

```json
{
    "ticker_symbols": [
        "AAPL"
    ],
    "period": "quarter",
    "as_of_fiscal_year": 2025,
    "as_of_fiscal_quarter": 1,
    "limit": 1,
    "balance_sheet_metrics": [
        "balance_sheet_total_debt",
        "balance_sheet_total_shareholders_equity"
    ]
}
```

```
# Calculate: balance_sheet_total_debt / balance_sheet_total_shareholders_equity
```

### Earnings Transcripts

Get earnings call transcripts using `finance_earnings_transcript`.

#### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `ticker_symbol` | `str` | Yes | - | Ticker symbol from a prior tool call (prefer finance_tickers_lookup for ticker resolution). Examples: 'NVDA', 'AMZN', 'META'. |
| `query` | `str` | Yes | - | Human-readable description of the earnings data request |
| `as_of_fiscal_quarter` | `int` | No | None | The most recent fiscal quarter to include (1-4). Data goes backward from this quarter. |
| `as_of_fiscal_year` | `int` | No | None | The most recent fiscal year to include. Data goes backward from this year. Omit to use most recent available data. |
| `limit` | `int` | No | 1 | Number of earnings periods to fetch going backward from as_of period (or from most recent if omitted) |
| `return_full_transcript` | `bool` | No | False | If true, writes every verbatim transcript row to the CSV instead of only the LLM-selected rows. |

#### Transcript citations

When the result has a non-empty `csv_files` list, cite the key transcript evidence you select. Claim links must wrap the evidence directly, but should occupy only a small part of the prose; do not append a source-style link after the sentence.

- For a normal summary, select **at most six** decision-relevant transcript takeaways total, usually one or two per topic the user named; count each evidence-bearing paragraph or bullet as one takeaway. Cover only the requested topics—do not add adjacent transcript discoveries as extra sections. More relevant rows in the CSV are not a reason to add more bullets. Expand past six only when the user explicitly asks for a comprehensive extraction or enumerates more than six specific claims.
- Decide the answer's takeaways before calling `cite()`, then register only the evidence that will appear. Citation coverage is not a completeness checklist: do not bulk-register candidate rows or lengthen the answer merely to use available claims.
- In each takeaway, cite its timestamp and the shortest useful evidence phrase. Prefer one non-numeric evidence marker; add another only when it supports a materially distinct claim the user requested. When a cited numeric value already supplies the evidence, generally do not add a separate non-numeric marker. Numeric values still follow the general rule above.
- Keep a non-numeric marker to a short phrase or single clause—normally 3–10 words. If it would be longer, select the smallest exact fragment that still supports the claim; never wrap a complete sentence or paragraph unless the user explicitly asks for that exact quotation. Keep speaker names, headings, connective prose, and your synthesis outside claim links.
- Put quotation marks around every verbatim transcript excerpt so copied language is visibly distinct from your synthesis. Keep the quotation marks outside the claim link so the linked text remains the exact evidence span. Leave paraphrases and numeric values unquoted unless they are part of a direct quotation.
- Pass the exact displayed evidence span to `cite()` and keep its marker directly around that span. Never cite a synthetic source note such as `earnings call passage`, `Data Center commentary`, or `Q&A source`.
- One CSV `text` cell may support multiple distinct claims. Call `cite()` once per selected claim with a unique human-readable `name`; those calls may reuse the same `file`, `metadata_s3_key`, `row_key`, and `col="text"`.
- Cite a displayed timestamp from `col="timestamp"`. Cite short quote fragments and transcript-grounded assertions from `col="text"`.
- Write the surrounding sentence as ordinary prose and insert only the cited values emitted by the script.

```python
row_key = row["transcript_position"]
timestamp = cite(row["timestamp"], "Call timestamp", source="finance_earnings_transcript", file=csv_filename, metadata_s3_key=metadata_s3_key, row_key=row_key, col="timestamp")
q3_start = cite("start in Q3", "Q3 production start", source="finance_earnings_transcript", file=csv_filename, metadata_s3_key=metadata_s3_key, row_key=row_key, col="text")
q4_ramp = cite("ramping would continue in Q4", "Q4 production ramp", source="finance_earnings_transcript", file=csv_filename, metadata_s3_key=metadata_s3_key, row_key=row_key, col="text")
purchase_orders = cite("POs were already in hand", "Purchase-order status", source="finance_earnings_transcript", file=csv_filename, metadata_s3_key=metadata_s3_key, row_key=row_key, col="text")

print(f'In Q&A at {timestamp}, management said production would “{q3_start},” expected “{q4_ramp},” and noted that “{purchase_orders}.”')
# → In Q&A at [55m 9s](claim:1), management said production would “[start in Q3](claim:2),” expected “[ramping would continue in Q4](claim:3),” and noted that “[POs were already in hand](claim:4).”
```

**Incorrect:**

```text
In Q&A at 55m 9s, management discussed production timing ([ramp passage](claim:2)).

Management said production would [start in Q3](claim:2).

Management said "[Once we get to Q4, we're probably going to start to see our ramping continue, and we already have demand planned with purchase orders from almost every major customer](claim:2)."
```

#### Examples

**Current Data (always pass as_of from reference date):**
Connector tool: `finance_earnings_transcript`

```json
{
    "ticker_symbol": "TSLA",
    "as_of_fiscal_year": 2025,
    "as_of_fiscal_quarter": 1,
    "limit": 1,
    "return_full_transcript": true
}
```

**Apple's last 3 earnings calls:**
Connector tool: `finance_earnings_transcript`

```json
{
    "ticker_symbol": "AAPL",
    "as_of_fiscal_year": 2025,
    "as_of_fiscal_quarter": 1,
    "limit": 3,
    "return_full_transcript": true
}
```

**Historical Data (as_of from explicit past reference date):**
Connector tool: `finance_earnings_transcript`

```json
{
    "ticker_symbol": "MSFT",
    "as_of_fiscal_year": 2024,
    "as_of_fiscal_quarter": 4,
    "limit": 1,
    "return_full_transcript": true
}
```

**Google earnings from 2022 back 4 quarters:**
Connector tool: `finance_earnings_transcript`

```json
{
    "ticker_symbol": "GOOGL",
    "as_of_fiscal_year": 2022,
    "as_of_fiscal_quarter": 4,
    "limit": 4,
    "return_full_transcript": true
}
```

### Earnings History

Get historical earnings actuals vs consensus estimates, beat/miss data, and post-earnings price moves using `finance_earnings_history` (returns `csv_files`).

#### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `ticker_symbols` | `list[str]` | Yes | - | Array of ticker symbols from a prior tool call (prefer finance_tickers_lookup for ticker resolution). Examples: ["AAPL"], ["NFLX", "DIS", "WBD"], [... |
| `period_type` | `str` | No | 'quarterly' | Reporting period. |
| `as_of_fiscal_quarter` | `int` | No | None | The most recent fiscal quarter to include (1-4). Data goes backward from this quarter. |
| `as_of_fiscal_year` | `int` | No | None | The most recent fiscal year to include. Data goes backward from this year. Omit to use most recent available data. |
| `limit` | `int` | No | 8 | How many prior reporting periods to return, going backward from the as_of period. |

#### Examples

**Earnings Metrics:**
Connector tool: `finance_earnings_history`

```json
{
    "ticker_symbols": [
        "AAPL"
    ],
    "period_type": "quarterly",
    "limit": 8
}
```

### Earnings Schedule

Look up earnings release dates and reporting status using `finance_earnings_schedule`. Always pass `as_of_fiscal_year`/`as_of_fiscal_quarter` derived from the reference date, except in calendar date mode (`start_date`/`end_date`).

#### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `ticker_symbols` | `list[str]` | No | [] | Array of ticker symbols from a prior tool call (prefer finance_tickers_lookup for ticker resolution). Examples: ["MSFT"], ["GOOGL", "META", "SNAP"]... |
| `direction` | `str` | No | None | Historical or future earnings dates. Omit when using date range or fiscal period filters. |
| `start_date` | `str` | No | None | Start of date range (YYYY-MM-DD). Use for calendar-based queries like 'this week' or 'next month'. |
| `end_date` | `str` | No | None | End of date range (YYYY-MM-DD). Use with start_date for calendar-based queries. |
| `as_of_fiscal_year` | `int` | No | None | Fiscal year to look up. Use for period-based queries like 'Q4 2024'. |
| `as_of_fiscal_quarter` | `int` | No | None | Fiscal quarter to look up (1-4). Use with as_of_fiscal_year for specific quarter queries. |
| `limit` | `int` | No | 1 | Number of earnings events to return per ticker. Use >1 for queries like 'last 4 quarters'. |

**Mode rules:** Calendar date mode (`start_date`/`end_date`) and fiscal period mode (`as_of_fiscal_year`/`as_of_fiscal_quarter`) are mutually exclusive. Omit both for default behavior (next upcoming + most recent past).

#### Examples

**Calendar (all companies in date range):**
Connector tool: `finance_earnings_schedule`

```json
{
    "ticker_symbols": [],
    "start_date": "2025-02-03",
    "end_date": "2025-02-07"
}
```

**Ticker + Date Range:**
Connector tool: `finance_earnings_schedule`

```json
{
    "ticker_symbols": [
        "AAPL"
    ],
    "start_date": "2025-02-01",
    "end_date": "2025-02-28"
}
```

**Ticker + Fiscal Period:**
Connector tool: `finance_earnings_schedule`

```json
{
    "ticker_symbols": [
        "AAPL"
    ],
    "as_of_fiscal_year": 2024,
    "as_of_fiscal_quarter": 4
}
```

**Default (next upcoming + most recent past):**
Connector tool: `finance_earnings_schedule`

```json
{
    "ticker_symbols": [
        "AAPL"
    ],
    "as_of_fiscal_year": 2025,
    "as_of_fiscal_quarter": 1
}
```

**Use cases:**

- "When does AAPL report?" → default mode with ticker
- "Earnings this week" → calendar mode with empty ticker list
- "Did NVDA already report Q3?" → fiscal period mode
- "Last 4 quarters of MSFT earnings dates" → default mode with limit=4

For earnings transcripts, use `finance_earnings_transcript`. For EPS history and beat/miss metrics, use `finance_earnings_history`.

### Macro Snapshot

Get the latest values for macroeconomic indicators by country using `finance_macro_snapshot`: GDP, inflation, unemployment, interest rates, trade balances, housing, and hundreds of other series from an offline macro dataset. Each row is one (country, indicator) series with the latest value, previous value, unit, and source attribution. Returns `csv_files` keyed by `series_id`.

Keywords match indicator names fuzzily — `"gdp"` matches "GDP Growth Rate", "GDP per capita", etc. Start broad to discover what series exist for a country, then narrow.

Do NOT retrieve macro indicator values from the open web — this tool returns structured, source-attributed data.

#### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `countries` | `list[str]` | No | None | Country names (e.g. ['United States', 'Japan', 'Germany']). Use full English names. Case-insensitive. Required unless keywords is set. |
| `keywords` | `list[str]` | No | None | Search terms to filter indicators by name (e.g. ['GDP', 'inflation', 'bond yield', 'interest rate']). Each keyword is matched against indicator nam... |
| `action` | `str` | No | '' | Brief description of what you are looking up and why. |

#### Examples

**Latest indicator values:**
Connector tool: `finance_macro_snapshot`

```json
{
    "countries": [
        "United States"
    ],
    "keywords": [
        "inflation rate",
        "unemployment rate"
    ]
}
```

**Cross-country comparison:**
Connector tool: `finance_macro_snapshot`

```json
{
    "countries": [
        "United States",
        "China",
        "Germany"
    ],
    "keywords": [
        "gdp growth rate"
    ]
}
```

### Macro History

Get the historical time series for macroeconomic indicators using `finance_macro_history`. Returns one CSV per (country, indicator) series, keyed by `date`, for trends and charts. Use `finance_macro_snapshot` first to discover the exact indicator names, then fetch history with the same country and keyword.

#### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `countries` | `list[str]` | Yes | - | Country names (e.g. ['United States', 'Canada']). Use full English names. Case-insensitive. |
| `keywords` | `list[str]` | Yes | - | Search terms to filter indicators by name (e.g. ['GDP', 'inflation', 'unemployment']). Each keyword is matched fuzzily against indicator names. Use... |
| `start_date_yyyy_mm_dd` | `str` | No | None | Start date in YYYY-MM-DD format (e.g. '2010-01-01'). |
| `end_date_yyyy_mm_dd` | `str` | No | None | End date in YYYY-MM-DD format (e.g. '2023-12-31'). |
| `action` | `str` | No | '' | Brief description of what you are looking up and why. |

#### Examples

**Multi-country trend:**
Connector tool: `finance_macro_history`

```json
{
    "countries": [
        "United States",
        "China"
    ],
    "keywords": [
        "gdp growth rate"
    ],
    "start_date_yyyy_mm_dd": "2021-01-01"
}
```

## Quick Reference

### Get current quote

Connector tool: `finance_quotes`

```json
{
    "ticker_symbols": [
        "AAPL",
        "MSFT",
        "GOOGL"
    ],
    "fields": [
        "price",
        "marketCap",
        "pe",
        "eps",
        "dividendYieldTTM"
    ]
}
```

### Get historical data

Connector tool: `finance_ohlcv_histories`

```json
{
    "ticker_symbols": [
        "AAPL"
    ],
    "start_date_yyyy_mm_dd": "2024-01-01",
    "end_date_yyyy_mm_dd": "2024-06-30"
}
```

### Get recent financial data (always pass as_of from reference date)

Connector tool: `finance_company_financials`

```json
{
    "ticker_symbols": [
        "TSLA"
    ],
    "period": "quarter",
    "as_of_fiscal_year": 2025,
    "as_of_fiscal_quarter": 1,
    "limit": 1,
    "income_statement_metrics": [
        "income_statement_total_revenues"
    ]
}
```

### Get historical financial data

Connector tool: `finance_company_financials`

```json
{
    "ticker_symbols": [
        "RIVN"
    ],
    "period": "quarter",
    "as_of_fiscal_year": 2023,
    "as_of_fiscal_quarter": 3,
    "limit": 4,
    "income_statement_metrics": [
        "income_statement_total_revenues"
    ]
}
```

### Get derived financial metrics

Connector tool: `finance_company_financials`

```json
{
    "ticker_symbols": [
        "AAPL"
    ],
    "period": "annual",
    "as_of_fiscal_year": 2025,
    "limit": 1,
    "income_statement_metrics": [
        "income_statement_consolidated_net_income"
    ],
    "balance_sheet_metrics": [
        "balance_sheet_cash_and_cash_equivalents"
    ],
    "cash_flow_metrics": [
        "cash_flow_statement_cash_from_operating_activities"
    ]
}
```

### Get recent earnings transcript (always pass as_of from reference date)

Connector tool: `finance_earnings_transcript`

```json
{
    "ticker_symbol": "TSLA",
    "as_of_fiscal_year": 2025,
    "as_of_fiscal_quarter": 1,
    "limit": 1,
    "return_full_transcript": true
}
```

### Get historical earnings transcript

Connector tool: `finance_earnings_transcript`

```json
{
    "ticker_symbol": "MSFT",
    "as_of_fiscal_year": 2024,
    "as_of_fiscal_quarter": 4,
    "limit": 1,
    "return_full_transcript": true
}
```

### Get earnings beat/miss history

Connector tool: `finance_earnings_history`

```json
{
    "ticker_symbols": [
        "AAPL"
    ],
    "period_type": "quarterly",
    "limit": 8
}
```

### Get earnings schedule (always pass as_of from reference date)

Connector tool: `finance_earnings_schedule`

```json
{
    "ticker_symbols": [
        "AAPL"
    ],
    "as_of_fiscal_year": 2025,
    "as_of_fiscal_quarter": 1
}
```

Connector tool: `finance_earnings_schedule`

```json
{
    "ticker_symbols": [],
    "start_date": "2025-02-03",
    "end_date": "2025-02-07"
}
```

Connector tool: `finance_earnings_schedule`

```json
{
    "ticker_symbols": [
        "AAPL"
    ],
    "as_of_fiscal_year": 2024,
    "as_of_fiscal_quarter": 4
}
```

### Get ETF holdings

Connector tool: `finance_etf_holdings`

```json
{
    "ticker_symbols": [
        "SPY",
        "QQQ"
    ],
    "ticker_names": [
        "SPDR S&P 500 ETF",
        "Invesco QQQ Trust"
    ],
    "query": "What are the top holdings in SPY and QQQ?"
}
```

### Get institutional holders

Connector tool: `finance_institutional_holders`

```json
{
    "ticker_symbols": [
        "AAPL"
    ]
}
```

### Get insider transactions

Connector tool: `finance_insider_transactions`

```json
{
    "ticker_symbols": [
        "NVDA"
    ],
    "months_lookback": 3
}
```

### Get latest macro indicators

Connector tool: `finance_macro_snapshot`

```json
{
    "countries": [
        "United States"
    ],
    "keywords": [
        "inflation rate",
        "unemployment rate"
    ]
}
```

### Get macro indicator history

Connector tool: `finance_macro_history`

```json
{
    "countries": [
        "United States",
        "China"
    ],
    "keywords": [
        "gdp growth rate"
    ],
    "start_date_yyyy_mm_dd": "2021-01-01"
}
```