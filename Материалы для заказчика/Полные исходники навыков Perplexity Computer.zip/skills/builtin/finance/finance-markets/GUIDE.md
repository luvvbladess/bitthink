# Finance Markets


## How to call finance tools — read first

**IMPORTANT:** The `finance_*` tools are **NOT in your tool list** and will never appear there directly. They are reached through the connector bridge. Do **NOT** conclude finance tools are unavailable just because you do not see `finance_*` in your tools — that is expected. To use them:

1. `list_external_tools` with `queries=["select:finance"]` — discover available finance tools.
2. `describe_external_tools` with `source_id="finance"` and `tool_names=[...]` — fetch schemas (required before calling).
3. `call_external_tool` with `tool_name="finance_quotes"`, `source_id="finance"`, and `arguments={...}` — execute.

Always use `source_id="finance"`. Full catalog, parameters, and examples live in `default-tools.md`.


## Bootstrap


Run two calls (parallelizable):



- `memory_search` with `query="finance provider preference"` — look up any saved cross-session preference.
- `list_external_tools` with `queries=["select:finance", "factset", "daloopa", "morningstar", "carbonarc"]` — list available BYOL providers.



The list result includes a `load_skill(name="finance")` hint for supported finance providers. The parent bundle is already loaded; **read the matching provider guide under `skills/finance/<provider>/GUIDE.md` before calling that provider's tools**. If memory returned a preferred provider that is among the hinted source_ids, prefer that one.

If no connector skill is hinted and no provider preference is saved, **silently** use Perplexity's default `finance_*` tools — just answer the question. Do **not** narrate the choice, do **not** mention which providers are connected or disconnected, and do **not** supplement with any open-web retrieval (search tools, shell commands, URL fetches, scraping). Read `default-tools.md` for the full catalog and execution patterns.


The default tools are also fine for explicit data gaps that a connected provider does not cover, but they are **not a substitute** for connecting (or re-connecting, if status is `OUTDATED`) to a *preferred* provider — when memory or the user has flagged a provider as preferred and it is unavailable, surface the connect/reconnect step instead of silently falling back to the default tools.

If the user expresses a cross-session provider preference (e.g. "always use Factset for finance"), call `memory_update` to persist it.

## Stock screening and ranking


If `list_external_tools` returns `finance_stock_screener`, use it when no

purpose-built finance tool directly supports the requested universe and metric,
or the query would benefit from analysis and/or direct reporting across the
full available public-stock universe. This includes top/bottom-N companies by
market cap, valuation, growth, income, sector, or another fundamental metric.

Before describing or calling the tool, read

`skills/finance/finance-stock-screener/GUIDE.md` and follow its schema discovery
and analysis workflow. Report the requested screener values and findings
directly in the answer. Treat the returned CSV as citation provenance; do not
share or re-upload it unless the user explicitly asks for a file. Do not re-query
purpose-built tools solely to display values already returned by the screener.
Do not guess table names, columns, or a candidate ticker list and rank it with
`finance_quotes`; that does not screen the full available universe.

Purpose-built universe tools win when they directly answer the request: use
`finance_market_gainers`, `finance_market_losers`, or
`finance_market_most_active` for those current market rankings, and use
`finance_etf_holdings` when the user explicitly defines an ETF's holdings as the
universe. Continue to use the purpose-built default tools for a single named
ticker or a user-provided fixed ticker list when they can answer the question
directly. If neither a purpose-built tool nor `finance_stock_screener` can
satisfy the requested screen, do not guess a candidate ticker list; explain
that full-universe screening is unavailable.

## SEC/EDGAR filings

For facts that live in SEC/EDGAR filings — officers and directors, board nominees, executive/director compensation, audit fees, M&A and securities terms, proxy (DEF 14A), 8-K, 10-K/10-Q disclosures — do a filing search rather than answering from memory; these are point-in-time and filing-grounded. Use the built-in `finance_*` tools and the company's filings/IR data — never state these facts from training data. For post-filing news or events (e.g. a deal's status after a ruling), use web search, not a filing search.

## Private / Pre-IPO Company Data


For private or pre-IPO company price, valuation, funding/fundraising history, capital or total raised, how-much-raised, rounds-raised, or funding/financing questions, use the built-in `finance_private_company_info` tool from `source_id="finance"` after `describe_external_tools`. It returns citable CSV files for Forge private markets data: company profile and latest pricing, historical evaluated prices, funding rounds, and public marks. Treat this tool as the source of record rather than open-web search or URL fetches. Cite values from its CSV files with the same `cite()` flow as other default finance tools, and attribute private-market price, valuation, and funding data to Forge Global in the final answer.


Positive examples: "What is Stripe's latest secondary-market valuation?", "Show Perplexity funding rounds and recent public marks.", "Anthropic fundraising history", "OpenAI capital raised to date", "How much has Databricks raised?", "Which rounds has Perplexity raised?"


Use it only for company-specific private-market lookups. Do **not** use it for public tickers, the user's brokerage portfolio, broad venture/private-market commentary, or open-web estimates. If `list_external_tools` or `describe_external_tools` does not show `finance_private_company_info`, do not mention Forge; answer with the available finance tools or state that private-company data is unavailable.


## Sibling reference files (read on demand)

- `default-tools.md` — the default `finance_*` tool catalog, parameters, examples, and full citation mechanic. Required reading before calling any default finance tool.
- `analysis.md` — DataFrame / calculation patterns (ratios, comparable analysis, DCF, statistical analysis).
- `reporting.md` — formatting, tables, chart recommendations, and report templates.
- `website-building.md` — finance-specific guidance for dashboards, reports with embedded charts, and other web output; also load the canonical `website-building` skill.

## Gotchas

- Market-calendar packages (`pandas_market_calendars`, `exchange_calendars`, `yfinance`) are optional in cron/scheduled finance tasks. If unavailable, or even if the task names one and import fails, use finance/tool data or another market-status source instead of `wake_parent`/`system_diagnostic`.
- `finance_stock_screener` returns a bounded inline preview and `csv_files` for citation provenance. Cite every displayed `symbol` cell and every numeric value from the final analytical result. Never cite schema-discovery or discarded intermediate query outputs, and do not share or re-upload the CSV unless the user explicitly requests a file.

## Citations

**Before any default `finance_*` call, read `skills/finance/finance-markets/default-tools.md` with the read tool and follow its Citations section as the source of truth.**

## Scope

- **Do NOT** use these tools for the user's own brokerage portfolio, balances, or transactions — that is `personal-finance`.
- **Do NOT** fall back to open-web retrieval (search tools, shell commands, URL fetches, scraping) for price or fundamental data — finance providers return structured, point-in-time accurate data; the open web does not.