# Intuition visuals — illustrative explainers, teaching animations, steppers

The *teach* family. Illustrative explainers (metaphor + motion that show how a concept works), sliders and toggles that parameterize a visual, cursor-driven visuals where pointer position changes model state, cycle steppers that click through stages, D3 simulations driven by `requestAnimationFrame`.

For routing by verb (when is something an illustrative explainer vs a reference diagram) see SKILL.md § "Route on the verb, not the noun".

## Visual metaphor — the illustrative shape

When the subject is an abstract mechanism rather than a physical object, reach for a visual metaphor: a spatial representation that *feels* like the concept. The goal is the mental model, not the precise implementation. A metaphor should look nothing like a flowchart — find the spatial shape load-bearing for the idea.

Shapes that often land:

| Shape | Example |
|---|---|
| Physical object spatialized | Hash table as a funnel scattering keys into N buckets |
| Process as motion | Gradient descent as a ball rolling down a loss surface |
| Intensity via spatial attribute | Attention as a fan of lines from one token, line opacity = weight |
| Flow between endpoints | TCP as two people passing numbered envelopes, an ACK returning |
| Stack / layers | Embeddings as a column of tokens lighting up through stacked layers |
| Containment with state | Event loop as queues feeding a worker, each with its own backlog |

If you catch yourself drawing "embedding → attention → FFN" labeled boxes in response to *"how does X work"*, you've defaulted to structural and missed the intuition. For abstract mechanisms, metaphor first. The metaphor should be drawable from memory — if it takes more than ~60 lines of SVG, simplify the metaphor rather than add detail.

### Illustrative with motion — the metaphor moves

Use motion only when it reveals mechanism. A one-shot animation of a mark moving across a metaphor is rarely enough; prefer controls, state, or a visual surface the user can inspect or replay to observe and comprehend the mechanism. CSS keyframes on `transform`/`opacity` are fine for small replayable motions; use `requestAnimationFrame` for anything that reads live state.

## What belongs inline vs. deploy_website

Apply SKILL.md § "Routing — widget or web app?" before writing interactive code. Use this module for bounded teaching interactions: parameter sliders, toggles, pointer interactions that change visual/model state, cycle steppers, and simulations where motion teaches the mechanism. Use `deploy_website` for stateful tools, sims, and games whose accumulated state is the artifact.

## Scripted behavior — the basics

- `<script>` runs once at stream end (not mid-stream); read `window.visualization.data` for structured state passed via the `data` field of the tool call.
- **Native HTML controls work** — `<input type="range">`, `<input type="checkbox">`, `<button>`, `<select>`. Place them in a `<div>` below the SVG, wire with `addEventListener('input', ...)` / `('change', ...)`.
- **Mouse / pointer interaction.** Listen for `mousemove` / `click` / `mouseleave` / `pointerdown` on the root `<svg>` for live hover effects, drag, and pointer-driven layout changes. Highlighted cell / nearest-point / cursor-as-data-source patterns all work.
- **Simulations that teach.** `requestAnimationFrame` is for *showing how a system behaves* — a gradient-descent ball rolling, particles flowing through a pipe, attention weights pulsing. Mutate existing SVG attributes (`setAttribute('cx', x)`, `selection.attr('d', ...)`) instead of re-rendering the DOM wholesale — morphdom doesn't own scripted content but re-renders still cost.
- **Respect reduced motion.** Gate continuous animation with `@media (prefers-reduced-motion: no-preference)` for CSS or `matchMedia('(prefers-reduced-motion: reduce)')` for script loops. A `while`-loop rAF without the query is a reader-hostile default.

## Interactive cutaway

When a physical system has one real control, make the widget a cutaway schematic with controls. The control should parameterize the mechanism, not decorate the UI; every scripted mutation should be a mechanical consequence. In this hydraulic brake example, pedal pressure becomes piston displacement, fluid pressure, caliper squeeze, and rotor slowdown. Quality comes from physical credibility: correct pivots, visible linkages, contact motion, local rotation origins, and continuous secondary motion make the slider feel like a mechanism. Keep those details efficient by deriving them from the same control value, not by adding disconnected effects.

```html
<style>
  .brake-cutaway {
    --slide: 0px; --squeeze: 0px; --squeeze-neg: 0px;
    --press-o: 0; --press-w: 7px; --dot-o: 0; --dot-scale: 0.75;
    --rotor-o: 1; --heat-o: 0;
    color: var(--color-text-primary);
    font-family: var(--font-sans);
  }
  .brake-cutaway svg { width: 100%; height: auto; display: block; }
  .brake-control {
    display: flex; align-items: center; gap: 12px; margin: 12px 24px 0;
    color: var(--color-text-secondary); font-size: 13px;
  }
  .brake-control input { flex: 1; accent-color: var(--color-warning-primary); }
  .brake-piston { transform-box: fill-box; transform: translateX(var(--slide)); }
  .brake-pressure { opacity: var(--press-o); stroke-width: var(--press-w); }
  .brake-dots { opacity: var(--dot-o); }
  .brake-dots circle { transform-box: fill-box; transform-origin: center; transform: scale(var(--dot-scale)); }
  .brake-rotor { opacity: var(--rotor-o); }
  .brake-pad { transform-box: fill-box; }
  .brake-pad-l { transform: translateX(var(--squeeze)); }
  .brake-pad-r { transform: translateX(var(--squeeze-neg)); }
  .brake-heat { opacity: var(--heat-o); }
  @media (prefers-reduced-motion: no-preference) {
    .brake-pressure,
    .brake-dots circle,
    .brake-heat {
      transition:
        opacity 130ms cubic-bezier(0.2, 0, 0.2, 1),
        stroke-width 130ms cubic-bezier(0.2, 0, 0.2, 1);
    }
  }
  html[data-theme="dark"] .brake-master,
  html[data-theme="dark"] .brake-pivot,
  html[data-theme="dark"] .brake-hub { fill: #1f2937; stroke: #64748b; }
  html[data-theme="dark"] .brake-face { fill: #20262e; stroke: #64748b; }
</style>

<div class="brake-cutaway" id="brake-cutaway">
  <svg viewBox="0 0 720 340" role="img" aria-labelledby="brake-title brake-desc">
    <title id="brake-title">Hydraulic brake cutaway</title>
    <desc id="brake-desc">Pedal pressure rotates the pedal, advances the master-cylinder piston, raises line pressure, squeezes the pads, slows the rotor, and creates heat at the contact patches.</desc>

    <path d="M190 156 C280 156 328 156 388 156 S470 156 510 156"
      fill="none" stroke="#2563eb" stroke-width="7" stroke-linecap="round" opacity="0.18"/>
    <path class="brake-pressure" d="M190 156 C280 156 328 156 388 156 S470 156 510 156"
      fill="none" stroke="#d97706" stroke-linecap="round"/>

    <path d="M74 112h36" stroke="#94a3b8" stroke-width="7" stroke-linecap="round"/>
    <g id="brake-pedal">
      <line x1="92" y1="112" x2="78" y2="224" stroke="#475569" stroke-width="7" stroke-linecap="round"/>
      <line x1="86" y1="162" x2="106" y2="162" stroke="#475569" stroke-width="4" stroke-linecap="round"/>
      <rect x="55" y="204" width="20" height="58" rx="5" fill="#475569" transform="rotate(-8 65 233)"/>
    </g>
    <circle class="brake-pivot" cx="92" cy="112" r="5" fill="#f8fafc" stroke="#94a3b8" stroke-width="0.5"/>
    <rect class="brake-master" x="136" y="130" width="92" height="52" rx="10"
      fill="#f8fafc" stroke="#94a3b8" stroke-width="0.5"/>
    <line id="brake-rod" x1="97" y1="164" x2="150" y2="156" stroke="#64748b" stroke-width="3" stroke-linecap="round"/>
    <rect class="brake-piston" x="150" y="138" width="24" height="36" rx="5" fill="#64748b"/>
    <circle id="brake-clevis" cx="97" cy="164" r="4" fill="#475569"/>

    <g class="brake-dots" fill="#d97706">
      <circle cx="258" cy="156" r="4"/><circle cx="330" cy="156" r="4"/>
      <circle cx="402" cy="156" r="4"/><circle cx="474" cy="156" r="4"/>
    </g>

    <g class="brake-rotor" transform="translate(560 176)">
      <g id="brake-wheel">
        <circle class="brake-face" r="70" fill="#e5e7eb" stroke="#94a3b8" stroke-width="1"/>
        <circle class="brake-hub" r="24" fill="#f8fafc" stroke="#94a3b8" stroke-width="0.5"/>
        <circle r="48" fill="none" stroke="#94a3b8" stroke-width="0.5" stroke-dasharray="4 7"/>
        <path d="M0-54v108M-54 0h108M-38-38l76 76M38-38l-76 76"
          stroke="#94a3b8" stroke-width="0.5"/>
      </g>
    </g>

    <path d="M500 108Q456 176 500 244M634 108Q676 176 634 244"
      fill="none" stroke="#475569" stroke-width="15" stroke-linecap="round"/>
    <rect class="brake-pad brake-pad-l" x="505" y="134" width="18" height="84" rx="4" fill="#334155"/>
    <rect class="brake-pad brake-pad-r" x="617" y="134" width="18" height="84" rx="4" fill="#334155"/>
    <g class="brake-heat" fill="none" stroke="#d97706" stroke-width="3" stroke-linecap="round">
      <path d="M525 130c-11-14-11-24-1-36M526 222c-12 14-12 24-2 36M594 130c12-14 12-24 2-36M594 222c12 14 12 24 2 36"/>
    </g>

    <g font-family="var(--font-sans)" font-size="12" fill="var(--color-text-secondary)">
      <text x="82" y="292" text-anchor="middle">pedal force</text>
      <text x="182" y="206" text-anchor="middle">master cylinder</text>
      <text x="350" y="132" text-anchor="middle">hydraulic pressure</text>
      <text x="560" y="276" text-anchor="middle">friction at rotor</text>
      <text id="brake-readout" x="360" y="314" text-anchor="middle"
        font-size="14" font-weight="500" fill="var(--color-text-primary)">0% pedal pressure → pads released</text>
    </g>
  </svg>

  <div class="brake-control">
    <span>released</span>
    <input id="brake-pressure" type="range" min="0" max="100" value="0" aria-label="Pedal pressure"/>
    <span>pressed</span>
  </div>
</div>

<script>
  const widget = document.getElementById('brake-cutaway');
  const slider = document.getElementById('brake-pressure');
  const readout = document.getElementById('brake-readout');
  const pedal = document.getElementById('brake-pedal');
  const rod = document.getElementById('brake-rod');
  const clevis = document.getElementById('brake-clevis');
  const wheel = document.getElementById('brake-wheel');
  const pivot = { x: 92, y: 112 };
  const clevisRest = { x: 106, y: 162 };
  let pressure = 0;
  let frame = 0;
  let rotorAngle = 0;
  let lastTime = 0;

  function rotatePoint(point, degrees) {
    const radians = degrees * Math.PI / 180;
    const dx = point.x - pivot.x;
    const dy = point.y - pivot.y;
    return {
      x: pivot.x + dx * Math.cos(radians) - dy * Math.sin(radians),
      y: pivot.y + dx * Math.sin(radians) + dy * Math.cos(radians),
    };
  }

  function paint() {
    const p = pressure / 100;
    const pedalAngle = 10 - p * 24;
    const clevisPoint = rotatePoint(clevisRest, pedalAngle);
    pedal.setAttribute('transform', `rotate(${pedalAngle.toFixed(1)} ${pivot.x} ${pivot.y})`);
    widget.style.setProperty('--slide', `${(p * 25).toFixed(1)}px`);
    widget.style.setProperty('--squeeze', `${(p * 25).toFixed(1)}px`);
    widget.style.setProperty('--squeeze-neg', `${(-p * 25).toFixed(1)}px`);
    widget.style.setProperty('--press-o', (p * 0.72).toFixed(3));
    widget.style.setProperty('--press-w', `${(7 + p * 5).toFixed(1)}px`);
    widget.style.setProperty('--dot-o', (p * 0.8).toFixed(3));
    widget.style.setProperty('--dot-scale', (0.75 + p * 0.65).toFixed(3));
    widget.style.setProperty('--rotor-o', (1 - p * 0.16).toFixed(3));
    widget.style.setProperty('--heat-o', (p * 0.85).toFixed(3));
    rod.setAttribute('x1', clevisPoint.x.toFixed(1));
    rod.setAttribute('y1', clevisPoint.y.toFixed(1));
    rod.setAttribute('x2', (150 + p * 25).toFixed(1));
    clevis.setAttribute('cx', clevisPoint.x.toFixed(1));
    clevis.setAttribute('cy', clevisPoint.y.toFixed(1));
    readout.textContent = pressure === 0
      ? '0% pedal pressure → pads released'
      : `${Math.round(pressure)}% pedal pressure → ${Math.round(pressure)}% caliper squeeze`;
  }

  function render(value) {
    pressure = value;
    if (frame) return;
    frame = requestAnimationFrame(() => {
      frame = 0;
      paint();
    });
  }

  function spin(now) {
    const dt = lastTime ? Math.min(40, now - lastTime) / 1000 : 0;
    lastTime = now;
    const speed = 430 - pressure * 3.8;
    rotorAngle = (rotorAngle + speed * dt) % 360;
    wheel.setAttribute('transform', `rotate(${rotorAngle.toFixed(2)})`);
    requestAnimationFrame(spin);
  }

  slider.addEventListener('input', () => render(Number(slider.value)));
  paint();
  if (!matchMedia('(prefers-reduced-motion: reduce)').matches) requestAnimationFrame(spin);
</script>
```

## D3 simulation — rAF + mouse tracking + controls

For continuous simulations (particle systems, dynamic tessellations, cursor-driven layouts), drive updates via `requestAnimationFrame` and mutate existing SVG attributes on each frame. Native HTML controls (`<input type="range">`, `<input type="checkbox">`) below the SVG drive parameters.

The example: Voronoi tessellation over bouncing points, with the mouse cursor as an extra point (its cell highlights). Sliders control point count and animation speed; a checkbox toggles point markers. This is a *teaching* sim — it demonstrates how Voronoi tessellation adapts to moving points. It is not a game or tool the user returns to.

Under `prefers-reduced-motion: reduce`, the rAF chain stops after the initial `tick()` call. Each input handler must re-`tick()` once after mutating state so the canvas reflects the change — a discrete frame per input event, not continuous animation.

```html
<style>
  #v { width: 100%; height: auto; display: block;
       border: 0.5px solid var(--color-border-tertiary); border-radius: var(--border-radius-md); }
  .controls { display: flex; gap: 20px; margin-top: 14px; align-items: center; flex-wrap: wrap; }
  .controls label { display: flex; align-items: center; gap: 8px;
                    font-size: 13px; color: var(--color-text-secondary); }
  .controls input[type="range"] { width: 90px; accent-color: var(--color-accent-primary); }
  .controls input[type="checkbox"] { width: 14px; height: 14px; accent-color: var(--color-accent-primary); }
  .val { font-size: 13px; font-weight: 500; min-width: 20px; }
</style>

<svg id="v" viewBox="0 0 720 380" role="img">
  <title>Voronoi tessellation reshaping in real time as points and the cursor move.</title>
  <rect width="720" height="380" fill="var(--color-background-secondary)"/>
  <g id="cells"></g>
  <path id="cursor-cell" display="none"/>
  <g id="dots"></g>
</svg>
<div class="controls">
  <label>Points <input type="range" id="sl-pts" min="6" max="40" value="18" step="1">
    <span class="val" id="out-pts">18</span></label>
  <label>Speed <input type="range" id="sl-spd" min="1" max="10" value="3" step="1">
    <span class="val" id="out-spd">3</span></label>
  <label><input type="checkbox" id="ck-dots" checked> Show points</label>
</div>

<script>
  const dark = document.documentElement.getAttribute('data-theme') === 'dark';
  const W = 720, H = 380;
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const palFill = dark
    ? ['#26215C','#04342C','#4A1B0C','#042C53','#173404','#412402','#3C3489','#085041','#712B13']
    : ['#EEEDFE','#E1F5EE','#FAECE7','#E6F1FB','#EAF3DE','#FAEEDA','#CECBF6','#9FE1CB','#F5C4B3'];
  const palStroke = dark
    ? ['#AFA9EC','#5DCAA5','#F0997B','#85B7EB','#97C459','#EF9F27','#7F77DD','#1D9E75','#D85A30']
    : ['#534AB7','#0F6E56','#993C1D','#185FA5','#3B6D11','#854F0B','#3C3489','#085041','#712B13'];
  const dotColor = dark ? 'rgba(255,255,255,0.7)' : 'rgba(0,0,0,0.5)';
  const svg = d3.select('#v');
  const cellGroup = d3.select('#cells');
  const cursorCell = d3.select('#cursor-cell');
  const dotGroup = d3.select('#dots');

  let N = 18, speed = 3, showDots = true;
  let cursorActive = false;
  let mouse = [W / 2, H / 2];
  let pts = makePoints(N);

  function makePoints(n) {
    return d3.range(n).map((_, i) => ({
      x: 40 + Math.random() * (W - 80),
      y: 40 + Math.random() * (H - 80),
      vx: (Math.random() - 0.5),
      vy: (Math.random() - 0.5),
      ci: i % palFill.length,
    }));
  }

  svg.on('pointermove', (e) => {
    const r = svg.node().getBoundingClientRect();
    cursorActive = true;
    mouse = [(e.clientX - r.left) * W / r.width, (e.clientY - r.top) * H / r.height];
  });
  svg.on('pointerleave', () => { cursorActive = false; });

  function tick() {
    const s = speed * 0.4;
    pts.forEach(p => {
      p.x += p.vx * s;
      p.y += p.vy * s;
      if (p.x < 10 || p.x > W - 10) { p.vx *= -1; p.x = Math.max(10, Math.min(W - 10, p.x)); }
      if (p.y < 10 || p.y > H - 10) { p.vy *= -1; p.y = Math.max(10, Math.min(H - 10, p.y)); }
    });

    const allPts = cursorActive ? [...pts.map(p => [p.x, p.y]), mouse] : pts.map(p => [p.x, p.y]);
    const voronoi = d3.Delaunay.from(allPts).voronoi([0, 0, W, H]);

    cellGroup.selectAll('path.cell').data(pts).join('path').attr('class', 'cell')
      .attr('d', (_, i) => voronoi.renderCell(i))
      .attr('fill', d => palFill[d.ci])
      .attr('stroke', d => palStroke[d.ci])
      .attr('stroke-width', 1.5);

    cursorCell.attr('display', cursorActive ? null : 'none')
      .attr('d', cursorActive ? voronoi.renderCell(pts.length) : null)
      .attr('fill', dark ? 'rgba(127,119,221,0.18)' : 'rgba(127,119,221,0.12)')
      .attr('stroke', dark ? '#AFA9EC' : '#534AB7').attr('stroke-width', 2);

    dotGroup.selectAll('circle.pt').data(showDots ? pts : []).join('circle').attr('class', 'pt')
      .attr('r', 3).attr('fill', dotColor)
      .attr('cx', d => d.x).attr('cy', d => d.y);

    if (!reduced) requestAnimationFrame(tick);
  }
  tick();

  document.getElementById('sl-pts').addEventListener('input', (e) => {
    N = +e.target.value;
    document.getElementById('out-pts').textContent = N;
    pts = makePoints(N);
    if (reduced) tick();
  });
  document.getElementById('sl-spd').addEventListener('input', (e) => {
    speed = +e.target.value;
    document.getElementById('out-spd').textContent = speed;
    if (reduced) tick();
  });
  document.getElementById('ck-dots').addEventListener('change', (e) => {
    showDots = e.target.checked;
    if (reduced) tick();
  });
</script>
```

## Cycle stepper — one panel per stage

When the subject is a *cycle* (Krebs, event loop, GC mark-and-sweep, TCP retransmit, CPU fetch-decode-execute), avoid crowded rings. Use a stepper when each stage has its own detail: one focused active panel, dots/pills or a compact stage rail for position, and Next wrapping from the last stage back to the first. The active panel owns what enters, what changes, what leaves, and where it goes next. Pre-render the first stage so the widget is useful before script runs; script should advance state, not create the whole experience. Use a linear row plus a return arrow only for low-detail cycles. Dots, a heading, and two chips are not enough visual substance for a widget; answer in prose instead.

## Gotchas

Beyond the root SKILL.md gotchas — script-specific defects:

- **Unbounded loops freeze the iframe** — any `while` or recursive routine with a probabilistic exit (rejection sampling, force-directed layout, collision avoidance) needs an iteration cap: `for (let i = 0; i < 500 && !done; i++)`. (Already in root, restated for script-heavy widgets.)
- **Wholesale DOM re-renders fight streaming and waste cycles** — mutate attributes on existing nodes; create once, update forever. Re-rendering a 200-node SVG every frame is both slower than attribute mutation and fights the live-DOM diff if the widget is still streaming.
- **Interactive widgets pop in all at once at stream end** — they don't paint progressively the way SVG does. Keep the pre-script DOM useful on its own (axis chrome, title, empty groups) so the user has something to look at during the script-tag stream.
