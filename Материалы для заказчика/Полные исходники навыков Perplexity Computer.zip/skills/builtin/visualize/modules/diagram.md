# Reference visuals — diagrams, callouts, cutaways

Hand-rolled inline SVG for *reference* visuals — flowcharts, structural diagrams, callouts, cutaways. Paint progressively as `widget_code` streams. For intuition visuals (illustrative explainers, steppers, teaching animations) see `interactive.md`; for HTML card patterns (comparison grids, data records, KPI surfaces) see `cards.md`; for routing by verb see SKILL.md § "Route on the verb, not the noun".

Element styling, font-width calibration, and cross-cutting SVG gotchas live in SKILL.md — applies to every SVG widget, not just diagrams.

## Failure modes to check first

Cross-cutting placement math lives in SKILL.md § "Pre-placement — compute before drawing." Diagram-specific:

- **Callouts in the quiet region** — place labels outside the subject when possible; avoid covering the subject or occupying the gap between subjects unless that region is intentionally blank. Pick one outer side per subject; in single-subject layouts, default right-side with `text-anchor="start"` and ≥140px reserved. If no quiet region fits the full set, the diagram is too dense — decompose.
- **Trees size bottom-up** — leaf tier first; parent width ≥ sum of children + gaps. Top-down sizing under-budgets the lower tier.

## Ground recognizable subjects in a reference

**The thumbnail test.** Glance at the widget at half size, labels hidden. Do you recognize what it is? A misdrawn aircraft silhouette doesn't land — it makes the whole response feel sloppy, not just the drawing. A vaguely-human figure with three-finger hands makes the reader trust the rest of the answer less. Recognizability before polish.

For recognizable physical subjects that fit one-shot SVG, ground proportions in a reference when one is available. Extract landmark positions and major masses before drawing. When complexity burdens the overall view, or fidelity starts making the drawing itself the focus, prefer a simplified overview plus focused teaching widgets for the parts that matter, with prose between them. Each focused widget should teach a relationship, mechanism, or labeled region rather than trying to reproduce the whole subject exactly.

Simple schematic does not mean loose perspective. Pick one view — front, side cutaway, top-down, exploded, sectional — and keep every part consistent with that view. Do not mix front-facing circles, side-view chambers, and top-view keys in the same subject. Mechanical relationships must still be correct enough that the diagram works before labels rescue it.

## Widget shape examples

A small `<style>` / `<defs>` preamble keeps repeated styling terse. Declare text defaults and reusable leader/shape styles only when they remove real repetition; one-off elements use inline attributes.

### Callout diagram

A recognizable subject (silhouette, cross-section, schematic) with margin-placed callouts naming its parts. The subject sits in a protected core region; labels live in the margins and leader lines bridge.

Callouts annotate; they do not rescue. The base subject must be recognizable with labels hidden. If the viewer needs the callouts to identify the object or understand the view, the diagram fails the job.

When long leader lines or dense labels become the main thing to debug, move part names into compact controls and a detail panel. The drawing stays visible; controls carry selection and detail.

For a non-subject layout (flowchart / structural), drop the silhouette and use the same `<rect>` + `<text>` pattern directly — consistent label boxes regardless of layout shape.

### Simple static SVG

Simple SVG is valid when the geometry itself carries the answer — attention fans, decision boundaries, dependency cuts, tradeoff frontiers, small before/after schematics. Keep these flat, bounded, and inspectable at rest. Route to `interactive.md` when controls change parameters, sequence, state, or motion to teach the mechanism.

### Labeled-part reference view

Use this when the drawing remains the answer and click/tap only reveals parts already visible in the diagram — plant-cell wall layers, organelles, engine components, anatomy regions. This stays in `diagram.md` when selection reduces label clutter. Route to `interactive.md` when controls change parameters, sequence, state, or motion to teach a mechanism.

- For coupled mechanical diagrams, establish reference anchors before drawing: pin centers, cut depths, pivots, contact points, clearances, and bounds. Derive dependent geometry from those anchors so parts cannot drift apart.
- Base SVG must be readable before script runs: show the subject, major regions, and enough labels to understand the diagram at first paint.
- Pre-render controls and the detail shell in the fragment. Script only toggles active state, updates ARIA state, highlights the selected region, and swaps compact detail text.
- Keep detail copy to 1–2 short sentences per selected part. Paragraph explanations, source attribution, and narrative context belong in the response.
- Prefer click/tap as the primary interaction; hover can supplement but cannot be the only way to read the diagram.
- Use Aether tokens for text, borders, control surfaces, and detail panels. Physical materials may use local hex fills, with `html[data-theme="dark"]` variants.
- Do not turn selection into a card grid or article panel below the visual. If each part needs its own paragraph, decompose into prose plus focused widgets.

```html
<div class="lock-widget">
  <style>
    .lock-widget { display: grid; gap: 12px; font-family: var(--font-sans); color: var(--color-text-primary); }
    .lock-svg { width: 100%; height: auto; }
    .lock-svg text { fill: var(--color-text-secondary); font-size: 12px; }
    .shell { fill: #e3e8ef; stroke: #8fa0b4; stroke-width: 0.5; }
    .plug { fill: #f8fafc; stroke: #8fa0b4; stroke-width: 0.5; }
    .bore { fill: var(--color-background-primary); stroke: #9aa8bb; stroke-width: 0.5; }
    .driver { fill: #64748b; stroke: #455569; stroke-width: 0.5; }
    .pin { fill: #d6aa4d; stroke: #986a21; stroke-width: 0.5; }
    .key { fill: #f3c95f; stroke: #986a21; stroke-width: 0.5; fill-rule: evenodd; }
    .spring { fill: none; stroke: #748296; stroke-width: 1.2; stroke-linecap: round; stroke-linejoin: round; }
    .shear { stroke: #d97706; stroke-width: 1; stroke-dasharray: 7 5; }
    .groove, .cut-face { fill: none; stroke-width: 0.5; opacity: 0.55; }
    .groove { stroke: #986a21; }
    .cut-face { stroke: #8fa0b4; }
    .region { transition: opacity .16s ease, transform .12s ease; transform-box: fill-box; transform-origin: center; }
    .dim .region { opacity: .28; }
    .dim .region.active { opacity: 1; transform: translateY(2px); }
    .dim .region.active :is(path, rect, line, use, ellipse) { stroke: #0f766e; stroke-width: 1.1; }
    .region.hovered { transform: translateY(1px); }
    .controls { display: grid; grid-template-columns: repeat(auto-fit, minmax(88px, 1fr)); gap: 6px; }
    .part-btn { min-height: 34px; border: .5px solid var(--color-border-secondary); border-radius: 6px; background: var(--color-background-primary); color: var(--color-text-primary); font: 12px var(--font-sans); cursor: pointer; }
    .part-btn[aria-pressed="true"] { border-color: var(--color-border-primary); background: var(--color-background-secondary); }
    .detail { min-height: 52px; border: .5px solid var(--color-border-tertiary); border-radius: 6px; background: var(--color-background-secondary); padding: 10px 12px; font-size: 13px; line-height: 1.35; }
    .detail strong { display: block; margin-bottom: 2px; font-size: 13px; }
    .detail span { color: var(--color-text-secondary); }
    html[data-theme="dark"] .shell { fill: #1f2937; stroke: #64748b; }
    html[data-theme="dark"] .plug { fill: #111827; stroke: #64748b; }
    html[data-theme="dark"] .bore { fill: #101317; stroke: #536174; }
    html[data-theme="dark"] .driver { fill: #9aa8ba; stroke: #cbd5e1; }
    html[data-theme="dark"] .pin, html[data-theme="dark"] .key { fill: #b9852f; stroke: #facc15; }
    html[data-theme="dark"] .dim .region.active :is(path, rect, line) { stroke: #5eead4; }
  </style>

  <svg class="lock-svg" viewBox="0 0 720 330" role="img">
    <title>Pin-tumbler lock cutaway</title>
    <desc>Key cuts lift the brass pins so every pin split clears the dashed shear line.</desc>
    <defs>
      <g id="coil">
        <ellipse cx="0" cy="0" rx="9" ry="3"/><ellipse cx="0" cy="8" rx="9" ry="3"/>
        <ellipse cx="0" cy="16" rx="9" ry="3"/><ellipse cx="0" cy="24" rx="9" ry="3"/>
        <ellipse cx="0" cy="32" rx="9" ry="3"/><path d="M-9 0v32M9 0v32"/>
      </g>
    </defs>

    <g class="region" data-part="housing">
      <path class="shell" d="M186 44H560q22 0 22 22v72H142V66q0-22 22-22z"/>
      <path class="shell" fill-rule="evenodd" d="M142 138H582v50q0 46-32 78t-78 32H254q-46 0-78-32t-32-78v-50zM166 138v48q0 37 25 62t62 25h214q37 0 62-25t25-62v-48z"/>
      <line class="cut-face" x1="160" y1="142" x2="186" y2="116"/>
      <line class="cut-face" x1="188" y1="142" x2="214" y2="116"/>
      <line class="cut-face" x1="524" y1="142" x2="550" y2="116"/>
    </g>
    <g class="region" data-part="plug">
      <path class="plug" d="M166 138H554v48q0 37-25 62t-62 25H253q-37 0-62-25t-25-62z"/>
    </g>
    <g class="region" data-part="shear">
      <line class="shear" x1="142" y1="138" x2="564" y2="138"/>
      <text x="162" y="129">shear line</text>
    </g>
    <g class="region" data-part="driver">
      <path class="bore" d="M229 62h30v158a15 15 0 0 1-30 0z"/>
      <path class="bore" d="M291 62h30v158a15 15 0 0 1-30 0z"/>
      <path class="bore" d="M353 62h30v158a15 15 0 0 1-30 0z"/>
      <path class="bore" d="M415 62h30v158a15 15 0 0 1-30 0z"/>
      <path class="bore" d="M477 62h30v158a15 15 0 0 1-30 0z"/>
      <use href="#coil" class="spring" transform="translate(244 72)"/>
      <use href="#coil" class="spring" transform="translate(306 72)"/>
      <use href="#coil" class="spring" transform="translate(368 72)"/>
      <use href="#coil" class="spring" transform="translate(430 72)"/>
      <use href="#coil" class="spring" transform="translate(492 72)"/>
      <path class="driver" d="M229 104h30v34h-30z"/>
      <path class="driver" d="M291 104h30v34h-30z"/>
      <path class="driver" d="M353 104h30v34h-30z"/>
      <path class="driver" d="M415 104h30v34h-30z"/>
      <path class="driver" d="M477 104h30v34h-30z"/>
    </g>
    <g class="region" data-part="key">
      <path class="key" d="M55 183H127C163 183 173 215 164 214L218 212L230 200L258 200L270 212L280 196L292 184L320 184L332 196L342 223L354 211L382 211L394 223L404 205L416 193L444 193L456 205L466 217L478 205L506 205L518 217L506 224L536 228L536 250H164V253C173 255 163 287 127 287H55C21 287 5 265 5 235C5 205 21 183 55 183ZM68 235a14 14 0 1 0 28 0a14 14 0 1 0 -28 0Z"/>
      <path class="groove" d="M188 239H510"/>
      <path class="groove" d="M194 231h44"/>
    </g>
    <g class="region" data-part="pins">
      <path class="pin" d="M229 138H259V188Q259 193 251 198L244 200L237 198Q229 193 229 188Z"/>
      <path class="pin" d="M291 138H321V172Q321 177 313 182L306 184L299 182Q291 177 291 172Z"/>
      <path class="pin" d="M353 138H383V199Q383 204 375 209L368 211L361 209Q353 204 353 199Z"/>
      <path class="pin" d="M415 138H445V181Q445 186 437 191L430 193L423 191Q415 186 415 181Z"/>
      <path class="pin" d="M477 138H507V193Q507 198 499 203L492 205L485 203Q477 198 477 193Z"/>
    </g>
  </svg>

  <div class="controls" aria-label="Lock parts">
    <button class="part-btn" type="button" data-part="housing" aria-pressed="false">Housing</button>
    <button class="part-btn" type="button" data-part="plug" aria-pressed="false">Plug</button>
    <button class="part-btn" type="button" data-part="driver" aria-pressed="false">Drivers</button>
    <button class="part-btn" type="button" data-part="pins" aria-pressed="false">Key pins</button>
    <button class="part-btn" type="button" data-part="shear" aria-pressed="false">Shear</button>
    <button class="part-btn" type="button" data-part="key" aria-pressed="false">Key</button>
  </div>
  <div class="detail" aria-live="polite">
    <strong>Pin-tumbler cutaway</strong>
    <span>Tap a part to isolate it. The key cuts and pin tips share the same reference points.</span>
  </div>

  <script>
    (() => {
      const root = document.currentScript.closest('.lock-widget');
      const svg = root.querySelector('.lock-svg');
      const detail = root.querySelector('.detail');
      const initial = [detail.querySelector('strong').textContent, detail.querySelector('span').textContent];
      const copy = {
        housing: ['Housing', 'The fixed shell carries the pin chambers and springs. It stays still while the plug rotates.'],
        plug: ['Plug', 'The plug is the rotating cylinder around the keyway. It turns only when no pin crosses the shear line.'],
        driver: ['Driver pins', 'The gray driver pins are pushed down by springs. A wrong key leaves one blocking the plug.'],
        pins: ['Key pins', 'The brass key pins share x positions with the key flats, so each tip lands on its matching cut.'],
        shear: ['Shear line', 'The correct key lifts every pin split exactly to this boundary.'],
        key: ['Key bitting', 'The large bow stays outside the lock; the slim blade carries the cut heights that lift the pins.'],
      };
      let selected = null;
      function render(part) {
        svg.classList.toggle('dim', Boolean(part));
        root.querySelectorAll('.region').forEach((r) => r.classList.toggle('active', r.dataset.part === part));
        root.querySelectorAll('.part-btn').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.part === part)));
        const text = part ? copy[part] : initial;
        detail.querySelector('strong').textContent = text[0];
        detail.querySelector('span').textContent = text[1];
      }
      root.querySelectorAll('.region').forEach((region) => {
        region.addEventListener('mouseenter', () => { region.classList.add('hovered'); if (!selected) render(region.dataset.part); });
        region.addEventListener('mouseleave', () => { region.classList.remove('hovered'); if (!selected) render(null); });
        region.addEventListener('click', (event) => event.stopPropagation());
      });
      root.querySelectorAll('.part-btn').forEach((button) => {
        button.addEventListener('mouseenter', () => { if (!selected) render(button.dataset.part); });
        button.addEventListener('mouseleave', () => { if (!selected) render(null); });
        button.addEventListener('click', (event) => {
          event.stopPropagation();
          selected = selected === button.dataset.part ? null : button.dataset.part;
          render(selected);
        });
      });
      root.addEventListener('click', () => { selected = null; render(null); });
    })();
  </script>
</div>
```

### Structural container (things inside things)

When the answer depends on *where* parts sit — regions inside a system, organelles inside a cell, stages inside a pipeline. Large outer rect is the container; smaller inner rects are regions; external arrows show inputs/outputs.

- Size parent containers from their children: inner regions first, then parent width/height = child bounds + padding. Keep ≥20px padding between parent edge and child region.
- Use different fills only for real categories, and declare light/dark variants together. Tailwind 50/600/800/900 stops work for colored region backgrounds, strokes, and text.
- Arrows between regions stop at region edges. Never draw through a box and rely on a fill to hide the line.
- If a plain node-and-arrow flow becomes the whole diagram, keep it simple and prefer the dedicated diagramming route when available.


## Streaming authoring order

`widget_code` streams token-by-token into the iframe and paints progressively via morphdom. **Structure your output so visible content appears as early as possible** — every non-painting byte emitted before the first paintable element is perceived as startup lag.

The most common cause of a "shell appears, then long pause, then stuff happens" perception is front-loading invisible scaffolding: a big `<style>` block, a `<defs>` block full of gradients/filters, `<!DOCTYPE>`/`<html>`/`<head>` wrappers, a `<script>` whose closing tag hasn't arrived yet. None of those produce pixels.

Emit in this order:

1. Keep `<defs>` minimal: arrow markers, clip paths, and simple patterns only when they serve the visual. Avoid filters and decorative gradients; they flash during morphdom diffs.
2. **First visible paintable element immediately** — a `<rect>` background, the first `<circle>`, the first `<path>`. This is the "first paint" moment.
3. Subsequent shapes build the picture progressively. Each additional element paints as it arrives.
4. Text labels *after* the shapes they annotate — they depend on final geometry anyway.
5. Keep `<style>` blocks under ~15 lines for simple diagrams (large preambles block first paint). Interactive widgets with controls and animation can run up to ~40 lines — don't bloat with decorative CSS. Lift only repeated styles into the block; one-off elements use inline attributes.
6. For pure SVG diagrams, make `<svg ...>` the first content node; use an HTML wrapper only when the widget needs controls or a compact detail panel.

## Visual discipline

### Pinned viewBox

The 720-wide bounded-coordinate convention is in the root SKILL.md § Width. Diagram-specific note: if the subject is naturally narrow, keep viewBox at 720 and center content (e.g. spans `x=200..520`) — don't shrink the viewBox.

### Font sizes in SVG — two only

14px for primary labels, 12px for subtitles / axis ticks / callouts. Additional sizes create hierarchy noise. (HTML UI records like data-record cards and KPI grids follow UI typography conventions with a larger hero size for the primary number — that's a different surface.)

### Strokes, corners, text placement

- **Stroke width: 0.5px** for diagram borders. Host UI runs thin strokes — heavier borders read as misaligned with the surrounding chat.
- **Corners: `rx="4"`** default, `rx="8"` for emphasized rounding. `rx ≥ height/2` is a pill — use deliberately.
- **Text inside boxes — pick one pattern:**
  - **Centered single label:** `dominant-baseline="central"` at rect center. Without it, text sits slightly above center and boxes feel top-heavy.
  - **Top-anchored header:** title at y ≈ rect_top + 30, subtitle at y ≈ rect_top + 48 (baseline-anchored). Content fills below.
- **Sentence case** on all labels — Title Case reads as a button.

### Accessibility

- **`role="img"`** on the outer `<svg>`.
- **`<title>` as the *first* child** — short one-sentence description. This is what screen readers announce.
- **`<desc>` immediately after `<title>`** for longer context — patterns, outliers, what to notice.

```xml
<svg viewBox="0 0 720 320" style="width:100%;height:auto" role="img">
  <title>Annual revenue for AAPL, 2020–2024</title>
  <desc>Bars show year-over-year growth, with a dip in 2022 and recovery in 2023–2024.</desc>
  ...
</svg>
```

HTML widgets inherit semantics from native tags.

### Spacing

- Same-row boxes: ≥20px gap between them.
- SVG nested containers: ≥20px padding inside — text and inner regions must not touch the container edges. (HTML cards follow CSS conventions, typically 10–16px.)

## Gotchas

Beyond the root SKILL.md gotchas and the pre-placement checks above — diagram-specific defects:

- **Leader lines through text read as strikethrough** — route around text with an L-bend; leave ≥8px clear air between leader and label cap-height.
- **Legends over data often clip illegibly** — prefer moving the legend outside the plotted area. If it must sit over dense artwork, use `fill="var(--color-background-secondary)"` with 8px padding to occlude cleanly.
