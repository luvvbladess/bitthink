# Cards — comparison grids, data records, KPI surfaces

HTML card patterns for bounded UI objects: comparison grids, data records, metric/KPI surfaces. Cards carry structured information (text, small numbers, identity-only inline SVGs); they don't carry spatial reasoning between elements — that belongs in `diagram.md`.

CSS handles the column math (`grid-template-columns: repeat(auto-fit, minmax(...))`); HTML handles text layout (wraps, no clipping); inline SVG, when it appears inside a card, carries only an identity glyph at small size (e.g. `viewBox="0 0 60 60"`). The `0 0 720 H` rule from SKILL.md applies to top-level widget SVGs where 1:1 pixel mapping matters — small embedded card SVGs can use their own viewBox.

## When comparing: how deep is each subject?

The depth of each compared subject decides the pattern:

- **Shallow per subject** (identity = small glyph or simplified schematic + a few text rows): one card per subject in a single `visualize` call — card grid, see "Cards with per-subject visuals" below.
- **Deep per subject** (each needs its own labeled diagram, callouts, or internal structure): one `visualize` call per subject, full canvas, prose between. Cards don't fit — at ~200–280px per card there's no room for callouts, leader lines, or labels. Each subject routes to `diagram.md`.

If you find yourself wanting both — full callouts AND a side-by-side compare in one widget — you've picked the wrong unit. Decompose. One subject per call.

For the shallow case, before drawing: what's the meaningful axis that puts similar entities together? Generation, era, tier, class, domain. Group by that first, then cards inside groups.

- Each compared entity has identity. Give it a card — role, 2–3 spec rows, a one-line strengths sentence. Readers scan cards, not cells.
- Add a single focused chart *below* the cards for the one dimension that rewards a direct visual (speed, size, cost, population). One axis, bar per entity, consistent ordering. See `chart.md`.
- Score matrices (rows × axes with colored cells) only when *every* axis is genuinely numeric and the question is explicitly about cross-axis pattern. A heatmap of qualitative judgments reads as decoration — it flattens each entity's character into a color cell and loses the reason the comparison was asked.
- 6+ entities → group first. Ungrouped sibling rows lose the structural insight of the comparison.
- No exact silhouettes or fidelity-heavy thumbnails on SVG-only cards — the text zone starves below the width-math floor and exact geometry does not survive at card size.

## Cards with per-subject visuals

When each subject benefits from a small identifying visual, use an HTML card grid with small inline SVG inside each card — not a pure-SVG grid. HTML handles text layout (wraps, no clipping); SVG carries only a simplified identity glyph or schematic cue. CSS does the column math; no per-card `rect_width` calculation.

```html
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:8px">
  <div style="display:flex;gap:10px;padding:10px;border:0.5px solid var(--color-border-tertiary);border-radius:var(--border-radius-md);background:var(--color-background-secondary)">
    <svg viewBox="0 0 60 60" style="flex-shrink:0;width:60px;height:60px" aria-hidden="true">
      <circle cx="30" cy="30" r="28" fill="#f5e9d0" stroke="#b8864a" stroke-width="0.5"/>
      <circle cx="30" cy="30" r="14" fill="#d4b37a"/>
      <circle cx="30" cy="30" r="8" fill="#8b5a2b"/>
      <path d="M30,6 Q39,30 30,54" fill="none" stroke="#c44" stroke-width="0.6"/>
    </svg>
    <div style="min-width:0">
      <div style="font-size:14px;font-weight:500">Baseball</div>
      <div style="font-size:12px;color:var(--color-text-secondary);line-height:1.5">Cork + rubber core<br/>Wool yarn wrap<br/>Leather cover</div>
    </div>
  </div>
</div>
```

Repeat the inner card `<div>` per subject.

Why each piece is load-bearing:
- `repeat(auto-fit, minmax(200px, 1fr))` — CSS picks 2–3 columns per row based on available width; at widget width, 3 cards fit comfortably. Adjust the min upward only if labels wrap ugly.
- `min-width: 0` on the text wrapper — lets text wrap at the card edge instead of pushing the column wider than the grid minimum.
- Embedded SVG uses its own small viewBox (e.g. `0 0 60 60`) because it's styled with CSS dimensions.
- SVG at schematic fidelity — the cue is enough to identify the object (circle + stitches = baseball, ellipse + laces = football). When identity depends on exact outline, material fidelity, or canonical geometry, skip the thumbnail or route to `diagram.md` for a focused teaching widget.

## Comparison grid with a recommended variant

Card grid where one card is the featured choice. Two-pixel accent border is the single exception to the 0.5px stroke rule — used to mark the recommended item without changing its background or density. All cards keep the same padding and layout so the highlight reads as visual priority, not visual inconsistency. Keep badges in normal flow; negative-positioned badges can clip at the widget edge.

```html
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px">
  <div style="background:var(--color-background-primary);border:0.5px solid var(--color-border-tertiary);border-radius:var(--border-radius-lg);padding:16px">
    <div style="font-size:14px;font-weight:500">Basic</div>
    <div style="font-size:24px;font-weight:500;margin:8px 0">$9<span style="font-size:13px;color:var(--color-text-secondary)">/mo</span></div>
    <div style="font-size:12px;color:var(--color-text-secondary);line-height:1.6">
      <div>Up to 5 projects</div>
      <div>Community support</div>
    </div>
  </div>
  <div style="background:var(--color-background-primary);border:2px solid var(--color-accent-primary);border-radius:var(--border-radius-lg);padding:16px">
    <div style="display:inline-block;background:var(--color-accent-primary);color:var(--color-background-primary);font-size:11px;font-weight:500;padding:2px 8px;border-radius:var(--border-radius-md);margin-bottom:8px">Recommended</div>
    <div style="font-size:14px;font-weight:500">Pro</div>
    <div style="font-size:24px;font-weight:500;margin:8px 0">$29<span style="font-size:13px;color:var(--color-text-secondary)">/mo</span></div>
    <div style="font-size:12px;color:var(--color-text-secondary);line-height:1.6">
      <div>Unlimited projects</div>
      <div>Priority support</div>
      <div>Advanced analytics</div>
    </div>
  </div>
  <div style="background:var(--color-background-primary);border:0.5px solid var(--color-border-tertiary);border-radius:var(--border-radius-lg);padding:16px">
    <div style="font-size:14px;font-weight:500">Team</div>
    <div style="font-size:24px;font-weight:500;margin:8px 0">$99<span style="font-size:13px;color:var(--color-text-secondary)">/mo</span></div>
    <div style="font-size:12px;color:var(--color-text-secondary);line-height:1.6">
      <div>Everything in Pro</div>
      <div>Shared workspace</div>
      <div>SSO</div>
    </div>
  </div>
</div>
```

What's load-bearing: `minmax(180px, 1fr)` lets the grid pick 2–3 columns by available width; the badge stays in normal flow so it cannot clip at the iframe edge; the accent card keeps the same `background-primary` as its neighbours so the weight lives in the border, not the fill.

## Data record — bounded UI object

A single card wraps one record (person, object, transaction); the widget is the labeled content, not a flow diagram. No arrows, no mechanism — just a predictable vertical hierarchy inside one card wrapper.

```html
<div style="background:var(--color-background-primary);border:0.5px solid var(--color-border-tertiary);border-radius:var(--border-radius-lg);padding:16px 20px">
  <div style="display:flex;gap:12px;align-items:center;margin-bottom:14px">
    <div style="width:44px;height:44px;border-radius:50%;background:var(--color-background-tertiary);display:flex;align-items:center;justify-content:center;font-weight:500;color:var(--color-text-primary)">MR</div>
    <div>
      <div style="font-size:14px;font-weight:500">Maya Rodriguez</div>
      <div style="font-size:12px;color:var(--color-text-secondary)">VP of Engineering</div>
    </div>
  </div>
  <div style="border-top:0.5px solid var(--color-border-tertiary);padding-top:12px;font-size:13px;display:grid;grid-template-columns:auto 1fr;gap:6px 16px">
    <span style="color:var(--color-text-secondary)">Email</span><span>m.rodriguez@acme.com</span>
    <span style="color:var(--color-text-secondary)">Phone</span><span>+1 (415) 555-0172</span>
    <span style="color:var(--color-text-secondary)">Team</span><span>Platform</span>
  </div>
</div>
```

The same shape covers receipts, invoices, inventory records, notification surfaces, profile cards. Header (identity), body (fields or line items), optional footer (total / action). Initials badge replaces avatar images, which the sandbox can't fetch.

## Metric surface — KPI grid

Stat cards drop the border; the surface itself (via `background-secondary`) carries the card shape. Label above in `--color-text-secondary`, number below at 22–24px weight 500. Use in a grid of 2–4 when the dashboard wants a summary row.

```html
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px">
  <div style="background:var(--color-background-secondary);border-radius:var(--border-radius-md);padding:14px 16px">
    <div style="font-size:12px;color:var(--color-text-secondary);margin-bottom:4px">Monthly revenue</div>
    <div style="font-size:22px;font-weight:500">$48,230</div>
  </div>
  <div style="background:var(--color-background-secondary);border-radius:var(--border-radius-md);padding:14px 16px">
    <div style="font-size:12px;color:var(--color-text-secondary);margin-bottom:4px">Active users</div>
    <div style="font-size:22px;font-weight:500">12,847</div>
  </div>
  <div style="background:var(--color-background-secondary);border-radius:var(--border-radius-md);padding:14px 16px">
    <div style="font-size:12px;color:var(--color-text-secondary);margin-bottom:4px">Churn</div>
    <div style="font-size:22px;font-weight:500">2.4<span style="font-size:14px;color:var(--color-text-secondary)">%</span></div>
  </div>
  <div style="background:var(--color-background-secondary);border-radius:var(--border-radius-md);padding:14px 16px">
    <div style="font-size:12px;color:var(--color-text-secondary);margin-bottom:4px">NPS</div>
    <div style="font-size:22px;font-weight:500">48</div>
  </div>
</div>
```

For signed deltas (up/down vs last period), use `var(--color-positive-primary)` or `var(--color-negative-primary)` on the number or a small adjacent arrow. Don't color the whole card — the semantic weight belongs to the delta, not the surface.
