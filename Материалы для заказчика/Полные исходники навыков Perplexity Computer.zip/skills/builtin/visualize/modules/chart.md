# Charts

Bar, line, scatter, area, time-series, stacked, multi-series, dual-axis, pie/doughnut, treemap, force-directed, Sankey, chord, radial, bespoke finance layouts.

### See also

- `finance.md` — price / OHLC / candlestick / volume.
- `interactive.md` — scripted charts with user-driven controls.

## Chart geometry — answer before ornament

Pick the geometry that answers the question before choosing a library. A non-default chart shape is valuable when the shape carries the answer; otherwise it is decoration.

- **Time path** → line / area. The x-axis is time; use bars only when the period bins themselves are the comparison.
- **Point-in-time magnitude or rank** → bars. Horizontal bars for 6+ labels; vertical bars for short ordered sets.
- **Part-to-whole shares** → doughnut/pie when the total is the answer and the slice count is small; stacked bar when grouped totals or category bands matter.
- **Before / after pairs** → slopegraph. Two vertical anchors, one line per subject, labels on both ends. Use when the question is *who changed how much?*
- **Rank over several checkpoints** → bump chart or small multiples. Avoid 8+ series spaghetti unless the crossings are the point.
- **Distribution** → histogram for shape; box / violin for comparing groups.
- **Relationship** → scatter / bubble. Add a trend line only if the trend is the answer.
- **Flow or composition** → Sankey, stacked bar, or treemap only when movement or part-to-whole is the insight.

## Library choice — default to the one with more defaults

Once the geometry is clear, choose the library with the most native support for that shape. Three libraries cover every chart we draw. The asymmetry matters: picking the library with fewer defaults means hand-rolling scales, axes, stacks, tooltips, and legends — the output looks visibly hand-rolled even when it works.

1. **Chart.js** — default for statistical primitives: bar, grouped bar, stacked bar (`stacked: true`), horizontal bars (`indexAxis: 'y'`), line, scatter, area, multi-series, dual y-axis. Axes, scales, legends, tooltips, animation are built-in. Pre-loaded as `window.Chart`, but date adapters are not.
2. **Lightweight Charts** — for price / OHLC / candlestick / volume overlays. See `finance.md` for the full recipe.
3. **D3** — for bespoke geometry the other two can't express: force-directed graphs, Sankey, chord, treemaps with custom hit-testing, non-Cartesian coordinates, canvas+SVG hybrids, per-mark enter-transitions with custom choreography.

**Composite charts** (stacked bar + bubble overlay, line + annotations, grouped bar + scatter): pick the library that handles the *larger primitive* and extend for the rest. Chart.js supports a second dataset with a different `type` on a second axis — the bespoke piece is usually smaller than it feels. Reach for D3 only when you're fighting the library on more than one axis.

**Asymmetric cost.** Picking Chart.js when D3 would have been slightly better → one constrained piece. Picking D3 when Chart.js would have worked → hand-rolled library primitives (`d3.scaleBand`, `d3.axisBottom`, manual stack math, custom tooltip wiring), split attention, visibly hand-rolled output. Default to the former.

**Do not hand-roll chart primitives with div widths or bespoke SVG arcs.** If the visual is a chart — bars, stacked bars, pie/doughnut slices, lines, axes, scales, legends, tooltips — use Chart.js, D3, or Lightweight Charts. Hand-rolled HTML/SVG chart marks are for non-chart diagrams, not quantitative comparisons.

## D3 — how it streams

Scripts execute once, after streaming completes. Hand-rolled SVG paints progressively via morphdom during stream; scripts wait. For D3 widgets this means: build a single mount-and-render script and render at stream end with a clean enter-transition so the chart feels alive without faking streaming.

SKILL.md § Width / § SVG basics / § Gotchas apply. D3-specific reminder: use `d3.axisBottom`/`axisLeft`, `d3.stack`, `d3.scaleBand`/`scaleLinear`/`scaleSqrt` — don't hand-roll what D3 ships.

**Authoring order that keeps the pre-script frame useful.** Scripts fire only after the closing `</script>` arrives, so the user stares at whatever you emitted before that. Make those bytes paint something useful:

1. Inline `style="..."` on elements, or a `<style>` block kept short (~15 lines for charts; up to ~40 for full interactive widgets with controls). Large CSS preambles block first paint.
2. The bare `<svg>` element with axis chrome / title / empty groups — gives the user structure to look at *before* data binds.
3. Mount-and-bind `<script>` last. Reference `window.d3` / `window.Chart` / `window.LightweightCharts` directly. Scripts execute once, after streaming completes — hand-rolled SVG has already painted progressively by then via morphdom.

## Canonical batch-render — data via `data` field

For data precomputed before the call (Python-shaped rows passed via `data`), use a single mount-and-render script with a D3 enter-transition:

```python
visualize(
  name="Monthly active users",
  data={"rows": [
    {"label": "Oct", "value": 142_300},
    {"label": "Nov", "value": 158_900},
    {"label": "Dec", "value": 173_400},
    {"label": "Jan", "value": 168_200},
  ]},
  widget_code='''
    <style>
      #chart .tick line, #chart .domain { stroke: var(--color-border-primary); }
      #chart .tick text { fill: var(--color-text-secondary); font-size: 11px; }
    </style>
    <svg id="chart" viewBox="0 0 720 320" style="width:100%;height:auto" role="img">
      <title>Monthly active users, Oct 2024 – Jan 2025</title>
      <rect width="720" height="320" fill="var(--color-background-primary)"/>
      <g class="x-axis"></g>
      <g class="y-axis"></g>
      <g class="bars"></g>
    </svg>
    <script>
      const width = 720, height = 320, margin = {top: 20, right: 20, bottom: 40, left: 60};
      const rows = window.visualization.data.rows;
      const svg = d3.select('#chart');
      const x = d3.scaleBand()
        .domain(rows.map(d => d.label))
        .range([margin.left, width - margin.right])
        .padding(0.15);
      const y = d3.scaleLinear()
        .domain([0, d3.max(rows, d => d.value)]).nice()
        .range([height - margin.bottom, margin.top]);

      svg.select('.x-axis').attr('transform', `translate(0,${height - margin.bottom})`).call(d3.axisBottom(x));
      svg.select('.y-axis').attr('transform', `translate(${margin.left},0)`).call(d3.axisLeft(y).ticks(5).tickFormat(d3.format('~s')));

      svg.select('.bars').selectAll('rect.bar').data(rows).enter().append('rect').attr('class', 'bar')
        .attr('fill', 'var(--color-accent-primary)')
        .attr('x', d => x(d.label)).attr('width', x.bandwidth())
        .attr('y', y(0)).attr('height', 0)
        .transition().duration(700).ease(d3.easeCubicOut)
          .delay((_, i) => i * 60)
          .attr('y', d => y(d.value))
          .attr('height', d => y(0) - y(d.value));
    </script>
  ''',
)
```

### Transition patterns that feel alive without faking streaming

- **Grow-from-baseline.** Bars start `height: 0` at the x-axis, animate to final height over ~700ms. Standard bar-chart reveal.
- **Fade-and-translate.** Shapes start at `opacity: 0` + small y-offset, animate to `opacity: 1` + final position. Works for any mark type.

`.delay((_, i) => i * 60)` adds a per-mark stagger so bars enter in quick succession rather than all at once — legitimate because it's a single render pass with built-in choreography, not fake progressive data arrival. Keep stagger short (40–80ms per mark); longer feels manipulative.

### Rendering rules

- **Colors / fonts via CSS variables** for UI chrome — `var(--color-accent-primary)`, `var(--color-text-primary)`. Style D3 axis output (`.tick text`, `.tick line`, `.domain`) via a small `<style>` block per widget — see the canonical example above.
- **Hardcoded hex for algorithmic per-element coloring** — Voronoi cells, treemap categories, force-graph clusters. Provide light + dark palette arrays and pick by `document.documentElement.getAttribute('data-theme') === 'dark'` when the encoding must stay readable in both.
- **One mount-and-render script.** Don't split into "mount + many push scripts" — scripts fire at stream end, not mid-stream.
- **`data` field for rows** — avoid hand-coding large JS literal arrays inside `widget_code`. Pass rows via `data`, reference as `window.visualization.data`.

For D3 widgets with `requestAnimationFrame`, mouse tracking, or user-driven controls (particle systems, dynamic tessellations, cursor-driven layouts, slider-parameterized simulations), see `interactive.md` § "D3 simulation — rAF + mouse tracking + controls". That belongs in the interactive module, not here.

## Gotchas

Beyond the root SKILL.md gotchas — chart-specific defects:

- **Chart.js options nest deep enough that single-line configs drop braces** — `scales.y.ticks.color` etc. reach 5–6 levels. Use multi-line indented config or lift to a named object.
- **Chart.js custom legends need `fontColor` per generated item** — Chart.js draws built-in legend text on canvas from `LegendItem.fontColor`, not from CSS. Its default `generateLabels` copies `legend.labels.color` into `fontColor`; custom `generateLabels` callbacks must set `fontColor` from the resolved text color or legend text will not respond correctly to theme changes.
- **Chart.js time scales require a date adapter** — the sandbox ships Chart.js core, not date adapters, so `type: 'time'` / `type: 'timeseries'` will fail at render time. Use category labels for evenly spaced periods, or numeric x-values with a tick callback when calendar spacing matters.
- **Seasonal / event-window overlays need real-length series** — use numeric x (trading day, days since event) and omit missing points; don't null-pad Chart.js `{x, y}` datasets to force equal lengths.
- **D3 link endpoints need one shape** — pair numeric links with default lookup: `{source: 0, target: 1}` and no `.nodeId(...)`. Pair named links with explicit lookup: `{source: "cash", target: "rent"}` plus `.nodeId(d => d.name)`. Mixing `.nodeId(d => d.name)` with numeric links throws `missing: 0`. After layout, `link.source` / `link.target` are node objects; read `d.source.kind`, not `nodes[d.source.index || d.source]`. Use `??`, never `||`, when `0` is valid.
- **Sankey is acyclic** — feedback loops throw `circular link`. Use Sankey for one-way flow; use a force graph, chord/ribbon diagram, or hand-rolled flow diagram when money, users, energy, or state can return to an earlier node.
