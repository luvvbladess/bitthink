# Finance

OHLC, candlestick, and price-history widgets via Lightweight Charts. For non-price finance data (revenue bar charts, EPS series, KPI grids) reach for `chart.md` (Chart.js / D3) — same `sources` field, different render library.

Finance tools (`finance_ohlcv_histories`, `finance_company_financials`, etc.) return CSV artifacts materialized in the workspace. Pass each returned `csv_files[i].workspace_path` through as a `sources` field source (see `SKILL.md` § "Data fields"). The widget reads parsed rows at `window.visualization.sources.<name>.data` and aggregates to viewport resolution in JS.

Python preprocessing is only needed when *computing* — moving averages, Bollinger, RSI, volatility, drawdown, Sharpe, multi-source joins, top-N selections. For plain price history the widget owns resolution; it knows its render width, the model doesn't.

**Order:** finance tool → `visualize` → (if needed) pandas reads the returned `workspace_path` + `cite()` for cited prose numbers.

## `sources` field mechanics

For Finance artifacts, use `{"workspace_path": <tool-returned-workspace-path>, "format": "csv"}`. The tool resolves that verified artifact in parallel with `widget_code` streaming and injects the parsed payload at `window.visualization.sources.<name>.data`.

Parsed shape by format:
- `"csv"` → array of row objects: `[{date, open, high, low, close, volume}, ...]`
- `"json"` → the raw parsed object (same shape as the server returned)

Per-source state has three shapes: `{loading: true}` while the parent is still fetching, `{data: ...}` once parsed, or `{error, data: null}` on a 404 / parse error / content-length overrun. Per-source failure is independent — other sources resolve normally. Guard before reading `.data`:

```js
const s = window.visualization.sources.nvda;
if (s.loading) {
  renderPlaceholder();
} else if (s.error) {
  renderFallback(s.error);
} else {
  const rows = s.data;
  renderChart(rows);
}
```

Size ceiling: ≤10MB per source (the resolver caps larger payloads with an error). OHLCV and consensus CSVs are well under this in practice.

## Widget-side shaping

With sources, the widget reads the parsed payload under each source name and decides resolution. Typical shapes:
- **Aggregate** OHLCV daily → weekly (see "Candlestick + volume" below for a concrete pattern).
- **Project** — pick just the fields you need: `data.map(r => ({time: r.date, value: +r.close}))`.
- **Window** — slice to last N points: `data.slice(-200)`.
- **Lookup-join** against inline data — e.g. merge consensus rows with a small Python-computed metrics dict passed as an inline sibling key.

Shape knowledge (which columns, row count, nesting) comes from the tool's documented output or a `head -c 500` peek if you haven't used it before. Populate that understanding into widget_code access patterns; the source itself carries no shape metadata.

## Data → chart

| Data | Chart |
|---|---|
| Single-ticker price over time | Line or area |
| OHLC time series | Candlestick |
| OHLC + volume | Candlestick + histogram overlay (the default finance view) |
| Multiple tickers over time | One line series per ticker; normalize to % change from start if price scales differ |
| Quarterly metrics (revenue, EPS) | Grouped bar (Chart.js) |
| Allocation / composition | Bar or treemap — never pie |

## Tokens → chart colors

Canvas libraries need concrete color strings, not CSS variables. Extract resolved Aether tokens once:

```js
const root = getComputedStyle(document.documentElement);
const T = {
  text:    root.getPropertyValue('--color-text-primary').trim(),
  textDim: root.getPropertyValue('--color-text-secondary').trim(),
  border:  root.getPropertyValue('--color-border-tertiary').trim(),
  up:      root.getPropertyValue('--color-positive-primary').trim(),
  down:    root.getPropertyValue('--color-negative-primary').trim(),
  accent:  root.getPropertyValue('--color-accent-primary').trim(),
};
```

Use `T.up` for gains / positive deltas, `T.down` for losses.

For translucent area and gradient colors, use the Aether-token `withAlpha()` helper from root `SKILL.md` § "Aether tokens".

## Lightweight Charts API

`window.LightweightCharts` is pre-loaded. Series-type symbols: `CandlestickSeries`, `LineSeries`, `AreaSeries`, `HistogramSeries`, `BarSeries`, `BaselineSeries`. v5 API is `chart.addSeries(LightweightCharts.CandlestickSeries, options)` — the v4 `chart.addCandlestickSeries(options)` methods were removed.

## Candlestick + volume — source in, weekly out

The widget reads raw daily rows from the source, aggregates to weekly candles, renders:

```html
<div id="chart" style="position:relative;height:420px"></div>
<script>
  const LC = window.LightweightCharts;
  const root = getComputedStyle(document.documentElement);
  const T = {
    text:   root.getPropertyValue('--color-text-primary').trim(),
    border: root.getPropertyValue('--color-border-tertiary').trim(),
    up:     root.getPropertyValue('--color-positive-primary').trim(),
    down:   root.getPropertyValue('--color-negative-primary').trim(),
  };

  function aggregateWeekly(daily) {
    const buckets = new Map();
    for (const r of daily) {
      const d = new Date(r.date);
      const mon = new Date(d);
      mon.setUTCDate(d.getUTCDate() - ((d.getUTCDay() + 6) % 7));
      const key = mon.toISOString().slice(0, 10);
      const b = buckets.get(key);
      if (!b) {
        buckets.set(key, { time: key, open: +r.open, high: +r.high, low: +r.low, close: +r.close, volume: +r.volume });
      } else {
        b.high = Math.max(b.high, +r.high);
        b.low = Math.min(b.low, +r.low);
        b.close = +r.close;
        b.volume += +r.volume;
      }
    }
    return [...buckets.values()];
  }

  const s = window.visualization.sources.nvda;
  if (s.loading) {
    renderPlaceholder();
  } else if (s.error) {
    renderFallback(s.error);
  } else {
    const weekly = aggregateWeekly(s.data);
    renderChart(weekly);
  }

  function setStatus(message) {
    const el = document.getElementById('chart');
    el.style.display = 'grid';
    el.style.placeItems = 'center';
    el.style.color = T.text;
    el.style.font = '13px var(--font-sans)';
    el.textContent = message;
  }

  function renderPlaceholder() {
    setStatus('Loading price data...');
  }

  function renderFallback(err) {
    setStatus(`Failed to load data: ${err}`);
  }

  function renderChart(weekly) {
    const el = document.getElementById('chart');
    el.style.display = '';
    el.style.placeItems = '';
    el.textContent = '';
    const chart = LC.createChart(el, {
      layout: { background: { type: 'solid', color: 'transparent' }, textColor: T.text },
      grid: { vertLines: { color: T.border }, horzLines: { color: T.border } },
      timeScale: {
        timeVisible: true,
        borderColor: T.border,
        rightOffset: 0,
        fixLeftEdge: true,
        fixRightEdge: true,
      },
      rightPriceScale: { borderColor: T.border },
    });

    const candles = chart.addSeries(LC.CandlestickSeries, {
      upColor: T.up,   wickUpColor: T.up,   borderUpColor: T.up,
      downColor: T.down, wickDownColor: T.down, borderDownColor: T.down,
    });
    candles.priceScale().applyOptions({ scaleMargins: { top: 0.1, bottom: 0.3 } });
    candles.setData(weekly);

    const volume = chart.addSeries(LC.HistogramSeries, {
      priceFormat: { type: 'volume' },
      priceScaleId: '',
    });
    volume.priceScale().applyOptions({ scaleMargins: { top: 0.75, bottom: 0 } });
    volume.setData(weekly.map((w) => ({ time: w.time, value: w.volume })));

    chart.timeScale().fitContent();
  }
</script>
```

Pattern extensions:
- **Swap to monthly**: anchor each bucket to the 1st of the month — ``const key = `${d.toISOString().slice(0, 7)}-01`;`` — and set `time: key`. Lightweight Charts requires `YYYY-MM-DD`; a bare `YYYY-MM` will not render.
- **Keep daily**: skip the aggregator entirely — feed `window.visualization.sources.nvda.data` directly if the window is narrow enough to read at daily resolution.
- **Window to last N**: `daily.slice(-N)` before aggregating.

## Multi-ticker comparison

One line series per ticker, colored from a palette, normalized to % change from the first point so scales line up:

Categorical comparisons need a non-semantic palette — `T.up` / `T.down` encode positive/negative deltas and would miscolor series that aren't directionally signed. Inline a categorical hex palette instead, paired for theme:

```js
const LC = window.LightweightCharts;
const root = getComputedStyle(document.documentElement);
const T = { text: root.getPropertyValue('--color-text-primary').trim(), border: root.getPropertyValue('--color-border-tertiary').trim() };
const chart = LC.createChart(document.getElementById('chart'), {
  layout: { background: { type: 'solid', color: 'transparent' }, textColor: T.text },
  grid: { vertLines: { color: T.border }, horzLines: { color: T.border } },
  rightPriceScale: { borderColor: T.border },
  timeScale: { timeVisible: true, borderColor: T.border },
});

const sources = window.visualization.sources;
const dark = document.documentElement.getAttribute('data-theme') === 'dark';
const palette = dark
  ? ['#85B7EB', '#5DCAA5', '#F0997B', '#AFA9EC', '#97C459']
  : ['#185FA5', '#0F6E56', '#993C1D', '#3C3489', '#3B6D11'];

Object.entries(sources).forEach(([name, s], i) => {
  if (s.loading) return;
  if (s.error || !s.data?.length) {
    console.warn(`Skipping ${name}:`, s.error ?? 'no data');
    return;
  }
  const base = +s.data[0].close;
  const normalized = s.data.map((r) => ({
    time: r.date,
    value: (+r.close / base - 1) * 100,
  }));
  const line = chart.addSeries(LC.LineSeries, {
    color: palette[i % palette.length],
    lineWidth: 2,
    title: name.toUpperCase(),
  });
  line.setData(normalized);
});
```

## Line / area for single-ticker price

```js
const line = chart.addSeries(LC.LineSeries, {
  color: T.accent,
  lineWidth: 2,
});
const s = window.visualization.sources.nvda;
if (!s.loading && !s.error) {
  line.setData(s.data.map((r) => ({ time: r.date, value: +r.close })));
}
```

For area fill under the line, swap `LineSeries` for `AreaSeries`. Use `withAlpha()` (see root `SKILL.md` § "Aether tokens") for a faded gradient — a fully opaque `topColor` reads as a flat block, not a chart fill:

```js
const area = chart.addSeries(LC.AreaSeries, {
  lineColor: T.accent,
  topColor: withAlpha(T.accent, 0.35),
  bottomColor: withAlpha(T.accent, 0.02),
  lineWidth: 2,
});
```

## Sizing

- **Raw CSV via source**: up to 10MB is fine. Widget aggregates to viewport resolution — for multi-year daily OHLCV at chat width, weekly or monthly candles read best.
- **Computed / inline**: emit derived rows inline only when the payload stays small enough for `data` (see SKILL.md § "Data fields"). If a computed series is still large, aggregate or window it further before passing it inline; use `sources` only for tool-returned artifacts.

## Labels

Exact cited figures in axis and tooltip labels. Do not hedge ("≈ $200M", "~ 3%") — the chart is a precise medium.

## Gotchas

- **`T.up` / `T.down` are semantic, not categorical** — using them as palette slots in a multi-ticker line chart miscolors direction; ticker C always renders red regardless of trend. Use a categorical hex palette for non-directional series.
- **Lightweight Charts lets you pan past data bounds by default** — `fitContent()` sets initial range only. Set `timeScale: { rightOffset: 0, fixLeftEdge: true, fixRightEdge: true }` to lock viewport edges to first/last candle.
- **One failed source crashes the widget without a per-source guard** — sources resolve independently, so a 404 on one symbol lands as `{ error, data: null }` while others succeed. Destructure `{ error, data }` and skip on `error` before reading `data`.
- **`.replace('rgb', 'rgba')` on an Aether token produces `rgbaa(...)`** — the tokens are already `rgba(...)`, so prefix surgery yields invalid color strings that canvas chart libraries can reject, leaving the chart blank. Use the root Aether-token `withAlpha()` helper to rebuild with a new alpha channel instead.
