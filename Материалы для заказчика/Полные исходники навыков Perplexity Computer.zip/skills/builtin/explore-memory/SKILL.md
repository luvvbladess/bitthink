# Explore Memory

Retrieve prior context — the shared history and accumulated knowledge from past work — from `memory/`.



**Default starting point for who/what/where context: read the relevant wiki index yourself first** (it's small). For personal user context (the "Brain"), start with `memory/knowledge/index.md`; durable user behavior rules live in `memory/knowledge/preferences/`, one topic per file, not in the index. Wikis are curated references distilled across many past sessions. `memory_search` does **not** search them — you must read them. If a wiki is absent for this user or project, fall back to `memory/notes/` and `memory/sessions/`.




**For everything else, delegate to a general-purpose subagent preloaded with `explore-memory`.** The subagent has its own context window and returns only distilled findings, which protects the main agent's context. Only skip the subagent when the answer is already visible from `memory_search` results or a single known file. If you'd need to open more than one file, scan a long conversation, iterate with `memory_search`, or explore broadly, delegate.

```python
run_subagent(
  objective="""
  Search past sessions and memories for context about [TOPIC].
  I need: [SPECIFIC QUESTIONS].
  Keywords to grep: [LIST]. Timeframe: [IF KNOWN].
  If pre-loaded data is empty, expand with memory_search.
  """,
  preload_skills=["explore-memory"],
  task_name="explore_memory",
)
```

Mention any `memory_search` queries you already ran so the subagent doesn't repeat them.


## What's in `memory/`

```
memory/
  knowledge/              # curated personal wiki (Brain) — start here for who/what/where
    index.md              # catalog of pages; read first
    entities/             # people, orgs, tools, services
    concepts/             # topics, techniques, domains
    projects/             # ongoing work, goals
    learnings/YYYY-MM-DD.md
  notes/{domain}/*.md     # distilled user-stated facts (work/, interests/, …)
  sessions/
    sessions_index.md     # overview of available sessions
    asset_index.md        # files generated or uploaded in past sessions
    {week_dir}/
      summaries/{title}.md  # mid-level overviews of past conversations (~60 days)
      {session_id}/
        conversation.md     # YAML session metadata followed by fenced User/Assistant messages
        ai_outputs/, attachments/
  changelog.md            # how this directory was populated (incl. past memory_search queries)
```

Wiki pages are denser than notes; notes are denser than session transcripts. Read the cheapest source that answers the question.

## Heuristics


- **Skim the relevant wiki index and `changelog.md` first.** The index tells you what's covered; the changelog tells you which `memory_search` queries have already been run.
- **Search within a transcript before reading long conversations.** Use content matches or the `## User` / `## Assistant` headings outside message fences to locate relevant messages in `conversation.md`, then read those line ranges with enough surrounding context.
- **Read session metadata from frontmatter.** `session_uuid` is the full citation identity. When present, `first_entry_at` and `last_entry_at` bound the available entry timestamps in UTC, and message headings use entry timestamps. Skill-improvement trajectory histories omit these times because their source has no per-entry timestamps. Each fenced body contains the available query or answer text, which may already combine several original messages.
- **If grep/search finds nothing, expand with `memory_search` before giving up.** It pulls additional sessions and memories from the backend into `memory/`; then search again.
- **Resolve specific session references with `load_sessions`.** Wiki citations (`[cite:N]: pplx://sessions/<uuid>`), short_ids, full UUIDs, and perplexity.ai session links all work — it pulls each session's full transcript into `memory/sessions/`. Use it instead of semantic search when you already know which session you need.
- **Re-share a past file** by reading `sessions/asset_index.md` for the path, then `share_file` with that path (files are already on disk).
- **Stop when you can answer the objective.** Don't keep exploring once you have what you need.
- **If nothing relevant exists, say so quickly.**

## Constraints

- **NEVER glob `memory/sessions/`.** Session IDs are opaque hashes — search file contents instead.
- **Never write under `memory/`.** It's read-only source data.