# seedance_2_5 (Seedance 2.5)

- Quality: ★★★★ | Speed: ★★★★ | Cost: $$
- Resolution: 480p or 720p
- Duration: 4, 6, 8, 12, or 30 seconds
- Aspect ratios: 16:9 (landscape), 9:16 (portrait)
- Supports up to 30 reference images for image-to-video
- Generates native synchronized audio

**Strengths:** ByteDance's newer Seedance model — higher fidelity than 2.0 with far more reference images. Roughly 50% pricier than 2.0.

**When to use:**

- Seedance-style generation when you want higher fidelity than 2.0
- Multi-reference image-to-video, where 2.0's 9-image limit is too low

| Use case                        | Model        |
| ------------------------------- | ------------ |
| Higher-quality ByteDance video  | seedance_2_5 |
