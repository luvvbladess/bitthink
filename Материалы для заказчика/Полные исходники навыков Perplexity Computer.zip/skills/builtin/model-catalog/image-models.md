# Image Generation Models

Use the `model` parameter in `generate_image` to select an image model.

## nano_banana_2 (Nano Banana 2)

- Fast image generation based on Gemini 3.1 Flash
- 1:1 aspect ratio
- Versatile styles: photorealistic, illustrations, artistic, abstract
- Supports up to 14 reference images for img2img / style transfer

**Strengths:** Faster generation, cost-effective, good quality for most tasks.

**When to use:**

- General image generation tasks
- Photos, illustrations, artistic images, decorative graphics
- Iterating on image concepts quickly
- AI-powered edits (remove background, change colors, add/remove objects)

**Not suitable for:**

- Charts, graphs, timelines, infographics (AI hallucinates data — use Python libraries instead)
- Images requiring specific text, numbers, or labels
- Precise measurements or technical diagrams

---

## nano_banana_pro (Nano Banana Pro)

- High-quality image generation
- 1:1 aspect ratio
- Versatile styles: photorealistic, illustrations, artistic, abstract
- Supports up to 14 reference images for img2img / style transfer

**Strengths:** Strong prompt following, diverse style range, effective reference image incorporation.

**When to use:**

- The user explicitly requests Nano Banana Pro
- The user requests a comparison that includes Nano Banana Pro

Brand fidelity, client-facing use, and requests for "highest quality" alone keep the Flare default. Use Sunburst for detailed reference-image refinements.

**Not suitable for:**

- Charts, graphs, timelines, infographics (AI hallucinates data — use Python libraries instead)
- Images requiring specific text, numbers, or labels
- Precise measurements or technical diagrams

---

GPT Image 2.5 Flare and Sunburst share token prices, but cost per image depends on token use. For both models, the command does not expose the vendor's `xhigh`/`max` quality settings or custom pixel dimensions. Use programmatic tools for charts and exact technical diagrams.

## gpt_image_2_5_flare (GPT Image 2.5 Flare) — default

- General image generation and reference-image editing
- Supports transparent backgrounds with `background: "transparent"`
- Supports up to five reference images through `generate_image`
- The command uses high quality and returns PNG files

**When to use:** General visual assets, brand references, client-facing images, in-image text, layouts, and transparent assets.

---

## gpt_image_2_5_sunburst (GPT Image 2.5 Sunburst)

- Detailed generation and editing with longer generation times than Flare
- Supports the same command parameters, transparency, and five-reference limit

**When to use:** Detailed editing or final creative assets when precision matters more than speed.

---

## seedream_5 (Seedream 5 Pro)

- ByteDance image generation model
- High quality at competitive cost
- Supports text-to-image and reference-image workflows
- Supports up to 10 reference images for img2img / style transfer
- LLM API model ID: `seedream_5`

**Strengths:** Cost-effective generation, fast iteration, broad style coverage for general visual assets.

**When to use:**

- Budget-conscious image generation
- Producing many variations to choose from
- General photos, illustrations, decorative graphics, and concept images

**Not suitable for:**

- Transparent backgrounds (use `gpt_image_2_5_flare` instead)
- Charts, graphs, timelines, infographics (AI hallucinates data — use Python libraries instead)
- Precise measurements or technical diagrams

---

## Default

If `model` is not specified, `generate_image` uses **gpt_image_2_5_flare**.

## Selection Summary

| Scenario                         | Model            |
| -------------------------------- | ---------------- |
| General-purpose / default        | gpt_image_2_5_flare |
| Routine style transfer           | gpt_image_2_5_flare |
| Detailed style refinement        | gpt_image_2_5_sunburst |
| Detailed OpenAI editing          | gpt_image_2_5_sunburst |
| Budget constraints               | seedream_5       |
| Quick drafts / iteration         | nano_banana_2    |
| Brand assets / premium quality   | gpt_image_2_5_flare |
| Explicit Nano Banana Pro request | nano_banana_pro |
| Transparent backgrounds          | gpt_image_2_5_flare |
| Strict layouts or in-image text  | gpt_image_2_5_flare |
| User hasn't specified preference | gpt_image_2_5_flare |
