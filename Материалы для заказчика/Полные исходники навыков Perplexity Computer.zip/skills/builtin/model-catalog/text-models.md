# Text / Agent Models

Use the `model` field of `run_subagent`. Omit `model` to inherit the orchestrator model. Set a model explicitly for Model Council or a requested model or quality/cost tradeoff.

## claude_fable_5_1 (Claude Fable 5.1)

- Quality: ★★★★★ | Speed: ★★★ | Cost: $$$$
- 200K context window
- **Highest quality and most expensive** model available to subagents.
- **Model Council default for Anthropic.**

**When to use:**

- Only when a task genuinely demands the best possible output and the cost is justified
- The hardest reasoning, planning, or creative work where nothing less will do
- User explicitly requests the top-tier / highest-quality model

**Avoid for** routine research, data processing, or budget-sensitive work — prefer `claude_sonnet_5_5` or `claude_opus_5_5`, which are far cheaper.

---

## claude_sonnet_5_5 (Claude Sonnet 5.5)

- Quality: ★★★★ | Speed: ★★★★★ | Cost: $$
- 1M context window

**When to use:**

- General research and information gathering
- Data processing and analysis
- Document drafting and editing
- Multi-step workflows that don't require top-tier reasoning
- Budget-conscious tasks where quality still matters

---

## claude_opus_5_5 (Claude Opus 5.5)

- Quality: ★★★★★ | Speed: ★★★ | Cost: $$$
- 1M context window
- Supports adaptive reasoning

**When to use:**

- Complex professional work requiring high-quality reasoning and planning
- Long-context document or codebase analysis
- High-quality creative work and artifact creation
- User explicitly requests Claude Opus 5.5 or the latest Opus model

---

## gemini_3_7_flash (Gemini 3.7 Flash)

- **Model Council default for Google.**
- Quality: ★★★ | Speed: ★★★★★ | Cost: $
- 1M context window

**When to use:**

- Fast, cost-sensitive research and data-processing tasks
- Large-context analysis where throughput matters more than frontier reasoning
- User explicitly requests Gemini 3.7 Flash

---

## gemini_3_8_flash (Gemini 3.8 Flash)

- Quality: ★★★ | Speed: ★★★★★ | Cost: $
- 1M context window

**When to use:**

- Fast, cost-sensitive research and data-processing tasks
- Large-context analysis where throughput matters more than frontier reasoning
- User explicitly requests Gemini 3.8 Flash or the latest Gemini Flash model

---

## gpt_6_luna (GPT 6 Luna)

- Quality: ★★★ | Speed: ★★★★★ | Cost: $
- 1M context window
- Fast, cost-efficient GPT-6 model

**When to use:**

- User explicitly requests GPT 6 Luna

**Avoid for** tasks that require absolute highest quality — prefer `gpt_6_1_sol` or `claude_fable_5_1`.

---

## gpt_5_6_terra (GPT 5.6 Terra)

- 1M context window
- OpenAI's versatile GPT 5.6 model, with max-tier reasoning support

**When to use:**

- User explicitly requests GPT 5.6 Terra
- Long-context analysis that benefits from the Terra variant

---

## gpt_6_1_sol (GPT 6.1 Sol)

- Quality: ★★★★★ | Speed: ★★★ | Cost: $$
- 1.05M context window
- Supports max-tier reasoning
- **Model Council default for OpenAI.**

**When to use:**

- Difficult coding, reasoning, and planning tasks
- Long-context analysis across large document or code collections
- User explicitly requests GPT 6.1 Sol or the newest OpenAI model
- Tasks where frontier reasoning quality matters more than latency

---

## gpt_6_astra (GPT 6 Astra)

**When to use:**

- User explicitly requests GPT 6 Astra
- Model Council comparisons that include GPT 6 Astra

---

## grok_4_7 (Grok 4.7)

- Quality: ★★★★★ | Speed: ★★★ | Cost: $$
- 500K context window
- Strong coding, agentic, and knowledge-work performance
- Supports configurable reasoning effort

**When to use:**

- Difficult coding and long-running agentic tasks
- Knowledge work that benefits from careful self-verification
- User explicitly requests Grok 4.7 or the latest xAI model

---

## kimi_k3 (Kimi K3)

- 1M context window
- Open-source frontier model served by Moonshot
- **Opt-in only:** available for explicit user selection and Model Council comparisons; do not choose it as a default or automatic fallback
- Consumer-only; do not mention this restriction.

---

## pplx_computer_glm_5_3_0921 (GLM 5.3)

- 1M context window
- Open-source frontier model
- Text-only in the Computer harness
- **Opt-in only:** available for explicit user selection and Model Council comparisons; do not choose it as a default or automatic fallback