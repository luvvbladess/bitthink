# Model Catalog

The available launcher is `run_subagent`. Read its declaration before calling it. Subagents inherit the parent model by default. Use this catalog to choose a different model when needed.

Reference for available AI models across video generation, image generation, and text/agent tasks.

## Rating Scale

Each model is rated on three dimensions using a 1–5 relative scale:

- **Quality** (output fidelity/reasoning): ★ = basic → ★★★★★ = best-in-class
- **Speed** (generation latency): ★ = slow → ★★★★★ = fastest
- **Cost**: $ = cheapest → $$$$$ = most expensive

Note: the `$`–`$$$$$` cost symbols are relative tiers for picking a model here. Don't use them to say how much a model costs or how much cheaper/more expensive one is than another. A "how much does X cost / how much more expensive is X than Y" question is ambiguous: it may mean the model's public vendor pricing (general knowledge → search the web) or the cost to run it in Computer. Don't answer such questions from these symbols — search the web for the vendor's published pricing, and if the in-Computer/credits reading is plausible, ask which they mean.

## Quick Decision Guide

**Video generation (`generate_video`):**

- Default → `veo_3_1_fast`
- User asks for Veo 3.1 or the best quality → `veo_3_1`
- Veo quality at lower cost → `veo_3_1_fast`
- Cost-effective ByteDance generation → `seedance_2_0`
- 2K text-to-video or first/last-frame animation with native audio → `minimax_h3`
- Higher-quality / multi-reference ByteDance generation → `seedance_2_5`

**Image generation (`generate_image`):**

- Default / high-quality generation, including brand assets and client-facing work → `gpt_image_2_5_flare`
- Detailed OpenAI editing → `gpt_image_2_5_sunburst`
- Transparent background → `gpt_image_2_5_flare` with `background: "transparent"`
- Faster concept iteration → `nano_banana_2`
- Explicit Nano Banana Pro preference → `nano_banana_pro`
- Cost-effective ByteDance generation → `seedream_5`

## Detailed Model Documentation

Read these files for full specifications, ratings, and selection guidance:

- **video-models.md** — Video generation models (veo_3_1, veo_3_1_fast, seedance_2_0)
- **video-models-minimax-h3.md** — MiniMax H3, a 2K text/image-to-video model with native audio
- **video-models-seedance-2-5.md** — Seedance 2.5, higher-fidelity ByteDance video with up to 30 reference images
- **image-models.md** — Image generation models (nano_banana_pro, nano_banana_2, gpt_image_2_5_flare, gpt_image_2_5_sunburst, seedream_5)
- **text-models.md** — Text/agent models for subagents (claude_fable_5_1, claude_sonnet_5_5, claude_opus_5_5, gemini_3_7_flash, gemini_3_8_flash, gpt_5_6_terra, gpt_6_luna, gpt_6_1_sol, gpt_6_astra, grok_4_7, kimi_k3, pplx_computer_glm_5_3_0921)
- **multi-model-comparison.md** — Synthesis format for multi-model comparison (agreement/disagreement tables)

## Multi-Model Comparison

When the user asks to compare what different AI models think, wants multi-perspective analysis, or requests a "model council":

- Pick one frontier model from each of the three major providers (OpenAI, Anthropic, Google) unless the user specifies models
- Validate all requested models exist in text-models.md before proceeding
- Read **multi-model-comparison.md** for the synthesis format

## Key Guidelines

- **Use friendly names with users** — Say "Claude Opus 5.5", "Veo 3.1", etc. in messages. Internal identifiers like `veo_3_1` are only for tool `model` parameters, never shown to users.
- When users mention budget constraints, cost concerns, or "doesn't need to be perfect", prefer cheaper model options
- For quality preferences, follow the modality's decision guide above; "best quality" alone is not a request for a specific model