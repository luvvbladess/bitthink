# minimax_h3 (MiniMax H3 / Hailuo-03, via Fal)

- Quality: ★★★★★ | Speed: ★★★ | Cost: $$$
- Resolution: 2K at 24 FPS
- Duration: 6, 8, or 12 seconds (8s default)
- Aspect ratios: 16:9 (landscape), 9:16 (portrait)
- Native stereo audio
- Supports image-to-video with one opening frame or an opening/final frame pair
- Image-to-video output follows the opening frame's aspect ratio

**Strengths:** Frontier 2K video with strong prompt adherence, realistic motion, native synchronized stereo audio, and precise keyframe control.

**When to use:**

- High-resolution cinematic output with synchronized audio
- Animating an opening frame, or interpolating between opening and final frames
- Dialogue, ambient sound, or sound effects without post-production
- Complex motion where visual fidelity matters more than cost

| Use case                              | Model      |
| ------------------------------------- | ---------- |
| Text/image-to-video, 2K with audio    | minimax_h3 |
| First-to-last keyframe interpolation | minimax_h3 |
