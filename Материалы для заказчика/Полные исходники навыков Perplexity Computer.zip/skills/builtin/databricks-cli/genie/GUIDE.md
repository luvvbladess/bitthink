# Curated Genie spaces

Use this workflow for an existing Genie space. Use Bash with `api_credentials=["databricks"]` for each request.

1. Resolve the space from the user's link/ID or `databricks genie list-spaces --output json`. Choose a space whose data and purpose match the question; do not create a space to answer a question.
2. Start a conversation with `databricks genie start-conversation "$SPACE_ID" "$QUESTION" --no-wait --output json`. Quote the question as one argument. Preserve the returned conversation and message IDs.
3. Poll `databricks genie get-message "$SPACE_ID" "$CONVERSATION_ID" "$MESSAGE_ID" --output json` until completion or failure. Inspect the status and attachments; a conversation ID alone is not an answer.
4. For a query attachment, retain its SQL and fetch its result with `databricks genie get-message-attachment-query-result "$SPACE_ID" "$CONVERSATION_ID" "$MESSAGE_ID" "$ATTACHMENT_ID" --output json`. Check query execution state, chunking, and truncation before using numerical results.
5. For a follow-up about the same question, use `databricks genie create-message "$SPACE_ID" "$CONVERSATION_ID" "$QUESTION" --no-wait --output json`. Reuse the conversation so Genie retains context, and poll the new message ID.

Conversation submission creates state. If submission times out after returning an ID, inspect that message rather than posting the question again. If Genie requests clarification, resolve that ambiguity before treating generated SQL as the intended analysis. Apply warehouse validation to the returned query and results.

`databricks genie ask` is a separate Genie One workflow. It is not an alias for these space/conversation commands and is not covered by the connector's curated-space guidance. Keep using the selected space or the SQL guide for these tasks.

## Preserve the evidence

Save the question, space/conversation/message IDs, generated SQL, and retrieved query results. Distinguish Genie's narrative from a successfully executed result. Use returned links when available; do not manufacture a citation or result when the service returns only an explanation.