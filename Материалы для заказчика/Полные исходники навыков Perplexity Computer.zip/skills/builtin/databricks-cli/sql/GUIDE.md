# Data discovery and SQL

Use Bash with `api_credentials=["databricks"]` for every Databricks request. Apply the loaded warehouse skill's query-planning, exploration, and validation guidance.

## Find the data and warehouse

Start with the user's table names and available business context. Verify them against live metadata:

```bash
databricks catalogs list --output json
databricks schemas list "$CATALOG" --output json
databricks tables list "$CATALOG" "$SCHEMA" --output json
databricks tables get "$TABLE_FULL_NAME" --output json
databricks warehouses list --output json
```

Assign these variables from actual names/IDs, preserving spelling. Prefer `catalog.schema.table`; quote individual SQL identifier components with backticks when required. Select an accessible warehouse appropriate to the task; do not guess its ID or start/resize compute as an incidental discovery step. Statement execution can start a stopped warehouse, so account for that before submitting work.

## Execute a statement

Use the workspace Statement Execution API through `databricks api`. The installed CLI does not have a `databricks sql execute` command. Save the intended SQL in `statement.sql`, and serialize the request:

```bash
python3 - "$WAREHOUSE_ID" <<'PY'
import json
import sys
from pathlib import Path

request = {
    "warehouse_id": sys.argv[1],
    "statement": Path("statement.sql").read_text(),
    "wait_timeout": "10s",
    "on_wait_timeout": "CONTINUE",
    "disposition": "INLINE",
    "format": "JSON_ARRAY",
}
Path("statement-request.json").write_text(json.dumps(request))
PY
databricks api post /api/2.0/sql/statements --json @statement-request.json --output json > statement-response.json
```

Use named statement parameters for data values, with matching `parameters` entries in the JSON body. Parameters do not substitute for table/column identifiers; validate identifiers against discovered metadata. Bound exploration in the SQL itself with filters and limits.

## Finish the operation

1. Save the returned `statement_id`. `PENDING` and `RUNNING` mean the query is still executing, even if no rows are present.
2. Poll `databricks api get "/api/2.0/sql/statements/$STATEMENT_ID" --output json` until `status.state` is terminal, respecting the task's time budget. Continue polling the same statement after a local wait timeout.
3. On `SUCCEEDED`, interpret `result.data_array` using `manifest.schema.columns`. Follow returned `next_chunk_internal_link` paths through `databricks api get` in the connected workspace when more rows are needed. Check the manifest's truncation indicator; never describe a truncated sample as the full population.
4. On `FAILED`, `CANCELED`, or `CLOSED`, inspect the returned status/error and report the outcome. An empty result before success is not zero.
5. To cancel an operation the user no longer wants, use `databricks api post "/api/2.0/sql/statements/$STATEMENT_ID/cancel"`. Confirm its state afterward.

Prefer SQL aggregation and inline results for analysis. An oversized result should prompt a narrower query or explicit export plan; external result links may require a destination the connector cannot reach.

Keep the SQL, statement ID, result files, and any returned resource links together. Follow the shared warehouse validation checks before presenting findings.