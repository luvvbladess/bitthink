# Jobs and workspace resources

Use Bash with `api_credentials=["databricks"]` for each Databricks request. Inspect an existing resource before selecting a mutation; preserve IDs across discovery, execution, and verification.

## Diagnose a job

```bash
databricks jobs list --output json
databricks jobs get "$JOB_ID" --output json
databricks jobs list-runs --job-id "$JOB_ID" --output json
databricks jobs get-run "$RUN_ID" --output json
```

Distinguish a job definition's `job_id`, a job run's `run_id`, and individual task run IDs. For a multi-task run, identify the failed task in `tasks`, then use `databricks jobs get-run-output "$TASK_RUN_ID" --output json`. The parent run ID is not a substitute for a task run ID when retrieving task output.

Inspect lifecycle/result state, task errors, dependencies, parameters, and the returned run link. Check pagination for large runs and listings. Task output can be truncated; disclose that limitation. Diagnose with reads before proposing a repair or rerun.

## Run or change a job

When the user requests execution, inspect `databricks jobs run-now --help` and the job's parameters. Before submitting, save the actual `job_id`, intended parameters, and a fresh UUID as `idempotency_token` in `run-request.json`. The token must be at most 64 characters; keep the same request file and token for recovery of this submission.

```bash
databricks jobs run-now --json @run-request.json --no-wait --output json > run-submission.json
```

With `--json`, put `job_id` in the request body and omit the positional job ID. `--no-wait` returns the submission response immediately; the default waiter can fail before rendering the run ID. Save the returned `run_id`, then poll `databricks jobs get-run "$RUN_ID" --output json` to terminal state. A successful submission is not a successful job, and a local timeout does not mean the remote run stopped.

If submission has an ambiguous outcome and no run ID was captured, retry the identical saved request with the same idempotency token and save its response separately. Databricks returns the existing run ID if that token already created a run. Once the run ID is known, poll it instead of submitting again. Use a new token only for a separately requested new run; a failed or deleted run is not a reason to silently create another.

For an explicitly requested configuration change, save the current settings and choose the narrow update command. `jobs reset` replaces a job's settings; do not use it as a generic patch. Repair/rerun can repeat side effects, so resolve the failed task and intended scope before invoking either. Read back changed settings or the resulting run state to verify the outcome.

## Workspace files and other products

- `workspace list`, `workspace get-status`, and `workspace export` inspect workspace objects/notebooks. Read their help for export format and output-file options. Preserve the object path and language/format when importing changes.
- `fs` handles DBFS and Unity Catalog volume paths such as `dbfs:/Volumes/<catalog>/<schema>/<volume>/...`. These are distinct from workspace notebook paths. Establish which object store the user means before copying or deleting.
- For compute, pipelines, dashboards, model serving, Apps, or other products, discover the matching command group through `databricks --help`, then inspect the resource and the specific subcommand's help. Do not assume every operation uses the same ID flag or JSON structure.
- Bundle deployment can create or update several resources. Inspect its target and proposed changes before deployment; do not let bundle configuration switch away from the connected workspace.

Return the inspected/changed resource and its returned URL or ID, the observed state, and any remaining failure. Warehouse-specific query and citation steps apply only when the task actually analyzes warehouse results.