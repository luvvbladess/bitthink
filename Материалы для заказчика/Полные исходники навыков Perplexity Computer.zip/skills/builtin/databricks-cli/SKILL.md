# Databricks CLI

Use the installed `databricks` executable through Bash with `api_credentials=["databricks"]` on each authenticated invocation. The connector source ID is `databricks_cli`; the credential name is `databricks`.

The connection selects the workspace and supplies authentication. Keep that workspace and credential configuration unchanged: do not run login, configure profiles, inspect tokens, or install/upgrade the CLI. Local `--help` and `--version` work without credentials. If the connection is missing or its credentials have expired, use the connector's `connect` action for `databricks_cli`. A permission or missing-scope error needs the corresponding grant; reconnecting alone does not grant access.

## Choose the workflow

The `data-warehouses` dependency supplies analysis planning, schema validation, query best practices, and result presentation. Apply it when analyzing warehouse data; jobs and workspace administration do not need an analytical report. This skill supplies the authenticated CLI execution path and the task-specific procedures below.

| Task | Read before executing |
| --- | --- |
| Discover tables or execute SQL | `skills/databricks-cli/sql/GUIDE.md` |
| Ask a question in a curated Genie space | `skills/databricks-cli/genie/GUIDE.md` |
| Inspect jobs/runs, work with notebooks/files, or change workspace resources | `skills/databricks-cli/jobs-workspace/GUIDE.md` |

For other Databricks products, use `databricks --help` to find the command group, then read that group's and subcommand's help. The guides are common workflows, not a limit on the available CLI.

## Command conventions

- Use `--output json` for structured responses. Save large responses to files and inspect the fields needed for the task.
- Resolve names and IDs from the user's resource link or resource listings. Preserve exact catalog/schema/table names, including hyphens and case. Ask when multiple resources fit the request.
- Check subcommand help before using unfamiliar arguments. Many IDs are positional: `databricks jobs get "$JOB_ID" --output json`, not `jobs get --job-id ...`.
- Build complex request bodies with a JSON serializer and pass `--json @request.json`. Keep user text out of hand-built shell/JSON strings; quote shell arguments.
- Follow the command's pagination contract. A single page, truncated result, or running operation is not a complete result. Preserve returned handles and poll the existing operation instead of submitting it again.
- Use `databricks api` for a documented workspace REST operation without a suitable command. It uses the same credentials and permissions; it is not an escape hatch for a denied command.

## Permissions and recovery

Analysis requests use reads. For an explicitly requested change, inspect the target and current configuration first, then perform only the requested change within the connector's permissions. Job execution, compute startup, conversation creation, and deployment can create state or incur cost even when they return data.

On invalid arguments, consult help and fix the command. On a permission/scope denial, stop that operation and explain the missing access. On an ambiguous write timeout, reconcile using the returned resource/run ID or the job guide's saved idempotency token before considering a retry. Never create a new job run solely because its output was lost.

This connection targets one workspace. Account-level commands, alternate workspace/profile selection, external download hosts, and interactive protocols can require capabilities this connector does not supply. Report that boundary rather than changing authentication or fetching credentials.

## Results

For SQL/Genie analysis, retain the SQL or question, resource/statement/conversation IDs, and the actual result files. Use the CLI-result provenance path in `data-warehouses`; CLI JSON does not supply MCP `source_metadata`. Report truncation, incomplete execution, and missing access before drawing conclusions.