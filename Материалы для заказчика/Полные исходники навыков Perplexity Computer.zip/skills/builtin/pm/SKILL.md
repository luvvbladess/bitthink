# Product Management Skills

- `skills/pm/competitive-analysis/GUIDE.md` — Analyze competitors with feature comparison matrices, positioning analysis, and win/loss methodology.
- `skills/pm/feature-spec/GUIDE.md` — Write PRDs with problem statements, user stories, MoSCoW requirements, and success metrics.
- `skills/pm/metrics-tracking/GUIDE.md` — Define product metrics hierarchies, set OKRs, and design dashboards.
- `skills/pm/roadmap-management/GUIDE.md` — Prioritize roadmaps using RICE/ICE/MoSCoW, map dependencies, and plan capacity.
- `skills/pm/stakeholder-comms/GUIDE.md` — Draft audience-tailored updates, communicate risks with ROAM, and document decisions as ADRs.
- `skills/pm/user-research-synthesis/GUIDE.md` — Synthesize qualitative and quantitative research into themes, personas, and sized opportunities.

Read the matching guide before starting the workflow.