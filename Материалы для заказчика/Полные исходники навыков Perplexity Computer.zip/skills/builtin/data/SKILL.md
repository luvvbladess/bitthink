# Data Analysis Skills

Before checking inputs or doing the analysis, read the matching guide:

- `skills/data/static-charts/GUIDE.md` - Create source-agnostic static charts with Python. Load `design-foundations` before reading this guide.
- `skills/data/statistical-analysis/GUIDE.md` - Apply statistical methods: descriptive stats, hypothesis testing, outlier detection.

For SQL, data warehouses, connector-backed analytics, or warehouse citations, load `data-warehouses`.