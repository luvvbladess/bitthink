# Presentation Visual QA

Read and analyze the slide images listed in your task, using any provided expected content as context. Assume there are issues — find them.

Check for: stray dots/circles (orphan shapes, bullets at display size — any unexpected circle is likely this bug), overlapping elements, text overflow/cutoff, decorative lines mispositioned after title wrap, source footers colliding with content, elements too close (< 0.3" gaps), uneven spacing, insufficient slide-edge margins (< 0.5"), misaligned columns, low-contrast text or icons, narrow text boxes causing excessive wrapping, leftover placeholder content, broken connectors, and chart/data mismatches.

For each slide, list ALL issues found, even minor ones.
