# Current Office file attachment

Use this shared recipe when the user asks to email, share, attach, or upload
the current Word document, Excel workbook, or PowerPoint deck from an Office
add-in session. The open Office file is the source of truth; read the actual
file bytes instead of recreating the file from extracted content.

## Host config

| Host | Source | Save before reading | Default filename | MIME |
| ---- | ------ | ------------------- | ---------------- | ---- |
| Word | `word_addin` | `context.document.save()` | `document.docx` | `application/vnd.openxmlformats-officedocument.wordprocessingml.document` |
| Excel | `excel_addin` | `context.workbook.save()` | `workbook.xlsx` | `application/vnd.openxmlformats-officedocument.spreadsheetml.sheet` |
| PowerPoint | `powerpoint_addin` | No PowerPoint JS save API to force a flush | `presentation.pptx` | `application/vnd.openxmlformats-officedocument.presentationml.presentation` |

For PowerPoint, ask the user to save or confirm the deck is up to date if
recent edits matter.
For Word and Excel, save first so unsaved edits are included.

Microsoft documents `Compressed` support by platform: PowerPoint supports it on
web, Windows, Mac, and iPad; Word supports it on Windows, Mac, and iPad but not
Office on the web; Excel supports it on Windows and Mac but not Excel on the
web or iPad. If `getFileAsync` fails because of platform support, surface that
limitation to the user instead of regenerating the file from extracted content.

## Read bytes with Office.js

`Office.FileType.Compressed` is not exposed inside the `run_office_js`
sandbox, so pass Microsoft's documented text value `"compressed"` directly.
The slice size cap is 4 MB; 3 MB matches the in-product Attach-current-file
button.

The `Office.File` handle does not survive across `run_office_js` calls. Read
all slices and close the file inside a single call. Office.js returns each
slice as either a `number[]` or a `Uint8Array`, so normalize with
`Array.from`.

```js
async function readCurrentOfficeFilePayload() {
  return await new Promise((resolve, reject) => {
    Office.context.document.getFileAsync(
      "compressed", // Office.FileType.Compressed
      { sliceSize: 3 * 1024 * 1024 },
      async (openResult) => {
        if (openResult.status !== "succeeded") {
          reject(new Error(openResult.error?.message || "getFileAsync failed"));
          return;
        }

        const file = openResult.value;
        const slices = [];
        try {
          for (let i = 0; i < file.sliceCount; i += 1) {
            const slice = await new Promise((res, rej) => {
              file.getSliceAsync(i, (sliceResult) => {
                if (sliceResult.status !== "succeeded") {
                  rej(new Error(sliceResult.error?.message || "getSliceAsync failed"));
                  return;
                }
                res(sliceResult.value.data);
              });
            });
            slices.push(Array.from(slice));
          }

          resolve({
            host: Office.context.host,
            document_url: Office.context.document.url || null,
            size: file.size,
            slices,
          });
        } catch (err) {
          reject(err);
        } finally {
          file.closeAsync(() => undefined);
        }
      },
    );
  });
}
```

Wrap the helper with the host runtime:

```js
// Word
return await Word.run(async (context) => {
  context.document.save();
  await context.sync();
  return await readCurrentOfficeFilePayload();
});
```

```js
// Excel
return await Excel.run(async (context) => {
  context.workbook.save();
  await context.sync();
  return await readCurrentOfficeFilePayload();
});
```

```js
// PowerPoint
return await PowerPoint.run(async () => {
  return await readCurrentOfficeFilePayload();
});
```

## Reassemble in the worker

Concatenate `slices` in order, write the result to the workspace, and pass the
file path through `attachment_files` for `gmail__send_email` /
`outlook__send_email`, or upload it with `google_drive__upload_file` /
`gws drive files create`.

```python
from pathlib import Path
from urllib.parse import unquote, urlparse

OFFICE_FILE_DEFAULTS = {
    "Word": (
        "document.docx",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ),
    "Excel": (
        "workbook.xlsx",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ),
    "PowerPoint": (
        "presentation.pptx",
        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    ),
}

def filename_for_office_payload(payload: dict, default: str) -> str:
    url = payload.get("document_url")
    if not url:
        return default

    name = unquote(urlparse(url).path.rsplit("/", 1)[-1])
    if not name:
        return default

    ext = "." + default.rsplit(".", 1)[1]
    return name if "." in name else f"{name}{ext}"

def write_office_payload(payload: dict, workspace: Path = Path("/home/user/workspace")) -> tuple[Path, str]:
    default_name, mime = OFFICE_FILE_DEFAULTS[payload["host"]]
    data = b"".join(bytes(chunk) for chunk in payload["slices"])
    path = workspace / filename_for_office_payload(payload, default_name)
    path.write_bytes(data)
    return path, mime
```

Reuse this pattern for requests like "email this document," "attach the
current file," "share this workbook," or "save a copy to Drive."
