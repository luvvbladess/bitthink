# Office Skills

- `skills/office/docx/GUIDE.md` — Create, read, edit, or manipulate Word documents (.docx files) with formatting, tables of contents, headings, and page numbers.
- `skills/office/pdf/GUIDE.md` — Read, extract, combine, split, rotate, watermark, create, fill forms, encrypt/decrypt, and OCR PDF files.
- `skills/office/pptx/GUIDE.md` — Create, read, edit, combine, or split PowerPoint presentations (.pptx files) including templates, layouts, and speaker notes.
- `skills/office/theme-factory/GUIDE.md` — Style non-web artifacts (slides, docs, reports) with pre-set or custom themes including colors and fonts.
- `skills/office/xlsx/GUIDE.md` — Create, read, edit, or manipulate spreadsheet files (.xlsx, .xlsm, .csv, .tsv) with formulas, formatting, and charting.
- `skills/office/current-file-attachment/GUIDE.md` — Read when an Office add-in task operates on the currently open file attachment.

Read the matching guide at `skills/office/<guide-name>/GUIDE.md`. For creation or substantive revision, identify the intended audience, artifact purpose, required content, and any central takeaway. Preserve native, editable structure.