# Financial Model Conventions

## Style Standard

Apply this standard to every finance deliverable unless the user or an existing template says otherwise. Analysts read font color as provenance, so a Perplexity-branded or design-foundations accent palette makes the workbook look wrong and untrustworthy in this context.

### Font color by cell source

| Cell type                                                                          | Font color | Hex      |
| ---------------------------------------------------------------------------------- | ---------- | -------- |
| Hard-coded number (input, assumption, historical data)                             | Blue       | `0000FF` |
| Calculation: any formula or function, including ones that reference other sheets   | Black      | `000000` |
| Direct link: a bare reference to one cell or range on another sheet, nothing else  | Green      | `008000` |
| Direct link: a bare reference to a cell or range in a different workbook           | Green      | `008000` |
| Formula from a data provider (Bloomberg, FactSet, Capital IQ, Refinitiv)           | Dark red   | `C00000` |

Color a cell by how it is populated, never by what it means. Text labels and headers are exempt.

A direct link has no operator or function around the reference. The moment a formula adds, multiplies, wraps a function, or combines references, it is a calculation and is black, even when every reference points at another sheet.

| Formula                                        | Color    | Why                                  |
| ---------------------------------------------- | -------- | ------------------------------------ |
| `='LBO Model'!C41`                             | Green    | Bare reference to another sheet      |
| `=Assumptions!D7*(1+Assumptions!D10)`          | Black    | Arithmetic, even though cross-sheet  |
| `=TEXT(Assumptions!D6,"0.0")&" NOI"`           | Black    | Function around the reference        |
| `=IF(C5=Assumptions!D11,C19,0)`                | Black    | Function around the reference        |
| `=BDP("AAPL US Equity","PX_LAST")`             | Dark red | Data-provider function               |

### Fonts, fills, and headers

- Body cells: Calibri or Arial 11 on a white background. Font color follows the source table above; the only body fill is the yellow key-assumption fill below.
- Headers: bold. One dark fill at most, navy `1F3864` with white text, for title and column-header rows.
- Yellow fill `FFFF00` marks key assumptions that need attention. Do not use fill to encode cell type or to highlight KPIs.
- No teal, mint, or other accent fills, no gradients, no theme-factory themes, unless the user asks for branded styling.
- No Excel Table banding, data bars, color scales, or icon sets in a model unless the user asks. These rules and the number formats below take precedence over the generic formatting defaults in the guide and in `charts-and-formatting.md`.

```python
from openpyxl.styles import Font, PatternFill

INPUT_FONT = Font(name="Calibri", size=11, color="0000FF")
FORMULA_FONT = Font(name="Calibri", size=11, color="000000")
LINK_FONT = Font(name="Calibri", size=11, color="008000")  # other sheet or other workbook
PROVIDER_FONT = Font(name="Calibri", size=11, color="C00000")  # Bloomberg, FactSet, Capital IQ
HEADER_FONT = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
HEADER_FILL = PatternFill("solid", fgColor="1F3864")
KEY_ASSUMPTION_FILL = PatternFill("solid", fgColor="FFFF00")
```

Assign the font when you write each cell, from what you know you are writing: a hard-code gets `INPUT_FONT`, a calculation gets `FORMULA_FONT`, a bare cross-sheet reference gets `LINK_FONT`. Do not classify by scanning formula text; a rule such as "any formula containing `!` is green" turns every cross-sheet calculation green, and a provider call wrapped in `IFERROR` loses its dark red. Restyle only the cells in the task's edit scope. Leave numeric headers such as years, existing template styles, and untouched sheets alone.

## Number Formatting Standards

- **Years**: Format as text strings (e.g., "2024" not "2,024")
- **Currency**: Use $#,##0 format; ALWAYS specify units in headers ("Revenue ($mm)")
- **Zeros**: Use number formatting to make all zeros "-" (e.g., `"$#,##0;($#,##0);-"`)
- **Percentages**: Default to 0.0% format (one decimal)
- **Multiples**: Format as 0.0x for valuation multiples (EV/EBITDA, P/E)
- **Negative numbers**: Use parentheses (123) not minus -123

```python
for row in range(2, 21):
    ws.cell(row=row, column=2).number_format = "$#,##0"
    ws.cell(row=row, column=3).number_format = "0.0%"
    ws.cell(row=row, column=4).number_format = "#,##0"
```

## Formula Construction Rules

### Assumptions Placement
- Place ALL assumptions (growth rates, margins, multiples, etc.) in separate assumption cells
- Use cell references instead of hardcoded values in formulas
- Example: Use `=B5*(1+$B$6)` instead of `=B5*1.05`

### Formula Error Prevention
- Verify all cell references are correct
- Check for off-by-one errors in ranges
- Ensure consistent formulas across all projection periods
- Test with edge cases (zero values, negative numbers)

### Documentation Requirements for Hardcodes
- Comment or in cells beside (if end of table)
- Format: "Source: [System/Document], [Date], [Specific Reference], [URL if applicable]"
