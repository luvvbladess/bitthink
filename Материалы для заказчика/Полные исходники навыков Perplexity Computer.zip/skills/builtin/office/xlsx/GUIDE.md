


# Required reading

**Read `references/xlsx-repl-workflow.md` before your first `xlsx_repl` call.** It covers the open → read → write+save → recalc → verify patterns and the recalc subprocess invocation. The schema alone won't tell you any of this; skipping the read produces split-call anti-patterns and missed recalcs. **Target: 2–3 calls per task.**

# Gotchas

1. **Don't cite values without sheet + address** — "Revenue!B5 = $1,234", not just "$1,234".
2. **Don't compute in Python; use formulas, not hardcodes** — derived values come from spreadsheet formulas (e.g. `=SUM(F2:F19)`, `=(B5-C5)/B5`), not Python snapshots. Don't forget `number_format` on formula cells either — they display raw precision otherwise.
3. **Don't ship formula errors** — after recalc, check the script's error report. Any `#REF!`, `#DIV/0!`, `#VALUE!`, `#N/A`, or `#NAME?` fails the deliverable.
4. **Recalc after the final save** — any later `openpyxl` save, including formatting or page-setup changes, can discard cached formula results. Run `recalc.py` after the last save, then verify representative formula cells with a separate `data_only=True` workbook. A PDF preview is not cache verification because LibreOffice recalculates while rendering.
5. **Don't edit beyond what's asked** — modify only the cells/sheets the user named (or strictly required to produce them). Match existing format, style, and formula conventions exactly. Don't add rows/values the user didn't request and don't touch unrelated cells or sheets. Preserve merged cells, conditional formats, and chart/table source ranges.
6. **Don't tidy what wasn't asked** — don't reformat, restyle, or rewrite existing formulas/cells just because they look improvable. "Helpful tidying" is silent damage from the user's perspective.
7. **Don't mutate read-only requests** — answer workbook questions without modifying, saving, or exporting the file.

# Preferred Tool: `xlsx_repl`

`xlsx_repl` is a persistent Python REPL with `openpyxl`; variables and loaded workbooks persist across calls. Use that state to follow the curated open → inspect → edit and save → recalculate → verify workflow.

For sandbox-side spreadsheet work, use `xlsx_repl` for all Python that reads, creates, modifies, saves, or verifies workbook files. Import and use `openpyxl` inside the REPL. Do not manipulate workbook files through bare `python`, `python3`, IPython, or shell scripts. If an `xlsx_repl` call fails, correct and retry it instead of switching to another Python execution path.


Call deferred tool `xlsx_repl` with the Python source in its `code` argument.

For Python containing `${...}`, use the direct file tool to create `/home/user/workspace/xlsx_task.py`, then call `xlsx_repl` with `code: "exec(open('/home/user/workspace/xlsx_task.py').read())"` to avoid JavaScript template-literal interpolation. Execute only the file you created.



# Output Requirements

## Professional Font

Use Calibri or Arial for all deliverables unless the user or existing template specifies otherwise.

## Financial Models

When the deliverable is a financial model or analyst workbook (LBO, DCF, three-statement, budget, forecast, valuation, comps, returns analysis), read `references/financial-models.md` before styling any cell. Analysts expect the industry standard: Calibri or Arial, black text on white, and font color by cell source — blue hard-codes, black for every calculation including cross-sheet arithmetic, green only for bare direct links to other sheets or other workbooks, dark red data-provider functions. Do not apply the design-foundations accent palette, theme-factory themes, or colored KPI fills to a finance deliverable unless the user asks for branded styling. For these deliverables the reference takes precedence over the generic Number Formatting table below and over the Excel Table, data bar, and color scale defaults in `references/charts-and-formatting.md`. Formatting never changes formulas or values.

## Number Formatting

| Data Type  | Format Code | Example   |
| ---------- | ----------- | --------- |
| Integer    | `#,##0`     | 1,234,567 |
| Decimal    | `#,##0.0`   | 1,234.6   |
| Percentage | `0.0%`      | 12.3%     |
| Currency   | `$#,##0.00` | $1,234.56 |

## Alignment

| Content    | Horizontal |
| ---------- | ---------- |
| Headers    | Center     |
| Numbers    | Right      |
| Short text | Center     |
| Long text  | Left       |
| Dates      | Center     |

## Layout

| Element         | Position                     |
| --------------- | ---------------------------- |
| Left margin     | Column A empty (width 3)     |
| Top margin      | Row 1 empty                  |
| Content start   | Cell B2                      |
| Section spacing | 1 empty row between sections |
| Table spacing   | 2 empty rows between tables  |
| Charts          | Below tables (2 rows gap)    |

## Content Completeness

| Check             | Action                                       |
| ----------------- | -------------------------------------------- |
| Missing values    | Blank or "N/A", never 0 unless actually zero |
| Units             | In header: "Revenue ($M)", "Growth (%)"      |
| Abbreviations     | Define on first use                          |
| Calculated fields | Use formulas so users can audit              |

## Reference files (read on demand)

| Need                                                                         | Reference file                        |
| ---------------------------------------------------------------------------- | ------------------------------------- |
| Multi-step `xlsx_repl` workflow (open / read / write+save / recalc / verify) | `references/xlsx-repl-workflow.md`    |
| Charts, conditional formatting, tables, images, data validation              | `references/charts-and-formatting.md` |
| Financial model standard (required for finance deliverables: colors, fonts, number formats) | `references/financial-models.md`      |
| Sheet organization, text rows, sorting, comparison columns                   | `references/layout-and-structure.md`  |
| Error recovery, formula verification                                         | `references/formula-verification.md`  |