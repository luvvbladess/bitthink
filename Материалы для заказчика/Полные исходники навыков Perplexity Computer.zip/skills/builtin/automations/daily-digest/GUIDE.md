# Create a daily digest

Use this workflow for a recurring digest, morning briefing, or roundup.

## Aim for a useful briefing

The digest should feel like a personal briefing, not a search-results recap. Each item should name one fresh, source-backed development and make clear why it matters to the user: something needing attention, a meaningful update, or wider context connected to their interests or work.

Prefer a small set of material updates over filler. Do not repeat old news without a new development, recap something the user already authored or acknowledged without a material new delta, combine unrelated events just because they share a topic, invent an update during a quiet period, or turn every mention into a task.

## Shape the digest with the user

Resolve these choices before creating the briefing:

- **Topics** — projects, people, companies, industries, or questions to follow. Treat the user's request and relevant session context as already supplied input.
- **Sources** — the web, named sites, and connected sources such as Slack, email, Calendar, Drive, GitHub, or Linear. If a requested source is not connected, follow the connection workflow in `skills/automations/creation/GUIDE.md` before creating the Automation.
- **Preferences** — what to always include or ignore, plus any desired length or organization. These are optional unless the user names them.
- **Schedule** — cadence, one or more local run times, and timezone. Use the user's timezone when available. Ask for it only when unavailable or when the user wants another timezone.

Use context rather than making the user complete a long questionnaire. For a broad prompt such as "set up my daily digest," ask one concise combined question covering the missing topics, sources, and schedule. Offer relevant connected sources or context-derived topics as suggestions when available. Do not re-ask for supplied details or require optional preferences before proceeding.

## Write the recurring brief

The stored prompt should preserve the user's choices and tell each run to:

1. Find material developments from the selected topics and sources since the previous run, using the preceding 24 hours for the first run. If a selected source cannot be checked, note that coverage is incomplete rather than treating the failure as evidence that nothing changed.
2. Select updates for this user rather than exhaustively recapping every source. Use the user's interests, work, and session context to judge relevance, never as evidence for a factual claim. Ground every factual item in the exact source that supports the development and include its link; never reconstruct a source URL.
3. Organize the result into the useful sections that have content:
   - **Needs your attention** — only source-evidenced requests, deadlines, blockers, or decisions owned by the user.
   - **Updates** — meaningful changes across followed work and topics.
   - **Wider context** — external developments with a concrete connection to the user's stated interests or work.
4. For each item, state what changed and why it matters. Consolidate multiple sources covering the same development, but keep distinct developments separate even when they concern the same project or topic. Group related items under stable topic labels when helpful.
5. Follow the user's instructions about what to include or ignore, as well as their length and formatting preferences. When updates are otherwise comparable, prefer material developments from the user's selected connected sources over generic web coverage. If nothing material changed, say so briefly instead of padding the digest.
6. Return the briefing in the current thread. Do not send its content through external-service connector tools such as email or Slack. Automatic completion notifications follow the default-on toggle and backend-computed route in `skills/automations/SKILL.md`. Add `send_notification` to the stored prompt only when the user separately requests custom Email or In-app delivery, and avoid duplicating automatic completion.

## Create and verify the Automation

Compile every requested run time into one schedule when the cadence supports it.

After creation, verify the returned next run against the user's schedule in their timezone. Report the schedule, timezone, sources, topics, computed automatic notification route, and any separate custom delivery so the user can correct the brief without reading the stored prompt.