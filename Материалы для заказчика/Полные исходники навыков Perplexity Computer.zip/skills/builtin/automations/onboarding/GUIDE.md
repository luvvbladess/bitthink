# Choose an automation

Use this guide only when the user needs help choosing what to automate. Reuse the conversation and skip choices already settled.

1. Offer a few concrete tasks through `request_user_input`, based on stated interests, current work, and known connections. Describe the result each task produces. Do not fetch unrelated private content to personalize suggestions or invent interests or connections. The tool supplies its own custom-answer option.
2. If the trigger is still unknown, ask when it should run: a schedule or a specific event. Tailor schedule choices to the task and reuse the known timezone. For an event, identify the source and condition, then check support with `pplx automation describe --source '<source>'`; do not promise availability from the guide list.
3. Read `skills/automations/creation/GUIDE.md` for a schedule or `skills/automations/references/events/GUIDE.md` for an event or price alert. Complete setup there without repeating answers or adding a mandatory final review.

Ask one unresolved question at a time. A custom answer is input to use, not a reason to ask the user to type it again. If it leaves the task unclear, ask a plain task question before asking about timing.