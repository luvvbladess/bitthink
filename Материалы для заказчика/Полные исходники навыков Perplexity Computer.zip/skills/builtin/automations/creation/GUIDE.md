# Create a reminder or schedule

Resolve the task, local time/cadence, and timezone from the request and context. Ask only for missing choices. Write a concise run prompt that preserves the scope, output format, and any deliverable; do not add an elaborate response template to a simple task. For a daily digest or briefing, first read `skills/automations/daily-digest/GUIDE.md`.

For schedules more frequent than daily, read `skills/automations/references/notifications.md` before writing the run prompt or confirming setup. It covers the default notification condition and the one-time notification preference question.

If the task needs a connected service, verify it before creating.

Use `list_external_tools` to check its status. Connect a `DISCONNECTED` service, or an `OUTDATED` service offering only `connect`. An `OUTDATED` service with normal tools is usable; reconnect only on a permission error.

Create only once the service is usable. If the user declines a required connection, leave the automation uncreated.

## Destination


For the first schedule in this conversation, omit `--deliver`: runs return here with shared context. If this conversation already has an automation and the user asks for another, use `--deliver automation-thread` for its own persistent session. Use conversation cards or `get` if the existing automation is unclear. Edit an existing automation when the user is changing it.

Explicit requests override these defaults: `--deliver source-thread` keeps updates here; `--deliver new-thread` gives each run a fresh session. Use fresh sessions when isolation across accounts, entities, or credentials is needed. Source-thread prompts can rely on shared context; dedicated and fresh sessions need self-contained instructions. New run sessions are visible on the automation page, not library/search.


## Computer mode and Project

Computer mode options apply to `--deliver new-thread` and the first run of `--deliver automation-thread`; later dedicated runs inherit their session's mode. Source-thread automations inherit the source session's mode, so never pass `--effort-mode`, `--reasoning-effort`, or `--model` for them.

Before using effort flags, check `pplx automation create --help` for `--effort-mode` and `--reasoning-effort`; an existing session may have an older CLI. If flags or discovery fields are missing, explain the limitation and never silently drop an explicit selection. For an unrequested routine selection, ask whether to proceed with the engine default or, when compatible with the requested destination, source-thread inheritance.

Before selecting a named preset or custom model for a dedicated or new-thread automation, run `pplx session models`. Use only the keys in `computer_harness.modes`, model ids in `models`, and each model's `supported_reasoning_efforts` returned for the current user:

- For routine dedicated or new-thread work, select `--effort-mode light` when Light is available.
- Select `--effort-mode standard` when the task warrants more reasoning than routine work and Standard is available.
- Select High, Ultra, or a custom `--model ... --reasoning-effort ...` combination only when the user explicitly requests it.


`create` binds to the current Project automatically when the session is Project-backed. A `--deliver new-thread` or `--deliver automation-thread` create can override that destination — `--project '<uuid>'` redirects it, and `--no-project` leaves it unbound when the user explicitly asks; a `--deliver source-thread` create always uses the source session's Project.


Passing `--model` without `--reasoning-effort` preserves the legacy model-only behavior.

## Create and verify

```bash
pplx automation create --name '<name>' --prompt '<run instructions>' \
    --rrule '<rule>' --tz '<IANA timezone>' \
    [--start-at '<local ISO date-time>'] [--end-at '<exclusive local date/time>'] \
    [--deliver '<source-thread|automation-thread|new-thread>'] \
    [--notifications-enabled '<true|false>']
```

Times are local to `--tz`; do not convert to UTC. Common rules:

| Request | Rule |
| --- | --- |
| Daily at 9am | `FREQ=DAILY;BYHOUR=9;BYMINUTE=0` |
| Weekdays at 9am | `FREQ=WEEKLY;BYDAY=MO,TU,WE,TH,FR;BYHOUR=9;BYMINUTE=0` |
| Mondays at 9am | `FREQ=WEEKLY;BYDAY=MO;BYHOUR=9;BYMINUTE=0` |
| Once at a future time | `FREQ=DAILY;COUNT=1` and `--start-at` at that time |

For other recurrences, anchors, or an end date, read `skills/automations/references/schedules.md`. An event-watching request belongs in `skills/automations/references/events/GUIDE.md`, not a polling schedule.

Leave completion notifications enabled unless the user asks otherwise; the shared skill rules cover custom or conditional delivery. Run the create command with untouched output. Verify the returned next run, end boundary, `output_kind`, and `notification_delivery`, then summarize them. `automation_thread` has no destination session until its first run; later runs reuse that session. A rejected source-thread request is not permission to switch destinations: ask before choosing independent sessions.