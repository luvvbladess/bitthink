# Create from a side chat

Automations cannot be created from an Incognito side chat. Explain this limitation and offer to set up the automation from a normal conversation; do not copy private content there without the user's approval.

Before creating from a Computer side chat, resolve the actual parent task's Project from its stored context; do not infer it from the side chat or guess its name. If it has a Project, name that Project and explain that its members can read the automation's stored prompt. The creator still owns the automation and runs it under their identity. Dedicated-session output starts private even with Project context; if using explicit `new-thread` delivery or an event trigger, Project members can also read the run threads.

If the proposed prompt includes details shared only in the side chat, show the proposed run instructions and the Project audience, ask for explicit confirmation to share them, and **wait for the user's answer before any create call**. A warning followed immediately by creation is not consent. If the Project or audience cannot be determined, resolve that missing information before asking for consent or creating.

If the user asks to keep the automation private or unbound, including `--no-project`, **do not create it under a Project-backed parent**. Explain that side-chat creation inherits the parent's Project and `--no-project` is rejected when the parent has a Project. Offer to set it up from an ordinary unbound conversation, or to remove private content with the user's approval; do not silently switch conversations or treat redaction as permission to ignore an unresolved private/unbound requirement.

If the parent has no Project, creation stays unbound with or without `--no-project`; do not invent a Project-sharing warning or confirmation. These are agent consent checks, not a backend consent gate. The server enforces parent Project inheritance and keeps runs out of the side chat, regardless of the agent's warning or the user's confirmation.
