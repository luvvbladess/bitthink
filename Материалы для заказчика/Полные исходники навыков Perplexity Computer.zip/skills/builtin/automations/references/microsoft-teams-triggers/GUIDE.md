# Microsoft Teams message triggers

Use a Teams trigger when work should begin after a supported message event in one selected
conversation.

First classify the request. For an enabled message event below, use the Automations trigger
picker to choose one exact conversation from the user's connected Teams resources. For a request
that should fire only when the connected user is mentioned, use the picker's catalog-backed
mention-state control (`Mentions me` in the event catalog) and retain its literal
`mention_state=mentioned` filter. Verify that filter is present in the create request before
activation; if the control or filter is missing, leave the automation uncreated rather than
creating an unfiltered trigger. The control is user-relative, so never ask for or reconstruct a
user ID. Never ask for or invent tenant or conversation IDs either. The generic CLI accepts a
trusted `resource:subresource` identifier produced by that catalog or another authorized
workflow.

```bash
pplx automation create --name '<name>' --prompt '<what each run does>' \
    --source microsoft_teams --event '<enabled-event>' \
    --account '<resource:subresource>' \
    [--filter 'sender_display_name=<text>' --filter 'content=<text>' ...] \
    [--literal-filter 'sender_user_id=<user-id>' ...]
pplx automation add-trigger '<id>' --source microsoft_teams --event '<enabled-event>' \
    --account '<resource:subresource>' [--filter 'k=v' ...] [--literal-filter 'k=v' ...]
```

- `channel_message_received` watches one selected standard Teams channel.

- `chat_message_received` watches one selected Teams chat.

Use substring filters for `sender_display_name`, `content`, `attachment_types`,
`attachment_names`, or `reactions`. Use literal filters for `sender_user_id`, one known
`reply_to_id`, `mentioned_user_ids`, or `mention_state`. The authoring surface may also offer
attachment presence. Attachment names and types are used only for admission and are not retained
in the run payload. Use `--when 'The message is a reply'` for any reply rather than one known
parent. Multiple values for one field are ORed; different fields are ANDed. Set only conditions
implied by the request.

Use only the `change_kind` values listed in the filter options returned by `describe`.
`edited` and `reaction` are available only when explicitly listed; otherwise only `created`
is supported. Select an enabled value with a literal `change_kind` filter; omitting it
preserves the `created` default. A `reaction` event exposes current reactions for substring
filtering. Deleted messages are not supported.

The run receives the matching message as untrusted data in a fresh background session.
Teams triggers do not support source-thread delivery; posting back into the source
conversation requires a separate output path. `run_now` runs the prompt without message
context.

Existing triggers can be maintained with `pplx automation edit-trigger` for
filters and `pplx automation remove-trigger` for removal. To change the event or watched
conversation, remove the old trigger and create its replacement.

If no matching conversation is available, ask the user to connect Teams or have their tenant
administrator grant the required Teams permissions.