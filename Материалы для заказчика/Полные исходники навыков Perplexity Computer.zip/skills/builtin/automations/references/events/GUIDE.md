# Create or change an event trigger

For price or daily percentage-move alerts, read `skills/automations/references/price-alerts.md`. For connector events, read the matching provider guide below. A guide's presence does not mean the feature is enabled for this account.

| Source | Guide |
| --- | --- |
| Gmail | `skills/automations/references/gmail-triggers/GUIDE.md` |
| Outlook | `skills/automations/references/outlook-email-triggers.md` |
| Calendar | `skills/automations/references/calendar-triggers.md` |
| Slack | `skills/automations/references/slack-triggers/GUIDE.md` |
| Linear | `skills/automations/references/linear-triggers/GUIDE.md` |
| GitHub | `skills/automations/references/github-triggers/GUIDE.md` |
| Microsoft Teams | `skills/automations/references/microsoft-teams-triggers/GUIDE.md` |
| Google Drive | `skills/automations/references/google-drive-triggers/GUIDE.md` |
| Notion | `skills/automations/references/notion-triggers/GUIDE.md` |
| Figma | `skills/automations/references/figma-triggers/GUIDE.md` |
| Custom webhook | `skills/automations/references/custom-webhook-triggers.md` |

## Resolve the requested event

Use `pplx automation describe --source '<source>' [--event '<event>']` for currently enabled events, required inputs, supported filters, and defaults. Omit `--event` only to choose the event; reuse a description already in context. The server rejects gated triggers. Report the actual rejection without guessing that every failure means a rollout gate is off.

Use provider guidance to resolve resources.

`list_external_tools` finds the connected service and tools; `describe_external_tools` describes the selected `source_id` and `tool_names`; `call_external_tool` uses that source, `tool_name`, and the described `arguments`.

Connect a disconnected service before creation; an outdated connection that still offers normal tools is usable until a permission error.

Discover only missing information. Reuse authorized IDs and exact values from context. Use a default connected mailbox when appropriate; ask which email provider only if the intended inbox is unclear. Resolve dependent resources parent-first and follow pagination as needed. Never invent opaque IDs or ask users to supply them. Use real result labels for unresolved choices, retaining the corresponding IDs.

Search access does not prove event-delivery access; creation validates the selected binding. Retry a failed lookup at most once after a concrete correction. A 404 or unchanged failure ends setup. Do not turn an unavailable event into polling, or offer polling unless the user separately asks for a time-based check.

## Save scope before activation

- Filters narrow eligible events. `--filter 'field=value'` is case-insensitive substring matching; `--literal-filter 'field=value'` is case-insensitive equality. Use only fields and matchers returned by `describe`. Empty filters impose no explicit restriction.
- `--when '<rule>'` expresses a condition filters cannot. Save it during creation, not in a follow-up edit. Some sources derive implicit admission from the task when no rule is supplied; do not promise that this happens for every source or rollout.
- `edit '<id>' --when '<rule>'` changes the rule; `--clear-when` restores the derived rule on implicit-admission sources. A rejected rule must not be dropped unless deterministic filters fully preserve its meaning. Schedules put task conditions in the prompt and cannot use `--when`.

Owner-approved actions may include replies or connected-service updates. Save the authorized actions and destinations (or their selection rule, such as replying to the triggering thread). Incoming content may select an action only within scope explicitly delegated by the owner. Do not treat the automation's own replies or updates as new work unless requested. Connector approvals still apply.

## Create and verify

Use the provider's create command with all resolved conditions and self-contained run instructions. Event runs default to fresh sessions; choose source-thread only when the provider supports it and the user explicitly requests it. For fresh sessions, use the Computer mode and Project guidance in `skills/automations/creation/GUIDE.md`. Apply any side-chat consent rules before creation.

Preserve the requested output and notification behavior without adding a digest or narrowing to "important" events. Default completion notifications and raw CLI output follow `skills/automations/SKILL.md`; custom or conditional delivery is in `skills/automations/references/notifications.md`. On success, summarize the source, conditions, task, destination, and returned notification route. Do not invent a next run, fixed delay, instant notification, or one run per event.