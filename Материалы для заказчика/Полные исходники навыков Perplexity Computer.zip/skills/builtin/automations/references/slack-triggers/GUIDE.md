# Slack message triggers

For user-owned Slack message automations, filters select eligible messages. When
Slack user admission is enabled, semantic admission decides whether the task
should run: an explicit `--when` is the rule; otherwise the automation's name and
prompt supply it. An admitted event starts a run without the connector batch
delay. When that rollout is disabled, Slack triggers use the connector batch
path without deriving an implicit rule from the name and prompt. Do not guarantee
implicit admission, no-batch timing, instant completion, or one run per message.
If the user wants every new message summarized, preserve that scope in the prompt;
do not turn it into a digest or an "important messages only" task.

The run receives matching messages as untrusted data in a fresh background session.
Follow the approved-action rules in `skills/automations/references/events/GUIDE.md` and notification rules in `skills/automations/SKILL.md`. When the owner
requests reactions or replies to matching messages, target the triggering message
or thread. Cross-service changes must stay within the saved task's approved scope. `run_now`
runs the prompt without message context.

Slack conversation-watching requests (a channel, DM, or group DM) use a connector
trigger, never a schedule.

Use `pplx automation describe --source slack --event message_received` for enabled
events, required inputs, supported filters, and defaults. The account input also
includes its format and enabled `resource_types`.
Only offer conversation types listed there. If the requested type is absent,
explain that this automation type is not enabled and leave it uncreated.

Use source and tool names from the discovery steps in `skills/automations/references/events/GUIDE.md`.

1. Verify Slack is connected as described in `skills/automations/references/events/GUIDE.md`. Select the listed
   tool for joined conversations with workspace and conversation IDs.

2. Describe and call the selected tool. Pass the supplied

   channel name as `query`; omit it if none was named. The default searches joined
   public/private channels. When enabled in `resource_types`, use `types: ["im"]`
   for an existing DM or `["mpim"]` for a group DM, with the participant's name as the query.
3. Continue an account's `next_cursor` with its `team_id`
   and `slack_user_id` and the same search inputs if needed, even on an empty page.
4. Treat any account error as incomplete search. For `missing_scope`, ask the user
   to reconnect Slack for the requested conversation types before retrying.
   Follow the lookup failure rule in `skills/automations/references/events/GUIDE.md` for other errors.
5. Ask only for a choice that is still ambiguous. Use result labels and show
   workspace names when channel names repeat.

Use the selected `account_identifier` directly in `--account`. Finish the run
instructions and conditions, then create. Do not open a separate form.

```bash
pplx automation create --name '<name>' --prompt '<what each run does>' \
    --source slack --event message_received --account '<team_id:conversation_id>' \
    [--filter 'mention_state=mentioned'] [--filter 'text=<text>'] \
    [--filter 'author_email=<email>'] [--filter 'subtype=file_share'] \
    [--filter 'file_types=<type>'] [--filter 'file_names=<name>'] \
    [--literal-filter 'thread_ts=<parent-ts>'] \
    [--literal-filter 'author_user_id=<user-id>'] \
    [--literal-filter 'channel_type=<channel|group|mpim|im>'] \
    [--when '<semantic admission rule>']
```

Use `mention_state=mentioned` when the user asks for messages that mention them.
Omit it when mention state should not restrict eligible messages. `text`, `author_email`,
`subtype`, `file_types`, and `file_names` are case-insensitive substring filters.
Use `--literal-filter` for exact `thread_ts`, `author_user_id`, or `channel_type`
matching. A `thread_ts` value watches replies in that one known thread; use `--when
'The message is a thread reply'` for any thread reply. Repeated values within one
field are ORed and different fields are ANDed. Ask a clarifying question only when
an unresolved choice would materially change the trigger—do not re-ask for a
conversation or scope the user already supplied.

Slack must be connected and the user must belong to the selected conversation.
Channel setup joins or invites Computer when Slack permits; DMs and group DMs
use the user's connector.

Manage the result with the normal automation commands and `edit-trigger` for
deterministic filters.

Wording with users: say "Slack trigger" or "Slack message trigger"; say "channel trigger" only when the selected conversation is a channel. Never say "webhook" or "event subscription".