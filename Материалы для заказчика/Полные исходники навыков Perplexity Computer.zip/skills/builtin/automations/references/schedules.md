# Schedule details

Times and ISO date-times are local to the IANA `--tz`; do not convert to UTC.

| Request | Rule and anchor |
| --- | --- |
| First of each month at 8am | `FREQ=MONTHLY;BYMONTHDAY=1;BYHOUR=8;BYMINUTE=0` |
| Every N hours | `FREQ=HOURLY;INTERVAL=N` (at the start time's minute) |
| Every 15 or 30 minutes | `FREQ=MINUTELY;INTERVAL=15` or `30` |
| Every other Tuesday at 9am | `FREQ=WEEKLY;INTERVAL=2;BYDAY=TU;BYHOUR=9;BYMINUTE=0`, with `--start-at` on the first intended Tuesday |
| Daily at 9am starting next Monday | `FREQ=DAILY;BYHOUR=9;BYMINUTE=0`, with `--start-at '<Monday>T09:00:00'` |

A `BYHOUR` list selects clock hours and restarts at midnight; use `HOURLY;INTERVAL=N` for elapsed-hour cadence. The server rejects occurrences closer than 15 minutes. Sub-daily schedules multiply credits (24 runs/day hourly, 96 every 15 minutes); state the run count and confirm first if the user did not request that frequency. Include any unstated notification preference in the same question, following `skills/automations/references/notifications.md`. Quiet runs still spend credits.

`--end-at` is exclusive: no occurrence at or after the boundary runs. A bare date means midnight at its start and excludes that entire day. Treat "through/until June 1" as inclusive unless told otherwise: use `--end-at '2027-06-02'` to include June 1, 2027. Use `edit --clear-end-at` to remove the boundary.

`--start-at` anchors the first occurrence, including which weeks are on for alternating weeks. On a cadence edit, omit it unless changing the next run. A one-time reminder uses `FREQ=DAILY;COUNT=1` with the intended `--start-at`. Verify the returned next run and final intended occurrence before reporting success.
