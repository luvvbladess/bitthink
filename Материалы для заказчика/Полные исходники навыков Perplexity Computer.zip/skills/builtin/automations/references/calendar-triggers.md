# Google Calendar event triggers

Use a Calendar event trigger when the user wants work to begin because an event is
created, updated, or cancelled. Route requests for work before an event starts here too.

Calendar trigger creation uses the CLI.
Each trigger binds one exact connected Google account; omit `--account` only for the default
connected account.

Use `pplx automation describe --source calendar [--event '<event>']` for enabled
events, required inputs, supported filters, and defaults.
Omit `--account` for the default connected Google account;
use a named connected Google address when the user selected one. Do not ask for
an account choice or enumerate calendars when the default fits the request.
This trigger watches the account's primary calendar. Use Calendar connector tools
to resolve a specific event or other missing filter value only when needed.

```bash
pplx automation create --name '<name>' --prompt '<what each run does>' \
    --source calendar --event '<event_created|event_updated|event_cancelled>' \
    [--account '<google-account>'] [--filter 'title=<text>' ...]
```

```bash
pplx automation add-trigger '<id>' --source calendar \
    --event '<event_created|event_updated|event_cancelled>' \
    [--account '<google-account>'] [--filter 'title=<text>' ...]
pplx automation edit-trigger '<id>' '<trigger-id>' [--filter 'title=<text>' ...] \
    [--clear-filters]
pplx automation remove-trigger '<id>' '<trigger-id>'
```

- `event_created` fires for a newly created event.
- `event_updated` includes time/detail changes and cancellations. The prompt must say how
  to handle cancellations when that matters.
- `event_cancelled` fires for cancellations or deletions. Use this event for
  cancellation-only requests when it is enabled in `describe`.

`event_starting_soon` is not authorable through the CLI or automation picker yet. If the
user asks for work relative to an event's start time, say that this event trigger is not
available and decline the automation.

`edit-trigger` changes only filters. To change the Calendar account or event
type, remove the old trigger and add its replacement.
