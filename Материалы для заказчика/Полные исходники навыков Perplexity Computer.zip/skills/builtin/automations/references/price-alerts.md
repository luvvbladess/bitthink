# Market price alerts

Target-price and daily percentage-move requests create a numeric-threshold trigger from Computer chat. Never create a minute/hourly polling schedule, use the legacy price-alert API, or look for a manual confirmation action.

First load the finance skill and follow its market-data guide. Resolve the instrument with `finance_tickers_lookup`, then fetch `price`, `currency`, and `changesPercentage` with `finance_quotes`. Use the resolved producer symbol exactly as returned (uppercase it when alphabetic); do not guess ticker aliases. If lookup is ambiguous, ask the user to choose before creating anything.

Quotes are available for more symbols than price alerts support. Creation checks the producer's supported-ticker list; if it rejects the ticker, explain that price alerts are unavailable for that symbol and stop without creating a polling fallback.

Create through the generic automation command:

```bash
pplx automation create --name '<name>' --prompt '<what to report when matched>' \
    --event-group FINANCE --event-entity '<resolved symbol>' \
    --event-type '<producer event type>' \
    [--value-upper-bound '<number>'] [--value-lower-bound '<number>'] \
    --rrule '<eligibility rule>' --tz UTC [--start-at '<ISO local, no offset>'] \
    [--notifications-enabled '<true|false>']
```

The numeric condition is inclusive: a producer event fires when its value is at or above `value_upper_bound` or at or below `value_lower_bound`. When both bounds exist, only values strictly between them do not fire. At least one bound is required. These are producer coordinates and generic bounds stored on the Automation; price-alert-specific state is not stored by Automations.

## Target price

Use `--event-type STOCK_PRICE_TARGET`. Compare the requested target with the current quote:

- Target above the current price: `--value-upper-bound '<target>'`.
- Target below the current price: `--value-lower-bound '<target>'`.
- Target equal to the current price: tell the user it is already at the target and ask whether they want an above or below crossing; do not guess.

Use `--rrule 'FREQ=DAILY;COUNT=1' --tz UTC`. It is eligible immediately, then completes after the first match. The prompt should report the matched instrument, target, actual event price, currency, and concise relevant context. Do not make the run fetch prices just to re-check the condition—the indexed producer already matched it.

Example after resolving BTC to `BTCUSD` and observing a current price below 80000:

```bash
pplx automation create --name 'BTC at $80,000' \
    --prompt 'Notify me that BTC reached my $80,000 target. State the matched price in USD and briefly explain any notable market context.' \
    --event-group FINANCE --event-entity BTCUSD --event-type STOCK_PRICE_TARGET \
    --value-upper-bound 80000 --rrule 'FREQ=DAILY;COUNT=1' --tz UTC
```

## Daily percentage move

Use `--event-type STOCK_PRICE_MOVEMENT`. The producer value is the signed daily percentage change:

- "rises X%": `--value-upper-bound 'X'`.
- "falls X%": `--value-lower-bound '-X'`.
- "moves X% either way": pass both `--value-upper-bound 'X' --value-lower-bound '-X'`.

Use `--rrule 'FREQ=DAILY;BYHOUR=0;BYMINUTE=0' --tz UTC --start-at '<today>T00:00:00'`. This rearms the alert at the start of each UTC day after it fires, while the producer—not a scheduled Computer run—continues watching the market. The prompt should report the matched instrument, signed percentage move, current price/currency from the event context, and concise relevant context.

Example:

```bash
pplx automation create --name 'AAPL 5% daily move' \
    --prompt 'Notify me that AAPL moved at least 5% today. State the signed move and matched price in USD, then briefly explain any notable market context.' \
    --event-group FINANCE --event-entity AAPL --event-type STOCK_PRICE_MOVEMENT \
    --value-upper-bound 5 --value-lower-bound -5 \
    --rrule 'FREQ=DAILY;BYHOUR=0;BYMINUTE=0' --tz UTC \
    --start-at '<today>T00:00:00'
```

Routine read-only alerts do not need a separate confirmation. After a successful create, say that the alert is active and restate the exact condition. Do not describe `next_run_at` as a polling time; for a numeric-threshold alert it is the next eligibility/rearm boundary, and the actual run begins only when a matching producer event arrives.

Fail closed if numeric-threshold creation is unavailable. If the command rejects an `--event-*` or `--value-*-bound` flag, report that price-alert creation is unavailable in this environment and leave no automation behind. A connector trigger or scheduled price check is not an equivalent fallback: do not try `--source finance`, ask for a polling cadence, or create an `FREQ=MINUTELY`/`FREQ=HOURLY` schedule.
