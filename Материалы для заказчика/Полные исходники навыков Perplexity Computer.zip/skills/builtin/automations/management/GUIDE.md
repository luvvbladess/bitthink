# Manage an automation

Identify the automation from context or inspect it before changing it:

```bash
pplx automation list [--search '<term>' | --project '<uuid>'] [--cursor '<next_cursor>']
pplx automation get '<id>'
pplx automation runs '<id>'
pplx automation edit '<id>' [--name '<name>'] [--prompt '<complete prompt>'] \
    [--rrule '<rule>'] [--tz '<IANA timezone>'] [--start-at '<local date-time>'] \
    [--end-at '<exclusive local date/time>' | --clear-end-at] \
    [--notifications-enabled '<true|false>']
pplx automation pause '<id>'
pplx automation resume '<id>'
pplx automation run_now '<id>'
pplx automation delete '<id>'
```

`list` is paginated: follow `next_cursor` while `has_next_page`, retaining the same search. `--limit` controls page size (default 50, max 100). Use history when diagnosing a failed run; a successful definition change does not prove the task ran.

Edit in place and pass only changed fields. `--prompt` replaces the whole prompt; preserve conditions, approved actions, output format, and custom delivery. Cadence edits do not need `--start-at` unless moving the next run. Re-check next run and final boundary after schedule edits; see `skills/automations/references/schedules.md` for anchors and bounded schedules.

- **Pause** stops future runs and retains history. **Resume** cannot give an exhausted one-time schedule another occurrence; create a new reminder or use `run_now` for one immediate extra run.
- **Run now** costs credits and works while paused without changing the schedule. Event runs started this way have no triggering event context.
- **Delete** permanently removes the automation, history, and run sessions, but never the source-thread target. Confirm deletion unless already explicitly authorized; use pause for a temporary stop.
- **Delivery** cannot be edited. Changing it requires replacement and loses old history if deleted; explain this and obtain deletion consent. Do not recreate merely to edit other fields.

For trigger changes, read `skills/automations/references/events/GUIDE.md` and the provider guide. For notification noise, conditions, or custom delivery, read `skills/automations/references/notifications.md`. Use command `--help` for current options; preserve an explicit request when an older CLI lacks its flag instead of silently dropping it.

## Computer mode and Project

For mode/model changes, use the discovery and selection rules in `skills/automations/creation/GUIDE.md`; check `pplx automation edit --help` for supported flags. Passing `--model` without `--reasoning-effort` preserves the legacy model-only behavior. Use `edit --clear-model` to clear a stored mode or model selection and restore the engine default. Once a dedicated session exists, change its mode in that session.

`edit` never moves an Automation implicitly: omit both Project flags to preserve its association, use `--project '<uuid>'` to bind or move it, and use `--clear-project` to detach it. `--deliver source-thread` automations always follow their target session's Project and cannot be moved or detached independently. Once an `automation-thread` session exists, move that session to change its Project.

## Legacy tasks

The first cursor-less `list` page also includes `legacy_automations`, with `legacy_` IDs; later pages return this field as null. These tasks can only be listed or deleted here. Deletion cancels their schedule without deleting the housing session or past output. Other management commands fail. The user can manage them in their original session or the Automations page.

For migration, read `skills/automations/migrate-legacy-automations/GUIDE.md`. Create a replacement before deleting the old schedule, and report cancellation only after deletion succeeds.