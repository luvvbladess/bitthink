# Sales Skills

- `skills/sales/account-research/GUIDE.md` — Research a company or person and get actionable sales intel with web search and enrichment tools.
- `skills/sales/call-prep/GUIDE.md` — Prepare for a sales call with account context, attendee research, and suggested agenda.
- `skills/sales/competitive-intelligence/GUIDE.md` — Research competitors and build an interactive battlecard with comparison matrix.
- `skills/sales/create-an-asset/GUIDE.md` — Generate tailored sales assets (landing pages, decks, one-pagers, workflow demos) from deal context.
- `skills/sales/daily-briefing/GUIDE.md` — Start your day with a prioritized sales briefing from calendar, CRM, and email.
- `skills/sales/draft-outreach/GUIDE.md` — Research a prospect then draft personalized outreach using web research and CRM data.

Read the matching guide at `skills/sales/<guide-name>/GUIDE.md`.