# Model Council

The user invoked **Model Council**. Run their query independently across several frontier models in parallel, then synthesize one **model-forward** answer organized around where the models agree, disagree, and diverge. The synthesis — not the individual answers — is the product.

The `model-catalog` skill is auto-loaded as a dependency. Use `text-models.md` for the canonical `run_subagent` model identifiers and `multi-model-comparison.md` for the synthesis format.

## Phase 1 — Decide the council (model selection)

Use the first matching rule below. Do not ask a question unless the final rule applies.

**User already specified models.** This includes exact identifiers supplied by the kickoff form and models named in the user's request (e.g. "use Fable and GPT 6.1 Sol", "council of Gemini and Claude", "compare GPT 6.1 Sol vs Claude"). If they supplied 2+ valid models, use exactly those, even when every selection is from the same provider. Cross-provider diversity is only a default and single-model completion rule; never critique, supplement, or explain a valid 2+ model selection. Map friendly names to identifiers via `text-models.md`, then proceed directly to dispatch without asking a clarifying question. If they supplied only one valid model, add exactly one other-provider frontier model using the single-model completion rule below.

**User explicitly opted out of choosing.** Use the **frontier default council** (below) with no question ONLY when the user gave a clear, unambiguous instruction to skip the model choice and let you decide — e.g. "just go", "you pick the models", "use the defaults", "don't ask, just run it", "surprise me". The opt-out must be explicit and directed at the model selection. Do NOT infer this from general urgency ("asap", "quick"), brevity, enthusiasm, a bare query with no models named, or any phrasing where it is merely plausible the user doesn't care. When in doubt, ask once as described below.

**Everything else → ask once, defaults first.** Ask a single `request_user_input` to confirm the council. `request_user_input` cannot preselect choices, so make the frontier default council the first option and rely on the automatic free-text "Other" option for custom picks. This is intentional: Model Council is Perplexity's "model aggregator" surface, so the model choice should be visible and editable.

- `title`: "Choose the council models"
- `question`: Build this exact shape, replacing the angle-bracket placeholder with all friendly display names from `text-models.md`: "Which model setup should I use? Available models: <comma-separated friendly display names>. Choose Other to pick custom models. Name 2+ models, or name one and I'll add another frontier model from a different provider."
- `header`: "Models"
- `multi_select: false`; provide exactly one explicit option so the UI displays two choices after it adds automatic "Other":
  1. `Latest frontier from OpenAI, Anthropic, and Gemini` — use the three models designated as Model Council defaults in `text-models.md`. This is the recommended/default choice; resolve the exact models at run time.
- Do not add an "Other" option yourself; `request_user_input` adds free text automatically. If the user uses free text, let them name any selectable text model from `text-models.md`.
- If the user names exactly one valid model in free text, add exactly one other-provider frontier model using the single-model completion rule below. If they name no valid models, use the frontier default council.

### Frontier default council — use catalog designations

The default council is the **single model designated as the Model Council default for each of Anthropic, OpenAI, and Google** in `text-models.md`. Read those designations live at run time. They are the catalog's authoritative frontier defaults; do not infer a default by comparing family names or version numbers.

Use the same provider designation when a user names a provider loosely (e.g. "use Claude" or "the newest GPT"). A specific valid model or family name remains an explicit user choice and must not be replaced by the provider default.

### Single-model completion rule

When the user provides only one valid council model, do not ask again and do not block. Add exactly one frontier model from a different provider. Choose the filler provider by scanning this priority order and taking the first provider that is different from the user's selected model's provider:

1. Anthropic
2. OpenAI
3. Google/Gemini

Then add that provider's Model Council default from the catalog. Examples: if the user picks GPT 6.1 Sol, add the Anthropic default; if they pick Claude Fable 5.1, add the OpenAI default; if they pick Gemini 3.7 Flash, add the Anthropic default.

> CRITICAL — model pinning: You MUST pass the `model` parameter explicitly on every council subagent so the selected model actually runs. Never let a council member silently use the runtime default — this is the exact bug to avoid. Re-read each identifier from `text-models.md` before dispatch. Always require at least 2 models.

## Phase 2 — Dispatch (one parallel batch)

Once the council has at least 2 models, dispatch it immediately. Do not load topical skills first; the council members perform the research themselves.

Launch one `run_subagent` per council member concurrently. Read the available declaration before dispatch:

- `model` = the council member's resolved identifier verbatim (the exact string from `text-models.md`) — never omit this
- `task_name` = a short council member name

- `objective` = the user's full query plus the council framing below. Each member must save its report to `/home/user/workspace/model-council-<model_id>.md`.

Council framing to append to every member's `objective`:

> You are one of several frontier models on a council, each independently researching this same query. Bring your own analytical angle and explore non-obvious dimensions — depth on a specific facet is more valuable than surface coverage of everything. Use web search to ground claims, cite sources inline, and produce a well-evidenced, standalone answer. A synthesizer will compare your findings against the other models', so prioritize accuracy, specificity, and distinctive analysis over generic summary.



After dispatching, your next tool call must be `wait_for_agents` — you have no independent work until they finish. If a member fails, proceed with the survivors as long as at least 2 succeed; note any drop-out in the final answer.

## Phase 3 — Synthesize (model-forward)

Read each member's report and write ONE synthesis. This output format mirrors Perplexity's production Model Council (the Ask-flow `agentic_research` synthesizer) and is the heart of the skill — follow it precisely. The organizing principle is **agreement and disagreement**, never a model-by-model recap.

### Model naming (headers, cells, and prose)

Use each council member's friendly **display name** from `text-models.md` everywhere it appears — table column headers, row cells, and prose alike. Use the actual model name (e.g. "Claude Fable 5.1", "GPT 6.1 Sol", "Gemini 3.7 Flash"), never a generic placeholder like "the newest GPT" or a raw technical identifier like `claude_fable_5_1`. The technical model_id is only for the `model` parameter when dispatching subagents in Phase 2 — it must never appear in the synthesis.

### Required sections, in this exact order

These tables are MANDATORY on every run — never skip, merge, or replace them with prose, regardless of query type or how similar the results are.

**1. Where Models Agree** (always first)
Lead with high-confidence findings. 3–6 rows. One ✓ column per council member (header in the model's friendly display name), ✓ where that model agrees, blank otherwise. Model columns contain ONLY ✓ or blank — no other text. Citations live in an `Evidence` column.

- **Every row MUST have at least two ✓.** A single-model finding is not "agreement" — it belongs in Unique Discoveries.

| Finding      | Claude Fable 5.1 | GPT 6.1 Sol | Gemini 3.7 Flash | Evidence                     |
| ------------ | ------------- | ----------- | -------------- | ---------------------------- |
| [Conclusion] | ✓             | ✓           | ✓              | [Key supporting point][1][4] |

**2. Where Models Disagree** (always present)
Same friendly display-name headers. Show each model's position in its column, plus a final **Why They Differ** column that names the cause: different evidence cited, different weighting of factors, different assumptions, or different interpretation of the data.

| Topic      | Claude Fable 5.1 | GPT 6.1 Sol | Gemini 3.7 Flash | Why They Differ        |
| ---------- | ------------- | ----------- | -------------- | ---------------------- |
| [Question] | [Position]    | [Position]  | [Position]     | [Reasoning difference] |

**3. Unique Discoveries** (omit entirely if none)
Only findings a single model surfaced. Use the model's friendly display name in the first cell.

| Model        | Unique Finding | Why It Matters |
| ------------ | -------------- | -------------- |
| [Model Name] | [Finding][N]   | [Relevance]    |

**4. Comprehensive Analysis** (always present)
Flowing prose — NOT bullets or tables. Length scales with query complexity: focused 400–600 words, moderate 600–1000, comprehensive 1000–1500. Cover, in order: high-confidence findings (why convergence = reliability), areas of divergence (why models reached different conclusions and how to weigh them), unique insights worth noting, then a final recommendation paragraph.

### Attribution

- Always attribute to specific models using their friendly display names from model-catalog: "Claude Fable 5.1 and GPT 6.1 Sol both found that...[2][5], while Gemini 3.7 Flash noted...[9]"
- Never write generic "research shows" or "experts suggest" when you have model-specific findings.

### Low-divergence results

When models largely agree (factual lookups, personal/memory queries), still produce every table. Populate "Where Models Agree" fully, and for "Where Models Disagree" look harder for differences in **emphasis, detail, framing, and completeness**. Only if genuinely identical, note "All models produced highly consistent findings" but keep the table header. Collapsing to prose is a failure.

### Anti-patterns (do not do)

- A model-by-model table that lists each model's individual answers (one column per model filled with each model's pick). Organize by agreement/disagreement instead.
- Generic placeholders ("the newest GPT") or raw technical model ids (`claude_fable_5_1`) anywhere in the synthesis — use the actual friendly display name.
- A summary that walks through "Model A said… Model B said…" — that is the exact shape to avoid.

## Phase 4 — Deliver

1. Open with one short line naming which models were consulted (friendly names).
2. Deliver each individual member report using the available file-sharing tool or response attachments. Member-to-parent mail does not deliver files to the user.
3. Present the synthesis inline. Also save it to `/home/user/workspace/model-council-synthesis.md` and deliver that file through the same user-facing mechanism.
4. If the user asked for a specific format (e.g. PDF), load the matching `office/*` skill and produce it from the synthesis.