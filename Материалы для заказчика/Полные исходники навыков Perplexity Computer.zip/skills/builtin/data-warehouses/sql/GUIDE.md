# Warehouse SQL

Connector constraints and best practices for warehouse queries.

## Warehouse Query Best Practices

### General

- Every exploratory query needs a tight date/partition filter and a `LIMIT`.
- Wildcard string filters are for discovery only. After discovery, switch to exact matches.
- Never mix entity types in one `COUNT`; `user_id` and `visitor_id` are different entities.
- Run one SQL statement per connector execution call. CTEs are fine; semicolon-separated statements are not.
- Use `DESCRIBE` for schema inspection instead of `SELECT * LIMIT 10` on large tables.
- Check timezone semantics before interpreting "today", "yesterday", or "last hour".

### Snowflake

- Prefer fully-qualified `database.schema.table` names.
- Use three-argument `convert_timezone('UTC', 'America/Los_Angeles', <created_at_utc>)` for UTC timestamp conversion.
- The Snowflake MCP SQL parser blocks some colon-path syntax. Prefer bracket notation such as `col['key']`, `col['a']['b']`, `col['arr'][0]`, or `GET_PATH(col, 'a.b')`.
- Use `DESCRIBE TABLE <database>.<schema>.<table>` for schema inspection.
- For large tables, use partition-pruned freshness checks such as `SELECT 1 ... WHERE <event_date> >= CURRENT_DATE - 3 LIMIT 1` instead of `MAX(<event_date>)`.

### Databricks

- Prefer fully-qualified Unity Catalog names: `catalog.schema.table`.
- Convert UTC timestamps explicitly with `from_utc_timestamp(<created_at_utc>, 'America/Los_Angeles')`.
- Use dot-access for typed structs and colon-path only when the column is JSON string data.
- Use `DESCRIBE TABLE` or `DESCRIBE TABLE EXTENDED` for schema inspection.
- Use `approx_count_distinct` when an approximate high-cardinality count is sufficient.
- Filter on partition columns before aggregating Delta tables.