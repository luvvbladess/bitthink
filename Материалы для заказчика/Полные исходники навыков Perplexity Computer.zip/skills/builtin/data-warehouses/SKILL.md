# Data Warehouses

This skill applies to the tool-based `snowflake` and `databricks` source IDs. Its execution restrictions apply only to those connectors. It owns SQL execution behavior, query planning, warehouse exploration, validation, and exact-value citations.

An authenticated CLI skill can reuse the analysis planning, exploration, and validation guidance. Follow that CLI's execution instructions and the CLI provenance path below. Co-loading this skill does not turn jobs or workspace administration into a warehouse-analysis task.

## Guides

- `skills/data-warehouses/sql/GUIDE.md` - Connector parser constraints and warehouse query best practices. Read it before writing warehouse SQL.
- `skills/data-warehouses/exploration/GUIDE.md` - Schema inspection, table profiling, data quality checks, and relationship discovery.
- `skills/data-warehouses/validation/GUIDE.md` - QA for warehouse analyses before sharing results.
- `skills/data/static-charts/GUIDE.md` - Static chart generation. Read it when charting warehouse results.

## SQL Execution


Use connector tools for warehouse access. Before calling a connector tool, use the connector description/schema tool when available so the input shape is known. Read `skills/data-warehouses/sql/GUIDE.md` before writing warehouse SQL — it carries query best practices and connector parser constraints.


Databricks provides a single SQL execution tool that also allows writes; always ask the user for permission before creating objects, writing data, or running other mutating statements.

For Snowflake, call the connector's `list_warehouses` tool before the first query in a session and use a warehouse from that list — do not guess warehouse names. Run queries with `async_exec: true` when the connector supports it. A statement handle is not a result. Poll the statement's status (every ~30-60 seconds for large scans) until it reaches terminal success before interpreting rows; early empty payloads can just mean the query is still running.

## Working Style

Narrate as you work: before each query, say in one plain-English sentence what you are checking and why. Give an update whenever you run a query, change direction, or hit something unexpected. Do not paste SQL into running commentary — SQL belongs in the final answer or report.

## Query Planning

Use tight filters and limits for exploratory queries. Prefer date or partition filters before broad scans. Use `DESCRIBE` for schema inspection instead of `SELECT *` on large tables.

Run multiple independent connector queries in parallel when it saves wall-clock time, but avoid repeated scans of the same large table. When you anticipate multiple breakdowns of the same data, pull wide and slice narrow — include all the GROUP BY dimensions in one query and post-process in Python, instead of scanning the table once per breakdown:

```sql
-- One round-trip serves daily, hourly, and per-dimension breakdowns:
SELECT <event_date>, DATE_PART('hour', <event_hour>) AS hour, <dim>, COUNT(*) AS cnt
FROM <events>
WHERE <event_date> BETWEEN '2026-01-18' AND '2026-01-24'
GROUP BY 1, 2, 3;
```

Capture every filter the user mentioned. If a filter is not available as a top-level column, extract it from nested JSON fields or join to a table that has it; if neither works, state in your assumptions that you could not filter on that dimension.

Never filter on a user-mentioned string value until you have checked the actual values in the data. Run a small grouped discovery query first and choose the relevant value; if context does not disambiguate, default to the higher-volume value from the discovery counts and state the choice as an assumption.

When a user asks for change, growth, or comparison without specifying percent or absolute units, provide both the absolute change and the percent change. Round percentages to two decimal places.

If no year is specified for a dated warehouse question, default to the current year and state that assumption.

## Citations

For authenticated CLI results, preserve the executed SQL or Genie question, resource/statement IDs, and result files. Link the saved query/results and any authoritative resource URLs returned by the service, and explain filters, aggregation grain, and calculations. CLI JSON does not carry MCP `source_metadata`; do not invent it or fabricate claim markers. Successfully retrieved CLI values can be presented with this evidence.

The claim-citation procedure below applies to MCP warehouse results and values derived from them. Choose the path from the actual execution route; do not relabel an MCP response as a CLI result to bypass missing metadata.

**Every exact number pulled from a warehouse connector result - amounts, counts, percentages, totals, raw lookups, and derived metrics - must:**

1. Pass through `cite()` from the shared `pplx_citations` runtime, AND
2. Appear in your final answer as a `[value](claim:N)` claim link.

A response with warehouse numbers but no claim markers is a failure.

This rule applies even when you already know the answer: every warehouse number you state must come from an actual warehouse connector result, pass through `cite()`, and appear as `[value](claim:N)` in your response. Short answers, follow-ups, and single-number lookups are not exempt; the script is a few lines and implies no report or chart. Never type literal `[value](claim:N)` markers without actually running `cite()` - fabricated markers look right but carry no provenance and will not render.

Citations apply only to warehouse connector results with `source_metadata` and values derived from those cited results. Never call `cite()` with web data, fabricated values, or hand-written source metadata. If a direct warehouse result lacks `source_metadata`, do not fake file, row, column, or source IDs, and do not present any of its values. Recheck the connector output once; if it remains absent, say only that the connector result could not be verified and offer to retry. Do not mention citations, claim markers, metadata, files, rows, columns, or source IDs.

### Setup

Run citation work with Python through the Bash tool. For multi-step or reusable analysis, write a `.py` file and run it with `python3 -P path/to/script.py`. A `python3 -P << 'PYEOF'` heredoc is also valid for short, one-off work.

```python
from pplx_citations import cite, load_citations, save_citations

load_citations()
```

### Source Values

Every direct number pulled from a warehouse connector result must copy the tool result's `source_metadata` into `result_source_metadata`, then pass `source_metadata=result_source_metadata` to `cite()`. Warehouse citations are source-level; do not pass file, row, or column arguments. Leave `source` at its default unless a system instruction explicitly says otherwise; claim grouping comes from backend source metadata, not from the display name.

Every direct warehouse `cite()` call must include `formula=`. The claim card shows it as the value's provenance. A total returned by the query is a direct source value, not a derivation. For values read directly from a query result, use a compact one-line SQL snippet: aggregate expression, table, and key filters, ideally under about 150 characters. Use human-readable citation names because they appear in the claim UI:

```python
result_source_metadata = tool_output["source_metadata"]
enterprise_revenue = cite(1250000, "Enterprise revenue", formula="SUM(AMOUNT) FROM DEMO.INVOICES WHERE INVOICE_DATE >= '2026-01-01'", source_metadata=result_source_metadata)
business_revenue = cite(750000, "Business revenue", formula="SUM(AMOUNT) FROM DEMO.INVOICES WHERE PLAN = 'Business'", source_metadata=result_source_metadata)
enterprise_invoices = cite(289, "Enterprise invoice count", formula="COUNT(*) FROM DEMO.INVOICES WHERE INVOICE_DATE >= '2026-01-01'", source_metadata=result_source_metadata)
```

### Derived Values

Every value you compute locally - margins, growth rates, ratios, shares, per-account metrics, and table totals - must be cited with `formula` and `derived_from`. The names in `derived_from` must exactly match the parent `cite()` `name` arguments; mismatches are rejected.

```python
conversion_rate = cite(0.1234, "Enterprise conversion rate", formula="Enterprise conversions / Enterprise visitors", derived_from=["Enterprise conversions", "Enterprise visitors"])
total_revenue = cite(enterprise_revenue + business_revenue, "Total revenue", formula="Enterprise revenue + Business revenue", derived_from=["Enterprise revenue", "Business revenue"])
```

Do not omit `formula=` for counts, subtotals, or derived values. Table totals are values too: if you compute a total locally, cite it as a derived claim with `derived_from=` listing the summed values. A table whose body is cited but whose Total row is bare is incomplete.

Do not narrate citation plumbing in user-visible prose; talk about what the numbers mean, not how they are being cited.

At the end of the script:

```python
save_citations()
```

Keep `save_citations()` stderr unredirected and out of filtered pipelines (for
example, do not use `2>&1 | ...`), so Bash receives the structured claim
update. Stdout may be piped or redirected when the script's printed text is not
needed for the response.

### Emitting Claim Links

`CitedValue` auto-formats with claim markers in f-strings. Do not manually wrap. `float()` removes the marker; `str()` preserves it but cannot apply a numeric format.

**Compose the numeric parts of your answer inside the citation script.** Cited variables format themselves as claim markers, so build your answer's tables and key sentences as f-strings over the cited variables and print the result — then paste the printed markdown into your answer. Use f-strings for numeric formatting; do not call `float()` before formatting because it strips the marker. Numbers interpolated this way are cited by construction; the only way to leak an uncited number is to type it outside the script. Example:

```python
print(f"| Enterprise | {enterprise_revenue} | {enterprise_invoices} |")
print(f"Enterprise drove {enterprise_share} of the month's revenue.")
```

The IDs in your script's stdout are the ones you reuse in your response prose. Never fabricate `claim:N` or `pplx://action/claim` links by hand; only use IDs the citation flow actually generated.

### Response Text

Use the emitted `[display](claim:N)` marker directly on each final-answer value, including numeric Markdown table cells. Reformat the display text for readability, but never drop the wrapper, and keep the link wrapper around the full display value including currency symbols, signs, units, and suffixes.

Correct:

```text
"Enterprise revenue was [$1.25M](claim:1)."
"Conversion was [12.3%](claim:3)."
"Total ARR was [~$17.3M](claim:8)."  (rounded from [17,334,048](claim:8))
```

Incorrect:

```text
"Enterprise revenue was $1.25M."                  - dropped the link
"Enterprise revenue was $1.25M [claim:1]."        - must use markdown link syntax
"Enterprise revenue was $[1.25M](claim:1)."       - unit/symbol must be inside brackets
"Conversion was [**12.3%**](claim:3)."            - markdown inside link text breaks rendering
"| Enterprise | $1.25M | 289 |"                  - table cells must contain claim links
```

Claim markers render as clean clickable links in the UI; never skip them for readability, even in large tables.

Cases that are never exempt:

- **Computed percentages and shares** — including 0%, 100%, and approximations like "~69%". Any percentage you compute is a value: cite it as a derived claim with `derived_from=` naming its inputs, and interpolate it like every other value. A "% of total" table column must be cited cell by cell.
- **Rounded restatements.** When prose restates a cited value in rounded or approximate form, wrap the restatement in the original claim's marker — for example `[~$1.0M](claim:7)` for a claim whose exact value is 1002345.60.
- **Secondary values and commentary.** Every exact number you mention anywhere in the answer — comparisons, caveats, footnotes — must be cited, not only the headline table.

### Rules Summary

- Cite values you present to the user - including every numeric cell in any table
- Direct warehouse citations require the connector result's `source_metadata`
- Direct warehouse citations require `formula=` with compact SQL provenance; derived warehouse citations require `formula=` and `derived_from=`
- `derived_from` names must exactly match parent `name` arguments; unknown names are rejected by `cite()`
- Use f-strings with `CitedValue` (`f"{revenue:,.0f}"`) for numeric formatting. `float()` removes the claim marker; `str()` preserves the current display.
- Never narrate citation plumbing - do not mention the citations module, `cite()`, `save_citations`, `load_citations`, PYEOF, "I'll cite this", "I need to wrap as claim", or any mechanics-level detail in your thought process or response prose

## Default Output

Answer inline by default. Start with the direct answer, then include concise methodology and assumptions. This should be meaningful but not book-length.

Do not generate a markdown report for every warehouse query. Create a report when the user requests one, when the analysis is too large to communicate inline, when there are multiple queries or complex methodology worth preserving, or when a reusable artifact would help.

Do not generate a chart for every query. Use `skills/data/static-charts/GUIDE.md` when the user asks for a chart, trend visualization, dashboard, or comparison, or when a multi-point trend/categorical comparison is materially clearer as a chart. Do not chart simple lookups.

## Final Answer Checklist

- Provenance: MCP warehouse values carry the `[display](claim:N)` marker emitted by `pplx_citations`; never hand-write markers. Authenticated CLI results link the saved query/results and available returned resource URLs, with enough context to reproduce the calculation.
- Methodology: tables, filters, aggregation grain, and query approach in a few sentences.
- Assumptions: timeframe, entity definitions, ambiguous string values, missing filters, or missing business context.
- Caveats: freshness, partial periods, sampling, or connector limitations when relevant.
- SQL: if the answer came from a single query of 20 lines or fewer, include it inline; otherwise keep the SQL in the report (when one exists) and say where it is.