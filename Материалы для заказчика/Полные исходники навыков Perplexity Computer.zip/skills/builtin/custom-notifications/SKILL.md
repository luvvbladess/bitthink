# Custom Notifications


Call deferred tool `send_notification`.


## Channel selection

`send_notification` supports three channels:

- **`in_app`** (default) — always use this unless the user asks for something else.
- **`push`** — only when the user explicitly asks for phone/mobile alerts.
- **`email`** — only when the user explicitly asks for email delivery (e.g., "email me a daily summary").

Never add `push` or `email` without explicit user request for these channels. If the user asks to "notify me", use `in_app`.

`send_notification` native Push delivery uses the global Activity & updates Mobile setting, including when called during an automation; automation completion channel settings and Scheduled tasks globals do not replace that policy. Custom Email delivery does not currently use the Activity & updates Email setting. Read effective settings with `pplx notification settings get --category activityUpdates`. Change a global Activity & updates transport only when the user explicitly asks, using `pplx notification settings update --category activityUpdates --channel <email|web|mobile|slack> --enabled <true|false>`; never infer a global preference from the current run or available endpoints.

Outside automation runs, read the `delivery` block from `pplx notification settings get --category activityUpdates` before choosing Push versus Email among user-requested channels; automation runs receive delivery state in their run context. `unknown` is not evidence of a missing device, and `deliverable` is an eligibility snapshot, not proof of receipt.
Never infer preferences or enable a channel from delivery availability; background runs may read settings but must not change them.

## Email templates

When using `channels=["email"]`, set `email_args` to a typed payload. The discriminator is `template`; each variant declares its own fields.

- **`generic`** — General-purpose email; renders the notification body as formatted HTML. Use when no specialized template fits.
  - Fields: `template: "generic"`, `subject?: str` (defaults to the notification title)
- **`finance_digest`** — Personal-finance email with structured overview metrics on top and structured body sections below. Use whenever the email is primarily about the user's holdings, net worth, or portfolio movement, regardless of cadence (scheduled or one-off).
  - Before composing the call, **read `skills/custom-notifications/finance-digest/GUIDE.md`** for content rules, title guidance, and a full example.

For simple emails, use `email_args={"template": "generic"}`.

## Inside an automation run

When an automation has automatic completion notifications enabled, the platform chooses one permitted route at send time: eligible Scheduled tasks Web/Mobile Push or Email fallback. The run's automation context states whether completion notification is on and, when it is on, each channel's delivery state. Never send a bare "task finished" notification through `send_notification`; automatic completion already covers that purpose.

Use `send_notification` only when the user or task separately requires useful task-specific Email, In-app, or custom Push content. Do not infer an automation-toggle or global-preference change from custom delivery, and do not duplicate the automatic completion notification. A successful custom send deduplicates the matching automatic channel; custom Email does not mute automatic Push. Do not call `pplx automation suppress-run-notification` merely for deduplication. That command is for a task-specific condition that suppresses the trusted current run's automatic completion, and it does not cancel an explicitly requested custom send or the final session response.

## Gotchas

- Do NOT use citations or claim links in the notification body or `email_args` content. No `[text](claim:N)` links.
- Section/item values support markdown — use it for rich text like lists or tables. For simple values like numbers or percentages, use plain text.
- Do NOT notify just to say "nothing happened" or "no updates found". Skipping a notification does not suppress the final session response: follow the task's output instructions, including any required no-change summary. End without a session response only when the user or task explicitly requests it.
- Set `schedule_description` for recurring tasks so the user sees the cadence (e.g., "Daily · 9am").
- Push body is truncated to a short preview — put the full details in `body` for in-app/email, not in `title`.
- `send_notification` does not end the run — after a send, continue the task and repeat the sent details (the actual values) in your final answer. Notifications are ephemeral and delivered outside the Perplexity thread; the final answer is the durable record, so assume the user won't open the notification.
- Do NOT use `request_user_input` before sending notifications. The user already consented when they set up the task. Just send it.