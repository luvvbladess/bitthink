# Website Building

Build distinctive, production-grade websites that avoid generic "AI slop" aesthetics. Every choice — type, color, motion, layout — must be intentional. Preview every site with `deploy_website`: the built static bundle is served from S3, and fullstack apps work too — `__PORT_XXXX__` placeholder URLs in the bundle are rewritten to proxy API calls back to the backend running in your sandbox, so keep the server running (`start_server`). `publish_website` is only for permanent `*.pplx.app` URLs after the user explicitly asks.

**This skill covers everything for web projects.** When loaded via `load_skill(name="website-building")`, all files are copied to `workspace/`. Read sub-files as needed based on your project type. For web applications, read `skills/website-building/webapp/GUIDE.md`.

**Universal design principles** (color philosophy, default palette, font selection) are shared with other skills via `design-foundations`. This skill's shared files extend those foundations with web-specific implementation (CSS variables, responsive tokens, base stylesheets). You don't need to load `design-foundations` separately — the web-specific versions in `shared/` are comprehensive.

Use `read` with the full workspace path, e.g. `skills/website-building/shared/01-design-tokens.md`.

---

## Project Type Routing

**Step 1: Identify project type and load domain-specific guidance:**

| Project Type        | Action                                         | Examples                                                                   |
| ------------------- | ---------------------------------------------- | -------------------------------------------------------------------------- |
| Informational sites | `read` `informational/informational.md`        | Personal sites, portfolios, editorial/blogs, small business, landing pages |
| Web applications    | `read(file_path="skills/website-building/webapp/GUIDE.md")`        | SaaS products, dashboards, admin panels, e-commerce, brand experiences     |
| Browser games       | `read` `game/game.md` + `game/game-testing.md` | 2D Canvas games, Three.js/WebGL, HTML5 games, interactive 3D experiences   |

**Step 2: Read shared files** — read `shared/01-design-tokens.md` and `shared/02-typography.md` first (mandatory for ALL project types, including webapp). These establish the Nexus design system defaults and typography rules that apply universally. For web applications and dashboards, skip files marked with `†` below — those contain implementation details pre-configured in the fullstack template.

If the user says just "website" or "site" with no detail, ask what type or default to informational.

**Never call `publish_website` without first reading `skills/website-building/website-publishing/GUIDE.md`.** That guide carries the rules for when publishing is allowed, the unprompted-publish guardrail, and the production-sandbox restrictions (e.g. external tool connectors and `api_credentials` do not work after publishing). Use `deploy_website` for previews — `publish_website` is only for permanent `*.pplx.app` URLs and only after the user explicitly asks for one. Subagents (including `website_building` and crons) cannot call `publish_website`; hand control back to the main agent so it can publish.

```
read(file_path="skills/website-building/website-publishing/GUIDE.md")
```

---

## Sub-File Reference

### Shared (`shared/`) — Every project

| File                                  | Covers                                                                                   | Load                       |
| ------------------------------------- | ---------------------------------------------------------------------------------------- | -------------------------- |
| `shared/01-design-tokens.md`          | Type scale, spacing, Nexus palette, base.css                                             | **Always**                 |
| `shared/02-typography.md`             | Font selection, pairing, loading, blacklist                                              | **Always**                 |
| `shared/04-layout.md`                 | Spatial composition, responsive, mobile-first                                            | **Always** †               |
| `shared/05-taste.md`                  | Skeleton loaders, empty/error states, polish                                             | **Always**                 |
| `shared/08-standards.md`              | Accessibility, performance, anti-patterns                                                | **Always**                 |
| `shared/09-technical/GUIDE.md`              | Project structure, sandbox, deploy, checklist                                            | **Always** †               |
| `shared/03-motion.md`                 | Scroll animations, Motion library, GSAP SVG plugins, hover/cursor                        | When animated              |
| `shared/06-css-and-tailwind.md`       | Tailwind CSS v3, shadcn/ui, modern CSS                                                   | When using Tailwind        |
| `shared/07-toolkit.md`                | CDN libraries, React, Three.js, icons, maps, SVG patterns/filters, esm.sh                | When choosing libs         |
| `shared/10-charts-and-dataviz.md`     | Chart.js, Recharts, D3, KPIs, sparklines                                                 | When data viz needed       |
| `shared/11-web-technologies.md`       | Framework versions, browser compatibility                                                | When checking compat       |
| `shared/12-playwright-interactive.md` | Persistent Playwright browser QA, screenshots, visual testing                            | When testing               |
| `shared/19-backend.md`                | FastAPI/Express/Flask servers, WebSocket, SSE, port forwarding                           | When backend needed        |
| `shared/20-llm-api.md`                | LLM chat, image/video/audio generation, transcription — models, credentials, SDK helpers | When site uses AI/LLM APIs |

Reference paths are relative to `skills/website-building/`.

† **Skip for webapp and dashboards** — implementation details pre-configured in the fullstack template. Design-tokens and typography are NOT skipped — they provide the authoritative design system defaults and font selection guidance for all project types.

### Domain-Specific — Load or read one

| File                                           | When to use                                                                                |
| ---------------------------------------------- | ------------------------------------------------------------------------------------------ |
| `read(file_path="skills/website-building/webapp/GUIDE.md")`        | SaaS, dashboard, admin, e-commerce, brand experience (guide with fullstack template) |
| `skills/website-building/webapp/dashboards.md` | Dashboard or data-dense interface (companion to webapp)                                    |
| `informational/informational.md`               | Personal site, portfolio, editorial, small business, landing                               |
| `game/game.md`                                 | Browser game, Three.js, WebGL, interactive 3D                                              |
| `game/2d-canvas.md`                            | 2D Canvas game (companion to game.md)                                                      |
| `game/game-testing.md`                         | Any browser game — read alongside game.md                                                  |

**Interactive QA:** Read `shared/12-playwright-interactive.md` for persistent browser automation with Playwright (screenshots, functional testing, visual QA). Required for game testing, useful for any complex site.

---

## Workflow


0. **Choose the app before editing**:
   - **Already deployed in this session:** Reuse its local project and design, then redeploy the same `project_path`. The session remembers that directory's app; no artifact list, get, or `update_asset_id` is needed.
   - **Existing app from another session:** If its ID is unknown, find it with `pplx artifact list --project <project_uuid>` inside a Project, or `pplx artifact list --type APP` outside one. Use the Project UUID from session context. Select the app with `pplx artifact get <asset_id>`; add `--download` and unzip only if editable source is missing. Pass `update_asset_id=<asset_id>` on the first deploy from your chosen directory. This keeps the app's ID and link; later edits reuse that directory. Local files alone do not select an update target. If the receipt says `viewer_is_owner: false`, do not attempt an update; explain that the app owner must make the change.
   - **First app deploy in a Project:** If no app is selected and the Project catalog has not been checked, run the unfiltered Project list above once. Update the intended existing app, or create one if the catalog contains no apps. Do not repeat this check for same-session edits.
   - **Separate app or copy:** Set `new_artifact: true` only when the user explicitly wants a separate app, never to work around an update error. This does not require a catalog check.

1. **Design Direction**: Clarify purpose, pick aesthetic direction
2. **Version Control**: Run `git init` in the project directory after scaffolding. Commit after each major milestone with a short message.
3. **Build**: Build the site page by page, taking screenshots via Playwright for visual QA. Implement every requested behavior and preserve the existing visual system and component structure when editing.
4. **Preview**: Commit all changes, then `deploy_website()` creates a `/computer/a` app asset with an inline preview in the thread

---

## Use Every Tool

- **Research first.** Search the web for reference sites, trends, and competitor examples before designing. Browse award-winning examples of the specific site type. Fetch any URLs the user provides.
- **Generate real assets — generously.** Generate images for heroes, section illustrations, editorial feature visuals, atmospheric backgrounds — not just one hero image. Every long page should have visual rhythm with generated images that match the site's art direction. No placeholders. Generate a custom SVG logo for every project (see below) — SVG is for logos only unless the user specifically requests SVG output. Save web reference images that inform direction.
- **Screenshot via Playwright (complex sites only).** For multi-page sites, web apps, dashboards, and games, read `skills/website-building/shared/12-playwright-interactive.md` to screenshot at desktop (1280px+) and mobile (375px). Skip Playwright for simple single-page static sites — see Visual QA below.
- **Write production code directly.** HTML, CSS, JS, SVG. Use bash for build tools and file processing.

---

## SVG Logo Generation

Every project gets a custom inline SVG logo. Never substitute a styled text heading.

1. **Understand the brand** — purpose, tone, one defining word
2. **Write SVG directly** — geometric shapes, letterforms, or abstract marks. One memorable shape.
3. **Principles:** Geometric/minimal (Paul Rand, Vignelli). Works at 24px and 200px. Monochrome first — add color as enhancement. Use `currentColor` for dark/light mode.
4. **Implement inline** with `aria-label`, `viewBox`, `fill="none"`, `currentColor` strokes
5. **Generate a favicon** — simplified 32x32 version if needed

For SVG animation (DrawSVG, MorphSVG), see `shared/03-motion.md`. For SVG patterns/filters, see `shared/07-toolkit.md`.

---

## Visual QA Testing Process

### When to use Playwright QA

**Skip Playwright for simple sites.** Single-page static sites do NOT need Playwright screenshots. Review the code directly, then deploy. Playwright QA adds significant time and is not worth it for simple static content.

**Use Playwright for complex sites.** Multi-page sites, web applications, dashboards, games, and any site with interactive features (forms, carts, filters, charts, drag-and-drop) MUST use Playwright QA.

#### Primary Tool: `js_repl`

Persistent Node.js REPL with Playwright, for interactive browser QA and screenshots. Prefer `js_repl` over running Playwright directly through bash, Node.js, or Python.

Before the first call, read `shared/12-playwright-interactive.md` for the persistent-session workflow. The REPL starts automatically on the first call.


Call deferred tool `js_repl` with the JavaScript source in its `code` argument.


### Playwright QA Process (complex sites only)

**Cycle:** `Build → Playwright QA → Evaluate → Fix → Repeat → Deploy when ready`

#### Stage 1: Page-by-Page QA

After building each page:

1. **Screenshot at desktop** (1280px+) and **mobile** (375px) via Playwright
2. **Evaluate critically:** Does it look professionally designed (not AI-generated)? Is typography distinctive? Is whitespace generous? Is there one clear visual hierarchy?
3. **Fix every issue before moving on.** No visual debt.

#### Stage 2: Final QA (before publishing)

1. Screenshot every page at desktop and mobile
2. Check cross-page consistency (spacing, color, type treatment)
3. Verify dark mode (screenshot both themes for homepage minimum)
4. Check interactive states: hover, focus, active, loading, empty, error; exercise requested controls with real input.
5. Cold-open first impression test: does it feel polished and intentional?

**QA failures:** text overflow, inconsistent spacing, off-token colors, missing dark mode, squished mobile, generic AI look, placeholder content, missing logo.

---

## Step 1: Art Direction — Infer Before You Ask, Ask Before You Default

Every site should have a visual identity derived from its content. **Do not skip to the Nexus fallback palette.** The Nexus palette is a last resort for when both inference and asking have failed — not a convenient default.

1. **Infer from the subject.** A coffee roaster site → earthy browns, warm cream, hand-drawn feel. A fintech dashboard → cool slate, sharp sans-serif, data-dense. A children's learning app → bright primaries, rounded type, playful motion. The content itself tells you the palette, typography, and spacing before the user says a word.
2. **Check the Art Direction tables.** Each domain file (`informational.md`, `webapp/GUIDE.md`, `game/game.md`) has an Art Direction table mapping site/product types to concept-driven directions and token starting points. Use these as a springboard.
3. **Derive the five pillars:** Color (warm/cool, accent from subject), Typography (serif/sans, display personality), Spacing (dense/generous), Motion (minimal/expressive), Imagery (photo/illustration/type-only).
4. **If the subject is genuinely ambiguous, ask** — "What mood are you going for?" and "Any reference sites?" One question is enough.
5. **Nexus fallback — only when inference AND asking yield nothing.** If the user has been asked and gave no direction, AND the subject matter gives no clear signal, then fall back to Nexus/Swiss defaults.

### The Fallback: Clean & Swiss (Last Resort)

When inference yielded no clear direction AND the user was asked but gave no style guidance, use defaults from `shared/01-design-tokens.md` with:

- **Typography:** Satoshi or General Sans body (Fontshare — preferred), or Inter/DM Sans. Weight contrast over font contrast. 3-4 sizes max. Keep text compact — `--text-3xl`/`--text-hero` are for informational site heroes only.
- **Color:** Nexus palette. Neutral surfaces + one teal accent for CTAs only.
- **Layout:** Grid-aligned. Generous margins. Asymmetric where interesting.
- **Motion:** Minimal, functional. Smooth state transitions only.
- **Imagery:** Generate clean, relevant visuals. No stock photos.

### Art Direction — Avoid the AI Aesthetic

See `shared/08-standards.md` for the full anti-patterns list.

---

## Step 2: Preview

Call `deploy_website()` with the project path and site name. It creates or updates the `/computer/a/...` app and attaches the inline preview. See `shared/09-technical/GUIDE.md` for call examples.

### Canvas pixel readback in the preview

Shared-host `/computer/a` previews use an opaque iframe origin. Drawing an image loaded without CORS can taint the canvas, causing `getImageData()` and `toDataURL()` to throw. Isolated previews on `preview--*.pplx.app` use their own origin, so local images support canvas readback without a workaround. External images still need CORS.

- Set `img.crossOrigin = 'anonymous'` **before** assigning `img.src` for every image you draw into a canvas or WebGL texture that gets read back. The hosting proxy sends CORS headers, so the image loads and the canvas stays clean in both preview and published sites.
- Wrap pixel readback in try/catch and fall back to drawing the plain image, so a taint failure degrades gracefully instead of blanking the section.
- Purely procedural canvases (nothing drawn from an image) are unaffected.

After `deploy_website()` succeeds, the user-facing final answer should briefly say the website is ready in the attached preview and prompt for a next action. Offer these paths: keep iterating on the preview, publish it to a `pplx.app` link, deploy it via the Vercel connector, or open the attached `/computer/a` app to share it. When mentioning Share, note that the Share dropdown has an `Allow remix` option that lets viewers fork the app and build their own version. Wait for the user to choose before calling `publish_website` or using the Vercel connector.