# LLM & Media API Access

The `anthropic` and `openai` SDKs (Python and Node.js) and `pplx.python.sdks.llm_api` are pre-installed in the sandbox. **Credentials are NOT available by default** — you must inject them via the `api_credentials` field on the `start_server` tool every time you start or restart a server.

**Important:** The OpenAI proxy only supports the Responses API (`client.responses.create`), not Chat Completions.

### Credential Presets

| Preset            | TTL            | Use when                |
| ----------------- | -------------- | ----------------------- |
| `llm-api:website` | Auto-refreshed | Website backend servers |

**Every `start_server()` call that starts a server using LLM/media APIs must include `api_credentials=["llm-api:website"]`.** Without it, API calls will fail with authentication errors.

```
start_server(command="python server.py", project_path="/home/user/workspace", port=8000, api_credentials=["llm-api:website"])
```

## Available Models

**Text/Chat:** claude_sonnet_5_5, claude_opus_5_5, claude_haiku_4_5, gpt5_mini, gpt5_nano, gpt_5_chat, gpt_5_1, gpt_5_1_chat, gpt_5_2, gpt_5_4, gpt_5_6_sol, gpt_5_2_pro, grok_4_3, gemini_3_1_pro, gemini_3_flash

**Image:** nano_banana_pro, nano_banana_2, gpt_image_2_5_flare, gpt_image_2_5_sunburst, seedream_5

**Video:** veo_3_1, veo_3_1_fast, seedance_2_0

**Audio (TTS):** gemini_2_5_pro_tts

## Text/Chat — Anthropic SDK (Messages API)

```python
from anthropic import Anthropic
client = Anthropic()
message = client.messages.create(
    model="claude_sonnet_5_5",
    max_tokens=1024,
    messages=[{"role": "user", "content": "Hello"}],
)
```

## Text/Chat — OpenAI SDK (Responses API)

```python
from openai import OpenAI
client = OpenAI()
response = client.responses.create(
    model="gpt_5_1",
    input="Hello",
)
```

## Media Generation — SDK Helper Scripts

Media generation (image, video, audio) uses a separate SDK (`pplx.python.sdks.llm_api`). **Do not use the Anthropic SDK for media.** Ready-to-use async helper scripts are in `shared/llm-api/`. **Read the relevant file, then copy it into your project directory** and import it from your FastAPI handlers.

| File                               | What it does                            | Key function                                                               |
| ---------------------------------- | --------------------------------------- | -------------------------------------------------------------------------- |
| `shared/llm-api/generate_image.py` | Text-to-image, image-to-image editing   | `await generate_image(prompt, image_bytes=..., aspect_ratio=...)`          |
| `shared/llm-api/generate_video.py` | Text-to-video, image-to-video animation | `await generate_video(prompt, image_bytes=..., duration=...)`              |
| `shared/llm-api/generate_audio.py` | Text-to-speech, multi-speaker dialogue  | `await generate_audio(text, voice=...)` / `await generate_dialogue(lines)` |

### Website Backend Example

Read the helper file, copy it into your project, then import it. **Always use `start_server` with `api_credentials=["llm-api:website"]`** — this is required every time you start or restart the server process.

```python
from generate_image import generate_image
from fastapi import FastAPI, File, UploadFile
from fastapi.responses import JSONResponse
import base64

app = FastAPI()

@app.post("/api/generate")
async def generate(prompt: str, file: UploadFile | None = None, aspect_ratio: str = "1:1"):
    image_bytes = await file.read() if file else None
    result = await generate_image(
        prompt,
        image_bytes=image_bytes,
        image_media_type=file.content_type if file else None,
        aspect_ratio=aspect_ratio,
    )
    b64 = base64.b64encode(result).decode()
    return {"image": f"data:image/png;base64,{b64}"}
```

### Image Generation Options

| Parameter          | Description                                                  | Default       |
| ------------------ | ------------------------------------------------------------ | ------------- |
| `prompt`           | Image description                                            | Required      |
| `image_bytes`      | Input image bytes for img2img                                | None          |
| `image_media_type` | MIME type of input image (image/png, image/jpeg, image/webp) | image/png     |
| `aspect_ratio`     | 1:1, 3:4, 4:3, 9:16, 16:9                                    | 1:1           |
| `model`            | gpt_image_2_5_flare, gpt_image_2_5_sunburst, nano_banana_pro, nano_banana_2, seedream_5 | gpt_image_2_5_flare |

Default to `gpt_image_2_5_flare` for image generation. Use `gpt_image_2_5_sunburst` for detailed editing; use `nano_banana_2` for faster concept iteration and `seedream_5` for lowest-cost generation.

### Video Generation Options

| Parameter          | Description                               | Default   |
| ------------------ | ----------------------------------------- | --------- |
| `prompt`           | Video description                         | Required  |
| `image_bytes`      | Starting frame image for image-to-video   | None      |
| `image_media_type` | MIME type of starting frame               | image/png |
| `aspect_ratio`     | 16:9, 9:16                                | 16:9      |
| `duration`         | Veo: 4, 6, 8; Seedance: 4, 6, 8, 12 (seconds) | 8         |
| `audio`            | Generate audio track                      | True      |
| `model`            | veo_3_1, veo_3_1_fast, seedance_2_0 | veo_3_1    |

### Audio Generation Options

| Parameter | Description            | Default |
| --------- | ---------------------- | ------- |
| `text`    | Text to speak          | Required |
| `voice`   | Voice name (see below) | kore    |

Only `gemini_2_5_pro_tts` is supported — ElevenLabs is discontinued. Transcription is not currently available.

**Multi-speaker dialogue:** Use `generate_dialogue()` with a list of `{"speaker": "voice", "text": "..."}` dicts. Max 2 voices.

**Gemini voices:** achernar, achird, algenib, algieba, alnilam, aoede, autonoe, callirrhoe, charon, despina, enceladus, erinome, fenrir, gacrux, iapetus, kore, laomedeia, leda, orus, pulcherrima, puck, rasalgethi, sadachbia, sadaltager, schedar, sulafat, umbriel, vindemiatrix, zephyr, zubenelgenubi
