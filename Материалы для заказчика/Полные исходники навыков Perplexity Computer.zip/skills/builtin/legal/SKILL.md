# Legal Skills

- `skills/legal/canned-responses/GUIDE.md` — Generate templated responses for common legal inquiries and identify when situations require individualized attention.
- `skills/legal/compliance/GUIDE.md` — Navigate privacy regulations (GDPR, CCPA), review DPAs, and handle data subject requests.
- `skills/legal/contract-review/GUIDE.md` — Review contracts against your organization's negotiation playbook, flagging deviations and generating redline suggestions.
- `skills/legal/meeting-briefing/GUIDE.md` — Prepare structured briefings for meetings with legal relevance and track resulting action items.
- `skills/legal/nda-triage/GUIDE.md` — Screen incoming NDAs and classify them as GREEN (standard), YELLOW (needs review), or RED (significant issues).
- `skills/legal/risk-assessment/GUIDE.md` — Assess and classify legal risks using a severity-by-likelihood framework with escalation criteria.

Read the matching guide at `skills/legal/<guide-name>/GUIDE.md`.