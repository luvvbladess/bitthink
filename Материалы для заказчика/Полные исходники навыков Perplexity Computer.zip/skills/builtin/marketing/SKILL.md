# Marketing Skills

- `skills/marketing/brand-voice/GUIDE.md` — Define and enforce brand voice, tone adaptation, style rules, and terminology.
- `skills/marketing/campaign-planning/GUIDE.md` — Plan campaigns with objectives, audience segmentation, channel strategy, budgets, and KPIs.
- `skills/marketing/competitive-analysis/GUIDE.md` — Compare competitor positioning, messaging, content strategy, and build battlecards.
- `skills/marketing/content-creation/GUIDE.md` — Draft channel-specific marketing content with SEO and CTA best practices.
- `skills/marketing/performance-analytics/GUIDE.md` — Analyze marketing metrics, attribution models, and optimization frameworks.

Read the matching guide at `skills/marketing/<guide-name>/GUIDE.md`.