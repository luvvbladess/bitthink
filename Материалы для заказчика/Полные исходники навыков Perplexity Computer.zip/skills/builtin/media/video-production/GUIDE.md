# Video Production Guide

You have a full production toolkit: `generate_video` (native audio, image-to-video), `generate_image` (img2img, multiple aspect ratios), `text_to_speech` (30 voices, two-voice dialogue, delivery tags), and ffmpeg in the sandbox.

These tools compose freely. A single-clip social post and a multi-scene short film use the same building blocks — the difference is how many you chain together. Individual clips are 4-30 seconds, and frame chaining can extend a scene when the user asks for a longer video. Confirm length and cost before generating more than one clip (see the media skill).

## Choosing a Video Model

Leave `model` unset to use the default, Veo 3.1 Fast, unless the user asks for a specific model or the best quality. Load the `model-catalog` skill for full specs (resolution, duration, cost). The key distinction for video production:

Every available video model supports native synchronized audio (sound effects, ambient sound, music, and lip-synced dialogue). Veo models offer creative control and prompt adherence; Seedance is the cost-effective ByteDance option for quick iteration, multiple variations, social clips, and motion concepts. Seedance is capped at 720p; 2.0 offers 4, 6, 8, or 12 second durations, while 2.5 also offers 30 seconds. But the most important difference is image-to-video behavior:

- **Veo** uses the input image as the **literal first frame** — it faithfully preserves composition, textures, and style. This makes Veo ideal for frame chaining and any workflow where visual continuity from a starting image matters.
- **Seedance 2.0** supports image-to-video with native synchronized audio at 720p with 4, 6, 8, or 12 second durations in 16:9 or 9:16. Use it when cost and iteration speed matter for drafts, variation sweeps, social clips, and motion concepts.
- **Seedance 2.5** is the higher-fidelity Seedance, 480p or 720p, generates clips up to 30 seconds, and accepts up to **30** reference images against 2.0's 9. Reach for it when a shot needs a longer take, more references than 2.0 allows, or when 2.0's fidelity is the limiting factor; it costs several times more per second than 2.0.
- **MiniMax H3** uses one image as the literal opening frame, or two images as opening and final keyframes. Use it for 2K frame chaining or controlled transitions with native audio.

## Audio Design

Two approaches that combine well.

**Native video audio** — All video models generate synchronized dialogue, sound effects, ambient audio, and music with lip-sync. Prompt techniques differ by model family:

- _Veo_: Use colons for dialogue (not quotation marks, which trigger unwanted subtitles): `The detective says: Where were you last night.` Add `(no subtitles)` to the prompt. Use [brackets] for effects ([thunder]), inline ambient descriptions. Keep dialogue under ~8 seconds to avoid unnaturally fast speech.
- _Seedance 2.0 and 2.5_: Prompt sound effects, ambient sound, music, and lip-synced dialogue inline with the action. Keep the 720p cap and 4, 6, 8, or 12 second duration choices in mind when planning shots; 2.5 additionally supports 30 seconds.

**TTS voiceover** — Use `text_to_speech` when you need specific voice character, precise emotional delivery, or two-voice dialogue, using the 30 voices and delivery tags in `speech/guide.md`. Max 4000 UTF-8 bytes of text and two voices per call.

**Combining both** — Generate video with native ambient audio, then layer TTS on top via ffmpeg for environmental realism plus precise voice control. Only do this when the ambient sound matters to the piece: Veo audio doubles the clip price, so narrated videos should otherwise generate clips with `audio: false`:

```
ffmpeg -i video.mp4 -i voiceover.mp3 -filter_complex "[0:a]volume=0.3[bg];[1:a]volume=1.0[vo];[bg][vo]amix=inputs=2:duration=longest" -c:v copy output.mp4
```

**Matching durations** — TTS and video are generated independently, so their durations won't match exactly. Never stretch, speed up, slow down, or trim either track to compensate. Instead, generate one first and calibrate the other:

- _Narration-first_: generate the voiceover, measure its duration with `ffprobe -show_entries format=duration`, then generate video clips that add up to that duration (choose clip count and `duration` to match)
- _Video-first_: generate the video, then adjust the voiceover script length to fit — fewer words = shorter audio, more words = longer
- _Video too short?_ Use frame chaining to extend it — extract the last frame and generate another clip to cover the remaining duration
- _Audio too long?_ Shorten the voiceover script and regenerate — fewer words = shorter audio
- Aim for the video to be slightly longer than the voiceover so the tail has ambient audio rather than silence. Use `duration=longest` in the amix filter so nothing gets cut off.

## Prompting for Quality

### Image prompts

Generated images are the starting frames for your videos — their quality determines the entire production's visual standard. The image model defaults to soft illustration styles when prompts are vague. Structure image prompts as: **[subject with specific details] + [action/pose] + [environment/setting] + [lighting] + [camera/composition] + [style]**.

**Describe scenes in natural language, not keyword lists.** "A towering brachiosaurus stands in a dense prehistoric jungle, golden sunlight streaming through the canopy, pterodactyls soaring between ancient trees, photorealistic 3D render with volumetric god rays" — not "dinosaur, jungle, sunset, pretty." Don't use quality keyword spam like "masterpiece, 8K, trending on artstation" — modern models don't need it and it can cause artifacts.

**Always specify a visual style.** Without one, the model defaults to children's book illustration. Anchor every prompt with style direction:

- Photorealistic: "photorealistic, cinematic lighting, shot on Arri Alexa"
- 3D render: "Pixar-quality 3D render, subsurface scattering, global illumination"
- Stylized: "cel-shaded anime, bold outlines, Studio Ghibli"

**Use specific materials and textures.** "Brushed aluminum" not "metal," "crushed velvet" not "fabric," "wet cobblestone" not "wet ground." Concrete material names produce dramatically sharper, more realistic results.

**Include camera and lighting.** The model understands technical photography language: lens type ("85mm f/1.4 portrait lens"), shot type ("extreme close-up," "wide establishing shot"), angle ("low-angle," "bird's eye view"), and lighting ("golden hour rim light," "three-point softbox setup," "volumetric god rays through fog"). Name 3-5 palette colors for visual stability ("deep teal, warm amber, charcoal").

**Match the video aspect ratio.** Set `aspect_ratio` on `generate_image` to match your target video (e.g., "16:9" for landscape, "9:16" for vertical). This avoids cropping or letterboxing when the image becomes a video starting frame.

**Use saved image assets directly.** `generate_video` accepts local PNG/JPEG/WebP references via `images`. Use absolute paths or workspace-relative paths for uploaded files, searched images, screenshots, extracted frames, and prior generated outputs. If a scene needs more visual references than the selected model accepts, combine them into one keyframe with `generate_image` first, then animate that keyframe.

### Visual consistency

For any production with recurring subjects (characters, locations, products), establish visual identity before generating scenes:

**Define a style string.** Write one style/aesthetic description for the whole production (e.g., "Pixar-quality 3D animation, vibrant saturated colors, soft global illumination, expressive cartoon characters") and include it verbatim in every image and video prompt. This prevents style drift between scenes.

**Generate character/subject references first.** Before any scene work, generate reference images of each recurring subject — characters, key locations, signature props. Use these as reference inputs to `generate_image` when generating storyboard keyframes so subjects look consistent across scenes. The image model supports multiple reference images per call.

### Video prompts

Video prompts control the motion, action, and energy of each clip. A strong starting keyframe with a weak video prompt produces static, lifeless output.

**One action + one camera move per clip.** This is the most reliable pattern. Each clip should have a single clear subject action and a single clear camera movement. Break complex sequences into multiple clips rather than cramming everything into one.

**Describe motion in sequential beats.** "She takes three steps to the window, pauses, and pulls the curtain aside" — not "she goes to the window." Beats and counts give the model timing structure.

**Specify camera movement.** Dolly in, tracking shot, crane up, slow orbit, handheld shake, static locked-off, whip pan, parallax dolly — the model responds to professional cinematography terms. No camera direction defaults to subtle or random movement.

**Match energy to the moment.** Slow, gentle prompts for quiet scenes ("camera drifts slowly across a still lake at dawn"); fast, dynamic prompts for action ("rapid zoom out as the asteroid tears through the atmosphere, fire and shockwaves rippling across the sky").

**For image-to-video: describe only motion and changes.** The model can already see the starting image — don't redescribe its contents. Focus on what happens next: camera movement, subject action, lighting shifts, temporal changes. Redescribing the image in detail can actually reduce motion or produce unexpected results.

**Specify ambient sound explicitly.** Veo models can hallucinate unwanted audio (e.g., audience laughter) when ambient sound isn't defined. Include brief sound direction: "sounds of distant traffic and wind through trees" or "quiet room tone with a ticking clock."

## Composable Techniques

These are building blocks — mix and match them freely. Not every video needs all of them. A single text-to-video clip with a good prompt is a perfectly valid production for quick requests. Scale the workflow to what the user asked for.

### Storyboarding

For multi-scene productions, plan before generating. For narrated content (explainers, stories, documentaries), generate narration first so you know the exact duration and can plan visuals to match:

1. Write the full script — narration text plus visual direction for each segment.
2. Work scene by scene. For each segment:
   a. Generate the voiceover for this segment with `text_to_speech`. Measure its duration with `ffprobe`.
   b. Plan video clips to cover that duration (e.g., 18s of narration → 3 × 8s clips). Each clip should depict a distinct moment — don't reuse starting images.
   c. Generate a unique storyboard keyframe for each clip using `generate_image`. Match the video aspect ratio. **Review each keyframe** — verify it matches the intended style, subject consistency, and composition before proceeding. Regenerate any that miss the mark.
   d. Generate video clips from each keyframe. **Review each clip** — check that motion, style, and subject look correct. Measure actual durations — if total video falls short, frame-chain one more clip to cover the gap.
   e. Segment is done and locked. Move to the next.
3. Stitch all segments together and concatenate the per-segment voiceovers into the final audio track.

For short narrations where seamless vocal delivery matters more, a single TTS call works — split it into segments later by re-running per-segment TTS calls.

For non-narrated content (music videos, montages, product demos), plan the visual sequence upfront with enough unique keyframes to avoid repetition, but you can also discover the direction as you go — generate a few clips, see what works, and adapt.

**Longer productions** — When the user asks for a video over ~5 minutes, break the script into independent chapters (e.g., a 30-minute documentary → 6 chapters of ~5 minutes each). Produce each chapter as its own complete unit. Stitch chapters together at the end. Write the full script upfront so chapters flow together narratively, but produce them one at a time.

### Frame Chaining

Extend a continuous shot to any length by feeding the last frame of each clip into the next:

1. Generate the first clip (text-to-video or image-to-video)
2. Extract the last frame: `ffmpeg -sseof -0.1 -i clip-1.mp4 -frames:v 1 -q:v 2 last-frame.jpg`
3. Save the frame to workspace, generate the next clip using `images: ["last-frame.jpg"]` with a prompt describing how the scene _continues_
4. Repeat for as many clips as needed, then stitch together

Write continuation prompts naturally — if clip 1 shows "a woman walking through a forest", the next prompt continues: "she reaches a clearing and looks up at the sky".

**Use Veo models for frame chaining** — they treat the input image as the literal first frame, giving seamless visual continuity.

Combines naturally with storyboarding: use a unique storyboard keyframe for the first clip of each scene, then frame-chain within a scene for longer continuous shots. Frame chaining works well for continuous motion, slow ambient shots, gradual transitions, and establishing shots — but don't use it as a shortcut to avoid generating new keyframes for visually distinct moments.

### Image Transformation

When the user provides photos that aren't ideal as direct starting frames (wrong style, too busy, not cinematic), transform them:

1. Use `generate_image` with the user's image(s) as reference inputs, prompting for a version optimized as a video starting frame — clean composition, cinematic look. Set the aspect ratio to match your target video (e.g., 16:9).
2. Use the generated image as `images` in `generate_video`.

Example: user uploads a product photo → `generate_image` with the photo as reference, prompt "cinematic product shot centered on dark gradient background, studio lighting, clean composition" → `generate_video` with the result as `images`, prompt "camera slowly orbits around the product, dramatic lighting shifts..."

### Custom Voiceover

When you want precise control over narration or dialogue:

1. Write the voiceover script — either a .txt file for single narrator or .json for two-voice dialogue with delivery tags
2. Generate audio with `text_to_speech`
3. Mix the voiceover over video using ffmpeg (see Audio Design section above). For silent clips, map the voiceover as the only audio track: `ffmpeg -i video.mp4 -i voiceover.mp3 -map 0:v -map 1:a -c:v copy output.mp4`

### Stitching Clips

All multi-clip productions need a final stitch. For hard cuts between scenes:

```
ffmpeg -f concat -safe 0 -i videos.txt -c copy final.mp4
```

Where `videos.txt` lists one `file 'clip-N.mp4'` per line.

For smoother scene transitions (crossfades, fade to/from black), use ffmpeg's xfade filter between clips:

```
ffmpeg -i clip1.mp4 -i clip2.mp4 -filter_complex "xfade=transition=fade:duration=0.5:offset=7.5" output.mp4
```

Where `offset` = duration of first clip minus the transition duration. Choose transitions that match the tone — `fade` or `dissolve` for narrative content, hard cuts for fast-paced edits.

## Quality Verification

Review your work at every stage — don't wait until the final stitch to discover problems.

**After each keyframe**: Does it match the style string? Is the subject consistent with references? Is the composition clean and the aspect ratio correct? Regenerate before building video on top of a bad frame.

**After each video clip**: Does the motion look natural? Does the subject match the keyframe? Is there any visual artifact or distortion? Check actual duration with `ffprobe`.

**After each segment**: Play back the segment's video with its voiceover. Does the pacing feel right? Is the audio/video alignment close enough? Lock the segment before moving on.

**Final production check**: After stitching everything together, review the complete video end-to-end. Check for: jarring transitions between scenes, inconsistent visual style, audio sync issues, any silent gaps or abrupt cuts. Fix individual segments rather than trying to patch the final output.

## Generated Video vs. Captured Video

AI video models create new visual content — they don't reproduce existing artifacts faithfully. Text, layouts, and precise details will drift or distort.

When the goal is to **show something that already exists** (an app, a website, a document, a dashboard, a design), capture it directly: take screenshots or screen grabs, then stitch them into a video with ffmpeg transitions and optional TTS narration or music. This is cheaper, faster, and accurate.

When the goal is to **create something new** (a cinematic trailer, a mood piece, product concept art, storytelling), AI video generation is the right tool.

## Guidelines

- **STOP and confirm before generating more than one clip.** Video is billed per second of output, so cost grows with length: one 8-second clip costs a few dollars, while a one-minute video (about 8 clips) costs tens of dollars, and Veo clip audio doubles that. Users usually don't know this, and a vague request like "make a video" rarely needs more than one clip. So before generating more than one clip, ask with request_user_input and state the cost in the question itself, since users may not read the option descriptions. If the user didn't ask for a length, recommend a single 8-second video.
- Never re-encode or reduce video quality to shrink file size — send full-quality output to the user
- **Never use ffmpeg atempo, setpts, asetpts, or any time-stretching/speed adjustment on generated video or speech audio.** This always produces distorted, unusable output. If video is too short, use frame chaining to extend it. If audio is too long, shorten the script and regenerate.
- Use the same aspect ratio throughout all clips in a production
- For frame chaining workflows, use Veo models, which treat the input image as the literal first frame
- Video generation takes 1-3 minutes per clip — inform the user and generate sequentially
- Don't create title cards or text overlays with ffmpeg drawtext — they look cheap. For titles and intros, generate a title image with `generate_image` and animate it with `generate_video` — a 4-second animated title sequence looks far more professional than a static card

## FFmpeg in the Sandbox

The sandbox has only 2 vCPUs. Encode settings and timeouts must account for this.

**Encoding presets:** Use `-preset fast` or `-preset medium`. Never use `slow`, `slower`, or `veryslow` — they will timeout or take unreasonably long on 2 vCPUs.

**Quality (CRF):** Use `-crf 23` for general output. For social media, `-crf 26` to `-crf 28` is fine since platforms re-encode anyway. For archival or broadcast, `-crf 18` to `-crf 20`.

**Pixel format:** Always use `-pix_fmt yuv420p`. AI-generated images are often RGB, which causes libx264 to default to `yuv444p` (H.264 High 4:4:4 Predictive profile). Browsers only decode 4:2:0.

**Bash timeout:** Always set the bash tool timeout to at least 300000 (5 minutes) for any ffmpeg command. Complex filter chains or longer videos may need even more.

**Example — fast encode:**

```bash
ffmpeg -i input.mp4 -preset fast -crf 26 -pix_fmt yuv420p -c:a aac -b:a 128k output.mp4
```

## Vertical Video (9:16)

To convert landscape footage to vertical 1080x1920:

**Crop + scale filter chain:**

```
-vf "crop=ih*9/16:ih,scale=1080:1920"
```

**ASS subtitles for vertical video:** Set `PlayResX: 1080` and `PlayResY: 1920` in the ASS header so text positions map correctly to the vertical frame:

```
[Script Info]
PlayResX: 1080
PlayResY: 1920
```