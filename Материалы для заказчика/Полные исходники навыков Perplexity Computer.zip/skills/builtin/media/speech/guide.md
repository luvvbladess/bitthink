# Speech Guide

`text_to_speech` uses Gemini 2.5 Pro TTS. Write one voice's script to a `.txt` file and pass `voice`. For dialogue, write a `.json` file; each line picks its speaker's voice, with at most 2 voices:

```json
[
  { "speaker": "kore", "text": "Welcome to the show!" },
  { "speaker": "puck", "text": "[uhm] Wait, did you see the news?" },
  { "speaker": "kore", "text": "[whispering] No... what happened?" }
]
```

## Voices

Full list with descriptions in `voices.txt`. Common picks:

- **kore**: strong and firm (female), the default
- **charon**: calm, deep, professional (male)
- **puck**: upbeat and lively (male)
- **aoede**: relaxed and natural (female)
- **rasalgethi**: narrator style (male)
- **fenrir**: passionate and energetic (male)
- **sulafat**: warm and approachable (female)
- **erinome**: clear and articulate (female)

## Delivery

The tool sends only your text, so delivery comes from the wording, punctuation, and these bracket tags (from [Google's Gemini TTS tag guide](https://cloud.google.com/text-to-speech/docs/gemini-tts)):

- Sounds: `[sigh]`, `[laughing]`, `[uhm]`.
- Style for the following phrase: `[sarcasm]`, `[whispering]`, `[shouting]`, `[robotic]`, `[extremely fast]`.
- Pauses: `[short pause]`, `[medium pause]`, `[long pause]`.
- Don't use emotion words as tags, such as `[scared]` or `[excited]`; the model reads them aloud. Write lines whose words carry the emotion instead.
- Punctuation adds natural pauses.
- Control length by editing the script, not by speeding up the audio.
