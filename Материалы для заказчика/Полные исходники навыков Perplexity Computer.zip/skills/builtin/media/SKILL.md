# Media

Pass reference files as sandbox paths. Save remote images to the workspace first; never pass URLs or base64.

Every generation is billed. If generation succeeds but sharing fails, share the returned path instead of generating again. After a timeout or cancellation, check for the output file before retrying.
Finish a generation request by generating and sharing the media. If generation fails, say so; never present a plan, prompt, or reference file as the result.

## Video

**Video is billed per second, so long videos get expensive.** A single 8-second clip costs a few dollars at most; a one-minute video can cost tens of dollars. Make one video generation per request unless the user asks for more.

- **Confirm before more than one clip.** Use request_user_input first, even when the user asked for a longer video. Put the cost in the question itself, for example: "Longer videos use more credits; a one-minute video can cost tens of dollars." Give each option's length. If the user didn't ask for a specific length, list a single 8-second video first as the recommended option and never mark a longer option as recommended.
- **Model:** leave `model` unset to use Veo 3.1 Fast unless the user asks for a specific model or the best quality.

  | Model | Durations (s) | Reference images |
  | --- | --- | --- |
  | `veo_3_1_fast` (default), `veo_3_1` | 4, 6, 8 | 3; the first is the literal first frame |
  | `seedance_2_0` | 4, 6, 8, 12 | 9; cheapest, 720p |
  | `seedance_2_5` | 4, 6, 8, 12, 30 | 30; several times 2.0's price |
  | `minimax_h3` | 6, 8, 12 | 2; first frame and optional last frame |

- **Audio:** set `audio: false` for silent footage or when a voiceover or music track will carry the audio. Audio doubles Veo's price.
- **Prompts:** for image-to-video, describe motion, camera movement, and changes rather than what the image already shows.
- To show something that already exists (an app, site, document, or design), use screenshots stitched with ffmpeg instead of generated video.
- For multi-clip productions, read `video-production/GUIDE.md`.

## Images

- Default to `gpt_image_2_5_flare`, including edits and `background: "transparent"`. Alternatives: `gpt_image_2_5_sunburst` for detailed edits, `nano_banana_2` for concept iteration, `nano_banana_pro`, and `seedream_5` for low cost.
- GPT Image 2.5 accepts up to 5 reference images. State each image's role by position in the prompt, such as "image 1 is the product, image 2 is the lighting reference."
- Don't use image generation for charts, graphs, infographics, or exact text; generate those with code.

## Speech and audio

- `text_to_speech` reads a `.txt` file for one voice or a `.json` dialogue for up to two voices. Read `speech/guide.md` for voices, delivery tags, and the dialogue format.
- `evaluate_audio` reviews an audio file against your prompt, such as checking clarity and levels with timestamps.