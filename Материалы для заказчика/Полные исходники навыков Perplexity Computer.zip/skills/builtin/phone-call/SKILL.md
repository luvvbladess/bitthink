# Phone Call Skill

Place outbound phone calls on behalf of the user via an AI voice agent. The voice agent conducts the conversation autonomously and returns a transcript and summary.


Invoke deferred tools `prepare_phone_call` and `phone_call`. `phone_call` returns a `subagent_id` immediately and runs in its own background subagent — do not wrap it in `run_subagent`. Use `wait_for_agents` to await results.


## Preparation

Before placing calls, you are required to call `prepare_phone_call` which will help you prepare for the call by flagging missing context needed for the call.

If the user requested multiple calls, each separate objective should have its own `prepare_phone_call` with a distinct `call_context`. However if multiple calls have the same objective, they should share one `prepare_phone_call` with the same `call_context`. For example:

- Call Nike to order me AirJordan 1 for Pickup and Call flowers delivery to order a bunch of roses -> two separate preparations
- Find 3 local plumbers for me and call them to get quotes and availability -> one single preparation (since the objective is the same for all calls, just different recipients)

Build very detailed plain-text `call_context`, including the user's request, intended recipient, phone number if known, objective, caller identity/contact details, authority to commit, relevant dates/preferences/constraints, facts already searched for, unresolved ambiguity, and prior clarification answers.
Treat `required_missing_info` as review output, not an automatic requirement to ask the user. Resolve all items that are genuinely blocking after considering current context, available tools, and what the voice agent can handle during the call.
For each prepared recipient call, pass the resolved E.164 recipient number as `recipient_phone_number` to `prepare_phone_call`. If `prepare_phone_call` returns an invalid-phone or unsupported-country error, relay it to the user and do not proceed with placing the phone call.

After `prepare_phone_call`, to resolve information requiring user input, use `request_user_input`:

- If multiple `prepare_phone_call` were made and many details are missing, split into multiple `request_user_input` calls, each focused on one objective.
- Ask one separate question per genuinely required missing detail. Do not combine unrelated required details into one question. A naturally atomic detail, such as a full street address, may ask for its components together.
- For ALL calls, non-optional: require the user's full name and phone number. If these are available in context or memory, prefill these as options but the user should still need to confirm.
- Do not mix `nice_to_have_info` into required questions.
- If `nice_to_have_info` contains unresolved items, ask one final free-text question that combines only nice-to-have items not already asked, answered, or resolved from context. Do this even when there are no required missing details. Start this question with `Optional:`. Do not add this question if it would exceed the tool's 4-question limit; prioritize required questions.
- Do not ask the user how to introduce yourself at the start of the call.

Since the voice agent cannot ask the caller for clarification mid-call, make sure you have the key details before dialing. If the user does not provide the required details for conducting the call effectively, explain this to the user and do not place the call.

## Approval Before Dialing

Before an immediate `phone_call`, use `request_user_input` and wait for approval. Do not call `phone_call` until the user approves, even if the user explicitly asked you to call.

If a call attempt errors out (the result reports the call failed or it was cut off mid-call), a retry with the same recipient, approved phone number, objective, and limits is covered by the original approval — proceed straight to `phone_call` without another `request_user_input`. This exception does not cover corrected or changed phone numbers, cancelled calls, rate-limited calls, or any no-contact outcome (no answer, voicemail, busy, could not be reached) — follow their rules in After the Call and Rate Limits.

For scheduled phone calls, request `request_user_input` when scheduling the task while the user is still engaged. Do not request approval right before dialing after the scheduled task resumes; the resumed task should proceed using the approval collected at scheduling time.

Scope each approval to one preparation group: one recipient, or multiple recipients that shared the same `prepare_phone_call` because they have the same objective and constraints. If the user requested unrelated calls with separate objectives, use separate `request_user_input` approvals.

Keep the prompt brief. Ask one question with a `Place call` option and a `Don't call` option. In `body`, list only who will be called, their phone number, the one-sentence objective, and any critical limits such as "inquiry only" or "do not book." Do not include other fields beyond these, or relationship descriptors like "(your friend)". Format each labeled field as a separate Markdown paragraph with a blank line between them (`\n\n`), not single line breaks.

Example `question`: `Ready to place the call?`

Example `body`:

```text
**Recipient**: Acme Dental (+14155551234)

**Objective**: Ask whether they have any cleaning appointments available this week.

**Limits**: Inquiry only; do not book an appointment.
```

## Call Intent

Every call has an intent that shapes the voice agent's behavior:

| `call_intent`       | When to use                                                                                                                                                                                                                                                                                                                                      |
| ------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `inquire` (default) | Quotes, availability, questions, comparisons. The voice agent will not commit on the caller's behalf.                                                                                                                                                                                                                                            |
| `commitment`        | The user named acceptable parameters and authorized you to act on a matching offer: book / reserve / schedule, modify / cancel, negotiate or agree to a price, lower a recurring bill, accept a retention or refund offer, switch a plan. The voice agent still only accepts terms inside the user's stated parameters and defers anything else. |
| `social`            | Personal/relational calls — wishing someone well, checking in, relaying personal news. No transactional framing.                                                                                                                                                                                                                                 |

Pick `commitment` when the user has stated parameters and authorized you to act on a matching offer — retention discounts, hold reservations, refund offers, and similar deals often won't survive a callback. Pick `inquire` when the user wants information to decide later, or when no acceptable parameters were named. When in doubt and the user did not name acceptable parameters, stay with `inquire`.

## Filling the Tool Fields

- **`phone_number`** — E.164 with country code, e.g. `+14155551234` (US) or `+447911123456` (UK). Local-format numbers and extensions are rejected. If the user only provides a local number, look up the recipient's country code (from their address, business location, or by searching) and construct the full E.164 number before calling.
- **`objective`** — What should the call accomplish? Be specific. "Get a quote for fixing a leaky kitchen faucet" not "call about plumbing."
- **`background`** — Relevant context the voice agent needs: dates, times, preferences, budget, problem description, reference numbers.
- **`caller_name`** — The user's name. Falls back to account name if not set.
- **`call_language`** — Language the recipient is expected to use on the call. Prefer the language of the recipient's country. Use a different language when the user explicitly asks for one or there is another clear reason the recipient expects it.
- **`call_intent`** — See call intent above.

## After the Call

When the call completes, you'll get a transcript and summary. Use these to:

1. **Summarize the outcome** for the user — what was learned, what was agreed, what the next steps are.
2. **If gathering quotes from multiple places** — present a comparison after all calls complete.
3. **If a callback is needed** — tell the user what info to have ready when they call back to confirm.
4. **If the call was cancelled** — phone-call cancellation is explicitly non-retriable. Do not offer or attempt another call unless the user explicitly asks.
5. **If the call otherwise failed or was cut short** — explain what happened and offer to retry or try a different approach. If the rate limit blocks a call, tell the user when they can try again (see Rate Limits).

## Multi-Call Workflows

When the user wants to call multiple businesses (e.g., "get quotes from 3 plumbers"):

1. Research phone numbers for all businesses via web search first.
2. Prepare the shared call context with one `prepare_phone_call` if all recipients have the same objective.
3. Request one `request_user_input` approval for that prepared call group.
4. After approval, launch a batch of `phone_call` calls (max 10 in flight — see Rate Limits), then use `wait_for_agents` before comparing results.
5. After all calls complete, present a structured comparison of what each offered.

## Rate Limits

Outbound calls reach real people. Repeated calls to the same number, or fan-out across many numbers in a short window, feel like harassment to the recipient — and the user may not realize they're causing that. Treat the limits below as a backstop, not a target: when the user asks for something that's clearly spammy ("call them every minute until they pick up", "call all 50 of these in a row"), push back and propose a calmer approach instead of working around the limits.

The system enforces, per user:

- **Concurrency**: at most 10 calls in flight at a time. For larger batches, launch up to 10, call `wait_for_agents`, then launch the next group. Do not fire all of them and let the rate limiter reject the excess.
- **Same recipient**: at most 2 calls every 10 minutes, 4 per hour, 5 per day to the same number. Do not silently retry within the cooldown after a no-answer / voicemail — that pattern is the most common form of recipient harassment, and the limit exists to stop it.

If `phone_call` returns a rate-limit error, that's a signal the request has crossed into spam territory. Surface the error and retry time to the user, and ask how they want to proceed — do not loop or auto-retry.

## When NOT to Call

Prefer other tools when:

- The business has online booking — OpenTable, Resy, Yelp Reservations, Calendly, etc. Use a browser subagent instead of calling.
- The information is on their website (use the web search tool instead).
- Email would work just as well (use integrations).
- The user just needs a phone number (search for it and give it to them).