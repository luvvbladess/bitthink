# The Perplexity API

Perplexity offers a developer API so teams can build with the same intelligence that powers Perplexity. It centers on three APIs on one platform, with the Agent API as the recommended starting point.

## The APIs

**Agent API** — The recommended way to build. A single OpenAI-compatible chat endpoint to call frontier models from multiple providers (OpenAI, Anthropic, Google, and more) at the same price as going direct. Includes built-in tools — web search, fetch a URL, people search, finance search, and a code sandbox — plus reusable presets. For web-grounded answers with citations, the Agent API is the path forward.

**Search API** — Raw, ranked web results with no LLM on top, served from its own endpoint. The retrieval foundation for building your own RAG or grounding logic.

**Embeddings API** — Turns text into vectors for semantic search and retrieval, served from its own endpoint. Models: pplx-embed-v1 (0.6b and 4b) plus contextualized variants.

## Good to know

- The Agent API's OpenAI-compatible chat surface means most existing SDK code works with a base-URL swap. Search and Embeddings have their own request and response shapes.
- Includes finance search, an endpoint to list available models, plus n8n and AWS Marketplace integrations.
- Perplexity's own Sonar models are available as one of the model choices in the Agent API.
- Perplexity API credits are purchased at [console.perplexity.ai](https://console.perplexity.ai) and are separate from Computer credits.
- Full model lists, pricing, and quickstarts live at [docs.perplexity.ai](https://docs.perplexity.ai).

## Example use cases

- Build a research feature that returns answers with citations.
- Power a multi-model app that switches providers without re-integrating.
- Add semantic search or RAG over your own content.
- Ground an assistant in real-time web results.
