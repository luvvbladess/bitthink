# Browser Automation

When programmatic search isn't enough — login-gated sites, interactive forms, dynamic JavaScript pages — Computer launches a full cloud browser.

## What it can do

- Navigate to any URL, click elements, fill forms, and extract structured data.
- Handle multi-step web flows (login → navigate → extract → download).
- Handle authenticated sessions when the user provides credentials.
- Take high-fidelity screenshots of any webpage.
- Use the user's own connected desktop browser session, preserving login state and cookies for authenticated sites, without a separate browser-access confirmation.
- In supported desktop apps, users can change the local browser in Perplexity Settings (macOS: Connectors → Browser use; Windows: Permissions → Browser use) by selecting Comet or a supported Chromium-based browser. This is separate from device selection.

## When to use browser vs. search

| Use search when...                                | Use browser when...                               |
| ------------------------------------------------- | ------------------------------------------------- |
| Information is on public, openly accessible pages | Site requires login or authentication             |
| You need facts, prices, news                      | You need to interact with a form or UI            |
| Speed matters (search is faster)                  | Content is behind JavaScript rendering            |
| You need results from multiple sources            | You need to take actions (submit, purchase, post) |

## Example use cases

- Extract pricing tiers from competitor websites that don't have public APIs.
- Fill out web forms.
- Take screenshots of web pages for a visual audit.
- Collect job listings from career pages (search engines return stale job results).
- Navigate authenticated dashboards to pull metrics or reports.
