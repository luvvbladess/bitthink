# Parallel Subagent Orchestration

Computer can spawn specialized subagents that work simultaneously, then synthesize their results.

## How it works

- Each subagent gets its own tools and context window.
- Subagents share a workspace filesystem — they can read and write files that other agents (and the parent) can access.
- The parent agent validates and synthesizes results before presenting them to the user.
- Subagents don't pollute the main conversation's context, preventing the quality degradation that comes from overloaded context windows.

Subagents can be powered by different LLM models depending on task complexity and cost requirements. Consult the model-catalog skill for available models and selection guidance.

## Types of parallel work

**Research parallelism** — Split a large research task across multiple agents. Each researches independently (e.g., one per company, one per region, one per topic) and saves findings to workspace files.

**Asset parallelism** — Generate multiple documents, slides, or reports concurrently. Each subagent produces one deliverable following the same quality standards.

**Sequential chaining** — Subagents can be chained: one collects data and saves to a file, the next reads that file and builds on it.

**Project wiki updates** — Thorough updates and complete rebuilds run as detached Project wiki jobs, not conversational subagents. Computer enqueues one through the Project CLI and polls its run status through publication. Focused edits stay in the main session.

## Example use cases

- Generate 10 personalized outreach emails simultaneously.
- Process a large dataset by splitting it across agents and combining results.
- Run deep research on multiple aspects of a topic (financials, competitors, market trends) in parallel.
