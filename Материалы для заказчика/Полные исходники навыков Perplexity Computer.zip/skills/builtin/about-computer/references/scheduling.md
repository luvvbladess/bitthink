# Scheduling and Automation

Computer can run tasks on a schedule and proactively notify the user — turning it from a reactive assistant into a persistent autonomous agent.

## Scheduled tasks

Set up one-time or recurring tasks that run automatically on a durable schedule:

- "Remind me about this on Friday."
- "Send this email at 9am tomorrow."
- "Monitor competitor pricing daily."
- "Summarize my inbox every morning."
- "Send a weekly sales summary every Monday at 9am."
- "Run a portfolio review on the first Monday of each month."
- "Post a daily market update to Slack."

One-time automations finish after one scheduled run and retain their run history; older tasks created with `schedule_cron` are removed when their one-time run begins. Recurring automations can pause themselves when their explicit goal is fulfilled, preserving their history for the user to resume. They can back off within the user’s timing constraints and save verified improvements to their instructions. Increasing frequency requires the user’s explicit approval of the faster cadence or range. A quiet check or an unavailable source does not mean the goal is finished. Calendar constraints such as "first Monday" are combined so the task runs only when every requested date constraint matches. Each run can access the full set of Computer's capabilities — search, integrations, code execution, document creation. Connector actions set to Always Ask require approval; choosing Always allow in a session also applies to future scheduled runs in that session.

Users can view, pause, or delete scheduled tasks themselves on the Tasks page at `/computer/tasks`. When Computer cannot change a schedule itself — for example the scheduling tool keeps failing — link the user there rather than to the session.

Computer normally sets up a scheduled automation to return to the creating session with its shared context. When that session already has an automation and the user asks for another, Computer selects a fresh background session for each run of the additional automation. Users can explicitly request either destination. Editing an existing automation preserves its destination.

## Automation setup

When the user wants an automation but has not chosen a task, Computer offers relevant
task suggestions through inline choices, then collects the schedule or supported
trigger conditions. Users can describe a custom task directly in the choice form,
and supplied details are reused.

Computer resolves connected accounts and resources, asks ordinary questions only for
missing required inputs, and creates the automation. A final plain-text review is optional
when requested or warranted by the task. The created automation appears in the thread;
users can request changes conversationally.

## Waiting within active work

When work is already underway and must pause before its next step, Computer can wait and resume the same workflow:

- "Follow up if no reply in 48 hours."
- "Continue processing after this API cooldown."

Computer pauses, wakes up at the specified time, and continues from where it left off with the session's shared context.

Slack message automations can filter by message text, mentions, sender, conversation type,
one known thread, subtype, and attached file names or types. When Slack user admission
is enabled, eligible messages are checked against the automation's rule, or its name
and instructions when no rule was supplied. Admitted messages start a run without the
connector batch delay. When that rollout is disabled, Slack triggers use the connector
batch path without deriving an implicit rule from the name and instructions. Completion
and notification timing depend on the work; there is no fixed delivery-time guarantee.

## Notifications

By default, Computer can notify users when each automation run finishes. Users can turn these completion notifications off for any automation. They can also separately ask Computer to send an Email, In-app notification, or Push notification with useful content; this is independent of the automatic completion notification.

## Example use cases

- Daily briefing — pull calendar, CRM, and email data every morning and send a prioritized summary.
- Price monitoring — check competitor pricing hourly, alert when changes are detected.
- Follow-up automation — send an email now, check for a reply in 48 hours, follow up if none.
- Recurring reporting — compile weekly metrics from connected tools and deliver as PDF.
