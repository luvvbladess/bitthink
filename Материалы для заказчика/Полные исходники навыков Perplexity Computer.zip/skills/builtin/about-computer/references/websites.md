# Live Website Deployment

Computer builds and deploys websites to live, published `pplx.app` URLs — in a single conversation.

Published sites have their own visibility settings, separate from threads and app preview assets. For users in organizations, new published sites are organization-only by default; consumer-owned sites are public by default. Users can change visibility to make a published site private, organization-visible, visible to specific people, or public.

## What it can do

- Build HTML/CSS/JS sites with modern frameworks and responsive design.
- Deploy to a live, published `pplx.app` URL instantly.
- Add server-side logic via backend servers (SQLite databases, form backends, webhooks).
- Edit files and re-deploy to the same URL with no manual deployment steps.
- Where isolated website previews are enabled, test browser storage, local-image canvas effects, and clean-path navigation inside the preview. Backend response cookies are scoped to that preview; service workers remain disabled.

## Three types of websites Computer can build

Computer has specialized expertise in three categories of web development:

### Informational Websites

Personal sites, portfolios, editorial publications, blogs, small business pages, and landing pages. Content-first design with beautiful typography, SEO optimization, and responsive layouts. Think portfolio showcases, company sites, magazine-style editorial pages, and single-page landing pages.

### Web Applications

SaaS products, dashboards, admin panels, e-commerce stores, and interactive brand experiences. Full-featured product interfaces with navigation architecture, state management, data visualization, authentication, and responsive app patterns. Think Linear, Notion, Shopify-style admin panels, and analytics dashboards.

### Web-Based Games

Browser-based games built with Three.js, Babylon.js, WebGL, and modern web game engines. From casual 2D puzzles to immersive 3D worlds — playable instantly in any browser with no install required. Includes asset sourcing from Fab.com, Sketchfab, and other marketplaces.

## Workflow

1. Computer writes the HTML, CSS, and JavaScript in the workspace.
2. Deploys to a live, published `pplx.app` URL.
3. User reviews the live site.
4. Computer makes changes and re-deploys to the same URL.

The cycle from idea to live URL takes minutes. Iteration is instant.

## Example use cases

- Build a product landing page from a description and deploy it live.
- Create an interactive dashboard for data visualization.
- Set up a simple form with a backend that stores submissions in SQLite.
- Build an internal tool and publish it as organization-only by default.
- Build a portfolio site or event page.
- Prototype a web app idea quickly with a working URL to share.
- Build a browser-based 3D game with Three.js and deploy it instantly.
- Create an e-commerce storefront with product pages and checkout flow.
- Design an editorial blog with beautiful typography and reading experience.
