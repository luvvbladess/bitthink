# Persistent Memory & Brain

When Memory, search history, and Brain are turned on, Computer remembers the user across sessions and uses that context to personalize every interaction. Each is user-controlled and can be turned on or off independently in Settings. Two layers work together: **Memory** makes Computer feel familiar, and **Brain** makes Computer more productive.

## Memory

Memory lets Computer remember details between sessions so interactions are more personalized and efficient. It draws on two sources, which the user can toggle independently in Settings → Memory:

- **Memories** — the preferences, interests, and information the user shares.
- **Search history** — past questions and answers that make a new response more relevant.

### What it remembers

- **Identity** — Name, role, company, team, manager, colleagues.
- **Preferences** — Communication style, formatting preferences, tools used, workflow habits.
- **Projects** — Active projects, goals, deadlines, key stakeholders.
- **History** — Specific facts and key exchanges from past sessions.
- **Corrections** — When the user says "I prefer X" or "don't do Y," Computer remembers for next time.

### How it works

**Personalized learning** — Computer stores durable facts as they come up naturally in conversation. No explicit "remember this" command needed (though that works too). The more the user engages, the more useful it becomes.

**Semantic recall** — Computer can search its memory to retrieve specific facts, preferences, and key exchanges from past sessions, understanding context and meaning beyond simple keyword matching.

**Automatic output** — Deliverables match the user's known preferences automatically. If the user prefers bullet-point summaries or uses specific terminology, Computer adapts without being asked.

### Managing memory

- View and manage everything in Settings → Memory: toggle search history, toggle Notes (simple details saved from sessions), and open **Manage memories** to search, filter, and delete individual entries.
- Memory and search history can each be turned off independently. Turning Memory off stops Computer from referencing it but does not clear existing memories — clear those in Manage memories.
- Deleted memories may be retained in a log for up to 30 days for safety and debugging before being fully removed.

### What it doesn't remember

- Ephemeral instructions ("make this shorter" applies only to the current task).
- Sensitive data — Memory has filtering to reduce retention of sensitive details like health or financial information, and the user can always review and clear the memory bank.
- Incognito tasks never read from or write to persistent memory.

### Scoping, enterprise, and training

- **Projects (formerly Spaces)** — Memory is tied to the individual account. Inside a project, memories are scoped to that project and don't flow into global memory. A user can optionally let a project reference their personal sessions; those sessions stay private to them.
- **Project knowledge** — Wiki-enabled Projects maintain shared durable context separately from personal Brain. Computer loads the Project wiki catalog when a Project task starts so it can find relevant decisions, entities, and background immediately. Wiki pages Computer reads appear in the task's context panel and link back to the Project wiki.
- **Enterprise** — Available to Enterprise organizations, with admin-level controls and memories owned by the organization.
- **Training** — Memory content may be used to improve models for everyone; specific data isn't shared with anyone. To stop content from being added, turn off Memory or its sources (search history, Notes) in Settings → Memory.

## Brain

**Brain is available to Max subscribers using Computer, and is currently rolling out in Research Preview.**

Brain is a background agent that continuously improves Computer's memory layer. It builds a working model of the user's world — the projects they're driving, the people involved, the documents behind them, the decisions already made, and the open loops still unresolved.

### Memory vs. Brain

Memory helps Computer **know you**. Brain gives Computer the **working context to move your work forward** — and it powers a richer Memory over time. Where Memory stores preferences and shared facts so answers come back personal, Brain goes further: it organizes the user's world as a connected, source-grounded structure and keeps it current as that world changes.

### How it works

- Brain runs in the background, not during active tasks, so it never slows down what the user is doing.
- It reviews recent activity — sessions, connector updates, files and artifacts, and corrections — and writes what it learns into Computer's memory.
- When enabled, recent observations from other Computer sessions can be available as pending learnings before Brain updates its wiki. These hints are unverified; Computer checks source sessions when resolving conflicts or updating knowledge.
- Every entry links back to its source, so the user can check or correct it. Corrections feed forward into Brain's next run.
- Each run builds on the last: reinforcing what's still true, updating what's changed, and marking what's stale.

### What Brain learns from

- **Sessions** — the tasks the user runs and the work Computer does with them.
- **Connected tools** — data Computer pulls from linked connectors (docs, messages, issue trackers, etc.).
- **Files and artifacts** created in Computer.
- **Corrections** the user makes, so Brain updates instead of repeating a mistake.

Brain only learns from the user's own activity. It does not pull in anyone else's data and does not learn from incognito sessions.

### What Brain does for the user

Brain gives Computer working context about projects, people, and files so it can act on requests that depend on what the user has been doing. Ask "what should I present to the customer tomorrow?" and Brain pulls together the relevant account context, recent notes, open issues, and product work — every claim linked back to its source. The result is a grounded recommendation, not a list of search hits. Brain compounds with use: the more the user returns to a project, the richer its understanding, so the biggest gains show up on returning work rather than a first task.

### Control and privacy

- **Viewing and editing** — In Memory the user can see everything Brain has learned (notes, concepts, entities, workstreams), open any entry to see how it connects and click through to its source, and edit or delete entries.
- **Project generation** — In a Brain-enabled project, writers can start a paid knowledge generation run from the project's Memory settings with **Update now**. The page shows queued, running, and publishing progress and displays the run duration when it finishes.
- **Its own toggle** — Brain has a separate toggle in Computer settings, independent of Search History. Turning it off stops Brain from writing new knowledge from the user's activity.
- **Enterprise** — Brain follows the organization's Memory setting by default; admins can adjust it independently.
- **Privacy** — Brain is built only from the user's own activity and used only to improve their own answers. Incognito is excluded, and it uses the same sensitive-information filtering as Memory.
- **Training** — AI Data Retention is scoped to searches used to improve models, not to what Brain writes into Computer's memory; Brain's own toggle controls its writing.
- **Does it act on its own?** — No. Brain only maintains memory; it doesn't take actions or message the user. It's the foundation for future proactive features, which are controlled separately and surfaced for review.

## Example use cases

- Start a new session and Computer already knows your role, company, and current projects.
- Ask for a report and it matches the format you preferred last time.
- Reference "that analysis we did last week" and Computer retrieves the relevant details.
- Computer recalls your colleagues' names and roles when prepping for internal meetings.
- Open a long-running project and Computer already understands how today's task fits the work you've done before, who's involved, and what's still outstanding (with Brain enabled).
- Project readers can load existing Project knowledge without receiving write access; creating the repository and writing changes still require Project write access.
