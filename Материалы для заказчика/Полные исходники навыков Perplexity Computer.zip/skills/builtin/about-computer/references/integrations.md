# External Integrations

Computer connects to 400+ external services through a managed connector framework.

## How it works

- Users authenticate once via OAuth. Computer uses tokens securely.
- Available connectors are discovered dynamically — Computer checks what's connected before saying it can't access something.
- Connectors support both reading and writing — not just fetching data but taking actions.
- Sandbox tasks can use `pplx connector list`, `describe`, and `call` to access Connector Service directly; eligible call results retain connector attribution for inline citations.
- Run citation-eligible connector calls in separate Bash commands so each result keeps unambiguous attribution.

## Supported services (examples)

| Category           | Services                                              |
| ------------------ | ----------------------------------------------------- |
| Communication      | Slack, Gmail, Outlook, Microsoft Teams                |
| Calendar           | Google Calendar, Outlook Calendar                     |
| Documents          | Notion, Google Docs, Google Sheets, Dropbox, OneDrive |
| Project management | Linear, Jira, Asana, Trello                           |
| CRM                | HubSpot, Salesforce                                   |
| Development        | GitHub, GitLab                                        |
| Data               | Airtable, Google Sheets, databases                    |
| Lifestyle          | Spotify, Strava                                       |
| And more           | Hundreds of additional connectors across categories   |

## What Computer can do with integrations

- **Read**: Search emails, pull calendar events, query CRM records, fetch documents, list tasks.
- **Write**: Send messages, create tasks, update records, post to channels, send emails, create calendar events.
- **Search**: Find specific items across connected services — including emails in known shared Outlook mailboxes and nested folders — plus documents mentioning a topic and tasks assigned to someone.
- **Analyze**: Combine data from multiple services, summarize and visualize key patterns, and generate actionable insights or recommendations from emails, docs, metrics, and tickets.
- **Linear watches**: An active Computer session can subscribe to a Linear team or a specific issue and wake when matching issue activity needs attention.
- **Slack canvases**: In Slack, Markdown deliverables are promoted into a standalone canvas, and follow-up edit requests can update that canvas instead of reposting the full response. A retried Markdown delivery reuses the canvas instead of also attaching the source file. A distinct later Markdown deliverable is attached as a file. If canvas creation is already in progress, a concurrent delivery waits up to 60 seconds for the saved canvas. If no saved canvas appears, the delivery attaches the Markdown file. When editing a table in a canvas, rewrite the whole table in a single update — send the full markdown (header, separator, and every row) as one replace — rather than adding rows one at a time; piecemeal per-row inserts fragment the table into separate blocks instead of extending it.
- **Slack message deletion**: Computer can delete Slack messages it posted itself — its chat replies and messages sent on the user's behalf — in conversations the user is a member of. It cannot delete the user's own messages, other people's messages, or messages Computer sent on behalf of other users.
- **Slack message editing**: Computer can edit Slack messages it authored while preserving their attribution and session link. It cannot edit messages from users or other apps, or messages Computer sent on behalf of another user.
- **Slack question attachments**: When Computer pauses to ask a question in Slack, users can attach files directly in the **Answer Questions** modal instead of replying with text alone.
- **Slack Projects**: Users can run `/project` to connect a Slack channel to a Project. When creating a Project, they can keep the suggested channel-based name or enter a different one. Computer announces the connected Project in the channel so future tasks can use it. Direct messages are never autocreated.
- **Slack model selection**: When enabled for their organization, users can send `!model` in a direct message with Computer to choose from the Computer orchestrator models available to their Perplexity account. The selection becomes their default for new Computer tasks in that Slack workspace; choosing **Default** removes that per-user selection so future tasks follow the organization's model default. The older `#model` keyword still works.
- **Slack account reset**: If Computer in Slack is linked to the wrong Perplexity account (for example, a personal account instead of a work account), users can send the exact text `!logout` in a direct message with Computer to clear the link between their Slack user and that Perplexity account. Computer confirms that they are logged out, and their next message triggers a fresh sign-in prompt. Before signing in again, users should sign out of Perplexity in their browser or confirm it is signed in to the intended account, because the link binds whichever Perplexity account completes the sign-in. Disconnecting the Slack connector in Perplexity settings does not reset this link. The older `#___logout____/` keyword still works.
- **Private Computer links**: In Slack, senders with a Perplexity organization can grant that organization access to a private Computer task directly from its private-link notice. Senders without an organization can grant access to anyone with the link.

## Connecting a new service


Connector approval requests show and store the operation's arguments for Allow once. For a CLI approval, pass `arguments={"command": "<exact bash command>"}` and retry that command unchanged: only a matching command can consume the one-time grant during credential setup. Always allow in thread covers subsequent uses of the connector operation with any arguments and clears pending once approvals for it. Direct `call_external_tool` argument matching is not yet enforced.


When Shared Project connectors are enabled, an explicitly selected GitHub connector can coexist with Project GitHub App repository access. Ordinary Project sessions with GitHub App bindings retain their restriction on personal GitHub connectors.

If the user needs a service that isn't connected yet, Computer offers a connection prompt. In Slack, Teams, email, CLI, and MCP, the prompt opens the task in Perplexity, where the user can authorize the connection.

## Example use cases

- Pull today's calendar and prep for each meeting using CRM data.
- Search Slack for messages about a topic and summarize the discussion.
- Create Jira tickets from a list of requirements.
- Send a personalized email to each contact in a CRM pipeline stage.
- Pull metrics from Google Sheets and generate a report.