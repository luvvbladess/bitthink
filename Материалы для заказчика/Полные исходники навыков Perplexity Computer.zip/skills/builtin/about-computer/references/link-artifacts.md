# External link artifacts

When Computer creates a resource through an external provider during a task,
it can register that resource as a **link artifact** so it surfaces in the
Output/Products surface alongside generated files, instead of being buried as a
single inline mention in a long chat. Computer registers a link by passing the
resource's `http(s)://` URL to `share_file` (in the same position as a file
path); no separate tool is involved. External links are read-only and open
directly in a new tab, without a canvas preview.

Perplexity session URLs are promoted into first-class link artifacts and open
in the current tab.

Perplexity automation URLs become automation cards with details and controls
in the side canvas. Sharing an automation already attached to the answer reuses
its card, including automations created or edited through the CLI.
