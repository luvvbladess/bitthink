# MCP Clients

Computer is available as an MCP (Model Context Protocol) server, so external AI clients — Claude Code, Claude Desktop, Cursor, and any other MCP-capable app — can delegate work to Computer and stay in their own interface.

## How it works

The client connects to Computer's MCP endpoint and authenticates with the user's Perplexity account via OAuth. Each conversation maps to a Computer thread; the client keeps the returned `thread_id` to continue it. Threads created over MCP also appear in the Perplexity product, so users can pick the same task up on the web at any time.

## What clients can do

- **Run tasks** — send a message and Computer completes it end to end, streaming progress updates while it works.
- **Continue threads** — follow-up messages with the same `thread_id` resume the conversation, including after a user submits input from the web or desktop app.
- **Read threads back** — fetch the transcript and status of an existing thread (including question and confirmation exchanges) without waking the agent or spending credits.
- **Answer questions and confirmations** — when Computer needs input or approval mid-task, the client shows the prompt and the user answers directly from their MCP client with its native accept/decline controls.
- **Attach files** — upload files that Computer can use as task inputs.

## Limits

When an OAuth token response includes a refresh token, refresh before `expires_in` elapses and save replacement tokens atomically. Access lasts up to 30 days, capped by the remaining grant lifetime. Refresh grants expire after 90 days without refresh or 365 days after sign-in. Sign-out-all revokes the original session and refreshed access. Serialize refresh requests. Authservice returns the same replacement pair for the immediately previous token within 30 seconds of rotation. Retries do not extend this window or the grant lifetime. Older replays or retries after the window revoke every access and refresh token in that grant. The proxy checks the stored grant on every use of a new MCP access token. HTTP `503 temporarily_unavailable` indicates a temporary access-validation or pre-rotation refresh failure. Keep the credentials and retry later. An HTTP `401 invalid_token` can require refresh. A refresh `invalid_grant` requires browser sign-in. This includes failures to save replacement tokens after upstream rotation and uncertain transport failures after sending a refresh request. Existing logins need one new sign-in to obtain refresh tokens after rollout.

- Clients can only read and continue threads owned by the authenticated user. Omit `thread_id` to create a task with a server-generated ID. Supplied IDs never create tasks. Invalid or inaccessible IDs return an MCP tool error.
- Long transcripts are truncated to the most recent turns.
- Task calls wait for up to two minutes. If Computer is still working, the call returns
  a `thread_id` that the client can pass to `read_thread` to check progress and read
  the eventual transcript. Generated files and the complete, untruncated response
  remain available in the web thread.

Use `list_thread_assets` to recover generated files after the foreground call ends. Follow its `next_cursor` and preserve opaque asset IDs. Use `create_asset_download` for a fresh URL to the exact listed asset version, even after an app redeployment. The returned expiration applies to the download URL. The primary-asset flag identifies shared deliverables when the source entry remains available.

Use `read_thread.web_state` to recover forms and displayed status from saved workflow blocks. Entries include `auth_requests` and `form_links`; complete connector authentication and web-only forms in the linked task. After connector authentication, call `notify_connected(thread_id, message)` to report the user’s completion.

Masked form defaults are omitted. If web state cannot be loaded, `read_thread` preserves the transcript and reports `web_state_error`; retry before treating missing state as no pending interaction.
