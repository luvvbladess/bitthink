# Custom API Credentials

Computer supports bring-your-own-key access for third-party HTTPS APIs that do not have a built-in connector.

## How users invoke it

Natural language is enough — for example, "I have credentials for the ___ API."
For the active workflow, load the `custom-credentials` skill; it owns the trigger details and credential form procedure.

## Secure credential entry

Computer opens a secure in-session credential form for the user; users enter the key there, not into chat. Computer should never ask users to paste secrets into the conversation, and never echo credential values back. If a user has already pasted a secret unprompted, Computer can prefill the matching masked field in the form so the user only needs to review and submit it.

## Scope and lifetime

Custom API credentials can be scoped to the current session or saved to the user's, project's, or organization's Credentials vault. Saved credentials can be reused within their scope. New credentials default to Always allow in every scope; existing credentials retain their approval settings. Users can change saved credentials to Ask for approval in the vault. Credentials are never shared outside their saved scope.

`list_credentials` reports where each credential is stored: `thread`, `user`, `project`, or `organization`. Attaching a saved credential to a task preserves its saved scope. Check `requires_approval` separately to determine whether it needs approval before use in the current session.

Workers resolving a host use the first eligible credential in session → user → project → organization order. Missing, disallowed, or unusable candidates can fall through during selection; API authentication failures do not trigger retries with broader credentials. Project sessions exclude user credentials. An exact credential handle selects only that credential.

## How credentials are used

After submission, Computer can call the matching service host over HTTPS; the credential is injected automatically through a secure proxy. Computer does not see the raw credential value after creation.

## Managing credentials

Users can view, revoke, and choose the approval behavior for saved credentials from the Credentials vault. Revoking a vault credential from a specific session only revokes that session's approval/reference; the reusable vault credential remains available for future approvals unless the saved credential itself is revoked.

## Prefer built-in connectors

For GitHub, use `gh`/`git` with the configured GitHub authentication. For other connected apps, prefer connector tools or `pplx connector` when enabled. Custom credentials are for direct APIs not covered by connectors, not a fallback around missing authorization. Computer uses `list_credentials` and Bash's `api_credentials`.
