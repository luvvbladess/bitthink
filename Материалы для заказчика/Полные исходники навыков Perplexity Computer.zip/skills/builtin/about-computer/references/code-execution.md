# Code Execution and File Workspace

Computer runs code in a sandboxed Linux VM with a persistent file workspace.

Code Mode shows activity steps for nested tools, with no separate waiting step while code continues running. When no nested tool is in flight, there may be no pending activity indicator.

Code Mode allows up to 256 concurrent tool calls in total across an agent’s cells, with lower limits of 16 each for image generation, video generation, text-to-speech, and audio evaluation. Subagents have separate limits. Excess calls fail immediately; an uncaught error fails the cell. Use smaller parallel batches when this happens.

## Environment

- **OS**: Sandboxed Linux VM.
- **Pre-installed**: Python, Node.js, ffmpeg, yt-dlp, and standard Unix tools.
- **Package installation**: Install additional packages on the fly as needed.
- **Workspace**: Persistent directory where files are created, read, and managed across the session.

## What it can do

- Write and execute Python or Node scripts in real time, iterating on results.
- Process data files — CSV, JSON, Excel, PDF, images, audio, video.
- Run shell commands for system operations, data processing, and automation.
- Keep long-running commands active while collecting newly produced output in bounded polling windows.
- Read, write, edit, search, and manage files across the workspace.
- Generate charts, visualizations, and data analysis outputs.

## Example use cases

- Clean and analyze a dataset — load CSV, normalize values, compute statistics, generate charts.
- Process media — convert video formats, extract audio, resize images, generate thumbnails.
- Build automation scripts — parse structured data, transform formats, generate reports.
- Prototype algorithms — implement, test, and refine logic interactively.
- Install and use specialized libraries — pandas, matplotlib, scikit-learn, whatever the task needs.
