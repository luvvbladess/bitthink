# Perplexity Computer — Capabilities Overview

Most AI agents do one thing well — search, code execution, or chat. Computer does all of it in a single, continuous session with a shared workspace, orchestrating multiple frontier models to match the right intelligence to each task — and letting users direct model choice. One agent, one conversation, full context.

## Core capabilities

New Pro sessions using the default model use Opus 5 with low reasoning effort unless a model experiment overrides the default. Existing sessions retain their saved model settings.

| Category        | What Computer does                                                                                                                                                  |
| --------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Research        | Parallel web, academic, social, image, video, and people search with deep page reading                                                                              |
| Browser         | Cloud-based automation across any site, including login-gated pages                                                                                                  |
| Code            | Interactive Linux sandbox with Python, Node, ffmpeg, and standard Unix tools                                                                                        |
| Visualizations  | Interactive inline charts, diagrams, and explainers that stream into the response                                                                                   |
| Documents       | PDF, DOCX, PPTX, XLSX — full professional formatting, not just text dumps                                                                                           |
| Media           | AI image and video generation (with model selection), video editing, text-to-speech, transcription with speaker diarization                                         |
| Websites        | Build and deploy to a live `pplx.app` URL in minutes, with Share settings for private, org-only, specific-people, or public visibility                              |
| Integrations    | 400+ managed connectors (Slack, Gmail, Calendar, Notion, Linear, CRM, etc.)                                                                                         |
| Subagents       | Parallel orchestration with shared workspace, structured result synthesis, and per-agent model selection (Claude, GPT, Gemini)                                      |
| Memory          | Persistent cross-session recall — semantic search over user facts and history                                                                                       |
| Scheduling      | Recurring tasks, delayed actions, and push notifications                                                                                                            |
| Model selection | Route subtasks to the best model for the job — users can direct model choice to optimize for quality, cost, or speed across frontier models from multiple providers |
| Skills          | 50+ domain-specific expert playbooks loaded on demand                                                                                                               |

## How capabilities compose

Learn Step by Step (`computer-learn`) is an opt-in skill for guided tutoring, study guides, flashcards, and practice questions. Users must explicitly select Learn Step by Step or request `computer-learn`; ordinary study or homework questions do not automatically enable it.

The real power is composition. Example workflows that chain multiple capabilities in a single session:

| Workflow                       | What happens                                                                                                                      |
| ------------------------------ | --------------------------------------------------------------------------------------------------------------------------------- |
| Competitive intelligence brief | Research competitors in parallel → fetch pages → analyze data → create PPTX deck                                                  |
| Customer outreach campaign     | Search for prospects → look up CRM data → research each one → generate personalized emails → send via Gmail → schedule follow-ups |
| Automated weekly report        | Scheduled trigger → pull metrics from connected tools → analyze trends → generate PDF → send via Slack/email                      |
| Product launch site            | Research market → generate imagery → write copy → build HTML/CSS → deploy to live URL                                             |
| Meeting prep                   | Recall past context from memory → check calendar → research attendees → create briefing doc                                       |
| Market research at scale       | Build entity list → parallel research across 100+ companies → collect into JSON → statistical analysis → visualization → report   |

## What makes Computer different

Computer is the next evolution of agentic intelligence. It does professional-grade work — marshaling every tool at its disposal, spinning up subagents to divide and conquer, and pushing through until the job is done.

- **Single session, full context** — No switching between tools or copy-pasting context. Research, execution, file creation, integrations, and memory all share one conversation.
- **Interactive and responsive** — You stay in the loop, steer the work, and iterate. Not "submit and wait."
- **Private Mac handoffs** — When a remote Mac tool result triggers Privacy Gate, the originating Computer thread can collect the share decision while detected values remain on the Mac.
- **Composition over specialization** — Capabilities chain together naturally. A research task can flow into a document, which flows into an email, which schedules a follow-up.
- **Multimodel intelligence** — Computer routes each subtask to the best frontier model for the job — Claude, GPT, Gemini, Veo, and more — and users can direct model choice to optimize for quality, cost, or speed.
- **Persistent memory** — Computer learns your preferences, projects, and context over time. Every session builds on the last.
