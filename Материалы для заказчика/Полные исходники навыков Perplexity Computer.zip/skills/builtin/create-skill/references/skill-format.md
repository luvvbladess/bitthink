# Skill file format

Read this when you are about to write or edit a `SKILL.md` — not before. It is the Agent Skills
specification as it applies here, plus the validation errors that actually come up.

## Agent Skills Format

An Agent Skill is a directory containing a SKILL.md file. Skills can also bundle additional resources alongside SKILL.md:

```
my-skill/
├── SKILL.md            (required)
├── scripts/            (optional) executable scripts for repetitive tasks
├── references/         (optional) documentation loaded into context as needed
└── assets/             (optional) templates, icons, or other output files
```

For simple skills, only SKILL.md is needed. Add bundled resources when the skill involves repetitive scripting work, large reference documentation, or reusable templates — things that would otherwise be recreated from scratch on every invocation.

**Pointing at bundled resources**: SKILL.md has to say when each one is used, or the agent will not
reach for it. Reference every bundled file by its path relative to the skill directory. For
`scripts/`, say what the script does and when to run it rather than restating its logic in prose —
the point of a script is that it is executed, not read. For `assets/`, say which file to copy or
fill in and when, rather than pasting its contents into SKILL.md.

**Keeping SKILL.md manageable**: Aim to keep SKILL.md under 500 lines. If it's growing large, move detailed content into `references/` files and link to them from SKILL.md with a note on when to read each one. This keeps the core instructions readable without losing depth.

### SKILL.md Structure

SKILL.md consists of two parts: a YAML frontmatter block at the top (delimited by ---), followed by the markdown body.

```markdown
---
name: my-skill
description: "A clear description of what this skill does and when to use it."
license: (optional)
compatibility: Any environment requirements (optional)
metadata: (optional)
  author: your-name
  version: '1.0'
---

# Skill Title

## When to Use This Skill

Describe the scenarios where this skill should be applied.

## Instructions

Step-by-step instructions for the agent to follow.

## Examples

Include examples of inputs and expected outputs.
```

### Frontmatter Requirements

**Required fields:**

- `name`: 1-64 characters, lowercase alphanumeric and hyphens only
  - Must match the directory name exactly
  - Cannot start or end with hyphens
  - No consecutive hyphens allowed
  - Valid examples: `pdf-processing`, `code-review`, `data-analysis`
  - Invalid examples: `-my-skill`, `my--skill`, `My_Skill`

- `description`: 1-1024 characters describing what the skill does and when to use it:
  - Be specific and detailed while staying within the character limit
  - Include keywords and trigger phrases that help identify when it should be used (important for agent discovery)
  - Descriptions may contain `:`, `#`, or other special characters that must be escaped via quotes. **Always** wrap in double quotes to be safe.
  - Example: "Use when the user mentions PDFs, forms, or document extraction" is better than "Helps with PDFs"

**Optional fields:**

- `license`: Licensing terms (e.g., MIT, Apache-2.0)
- `compatibility`: Environment requirements, max 500 characters
- `metadata`: Key-value pairs for additional information
- `allowed-tools`: Space-delimited list of pre-approved tools (experimental)

### Declaring connectors (Perplexity)

If your skill uses Perplexity connectors (Google Drive, Notion, Slack, etc.), list them under `metadata.perplexity.connectors`. The service parses and stores this today; the skill-detail UI that renders each connector's per-user connection state and a connect prompt is still in progress, so a declaration has no user-visible effect yet:

```yaml
metadata:
  perplexity:
    connectors:
      - id: google_drive
        reason: Cross-references your Drive docs; without it, research is limited to public web sources.
      - id: notion # reason is optional
      - slack # a bare id string works too
```

- Each entry is `{ id, reason? }`; a bare `id` string is shorthand for a connector with no reason.

- `id` is the connector's `source_id` (e.g. `google_drive`, `notion`, `slack`). Use `list_external_tools` to discover exact ids.

- `reason` is optional author-written color describing what the connector unlocks — or how the skill is limited without it — and will be shown in the skill-detail UI once it launches.
- This is a Perplexity-specific extension. It lives under `metadata` (not a top-level key) so the skill stays valid per the Agent Skills spec; other hosts parse the file and ignore it.
- Connectors are **advisory**: they are never required to install, enable, or run the skill.
- Limits enforced on upload: at most **50** connectors, `id` up to **128** bytes, and `reason` up to **500** bytes. These are byte counts (not code points), so multi-byte characters use more of the budget. `agentskills validate` does not check these Perplexity-specific bounds, so a skill can pass local validation but be rejected on upload — keep declarations within these limits.


## Example: Creating a Code Review Skill

If asked to create a code review skill:

```markdown
---
name: code-review
description: "Review code for bugs, security issues, and best practices. Use when asked to review, audit, or check code quality."
license: MIT
---

# Code Review Skill

## When to Use This Skill

Use this skill when the user asks you to:

- Review code for issues
- Check code quality
- Audit for security vulnerabilities
- Suggest improvements to existing code

## Instructions

1. Read the code file(s) to be reviewed
2. Analyze for:
   - Logic errors and bugs
   - Security vulnerabilities (injection, XSS, etc.)
   - Performance issues
   - Code style and readability
   - Missing error handling
3. Provide feedback organized by severity (critical, warning, suggestion)
4. Include specific line references and suggested fixes
```


## Common Errors

**Error: "SKILL.md must start with YAML frontmatter (---)"**

This means the file doesn't start with `---` on line 1. The very first character must be the opening frontmatter delimiter.

- Wrong: Starting with title `# My Skill` before `---`
- Wrong: Blank lines before `---`
- Correct: File starts immediately with `---`

**Error: "invalid YAML in frontmatter" (e.g., "mapping values are not allowed in this context")**

The `description` value contains a character YAML treats specially — most commonly `:`, but also `#`, `[`, `{`, a leading `-`, or a reserved word like `yes`/`no`/`null`. Wrap the description in double quotes so YAML reads it as a literal string.

- Wrong: `description: Use when: the user asks X`
- Correct: `description: "Use when: the user asks X"`

Quoting is always safe, even when not strictly required — when in doubt, quote.

**Error: Invalid name format**

The name field has strict validation:

- Must be 1-64 characters
- Lowercase letters, numbers, and hyphens only
- Cannot start or end with hyphen
- No consecutive hyphens (`--`)
- Must match the directory name exactly
- Must not duplicate an existing skill name in the target scope (user or organization). Check existing skills before deciding on a name for any new skill.

**Error: "Unexpected fields in frontmatter"**

Only these fields are allowed at the top level of frontmatter: `name`, `description`, `license`, `compatibility`, `metadata`, `allowed-tools`. Any other top-level field will fail local validation via `agentskills validate`. Note: this is enforced by the local validator, not the server — but since step 6 runs local validation before uploading, the skill must pass this check.

If you need custom key-value data, nest it under `metadata`:

- Wrong: `version: '1.0'` as a top-level frontmatter field
- Correct:
  ```yaml
  metadata:
    version: '1.0'
  ```