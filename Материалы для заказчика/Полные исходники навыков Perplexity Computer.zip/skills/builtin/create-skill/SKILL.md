# Work on a skill

Authoring a new skill, changing one the user already has, and repairing one that misbehaved are the
same job: the user ends up with a skill that does what they want. The save path depends on both the
request and the target scope.

## Decide before you draft

**Distinguish making a change from proposing one.** If the user asks you to make, edit, fix, change,
or save a skill, make the change and save it without a separate Apply step. If they ask you to
suggest, propose, or prepare a change for review, show the candidate with `request_user_input` and
save only if they approve. Entry-point metadata does not decide between those paths. The Skills-page
**Improve Skill** action explicitly asks for a suggestion, so it follows the proposal path. The
in-thread chip submits its query text unchanged: usually a specific request naming the target and the
behavior to change, and `Improve <name> skill` when no specific wording was available. Use judgment
from that request instead of treating the chip type or signal ID as either mandatory review or save
authority.

Decide before drafting. If either the requested operation or the target is ambiguous, ask. A passive
reviewer suggestion or an unclicked chip is not a request to write a skill.

Either way, when you are done say plainly what changed.

## Which skills you can change

You can prepare changes to user, organization, project skills.

Reviewable updates can target a loaded personal, organization, or project skill. Load the target by
its exact name and preserve its original scope.

Organization skills are permission-gated: not every member may change one. If the write is refused,
say so plainly — do not retry it and do not silently fall back to a copy.

A global Perplexity skill or a built-in cannot be changed in place.

**Fork it instead.** Save a copy into their own library with `save_custom_skill` and no
`existing_skill_name`, so it lands as a new user skill. Do not attempt the shared write first, and
do not report the request as impossible.

Say plainly what happened: the shared skill is untouched, they now have their own copy, and changing
the shared one for everybody is up to whoever owns it.

## Build and save

Read `references/skill-format.md` before you write or edit a `SKILL.md`. It carries the frontmatter
rules, directory layout, connector declarations, and validation errors that actually come up. Do
not write frontmatter from memory.

1. **Load.** For an update, load the exact target in its original scope and treat the complete
   returned `workspace_path` as the pristine original. If several skills could be the target, ask
   rather than guessing. For a new skill, establish what it should do before drafting.

2. **Copy and edit.** Copy the complete pristine source directory to a separate candidate directory
   and work only on the candidate. Make the requested behavior concrete. Name and description matter
   most for a new skill because the description is how it gets found; include trigger phrasing a
   user would actually say.

   For an existing-Skill edit or improvement only, apply this proposal-neutral authoring-quality
   contract to the complete candidate postimage:

   - Make the smallest coherent edit for one behavior change. Ground every load-bearing claim in
     the initiating request and available evidence. Preserve unrelated behavior, frontmatter,
     metadata, resources, and structure, along with reusable specifics such as tool names, fields,
     commands, query shapes, paths, output templates, checks, and demonstrated remedies. Omit
     secrets and incidental values.
   - Evaluate the complete postimage instead of appending the newest lesson. Replace or move stale
     detail when the hub is growing. If `SKILL.md` would exceed about 4,000 characters or gain a
     third substantial conditional branch, move conditional material into `references/` and add an
     exact read condition in the hub. Put stable deterministic transformations in `scripts/`.
     Supporting files must be useful independently at runtime and referenced by the hub when
     appropriate. Repair dangling references in the same edit.
   - Skills are not documentation. Every token loaded into a session costs context until
     compaction, and a noisy skill silently degrades adjacent skills. Do not recapitulate generic
     model knowledge; keep only instructions that change behavior the model would not already
     produce.
   - Description is the highest-leverage line. When changing it, write one double-quoted YAML
     scalar of at most 50 words with the capability, generalized request shape that should load the
     skill, and closest adjacent request that should not. Front-load useful domain terms, abstract
     incidental literals, and test it against two paraphrases and one adjacent non-example.
   - The hub and every spoke must earn their context cost. Keep short, always-needed decisions and
     navigation in `SKILL.md`. Use `references/` for optional detailed lookup, `templates/` for
     substantial exact scaffolding, `scripts/` for deterministic logic better executed than loaded,
     and `assets/` for reusable static files. Every spoke needs a clear runtime reader and an exact
     read or run condition in the hub.
   - The body must earn its tokens. Keep it within 5,000 tokens. Match specificity to fragility,
     preserve reusable exact artifacts, use imperative sentences, and give four or more ordered
     actions a numbered checklist with an observable completion condition. Add an input/output
     example when output shape matters. Address the executing agent directly, refer to the person as
     "the user," and keep evidence-grounded failure-and-remedy lines concise.
   - Do not restate platform-owned scheduler, connector-call, rendering, sandbox, tool, or
     skill-loading mechanics. Keep scope-specific requirements such as recipients, channels,
     thresholds, and sources.
   - Before packaging, inspect and validate the complete candidate tree, including frontmatter,
     referenced paths, bundled resources, and repaired references. Do not validate only the changed
     files.

   You own the interactive workflow, but you may use an ordinary generic subagent when authoring is
   substantial, especially for a multi-file skill or a change that needs broader analysis. First
   create a unique `skill-candidates/<unique-suffix>/<skill-name>/` directory, copying the loaded
   target there for an update. Then launch the child with no `subagent_type` and no preloaded
   skills. The loaded source tree remains read-only and outside the child's task. Start the child
   objective with this context, replacing every bracketed value:

   ```text
   Author one complete Skill candidate.

   Candidate path: [skill-candidates/<unique-suffix>/<skill-name>/]
   Target Skill: [exact Skill name and current source path, or "new Skill"]
   Mode: [create or update]
   Requested behavior: [the concrete outcome requested by the user]
   Evidence and constraints: [the request and all relevant evidence, limits, and requirements]
   Behavior to preserve: [the target's existing purpose, scope, and useful behavior]

   Read skills/create-skill/references/skill-format.md before editing SKILL.md.
   ```

   For an existing-Skill edit or improvement, append the following authoring-quality contract
   verbatim because the generic child does not inherit this parent context. Leave this block out of
   a new-Skill objective:

   ```text
   For an existing-Skill edit or improvement only, apply this proposal-neutral authoring-quality
   contract to the complete candidate postimage:

   - Make the smallest coherent edit for one behavior change. Ground every load-bearing claim in
     the initiating request and available evidence. Preserve unrelated behavior, frontmatter,
     metadata, resources, and structure, along with reusable specifics such as tool names, fields,
     commands, query shapes, paths, output templates, checks, and demonstrated remedies. Omit
     secrets and incidental values.
   - Evaluate the complete postimage instead of appending the newest lesson. Replace or move stale
     detail when the hub is growing. If `SKILL.md` would exceed about 4,000 characters or gain a
     third substantial conditional branch, move conditional material into `references/` and add an
     exact read condition in the hub. Put stable deterministic transformations in `scripts/`.
     Supporting files must be useful independently at runtime and referenced by the hub when
     appropriate. Repair dangling references in the same edit.
   - Skills are not documentation. Every token loaded into a session costs context until
     compaction, and a noisy skill silently degrades adjacent skills. Do not recapitulate generic
     model knowledge; keep only instructions that change behavior the model would not already
     produce.
   - Description is the highest-leverage line. When changing it, write one double-quoted YAML
     scalar of at most 50 words with the capability, generalized request shape that should load the
     skill, and closest adjacent request that should not. Front-load useful domain terms, abstract
     incidental literals, and test it against two paraphrases and one adjacent non-example.
   - The hub and every spoke must earn their context cost. Keep short, always-needed decisions and
     navigation in `SKILL.md`. Use `references/` for optional detailed lookup, `templates/` for
     substantial exact scaffolding, `scripts/` for deterministic logic better executed than loaded,
     and `assets/` for reusable static files. Every spoke needs a clear runtime reader and an exact
     read or run condition in the hub.
   - The body must earn its tokens. Keep it within 5,000 tokens. Match specificity to fragility,
     preserve reusable exact artifacts, use imperative sentences, and give four or more ordered
     actions a numbered checklist with an observable completion condition. Add an input/output
     example when output shape matters. Address the executing agent directly, refer to the person as
     "the user," and keep evidence-grounded failure-and-remedy lines concise.
   - Do not restate platform-owned scheduler, connector-call, rendering, sandbox, tool, or
     skill-loading mechanics. Keep scope-specific requirements such as recipients, channels,
     thresholds, and sources.
   - Before packaging, inspect and validate the complete candidate tree, including frontmatter,
     referenced paths, bundled resources, and repaired references. Do not validate only the changed
     files.
   ```

   Finish every child objective with the candidate-only boundary:

   ```text
   Write only inside the candidate directory. Do not save, approve, or share the Skill. Do not
   create proposal state or invoke proposal tools. Return the exact candidate path to the parent
   with a concise summary.
   ```

   Never preload `user-skill-improvement`, which belongs exclusively to asynchronous proposal
   workers.

   Wait for the child, then inspect its entire candidate and continue the steps below yourself. The
   shared-workspace directory is only an ephemeral candidate artifact: it is not a saved skill or a
   durable proposal. Whether you author directly or use a child, you remain responsible for the
   final contents, validation, packaging, scope, any required review, and save.

3. **Validate.** Pass the skill *directory* to the validator:

   ```bash
   agentskills validate {skills_dir}/{skill-name}/
   ```

   Fix what it reports before going further.

4. **Review a requested proposal.** Skip this step unless the request is a proposal or review under
   the decision above. Build a complete multi-file unified diff between the pristine original and
   the candidate, covering every added, modified, and removed file. Call `request_user_input` exactly
   once with:

   - `title`: a concise plain-text title naming the skill
   - `body`: Markdown with a one-sentence summary, one to three context bullets, and the
     unified diff in a fenced `diff` block
   - one single-select question asking whether to save, with **Save** and **Keep current skill** as
     the two options

   Stop and wait for the result. A denial, interruption, or ambiguous result means no save: do not
   call `save_custom_skill`. If approved, continue with the candidate unchanged.

5. **Package.** Save a skill as a single `.md` or `.zip`, never a directory path. Use SKILL.md alone
   when there are no bundled resources; otherwise zip the complete candidate directory. Include at
   most 100 files and 20 MiB. For a proposal, package only after approval and preserve the
   exact approved candidate.

6. **For a new skill, ask where it goes.** End the turn with one `request_user_input` call and wait.
   Skip it when the user already chose a destination. Do not ask this for an update; preserve the
   loaded skill's scope.

   - `title`: "Choose where this skill goes"
   - one question, `header`: "Destination", `multi_select: false`
   - options, in order: **Save to My Skills** (personal library, usable in any session) ·
     **Submit to my organization** (teammates can use it) · **Save as a file** (download only,
     nothing saved) · **Keep editing** (keep the draft open)

   Do not add an "Other" option; `request_user_input` adds free text automatically.

7. **Save.**

   Discover and invoke deferred tool `save_custom_skill` with:

   ```json
   {"file_path": "/home/user/workspace/skill.zip"}
   ```

   - **Every existing-skill edit**: invoke `save_custom_skill` exactly once after packaging
     with the

     finalized candidate, `existing_skill_name`, and original loaded scope. A proposal reaches this
     step only after step 4 approval. Omit `review`.
   - **Save a new skill to My Skills**: after the user chooses this destination, call
     `save_custom_skill` with the packaged file and no `review`.
   - **Submit a new skill to my organization**: after the user chooses this destination, call
     `save_custom_skill` with `scope="org"` and no `review`. Org saves are restricted to org skill
     managers, so this can return a permission error. Explain it and let the user choose another
     destination; do not silently save elsewhere.
   - **Save as a file**: `share_file` the packaged file; do not call `save_custom_skill`.
   - **Keep editing**: `share_file` the SKILL.md itself, even for a zipped skill, since a zip cannot
     be read in the conversation. Pass `name` as the skill's name or every draft is titled "SKILL"
     and unrelated skills stack as versions of each other. Then edit, re-validate, and re-share
     under that name. Ask about the destination again only once they say it is done.

8. **Report.** Claim the skill was saved only after `save_custom_skill` confirms success. Report a
   declined proposal or save failure without asking again. The user can manage saved skills at
   https://www.perplexity.ai/computer/skills.

If the user also wants a corrected answer, provide it as well as repairing the skill. Never re-answer
the original question as a substitute for the repair.