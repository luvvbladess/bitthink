
# Import Local Memories

Reads Claude Code / Codex memory, rules, and personal-instruction files on the user's Mac and stores each user-portable preference as a Perplexity memory via `memory_update`. If you can't reach the user's Mac, stop and tell them this only works when Perplexity is connected to a personal computer.

Discovery happens on the user's Mac (via the host-side execution tools); synthesis and `memory_update` calls happen in the sandbox.

Per-project memory under repo roots (`<repo>/CLAUDE.md`, `<repo>/AGENTS.md`, `<repo>/CLAUDE.local.md`) tends to be repo-specific — only scan it if the user explicitly names a project. Re-running creates duplicates; the `memory_update` tool has no dedup, so warn the user before a second run.

## Procedure

Placeholder used below:
- `<workspace_path>` — the `workspace_path` returned by `load_skill` for this skill.

### 1. Discover memory files on the Mac

Copy `<workspace_path>/scripts/memory_discover.sh` to `/tmp/memory_discover.sh` on the Mac. Run it with `--output /tmp/memory_sources.txt`. Then pull `/tmp/memory_sources.txt` into the sandbox at `/home/user/workspace/memory_sources.txt`.

The script scans canonical Claude Code and Codex memory locations (`~/.claude/CLAUDE.md`, `~/.claude/rules/*.md`, `~/.claude/projects/*/memory/*.md`, `~/.codex/AGENTS.md`, `~/.codex/AGENTS.override.md`, `~/.codex/memories/*.md`) and dumps each file as a delimited block:

```
=== <relative path> ===
<file content, truncated at 40KB>
```

### 2. Synthesize candidate entries — filter aggressively

Read `/home/user/workspace/memory_sources.txt` (in the sandbox). If the file is empty, report "No Claude Code or Codex memory found on this Mac" and stop.

For each file block, extract zero or more candidate memory entries. Each candidate must be a single first-person sentence starting with **"Remember that I"** (or its equivalent in the user's language). Match whatever format `memory_update` expects — check its schema if unsure.

**The hard part is filtering.** Claude Code `CLAUDE.md` and Codex `AGENTS.md` files are usually **heavily coding-tool-specific** — build commands, repo CLI wrappers, language idioms, file paths. Importing those wholesale would inject noise into a general-purpose agent.

Keep only **agent-agnostic durable preferences**:
- Communication style: "be concise", "lead with the answer", "no emojis", "don't summarize at the end".
- Working-style preferences: "ask before acting on shared state", "surface tradeoffs", "find new issues on re-review".
- Persistent facts about the user: role, team, expertise level, name.

Drop:
- Tool-specific instructions (specific build commands, internal CLI wrappers, linter rules tied to one codebase).
- File-path or repo-path references.
- Build / linter / testing recipes that only apply inside one codebase.
- One-time instructions — the tool description explicitly rejects these. "Remember that I want this PR rebased onto main" is one-time, not a preference.

A typical Claude auto-memory sidecar (e.g. `feedback_<topic>.md`) yields one entry. A `CLAUDE.md` may yield several entries (one per portable preference section) or zero (if everything is coding-tool-specific).

### 3. Show the user the list, get approval

Render one markdown table grouped by source file. Surface near-duplicates across files so the user can pick one to keep.

```
| # | Source | Candidate memory |
| --- | --- | --- |
| 1 | <source-file-a> | Remember that I ... |
| 2 | <source-file-b> | Remember that I ... |
```

Use a single batched confirmation. With more than 10 candidates, default to import-all with deselect.

### 4. Store each approved entry — fail fast if memory is disabled

Call `memory_update` once per approved entry. If any call surfaces an error indicating memory is disabled or unavailable for the user, **stop the loop immediately**: don't retry, don't attempt subsequent entries. Surface to the user that Perplexity memory is disabled on their account/org, ask them to enable it in Settings, and confirm whether to retry the import.

### 5. Report once at the end

```
| Status | Source | Notes |
| --- | --- | --- |
| `Imported` | <source-file-a> | Stored as Perplexity memory |
| `Skipped` | CLAUDE.md | Coding-tool-specific — no portable preferences extracted |
| `Skipped` | <source-file-b> | One-time instruction, not a long-term preference |
| `Failed` | <source-file-c> | Memory disabled for user — see Settings |
```

Status must be `Imported`, `Skipped`, or `Failed`. Don't add prose before or after the table.