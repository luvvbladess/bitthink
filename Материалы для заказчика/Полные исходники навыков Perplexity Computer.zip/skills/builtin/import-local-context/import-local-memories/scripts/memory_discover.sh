#!/bin/bash
# Discover Claude Code / Codex memory and personal-instruction files on the user's Mac.
#
# Run on the user's Mac via the native device bash tool. Pure bash + macOS built-ins —
# we can't assume what's installed on the user's machine, so no Python
# or other tooling.
#
# Reads from canonical locations only. If the user has overridden Claude's
# autoMemoryDirectory in ~/.claude/settings.json (rare), the override is not
# auto-detected here; the agent can scan that path explicitly if needed.
#
# Output: one delimited block per discovered file, on stdout or to --output PATH:
#
#   === <relative or absolute path> ===
#   <file content, truncated at MAX_BYTES>
#
# Missing files and missing directories are silently skipped. Goes to stdout
# by default; pass `--output PATH` to write to a file instead (preferred —
# avoids the tool response wrapper polluting the output).

set -eo pipefail

MAX_BYTES=40000
OUTPUT=""
if [ "${1:-}" = "--output" ] && [ -n "${2:-}" ]; then
  OUTPUT="$2"
fi

if [ -n "$OUTPUT" ]; then
  : > "$OUTPUT"
fi

emit_header() {
  local header="$1"
  if [ -n "$OUTPUT" ]; then
    printf '%s\n' "$header" >> "$OUTPUT"
  else
    printf '%s\n' "$header"
  fi
}

emit_file() {
  local path="$1"
  [ -f "$path" ] || return 0
  local rel
  if [[ "$path" == "$HOME"* ]]; then
    rel="~${path#"$HOME"}"
  else
    rel="$path"
  fi
  emit_header "=== $rel ==="
  if [ -n "$OUTPUT" ]; then
    head -c "$MAX_BYTES" "$path" >> "$OUTPUT" 2>/dev/null || true
    printf '\n' >> "$OUTPUT"
  else
    head -c "$MAX_BYTES" "$path" 2>/dev/null || true
    printf '\n'
  fi
}

# Claude Code global user instructions.
emit_file "$HOME/.claude/CLAUDE.md"

# Claude Code personal rules.
if [ -d "$HOME/.claude/rules" ]; then
  for f in "$HOME"/.claude/rules/*.md; do
    emit_file "$f"
  done
fi

# Claude Code per-project auto-memory.
if [ -d "$HOME/.claude/projects" ]; then
  for memdir in "$HOME"/.claude/projects/*/memory; do
    [ -d "$memdir" ] || continue
    for f in "$memdir"/*.md; do
      emit_file "$f"
    done
  done
fi

# Codex global instructions (override takes precedence; emit both if present).
emit_file "$HOME/.codex/AGENTS.override.md"
emit_file "$HOME/.codex/AGENTS.md"

# Codex auto-memory.
if [ -d "$HOME/.codex/memories" ]; then
  for f in "$HOME"/.codex/memories/*.md; do
    emit_file "$f"
  done
fi
