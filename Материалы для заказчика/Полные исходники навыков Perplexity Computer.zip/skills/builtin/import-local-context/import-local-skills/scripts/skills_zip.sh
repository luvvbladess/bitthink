#!/bin/bash
# Zip one or more Agent Skill directories on the user's Mac.
#
# Run on the user's Mac via the native device bash tool. Pure bash + the system `zip` —
# we can't assume what's installed on the user's machine, so no Python
# or other tooling.
#
# Each argument is the absolute path to a skill directory (the directory
# that contains SKILL.md). The skill folder is placed at the zip root,
# matching what save_custom_skill expects.
#
# Output directory: /tmp/perplexity-skill-imports/ (wiped and recreated when
# there are args to process — pull zips into the sandbox before starting a
# second batch).
# Zip names:        /tmp/perplexity-skill-imports/<dirname>.zip
#
# Excludes from the archive: .git, __pycache__, node_modules, .venv,
# .DS_Store, and *.pyc.
#
# Output: one TSV row per argument, in input order:
#   <skill_dir>\t<zip_path>\t<status>
# Status is "ok" or an error string like "missing_dir" or "zip_failed".
# Goes to stdout by default; pass `--output PATH` to write to a file instead
# (preferred — avoids the tool response wrapper polluting the TSV).

set -eo pipefail

OUTDIR="/tmp/perplexity-skill-imports"

OUTPUT=""
ARGS=()
while [ $# -gt 0 ]; do
  case "$1" in
    --output)
      OUTPUT="$2"
      shift 2
      ;;
    *)
      ARGS+=("$1")
      shift
      ;;
  esac
done

emit() {
  if [ -n "$OUTPUT" ]; then
    printf '%s\n' "$1" >> "$OUTPUT"
  else
    printf '%s\n' "$1"
  fi
}

# bash 3.2 (default macOS) errors on `"${ARGS[@]}"` when ARGS is empty under
# set -u, so we don't use -u and we guard with ${#ARGS[@]} below.
if [ ${#ARGS[@]} -eq 0 ]; then
  exit 0
fi

# Reset state only when there's real work to do, so an accidental no-arg
# invocation doesn't wipe the previous batch's zips or TSV.
rm -rf "$OUTDIR"
mkdir -p "$OUTDIR"
if [ -n "$OUTPUT" ]; then
  : > "$OUTPUT"
fi

for skill_dir in "${ARGS[@]}"; do
  if [ ! -d "$skill_dir" ]; then
    emit "$(printf '%s\t%s\t%s' "$skill_dir" "" "missing_dir")"
    continue
  fi
  name=$(basename "$skill_dir")
  parent=$(dirname "$skill_dir")
  zip_path="$OUTDIR/$name.zip"

  if [ -e "$zip_path" ]; then
    emit "$(printf '%s\t%s\t%s' "$skill_dir" "$zip_path" "duplicate_filename")"
    continue
  fi

  if (cd "$parent" && zip -rq "$zip_path" "$name" \
      -x "$name/.git/*" \
      -x "$name/**/.git/*" \
      -x "$name/__pycache__/*" \
      -x "$name/**/__pycache__/*" \
      -x "$name/node_modules/*" \
      -x "$name/**/node_modules/*" \
      -x "$name/.venv/*" \
      -x "$name/**/.venv/*" \
      -x "$name/.DS_Store" \
      -x "$name/**/.DS_Store" \
      -x "$name/*.pyc" \
      -x "$name/**/*.pyc") >/dev/null 2>&1; then
    emit "$(printf '%s\t%s\t%s' "$skill_dir" "$zip_path" "ok")"
  else
    emit "$(printf '%s\t%s\t%s' "$skill_dir" "$zip_path" "zip_failed")"
  fi
done
