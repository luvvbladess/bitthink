#!/bin/bash
# Discover Agent Skills under canonical macOS roots.
#
# Run on the user's Mac via the native device bash tool. Pure bash + POSIX utilities —
# we can't assume what's installed on the user's machine, so no Python
# or other tooling.
#
# Output: TSV on stdout (or to --output PATH), one row per candidate:
#   <kind>\t<root>\t<name>\t<skill_md_path>\t<duplicate>
# Fields:
#   kind:          "user" or "plugin"
#   root:          source skills root the candidate lives under
#   name:          directory leaf (the skill's name on disk)
#   skill_md_path: absolute path to the candidate's SKILL.md
#   duplicate:     "yes" if another candidate already claimed this name in this scan,
#                  "no" otherwise. Duplicate detection uses the directory leaf
#                  as the de facto name (we don't parse SKILL.md here). For
#                  spec-compliant skills, frontmatter `name` equals leaf, so
#                  the two are identical; the sandbox validator catches any
#                  mismatch as a hard failure.

set -uo pipefail

OUTPUT=""
if [ "${1:-}" = "--output" ] && [ -n "${2:-}" ]; then
  OUTPUT="$2"
fi

emit() {
  if [ -n "$OUTPUT" ]; then
    printf '%s\n' "$1" >> "$OUTPUT"
  else
    printf '%s\n' "$1"
  fi
}

if [ -n "$OUTPUT" ]; then
  : > "$OUTPUT"
fi

seen_names=""

scan_root() {
  local kind="$1"
  local root="$2"
  [ -d "$root" ] || return 0
  for dir in "$root"/*/; do
    [ -d "$dir" ] || continue
    local name
    name=$(basename "$dir")
    [ "$name" = ".system" ] && continue
    local skill_md="${dir}SKILL.md"
    [ -f "$skill_md" ] || continue

    local duplicate="no"
    case " $seen_names " in
      *" $name "*) duplicate="yes" ;;
      *) seen_names="$seen_names $name" ;;
    esac

    emit "$(printf '%s\t%s\t%s\t%s\t%s' "$kind" "$root" "$name" "$skill_md" "$duplicate")"
  done
}

scan_root user "$HOME/.claude/skills"
scan_root user "$HOME/.codex/skills"
scan_root user "$HOME/.agents/skills"

for pat in \
  "$HOME"/.claude/plugins/marketplaces/*/plugins/*/skills \
  "$HOME"/.claude/plugins/marketplaces/*/external_plugins/*/skills; do
  scan_root plugin "$pat"
done
