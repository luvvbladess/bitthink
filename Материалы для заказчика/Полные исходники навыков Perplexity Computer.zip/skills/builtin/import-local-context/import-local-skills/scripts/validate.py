#!/usr/bin/env python3
"""Validate a single Agent Skill zip before upload.

Runs the same checks as the server, so a zip that passes here will
pass on the server side. Catches issues locally instead of round-tripping.

Why not use `agentskills validate` with official library?
    The official validator enforces a strict top-level frontmatter allowlist
    that rejects fields used in real-world skills (notably top-level `version`,
    `tools`, `user-invocable`, `argument-hint`). Anthropic's own Claude Code
    plugin marketplace ships skills that violate these rules, so we need a custom validator.
    Tracking issue: https://github.com/anthropics/claude-code/issues/25380

Usage:
    python3 validate.py <zip_path>

Stdout (single line of JSON):
    {"valid": true,  "name": "<name>"}
    {"valid": false, "name": "<name>", "reason": "<failure description>"}
"""

from __future__ import annotations

import json
import re
import sys
import zipfile
from pathlib import Path

import yaml

# Match server-enforced limits on uploaded skills.
NAME_RE = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)*$")
MAX_NAME_CHARS = 64
MAX_DESCRIPTION_CHARS = 1024
MAX_ZIP_FILE_COUNT = 100
MAX_UNCOMPRESSED_BYTES = 20 * 1024 * 1024  # 20 MiB


def parse_frontmatter(
    skill_md_text: str,
) -> tuple[dict[str, object] | None, str | None]:
    text = skill_md_text.replace("\r\n", "\n")
    if not text.startswith("---"):
        return None, "SKILL.md missing YAML frontmatter (no leading ---)"
    end = text.find("\n---", 3)
    if end == -1:
        return None, "SKILL.md missing YAML frontmatter terminator"
    body = text[3:end].lstrip("\n")
    try:
        data = yaml.safe_load(body)
    except yaml.YAMLError as e:
        return None, f"invalid YAML in frontmatter: {e}"
    if not isinstance(data, dict):
        return None, "frontmatter is not a mapping"
    return data, None


def validate_frontmatter(fm: dict[str, object]) -> tuple[str | None, str | None]:
    """Return (name, reason). On failure name may be None or partially recovered."""
    name = fm.get("name")
    if not isinstance(name, str) or not name.strip():
        return None, "frontmatter missing `name`"
    name = name.strip()
    if len(name) > MAX_NAME_CHARS:
        return name, f"name {name!r} exceeds {MAX_NAME_CHARS} chars"
    if not NAME_RE.match(name):
        return (
            name,
            f"name {name!r} fails [a-z0-9-] rule (no leading/trailing/consecutive hyphens)",
        )

    description = fm.get("description")
    if not isinstance(description, str) or not description.strip():
        return name, "frontmatter missing `description`"
    if len(description.strip()) > MAX_DESCRIPTION_CHARS:
        return (
            name,
            f"description is {len(description.strip())} chars, exceeds {MAX_DESCRIPTION_CHARS}",
        )

    return name, None


def validate_zip_shape(zf: zipfile.ZipFile) -> str | None:
    """Server-enforced zip resource limits."""
    if len(zf.infolist()) > MAX_ZIP_FILE_COUNT:
        return f"zip contains {len(zf.infolist())} files, exceeds {MAX_ZIP_FILE_COUNT}"
    total = 0
    for info in zf.infolist():
        if info.file_size > MAX_UNCOMPRESSED_BYTES:
            return f"single file {info.filename!r} uncompressed size exceeds limit"
        total += info.file_size
        if total > MAX_UNCOMPRESSED_BYTES:
            return f"zip total uncompressed size exceeds {MAX_UNCOMPRESSED_BYTES} bytes"
    return None


def find_skill_md(zf: zipfile.ZipFile) -> str | None:
    """Locate SKILL.md inside the zip, case-insensitive (matches server)."""
    for info in zf.infolist():
        if Path(info.filename).name.upper() == "SKILL.MD":
            return info.filename
    return None


def emit(result: dict[str, object]) -> None:
    print(json.dumps(result))


def main() -> int:
    if len(sys.argv) != 2:
        emit({"valid": False, "name": "", "reason": "usage: validate.py <zip_path>"})
        return 2

    zip_path = Path(sys.argv[1])
    if not zip_path.is_file():
        emit({"valid": False, "name": "", "reason": f"zip not found: {zip_path}"})
        return 1

    if zip_path.stat().st_size > MAX_UNCOMPRESSED_BYTES:
        emit({"valid": False, "name": "", "reason": "zip exceeds upload size limit"})
        return 1

    try:
        zf = zipfile.ZipFile(zip_path)
    except zipfile.BadZipFile as e:
        emit({"valid": False, "name": "", "reason": f"bad zip: {e}"})
        return 1

    with zf:
        shape_err = validate_zip_shape(zf)
        if shape_err:
            emit({"valid": False, "name": "", "reason": shape_err})
            return 1

        skill_md_path = find_skill_md(zf)
        if skill_md_path is None:
            emit({"valid": False, "name": "", "reason": "SKILL.md not found in zip"})
            return 1

        try:
            skill_md_text = zf.read(skill_md_path).decode("utf-8")
        except (UnicodeDecodeError, KeyError) as e:
            emit(
                {"valid": False, "name": "", "reason": f"could not read SKILL.md: {e}"}
            )
            return 1

    fm, parse_err = parse_frontmatter(skill_md_text)
    if fm is None:
        emit({"valid": False, "name": "", "reason": parse_err})
        return 1

    name, validate_err = validate_frontmatter(fm)
    result: dict[str, object] = {"valid": validate_err is None, "name": name or ""}
    if validate_err is not None:
        result["reason"] = validate_err
    emit(result)
    return 0 if validate_err is None else 1


if __name__ == "__main__":
    sys.exit(main())
