# Import Local Skills

Operates on the user's Mac, not the sandbox — host-side commands are required to read their local files. If you can't reach the user's Mac, stop and tell them this only works when Perplexity is connected to a personal computer.

Discovery and zipping happen on the user's Mac (via the host-side execution tools). Validation and upload happen in the sandbox.

## Where to look

Only scan the four user-level roots below by default. If the user explicitly asks for project skills, also look for `.claude/skills/` or `.agents/skills/` under their project directories — but never blanket-scan `~/`.

- `~/.claude/skills/` — Claude Code personal skills
- `~/.claude/plugins/marketplaces/*/plugins/*/skills/` and `~/.claude/plugins/marketplaces/*/external_plugins/*/skills/` — Claude Code plugin-bundled
- `~/.codex/skills/` — Codex (older path)
- `~/.agents/skills/` — Codex (current docs)

## Procedure

The skill ships three helpers under `scripts/`: two bash scripts that run on the user's Mac (pure bash + macOS built-ins), and one Python script that runs in the sandbox.

Placeholders used below:
- `<workspace_path>` — the `workspace_path` returned by `load_skill` for this skill.
- `<name>` — the skill's directory leaf, taken from the discover TSV's `name` column.

### 1. Discover candidates on the Mac

Copy both helpers to the Mac up front (parallel tool calls): `<workspace_path>/scripts/skills_discover.sh` to `/tmp/skills_discover.sh`, and `<workspace_path>/scripts/skills_zip.sh` to `/tmp/skills_zip.sh`. Run `skills_discover.sh` with `--output /tmp/skill_candidates.tsv`. Then pull `/tmp/skill_candidates.tsv` into the sandbox at `/home/user/workspace/skill_candidates.tsv`.

The TSV is **headerless** — every line is a data row. Tab-separated fields in order:
1. `kind` — `"user"` or `"plugin"`
2. `root` — the skills root the candidate lives under
3. `name` — the skill's directory leaf
4. `skill_md_path` — absolute path to its SKILL.md on the Mac
5. `duplicate` — `"yes"` if another candidate in this scan already claimed this name, `"no"` otherwise

Files under `~/.claude/commands/*.md` are single-file slash commands, not skill directories — don't try to import them as skills if the user mentions them.

### 2. Show the user the list, get approval

Read the TSV in the sandbox. Group rows by `kind` and source `root`. Mark rows with `duplicate: yes` so the user knows only one of each name can be imported. Use one batched confirmation; don't prompt per skill.

Different plugins sometimes ship skills with identical leaf names — don't auto-pick a winner. They're not interchangeable. Group those rows by `name`, show each candidate's `root`, and ask the user which to import (or skip the whole name).

### 3. Zip only the approved skills on the Mac

Run the zip helper with the absolute skill directory paths the user approved: `bash /tmp/skills_zip.sh --output /tmp/zip_results.tsv <skill_dir_1> <skill_dir_2> ...` on the Mac. Then pull `/tmp/zip_results.tsv` into the sandbox at `/home/user/workspace/zip_results.tsv`.

Each `skill_dir` is the `dirname` of the `skill_md_path` from the **discover** TSV (step 1). The zip output TSV has three columns: `skill_dir`, `zip_path`, `status` (`ok`, `missing_dir`, `zip_failed`, `duplicate_filename`). `duplicate_filename` means a prior argument already claimed `<name>.zip` — same root cause as the discover-step `duplicate: yes` flag, just hit at zip time if multiple duplicates were approved. Inspect the status before pulling each zip.

### 4. Pull approved zips into the sandbox

Don't pull each zip individually — in a shell loop, only the first file transfers. Instead, tar the whole batch on the Mac and pull once.

On the Mac, run `COPYFILE_DISABLE=1 tar -czf /tmp/perplexity-skill-imports.tar.gz -C /tmp perplexity-skill-imports`, then pull `/tmp/perplexity-skill-imports.tar.gz` into the sandbox at `/home/user/workspace/perplexity-skill-imports.tar.gz`. Unpack in the sandbox:

```
rm -rf /home/user/workspace/skill-imports && mkdir -p /home/user/workspace/skill-imports
tar -xzf /home/user/workspace/perplexity-skill-imports.tar.gz -C /home/user/workspace/skill-imports --strip-components=1
```

Surface any non-`ok` statuses from step 3's TSV in the final report.

### 5. Validate each zip in the sandbox

```
python3 <workspace_path>/scripts/validate.py /home/user/workspace/skill-imports/<name>.zip
```

Stdout is one JSON line: `{"valid": bool, "name": "<name>", "reason": "<msg if invalid>"}`. Exit code is 0 for valid, 1 for invalid. Skip skills that fail validation and surface the reason in the final report.

The validator's `name` is the skill's frontmatter name and may differ from the zip filename. Use the validated `name` (not the zip filename) for reporting and for `existing_skill_name` in step 6.

### 6. Upload valid skills

Run this step on the main agent — `save_custom_skill` fails if delegated to a subagent.


Discover and invoke deferred tool `save_custom_skill` with:

```json
{"file_path": "/home/user/workspace/skill-imports/<name>.zip"}
```


Omit `existing_skill_name` on first import. If the server rejects with a duplicate-name error (the user's library already contains this skill — distinct from step 2's scan-time duplicates), ask whether to overwrite. If the user agrees, load the existing personal skill with `load_skill(name="user:<name>")` to preserve its identity and version, then make one save call with `existing_skill_name` set to the validated name from step 5. Do not ask again:


```json
{
  "file_path": "/home/user/workspace/skill-imports/<name>.zip",
  "existing_skill_name": "<name>"
}
```


### 7. Report once at the end

Imported, skipped (with reason), unresolved duplicates.