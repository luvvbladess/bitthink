
# Import Local Connectors

Reads the user's MCP server config from Claude Code / Codex on their Mac, matches each server to a Perplexity connector by name, and offers to drive the connect flow for unconnected matches. If you can't reach the user's Mac, stop and tell them this only works when Perplexity is connected to a personal computer.

This skill does not transfer credentials. It surfaces which Perplexity connectors overlap with the user's MCP setup by name, then kicks off the standard Perplexity OAuth flow per service. Project-level MCP configs (`<repo>/.mcp.json`, `<repo>/.codex/config.toml`) describe project-specific tools — only scan those if the user names a project.


Discovery happens on the user's Mac (via the host-side execution tools); matching and `connect` flows happen in the sandbox.


## Procedure

Placeholder used below:
- `<workspace_path>` — the `workspace_path` returned by `load_skill` for this skill.

### 1. Discover MCP server names on the Mac

Copy `<workspace_path>/scripts/connector_discover.sh` to `/tmp/connector_discover.sh` on the Mac. Run it with `--output /tmp/connector_servers.tsv`. Then pull `/tmp/connector_servers.tsv` into the sandbox at `/home/user/workspace/connector_servers.tsv`.

The script reads `~/.claude.json` (user-scope `mcpServers` only) and `~/.codex/config.toml` (`[mcp_servers.*]` sections), extracts server names, and emits a headerless TSV:

```
<name>\t<sources>
```

Where `sources` is comma-separated: `claude`, `codex`, or `claude,codex` if the server is configured in both. Endpoint URLs and server types are intentionally not extracted — Perplexity matches by name, and local config details don't matter downstream.

### 2. Match each server to a Perplexity connector

Read `/home/user/workspace/connector_servers.tsv` (in the sandbox). If the file is empty, report "No MCP servers found in Claude Code or Codex config on this Mac" and stop.


Call `list_external_tools` once to fetch the full Perplexity connector catalog, which returns each entry's name, description, and connection status. For each local server, check for a matching catalog entry by using the local server name together with what you already know about well-known products (e.g. a server named `notion` corresponds to the Notion connector in the catalog). If no catalog entry matches the local server's underlying service, classify it as `No equivalent` and move on. If a local server name is opaque or could plausibly map to more than one catalog entry, suggest the most likely match and confirm with the user before proceeding.


Classify each row:
- **Mappable, not connected** — Perplexity has the connector but the user hasn't authorized it.
- **Mappable, already connected** — connector exists and is authorized.
- **Mappable, auth expired or needs re-auth** — connector exists but the existing authorization is stale.
- **No equivalent** — no matching connector in Perplexity's catalog.

### 3. Show the report, get approval

Render one markdown table grouped by classification, ordered with actionable rows first.

```
| Status | Server | Perplexity connector |
| --- | --- | --- |
| `Connect?` | <server-a> | <connector-a> |
| `Reconnect?` | <server-b> | <connector-b> |
| `Already connected` | <server-c> | <connector-c> |
| `No equivalent` | <server-d> | — |
```

Use a single batched confirmation: ask which `Connect?` and `Reconnect?` rows to act on.

### 4. Drive the connect flow per approved row


For each approved row, invoke `call_external_tool` targeting the matched connector's `connect` action after checking its schema. The tool handles the OAuth flow.


### 5. Report once at the end

```
| Status | Server | Notes |
| --- | --- | --- |
| `Connected` | <server-a> | Connected via Perplexity OAuth |
| `Already connected` | <server-b> | No action taken |
| `Auth pending` | <server-c> | Auth link shown; user hasn't completed flow yet |
| `Auth declined` | <server-d> | User cancelled OAuth flow |
| `No equivalent` | <server-e> | No matching Perplexity connector |
```

Status must be `Connected`, `Already connected`, `Auth pending`, `Auth declined`, or `No equivalent`. Don't add prose before or after the table.