#!/bin/bash
# Discover MCP server names from Claude Code / Codex on the user's Mac.
#
# Run on the user's Mac via the native device bash tool. Pure bash + macOS built-ins —
# we can't assume what's installed on the user's machine, so no Python
# or other tooling.
#
# Reads:
#   - ~/.claude.json (top-level `mcpServers` field — user scope; project-scope
#     entries nested under `projects.<path>.mcpServers` are skipped by design,
#     since they're tied to specific repos)
#   - ~/.codex/config.toml ([mcp_servers.<name>] sections)
#
# Output: TSV on stdout or to --output PATH. Headerless. Fields per row:
#   <name>\t<sources>
# Where:
#   name:    server name (e.g. "notion", "figma", "linear")
#   sources: comma-separated source attribution ("claude", "codex", or "claude,codex")
#
# Names appearing in both configs are merged. Endpoint URLs and server types
# (http/stdio) are intentionally not extracted — Perplexity matches by name,
# and local config details aren't needed downstream.
#
# Goes to stdout by default; pass `--output PATH` to write to a file
# (preferred — avoids the tool response wrapper polluting the TSV).

set -eo pipefail

OUTPUT=""
if [ "${1:-}" = "--output" ] && [ -n "${2:-}" ]; then
  OUTPUT="$2"
fi

if [ -n "$OUTPUT" ]; then
  : > "$OUTPUT"
fi

# Extract user-scope mcpServers keys from ~/.claude.json. The file is written
# by Claude Code with two-space indentation; the top-level `mcpServers` object
# is anchored at column 0+2. Nested project-scope `mcpServers` lives under
# `projects.<path>.mcpServers` and is indented deeper, so it's skipped by the
# regex anchor below.
claude_names=""
if [ -f "$HOME/.claude.json" ]; then
  claude_names=$(awk '
    # Match only the top-level mcpServers (exactly two leading spaces).
    /^  "mcpServers"[[:space:]]*:[[:space:]]*\{/ {
      in_block = 1
      depth = 1
      sub(/.*"mcpServers"[[:space:]]*:[[:space:]]*\{/, "")
    }
    in_block {
      line = $0
      n_open = gsub(/\{/, "{", line)
      n_close = gsub(/\}/, "}", line)
      if (depth == 1) {
        # Extract server names at the immediate level.
        while (match($0, /"[^"]+"[[:space:]]*:[[:space:]]*\{/)) {
          key = substr($0, RSTART + 1, RLENGTH - 1)
          sub(/".*/, "", key)
          print key
          $0 = substr($0, RSTART + RLENGTH)
        }
      }
      depth += n_open - n_close
      if (depth <= 0) exit
    }
  ' "$HOME/.claude.json" 2>/dev/null || true)
fi

# Extract Codex top-level [mcp_servers.<name>] headers. Disallow dots in
# the captured key so sub-table headers like [mcp_servers.foo.env]
# (valid TOML for nested config such as env-var maps) don't leak through
# as spurious server names.
codex_names=""
if [ -f "$HOME/.codex/config.toml" ]; then
  codex_names=$(grep -E '^\[mcp_servers\.[A-Za-z0-9_-]+\][[:space:]]*$' "$HOME/.codex/config.toml" 2>/dev/null \
    | sed -E 's/^\[mcp_servers\.//; s/\][[:space:]]*$//' \
    || true)
fi

emit() {
  if [ -n "$OUTPUT" ]; then
    printf '%s\n' "$1" >> "$OUTPUT"
  else
    printf '%s\n' "$1"
  fi
}

# Combine and dedupe with source attribution.
combined=$(
  if [ -n "$claude_names" ]; then printf '%s\n' "$claude_names" | awk '{print $0 "\tclaude"}'; fi
  if [ -n "$codex_names" ]; then printf '%s\n' "$codex_names" | awk '{print $0 "\tcodex"}'; fi
)

[ -z "$combined" ] && exit 0

printf '%s\n' "$combined" \
  | awk -F'\t' '
    {
      if (!($1 in seen)) {
        order[++n] = $1
        seen[$1] = $2
      } else if (index(seen[$1], $2) == 0) {
        seen[$1] = seen[$1] "," $2
      }
    }
    END {
      for (i = 1; i <= n; i++) {
        print order[i] "\t" seen[order[i]]
      }
    }
  ' \
  | while IFS= read -r line; do
      emit "$line"
    done
