# Import Local Context

## Bootstrap

Requires a Mac listed in the `<devices>` block of the user-context message. If no Mac is listed (or the block is absent), stop and tell the user this only works when Perplexity is connected to a personal computer. Do not load any guide.

## Guides

- `skills/import-local-context/import-local-skills/GUIDE.md` — Read when the user wants to import or migrate Agent Skills from their Mac into Perplexity.
- `skills/import-local-context/import-local-memories/GUIDE.md` — Read when the user wants to import or migrate Claude Code or Codex memories, rules, or personal instructions.
- `skills/import-local-context/import-local-connectors/GUIDE.md` — Read when the user wants to set up Perplexity connectors matching MCP servers they already use.

If the user asks for several at once, run the guides in sequence (one tool, one approval batch per guide).

Read the matching guide at `skills/import-local-context/<guide-name>/GUIDE.md`.