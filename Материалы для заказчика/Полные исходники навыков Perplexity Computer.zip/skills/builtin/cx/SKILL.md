# Customer Support Skills

These skills are for customer-support (CX), helpdesk, or support-team workflows serving external customers or users. Do not use them for personal email triage, PM or engineering bug triage, generic email replies, IT-ticket spreadsheets, or non-CX SOP/playbook work.

- `skills/cx/customer-research/GUIDE.md` — Research an external-customer question or account context for a support issue: synthesize a confidence-scored answer from docs, KBs, CRM records, tickets, or internal sources before replying. Not for generic market/customer research, sales prospecting, or non-CX research.
- `skills/cx/escalation/GUIDE.md` — Decide whether to escalate an external-customer support issue and package context for engineering, product, security, or leadership. Not for generic workplace escalations, non-CX incident reports, or SOP/playbook authoring.
- `skills/cx/knowledge-management/GUIDE.md` — Create, update, or audit customer-support KB or help-center content from resolved external-customer issues (support articles, troubleshooting docs, known issues, FAQs). Not for generic SOP/playbook authoring, engineering runbooks, or docs outside a CX team.
- `skills/cx/response-drafting/GUIDE.md` — Draft a support-team communication to an external customer about a ticket, escalation, outage, bug report, feature request, or billing/account issue. Not for personal email replies, complaint letters, or marketing/sales emails.
- `skills/cx/ticket-triage/GUIDE.md` — Categorize, prioritize, assess severity/SLA, detect duplicates, or route external-customer support tickets. Not for personal inbox triage, PM or engineering bug triage, or generic issue trackers.

Read the matching guide at `skills/cx/<guide-name>/GUIDE.md`.