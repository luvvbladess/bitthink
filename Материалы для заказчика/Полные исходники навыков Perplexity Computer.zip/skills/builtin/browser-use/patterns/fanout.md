# Fan-Out Across Sites

For "visit N sites and collect the same fields from each", delegate one subagent
per site rather than driving them yourself. Each child gets its own browser and its
own context, so page content never enters yours.

## Preload the browser skill

Any subagent that can load this skill can browse. Spawn:

```python
run_subagent(
    task_name="Collect from acme.com",
    preload_skills=["browser-use"],
    model="gpt_5_6_terra",
    reasoning_effort="low",
    objective="…",  # see the briefing checklist below
)
```

`preload_skills=["browser-use"]` is required — without it the child has `browser_exec`
but no idea how to drive it.

`model` and `reasoning_effort` are required for the same reason as any other browser
delegation: omitted, each child runs at its own reasoning-heavy default, and fan-out
multiplies that across every site.

## Brief each child with

1. The exact fields to collect, as a JSON object shape.
2. Where to write: `$RD/browse/<slug>.jsonl`, one JSON object per line.
3. What to return: `{"path": ..., "rows": <count>, "status": "ok"|"partial"}` and
   nothing else — no page content, no commentary.
4. What to do on failure: write what it got, report `"partial"` with the reason. A
   child that fails must not take the batch with it.

Parent and children share the sandbox workspace, so you read the files directly and
the completion notification stays a few tokens instead of a page of prose.

## Merging

Run the merge script through `bash` — `pplx_sdk` credentials attach
automatically:

```python
bash(
    command="python3 $RD/scripts/merge.py",
)
```

```python
# $RD/scripts/merge.py
import pplx_sdk
rows = [r for p in PATHS for r in pplx_sdk.utils.read_jsonl(p)]
pplx_sdk.utils.write_jsonl(OUT, pplx_sdk.utils.dedup_by_url(rows))
```

## Sizing

- **Cloud: at most 8 at once.** Every browser is a billed pod. More sites than
  that, run in waves.
- **Local: each child connects directly.** Each child calls
  `start_browser("local")` for its own connection to the user's browser and its
  own tabs. Several can work there at once; no parent approval call is needed.
- **Two or three local children, not eight.** They share one window: every focus
  change is visible to the user, and they are all in the same logged-in session, so
  one child logging out or switching account context affects the others. Give each a
  different site.
- **Children cannot confirm.** No `request_user_input`. Brief them
  to read, navigate and extract only, and to report anything that needs a purchase,
  send, submit, download or sign-in back to you.
- Past ~20 sites, ask whether the browser is the right tool at all: try
  `pplx_sdk.search.web(..., domains=[host])` plus
  `pplx_sdk.content.fetch(urls, prompt="...")` first (via `bash`; load the
  `search` skill for the full guide). It is far cheaper and needs no browser.

## When to keep it yourself

One or two sites, or when deciding what to collect depends on what the previous
page showed. Delegation costs a round trip and loses your context — don't pay it to
save two browser_exec calls.
