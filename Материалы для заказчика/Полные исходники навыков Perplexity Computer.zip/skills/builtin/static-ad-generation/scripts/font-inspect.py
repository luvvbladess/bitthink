"""Inspect per-run font bytes, reading coverage text from stdin."""

import argparse
import hashlib
import json
import sys
from pathlib import Path

from fontTools.ttLib import TTFont


def inspect_font(filename, weight, style, family=None, text=""):
    file = Path(filename).resolve(strict=True)
    root = Path(__file__).resolve().parents[1]
    if file == root or root in file.parents:
        raise ValueError("FONT_MUST_STAY_OUTSIDE_SKILL")
    with TTFont(file) as font:
        names = font["name"]
        actual_family = names.getBestFamilyName()
        postscript = names.getDebugName(6)
        actual_weight = font["OS/2"].usWeightClass
        axes = (
            {
                a.axisTag: [a.minValue, a.defaultValue, a.maxValue]
                for a in font["fvar"].axes
            }
            if "fvar" in font
            else {}
        )
        actual_style = (
            "italic"
            if font["OS/2"].fsSelection & 1 or font["head"].macStyle & 2
            else "normal"
        )
        if family is not None and family != actual_family:
            raise ValueError("FONT_FAMILY_MISMATCH")
        lo, _, hi = axes.get("wght", [actual_weight] * 3)
        if not lo <= weight <= hi:
            raise ValueError("FONT_WEIGHT_MISMATCH")
        if style != actual_style:
            raise ValueError(
                "FONT_STYLE_MISMATCH: use a matching face/instance, not synthetic style"
            )
        missing = sorted(
            set(text) - set(map(chr, font.getBestCmap())) - {"\n", "\r", "\t"}
        )
        if missing:
            raise ValueError(
                f"FONT_MISSING_GLYPHS: {len(missing)} unsupported characters"
            )
        return {
            "sha256": hashlib.sha256(file.read_bytes()).hexdigest(),
            "family": actual_family,
            "postScriptName": postscript,
            "intrinsicWeight": actual_weight,
            "selectedWeight": weight,
            "style": actual_style,
            "axes": axes,
            "limits": "Byte metadata/coverage only; corroborate official ad use and actual rendered lettering.",
        }


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("font")
    p.add_argument("--weight", type=int, required=True, choices=range(100, 901))
    p.add_argument("--style", choices=["normal", "italic"], required=True)
    p.add_argument("--family")
    a = p.parse_args()
    print(
        json.dumps(
            inspect_font(a.font, a.weight, a.style, a.family, sys.stdin.read()),
            indent=2,
        )
    )
