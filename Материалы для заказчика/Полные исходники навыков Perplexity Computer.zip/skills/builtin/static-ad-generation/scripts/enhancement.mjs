// Bounded OPTIONAL rough-selection ledger. Core final image QA is in final-review.mjs, never budget-deferred.
import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { validateCommunication, validatePacketEvidence, validateGroups, validateRunIdentity } from './concept-contract.mjs';
import {canonicalJSON,loadJSON as load,sameJSON,saveJSON as save,sha} from './runtime.mjs';

const check = (ok, message) => { if (!ok) throw Error(message); };
const text = x => typeof x === 'string' && !!x.trim();
const list = x => Array.isArray(x);
const hashOK = x => typeof x === 'string' && /^[a-f0-9]{64}$/.test(x);
const kinds = ['strategy', 'inputs', 'review', 'records'];
export const briefFields = ['buyer', 'buyingMoment', 'desiredOutcome', 'alternativeOrObjection',
  'differentiatedPromise', 'proofAsset', 'offer', 'destination'];

export function time(value) {
  check(typeof value === 'string' && /^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/.test(value) &&
    Number.isFinite(Date.parse(value)) && new Date(value).toISOString() === value, 'INVALID_TIME');
  return Date.parse(value);
}
export function newBudget(options = {}) {
  const { limitSeconds = 180, reviewReserveSeconds = 60, overrideReason = null } = options;
  check(Number.isFinite(limitSeconds) && limitSeconds >= 0 &&
    Number.isFinite(reviewReserveSeconds) && reviewReserveSeconds >= 0 &&
    reviewReserveSeconds <= limitSeconds, 'INVALID_BUDGET');
  check((limitSeconds === 180 && reviewReserveSeconds === 60) || text(overrideReason), 'BUDGET_OVERRIDE_AUTHORITY');
  return { schemaVersion: 1, limitSeconds, reviewReserveSeconds, overrideReason,
    blocks: [], deferrals: [], reviewDisposition: 'pending', lastEventAt: null };
}
export function budgetSummary(b, now = new Date().toISOString()) {
  newBudget(b); // Check recorded limits as well as newly constructed ones.
  const at = time(now);
  check(b.schemaVersion === 1 && list(b.blocks) && list(b.deferrals), 'BUDGET_LEDGER');
  check(['pending', 'attempted', 'deferred', 'unavailable'].includes(b.reviewDisposition), 'REVIEW_DISPOSITION');
  if (b.lastEventAt) check(at >= time(b.lastEventAt), 'CLOCK_REVERSED');
  let used = 0, previous = -Infinity, active = null, reviews = 0;
  const ids = new Set();
  for (const [i, block] of b.blocks.entries()) {
    check(text(block.id) && !ids.has(block.id) && kinds.includes(block.kind), 'BLOCK_ID_OR_KIND');
    ids.add(block.id);
    check(Number.isFinite(block.admissionSeconds) && block.admissionSeconds > 0, 'ADMISSION_SECONDS');
    const start = time(block.startedAt), end = block.endedAt === null ? at : time(block.endedAt);
    check(start >= previous && end >= start && end <= at, 'BLOCK_TIME_ORDER');
    check(!b.lastEventAt || time(b.lastEventAt) >= start, 'LEDGER_EVENT_TIME');
    if (block.kind === 'review') reviews++;
    if (block.endedAt === null) {
      check(i === b.blocks.length - 1 && block.elapsedSeconds === null && block.outcome === 'active', 'ACTIVE_BLOCK');
      active = block.id;
    } else {
      check(['complete', 'interrupted', 'overrun'].includes(block.outcome), 'BLOCK_OUTCOME');
      check(block.elapsedSeconds === (end - start) / 1000, 'ELAPSED_MISMATCH');
      check(b.lastEventAt && time(b.lastEventAt) >= end, 'LEDGER_EVENT_TIME');
    }
    used += end - start; previous = end;
  }
  check(reviews <= 1, 'ONE_REVIEW_ONLY');
  for (const d of b.deferrals) {
    check(kinds.includes(d.kind) && ['deferred', 'unavailable'].includes(d.status) && text(d.reason), 'DEFERRAL_RECORD');
    check(time(d.at) <= at && b.lastEventAt && time(d.at) <= time(b.lastEventAt), 'DEFERRAL_TIME');
  }
  const usedSeconds = used / 1000;
  return { startedAt: b.blocks[0]?.startedAt ?? null,
    endedAt: active ? null : b.blocks.at(-1)?.endedAt ?? null,
    usedSeconds, remainingSeconds: Math.max(0, b.limitSeconds - usedSeconds),
    overrunSeconds: Math.max(0, usedSeconds - b.limitSeconds), activeBlock: active,
    status: usedSeconds > b.limitSeconds ? 'overrun' : usedSeconds >= b.limitSeconds ? 'exhausted' : 'available',
    measurement: 'Sum of non-overlapping enhancement-block wall time, not counterfactual end-to-end latency' };
}
export function deferWork(b, kind, status, reason, now = new Date().toISOString()) {
  const s = budgetSummary(b, now);
  check(kinds.includes(kind) && ['deferred', 'unavailable'].includes(status) && text(reason), 'DEFERRAL_RECORD');
  check(!s.activeBlock, 'END_ACTIVE_BLOCK_FIRST');
  b.deferrals.push({ kind, status, reason, at: now });
  if (kind === 'review') b.reviewDisposition = status;
  b.lastEventAt = now;
}
export function commandOutput(command, result) {
  if (command === 'defer') return { kind: result.kind, status: result.status,
    at: result.at, reasonLength: result.reason.length };
  if (command === 'validate') return { status: result.status,
    strategyStatus: result.strategyStatus, reviewStatus: result.reviewStatus,
    validRecords: result.validRecords, limitationCount: result.limitations.length,
    deferredCount: result.deferred.length, batchGroupCount: result.batchGroups?.length ?? 0 };
  return result;
}
export function beginBlock(b, kind, admissionSeconds = 30, now = new Date().toISOString()) {
  const s = budgetSummary(b, now);
  check(kinds.includes(kind) && Number.isFinite(admissionSeconds) && admissionSeconds > 0, 'ADMISSION_SECONDS_OR_KIND');
  check(!s.activeBlock, 'END_ACTIVE_BLOCK_FIRST');
  const reserve = kind !== 'review' && b.reviewDisposition === 'pending' ? b.reviewReserveSeconds : 0;
  const available = Math.max(0, s.remainingSeconds - reserve);
  const reason = kind === 'review' && b.reviewDisposition !== 'pending' ? 'Review already attempted or deferred' :
    s.remainingSeconds <= 0 ? 'Enhancement budget exhausted' :
      admissionSeconds > available ? 'Insufficient remaining time after review reserve' : null;
  if (reason) {
    // A refused second review is logged without erasing the first review's receipt.
    if (kind === 'review' && b.reviewDisposition === 'attempted') {
      b.deferrals.push({ kind, status: 'deferred', reason, at: now }); b.lastEventAt = now;
    } else deferWork(b, kind, 'deferred', reason, now);
    return { admitted: false, reason };
  }
  b.blocks.push({ id: `enh-${b.blocks.length + 1}`, kind, admissionSeconds,
    startedAt: now, endedAt: null, elapsedSeconds: null, outcome: 'active' });
  b.lastEventAt = now;
  return { admitted: true, blockId: b.blocks.at(-1).id, availableSeconds: available };
}
export function endBlock(b, outcome = 'complete', now = new Date().toISOString()) {
  const s = budgetSummary(b, now);
  check(s.activeBlock && ['complete', 'interrupted'].includes(outcome), 'NO_ACTIVE_BLOCK_OR_OUTCOME');
  const block = b.blocks.at(-1);
  block.endedAt = now; block.elapsedSeconds = (time(now) - time(block.startedAt)) / 1000;
  block.outcome = s.overrunSeconds > 0 ? 'overrun' : outcome;
  block.reviewReserveEncroachedSeconds = block.kind !== 'review' && b.reviewDisposition === 'pending' ?
    Math.max(0, b.reviewReserveSeconds - s.remainingSeconds) : 0;
  b.lastEventAt = now;
  if (block.kind === 'review') b.reviewDisposition = block.outcome === 'complete' ? 'attempted' : 'deferred';
  if (block.outcome !== 'complete') b.deferrals.push({ kind: block.kind, status: 'deferred',
    reason: block.outcome === 'overrun' ? 'In-flight block overran budget; no additional work may start' : 'Block interrupted', at: now });
  return budgetSummary(b, now);
}

function unique(items, label) {
  check(list(items), label);
  const ids = new Set();
  for (const item of items) { check(text(item.id) && !ids.has(item.id), label); ids.add(item.id); }
  return ids;
}
function provenance(e) {
  check(text(e.origin) && text(e.attribution) && text(e.scope), 'EVIDENCE_PROVENANCE');
  time(e.asOf);
  check(['owned', 'authorized', 'structure-only', 'unknown'].includes(e.permissionStatus) &&
    text(e.permissionBasis) && ['cleared', 'not-cleared'].includes(e.modelUploadPermission), 'EVIDENCE_PERMISSION');
}
export function validateExternal(data, brand) {
  const a = data.authorization;
  const authorizedBoard = data.brand === null && a?.allowCrossBrandHumanReferences === true &&
    list(a.targetBrands) && a.targetBrands.includes(brand);
  check(data.schemaVersion === 1 && (data.brand === brand || authorizedBoard) && text(a?.basis) &&
    text(data.authorization.scope), 'EXTERNAL_AUTHORITY');
  time(data.authorization.asOf); unique(data.records, 'EXTERNAL_IDS');
  for (const r of data.records) {
    check(text(r.brand) && ['human-reference', 'brand-history'].includes(r.recordType) &&
      text(r.artifact?.path) && hashOK(r.artifact.sha256), 'EXTERNAL_ARTIFACT_OR_BRAND');
    provenance(r);
    const h = r.humanJudgment, m = r.measurement;
    if (r.recordType === 'human-reference') check(r.useScope === 'reference-only', 'REFERENCE_ONLY_SCOPE');
    if (r.brand !== brand) {
      check(r.recordType === 'human-reference' && m?.status === 'untested', 'CROSS_BRAND_PERFORMANCE');
      check(a.allowCrossBrandHumanReferences === true && r.compatibleWith?.brand === brand &&
        text(r.compatibleWith.basis) && h?.status !== 'unrated', 'CROSS_BRAND_REFERENCE_AUTHORITY');
    }
    check(['unrated', 'human-approved', 'human-rejected', 'human-mixed'].includes(h?.status), 'HUMAN_LABEL');
    if (h.status !== 'unrated') check(text(h.judge) && text(h.exactFeedback) &&
      text(h.scope) && text(h.origin), 'HUMAN_PROVENANCE');
    check(['untested', 'insufficient-delivery', 'observational-signal', 'randomized-relative-winner'].includes(m?.status), 'MEASUREMENT_STATUS');
    if (m.status === 'untested') { check(m.context === null, 'UNTESTED_WITH_RESULTS'); continue; }
    const c = m.context;
    check(c && ['origin', 'attribution', 'unit', 'metric', 'audience', 'placement',
      'attributionWindow', 'decisionRule'].every(k => text(c[k])), 'MEASUREMENT_CONTEXT');
    check(time(c.dateEnd) >= time(c.dateStart), 'MEASUREMENT_DATE_ORDER');
    check(['value', 'numerator', 'denominator'].every(k => Number.isFinite(c[k]) && c[k] >= 0) &&
      Number.isFinite(c.delivery?.impressions) && c.delivery.impressions >= 0 &&
      Number.isFinite(c.delivery?.spend) && c.delivery.spend >= 0 && text(c.delivery.currency), 'MEASUREMENT_UNITS');
    if (m.status === 'randomized-relative-winner') check(c.randomized === true && text(c.assignmentUnit) &&
      text(c.comparator) && text(c.uncertainty) && c.denominator > 0, 'RANDOMIZED_EVIDENCE');
  }
  return data;
}
export function validateStrategy(r, brand, maxMasters = 6) {
  check(r.schemaVersion === 1 && r.brand === brand && ['complete', 'deferred'].includes(r.status), 'STRATEGY_HEADER');
  if (r.status === 'deferred') check(text(r.reason), 'STRATEGY_DEFERRAL_REASON');
  const ids = unique(r.evidence, 'EVIDENCE_IDS');
  for (const e of r.evidence) { provenance(e); check(text(e.exactEvidence), 'EXACT_EVIDENCE'); }
  if (r.status === 'complete') {
    for (const name of briefFields) {
      const f = r.brief?.[name];
      check(text(f?.text) && ['fact', 'quote', 'hypothesis', 'unavailable'].includes(f.label) &&
        list(f.evidenceIds) && f.evidenceIds.every(id => ids.has(id)), `BRIEF_FIELD ${name}`);
      if (['fact', 'quote'].includes(f.label)) check(f.evidenceIds.length > 0, `UNSOURCED_BRIEF ${name}`);
      if (f.label === 'unavailable') check(f.evidenceIds.length === 0, 'UNAVAILABLE_WITH_EVIDENCE');
      if (f.label === 'quote') check(f.evidenceIds.some(id => r.evidence.find(e => e.id === id).exactEvidence.includes(f.text)), 'QUOTE_NOT_EXACT');
    }
    check(['fact', 'unavailable'].includes(r.brief.offer.label) &&
      ['fact', 'unavailable'].includes(r.brief.destination.label), 'OFFER_OR_DESTINATION_NOT_VERIFIED');
  }
  unique(r.concepts, 'CONCEPT_IDS');
  check(r.concepts.length <= maxMasters, 'CONCEPT_CAP');
  const masters = new Set();
  for (const c of r.concepts) {
    validateCommunication(c.communication);
    check(['buying-argument', 'reference-iteration'].includes(c.kind) && text(c.motivationOrUseCase) &&
      text(c.hypothesis) && text(c.reason) && ['selected', 'rejected', 'tied'].includes(c.decision), 'CONCEPT_ARGUMENT');
    check(list(c.briefFields) && c.briefFields.length && c.briefFields.every(k => briefFields.includes(k)) &&
      list(c.proofIds) && c.proofIds.length && c.proofIds.every(id => ids.has(id)) &&
      list(c.referenceLinks) && c.referenceLinks.length && c.referenceLinks.every(text), 'CONCEPT_LINKS');
    check(list(c.masterIds), 'MASTER_IDS');
    for (const id of c.masterIds) { check(text(id) && !masters.has(id), 'MASTER_CONCEPT_MAPPING'); masters.add(id); }
  }
  check(masters.size <= maxMasters, 'MASTER_CAP');
  if (r.status === 'complete') check(r.concepts.some(c => c.decision !== 'rejected' && c.masterIds.length), 'NO_SUPPORTED_CONCEPT');
  const o = r.optionalInputs;
  check(['missing', 'unavailable', 'irrelevant', 'used'].includes(o?.status) && list(o.usedRecordIds), 'OPTIONAL_INPUT_STATUS');
  if (o.status === 'used') check(text(o.path) && o.usedRecordIds.length > 0 &&
    o.usedRecordIds.length <= 6 && new Set(o.usedRecordIds).size === o.usedRecordIds.length, 'OPTIONAL_INPUT_LINK');
  else check(text(o.reason) && !o.usedRecordIds.length, 'OPTIONAL_INPUT_REASON');
  const v = r.review;
  check(['completed', 'deferred', 'unavailable'].includes(v?.status) && list(v.results) &&
    list(v.candidates) && v.candidates.length <= 6, 'REVIEW_STATUS');
  unique(v.candidates, 'REVIEW_CANDIDATE_IDS');
  if (v.status !== 'completed') check(text(v.reason) && !v.results.length &&
    list(v.batchGroups) && !v.batchGroups.length, 'DEFERRED_REVIEW_CANNOT_PASS');
  else {
    check(['separate-agent', 'human'].includes(v.reviewerType) && text(v.reviewerId) &&
      text(v.producerContextId) && text(v.reviewerContextId) &&
      v.producerContextId !== v.reviewerContextId, 'INDEPENDENT_REVIEW_PROVENANCE');
    if (v.reviewerType === 'separate-agent') check(text(v.tool), 'REVIEW_TOOL');
    check(text(v.inputPath) && hashOK(v.inputSha256) && text(v.outputPath) && hashOK(v.outputSha256), 'REVIEW_RECEIPT');
    check(time(v.endedAt) >= time(v.startedAt), 'REVIEW_TIME_ORDER');
    const seen = new Set();
    for (const result of v.results) {
      check(v.candidates.some(c => c.id === result.candidateId) && !seen.has(result.candidateId) &&
        ['selected', 'rejected', 'tied'].includes(result.decision) && text(result.reason), 'REVIEW_RESULT');
      seen.add(result.candidateId);
    }
    check(v.candidates.length > 0 && seen.size === v.candidates.length, 'REVIEW_ALL_CANDIDATES');
    validateGroups(v.batchGroups, v.candidates.map(c => c.id), 'candidateIds');
  }
  return r;
}

async function pinned(file, hash) {
  const bytes = await fs.readFile(file);
  check(hashOK(hash) && sha(bytes) === hash, 'RECORD_HASH_MISMATCH');
  return bytes;
}
async function optionalRecords(r, base) {
  if (r.optionalInputs.status !== 'used') return [];
  const file = path.resolve(base, r.optionalInputs.path), data = validateExternal(await load(file), r.brand);
  const used = r.optionalInputs.usedRecordIds.map(id => data.records.find(x => x.id === id));
  check(used.every(Boolean), 'OPTIONAL_RECORD_ID');
  for (const a of used) await pinned(path.resolve(path.dirname(file), a.artifact.path), a.artifact.sha256);
  return used.map(a => ({ ...a, artifact: { ...a.artifact, path: path.resolve(path.dirname(file), a.artifact.path) } }));
}
export async function prepareReview(m, base, outputFile) {
  validateRunIdentity(m);
  const b = m.enhancement.budget, s = budgetSummary(b);
  check(s.activeBlock && b.blocks.at(-1).kind === 'review' && s.remainingSeconds > 0, 'REVIEW_BLOCK_REQUIRED');
  check(!b.blocks.at(-1).reviewInputSha256, 'ONE_REVIEW_INPUT_ONLY');
  const recordFile = path.resolve(base, m.strategyPath), r = validateStrategy(await load(recordFile), m.request.brand, m.maxMasters);
  check(text(r.review.producerContextId) && r.review.candidates.length, 'REVIEW_INPUT_CANDIDATES');
  const candidates = [];
  for (const c of r.review.candidates) {
    check(text(c.file) && text(c.plan) && c.completeAd === true, 'COMPLETE_AD_INPUT');
    const planFile = path.resolve(base, c.plan), plan = await load(planFile);
    const packetFile = path.resolve(path.dirname(planFile), plan.referencePacket), p = validatePacketEvidence(await load(packetFile));
    const file = path.resolve(base, c.file);
    const references = [];
    for (const x of p.selectedReferences) {
      check(text(x.path), 'VIEWABLE_REFERENCE_REQUIRED');
      const refPath = path.resolve(path.dirname(packetFile), x.path);
      references.push({ id: x.id, path: refPath, sha256: sha(await fs.readFile(refPath)),
        sourceType: x.sourceType, observedContext: x.observedContext, retrievedAt: x.retrievedAt ?? null,
        eligibility: x.eligibility ?? null,
        url: x.url, crop: x.crop, permissionStatus: x.permissionStatus,
        permissionBasis: x.permissionBasis, modelUploadPermission: x.modelUploadPermission });
    }
    const productionAssets = [];
    for (const x of (p.imageRoles || [])) {
      check(text(x.path), 'IDENTITY_ASSET_PATH');
      const assetPath = path.resolve(path.dirname(packetFile), x.path);
      const source = p.sources?.find(s => s.id === x.sourceId);
      check(source, 'PRODUCTION_ASSET_SOURCE');
      productionAssets.push({ assetId: x.assetId, sourceId: x.sourceId, role: x.role,
        path: assetPath, sha256: sha(await fs.readFile(assetPath)),
        permissionStatus: source.permissionStatus, permissionBasis: source.permissionBasis,
        modelUploadPermission: source.modelUploadPermission });
    }
    const control = p.previousVersionControl;
    const previousVersionControl = { status: control.status, reason: control.reason };
    if (control.status === 'provided') {
      const controlPath = path.resolve(path.dirname(packetFile), control.path);
      const bytes = await fs.readFile(controlPath);
      if (control.sha256) check(sha(bytes) === control.sha256, 'CONTROL_HASH_MISMATCH');
      Object.assign(previousVersionControl, { path: controlPath, sha256: sha(bytes),
        url: control.url ?? null, origin: control.origin, retrievedAt: control.retrievedAt,
        permissionStatus: control.permissionStatus,
        permissionBasis: control.permissionBasis, modelUploadPermission: control.modelUploadPermission });
    }
    candidates.push({ id: c.id, file, sha256: sha(await fs.readFile(file)),
      packetPath: packetFile, packetSha256: sha(await fs.readFile(packetFile)),
      grounding: p.grounding, groundingException: p.groundingException ?? null,
      inspirationLimitation: p.inspirationLimitation ?? null,
      destination: r.brief?.destination?.label === 'fact' ? r.brief.destination.text : null,
      caption: c.captionPath ? { path: path.resolve(base, c.captionPath),
        text: await fs.readFile(path.resolve(base, c.captionPath), 'utf8'),
        sha256: sha(await fs.readFile(path.resolve(base, c.captionPath))) } : null,
      inspirationAds: references.filter(x => x.sourceType === 'ad'),
      otherVisualSources: references.filter(x => x.sourceType !== 'ad'),
      productionAssets, previousVersionControl,
      sources: (p.sources || []).map(x => ({ ...x,
        localPath: x.localPath ? path.resolve(path.dirname(packetFile), x.localPath) : null })),
      claims: p.claims, copy: p.copy,
      identityAssets: productionAssets.filter(x => ['product-identity', 'product', 'logo', 'logo-identity'].includes(x.role)) });
  }
  const anchors = (await optionalRecords(r, base)).filter(a => a.humanJudgment.status !== 'unrated');
  const neutralFields = ['buyer', 'buyingMoment', 'desiredOutcome', 'alternativeOrObjection', 'offer', 'destination'];
  const briefContext = Object.fromEntries(neutralFields.filter(k => r.brief?.[k]).map(k => {
    const f = r.brief[k]; return [k, { text: f.text, label: f.label, evidenceIds: f.evidenceIds }];
  }));
  const contextEvidenceIds = new Set(Object.values(briefContext).flatMap(f => f.evidenceIds));
  const input = { schemaVersion: 1, task: 'Inspect all complete ads together and each beside its Inspiration ad and claim/brand evidence. Keep Production assets, other visual sources and Previous-version control separate. Check sourceType/observedContext against what is visible; photos/studies are not ads, and missing controls stay missing. Group near-duplicates by complete communication including text, not IDs or producer intent. Exploration needs distinct concepts; variants preserve purposeful siblings. Neutral buyer hypotheses are unvalidated context. Packet paths/hashes are provenance only: do not read producer packets or infer version labels from filenames. Return JSON {results:[{candidateId,decision:"selected|rejected|tied",reason:"concrete observation"}],batchGroups:[{id,candidateIds,reason:"visible communication"}],limitations:[]}. No human approval or performance inference.',
    request: { brand: m.request.brand, product: m.request.product, placement: m.request.placement,
      width: m.request.width, height: m.request.height, creativeMode: m.creativeMode,
      requestedCount: m.request.requestedCount }, briefContext,
    contextEvidence: r.evidence.filter(e => contextEvidenceIds.has(e.id)), candidates, anchors };
  await save(outputFile, input);
  r.review.inputPath = outputFile; r.review.inputSha256 = sha(await fs.readFile(outputFile));
  b.blocks.at(-1).reviewInputPath = outputFile;
  b.blocks.at(-1).reviewInputSha256 = r.review.inputSha256;
  await save(recordFile, r);
  return input;
}

export async function finishEnhancement(m, base, now = new Date().toISOString()) {
  validateRunIdentity(m);
  const b = m.enhancement.budget;
  if (budgetSummary(b, now).activeBlock) endBlock(b, 'interrupted', now);
  const timing = budgetSummary(b, now);
  const result = { ...timing, strategyStatus: 'deferred', reviewStatus: 'deferred',
    reviewScope: 'Exact reviewed complete-rough bytes only; not approval of later siblings or final QA',
    optionalInputsStatus: 'missing', validRecords: true, limitations: [], deferred: [...b.deferrals] };
  m.enhancement.reviewedArtifacts = [];
  let r = null;
  try {
    if (!m.strategyPath) {
      result.limitations.push('No strategy record supplied; legacy/core QA only');
      m.enhancement.reviewDisposition = result.reviewStatus; m.enhancement.summary = result;
      return null;
    }
    r = validateStrategy(await load(path.resolve(base, m.strategyPath)), m.request.brand, m.maxMasters);
    check(r.status !== 'complete' || b.blocks.some(x => x.kind === 'strategy' && x.endedAt), 'UNMETERED_STRATEGY');
    result.strategyStatus = r.status;
    try { await optionalRecords(r, base); result.optionalInputsStatus = r.optionalInputs.status; }
    catch (e) { result.optionalInputsStatus = 'unavailable'; result.limitations.push(e.message); }
    const v = r.review;
    if (v.status === 'completed') {
      const block = b.blocks.find(x => x.kind === 'review');
      // Count time only through review end: a later records-block overrun cannot erase a valid earlier review.
      const throughReview = block ? b.blocks.slice(0, b.blocks.indexOf(block) + 1).reduce((n, x) => n + x.elapsedSeconds, 0) : Infinity;
      check(b.reviewDisposition === 'attempted' && block?.outcome === 'complete' &&
        throughReview <= b.limitSeconds && time(v.startedAt) >= time(block.startedAt) &&
        time(v.endedAt) <= time(block.endedAt), 'REVIEW_DEFERRED_OR_OUTSIDE_BUDGET');
      check(result.optionalInputsStatus !== 'unavailable', 'REVIEW_OPTIONAL_INPUT_UNAVAILABLE');
      check(block.reviewInputSha256 === v.inputSha256 &&
        path.resolve(base, block.reviewInputPath) === path.resolve(base, v.inputPath), 'REVIEW_INPUT_LEDGER_MISMATCH');
      const input = JSON.parse(await pinned(path.resolve(base, v.inputPath), v.inputSha256));
      const output = JSON.parse(await pinned(path.resolve(base, v.outputPath), v.outputSha256));
      check(sameJSON(output.results,v.results), 'REVIEW_RESULT_RECEIPT_MISMATCH');
      check(sameJSON(output.batchGroups,v.batchGroups), 'REVIEW_BATCH_RECEIPT_MISMATCH');
      validateGroups(output.batchGroups, input.candidates.map(c => c.id), 'candidateIds');
      check(input.candidates?.length === v.candidates.length &&
        input.candidates.every(c => v.candidates.some(x => x.id === c.id)), 'REVIEW_INPUT_MISMATCH');
      m.enhancement.reviewedArtifacts = input.candidates.map(c => ({
        candidateId: c.id, path: path.resolve(base, c.file), sha256: c.sha256,
        packetSha256: c.packetSha256, grounding: c.grounding,
        captionSha256: c.caption?.sha256 ?? null, destination: c.destination ?? null,
        ...v.results.find(x => x.candidateId === c.id),
        receiptPath: v.outputPath, receiptSha256: v.outputSha256, status: 'reviewed' }));
      for (const c of input.candidates) {
        try {
          await pinned(path.resolve(base, c.file), c.sha256);
          if (c.caption) await pinned(path.resolve(base, c.caption.path), c.caption.sha256);
          await pinned(path.resolve(base, c.packetPath), c.packetSha256);
          for (const ref of [...(c.inspirationAds || []), ...(c.otherVisualSources || [])])
            await pinned(path.resolve(base, ref.path), ref.sha256);
          for (const asset of c.productionAssets || []) await pinned(path.resolve(base, asset.path), asset.sha256);
          if (c.previousVersionControl?.status === 'provided')
            await pinned(path.resolve(base, c.previousVersionControl.path), c.previousVersionControl.sha256);
        } catch (e) {
          m.enhancement.reviewedArtifacts.find(a => a.candidateId === c.id).status = 'stale';
          throw Error(`REVIEW_ARTIFACT_STALE ${c.id}: ${e.message}`);
        }
      }
      result.batchGroups = output.batchGroups;
    }
    result.reviewStatus = v.status;
    if (v.status !== 'completed') result.limitations.push(v.reason);
  } catch (e) {
    result.validRecords = false;
    result.limitations.push(e.message);
    if (!r) result.strategyStatus = 'deferred';
    result.reviewStatus = 'deferred';
  }
  m.enhancement.reviewDisposition = result.reviewStatus;
  m.enhancement.summary = result;
  return r;
}

export async function creativeRecords(m, r, base) {
  return Promise.all(m.slots.map(async s => {
    const c = r?.concepts.find(c => c.masterIds.includes(s.masterId));
    let captionHash = null;
    const captionProvenance = { status: s.captionPath ? 'not-checked' : 'not-provided', reason: null };
    if (['complete','draft'].includes(s.status) && s.captionPath) {
      try { captionHash = sha(await fs.readFile(path.resolve(base, s.captionPath))); captionProvenance.status = 'recorded'; }
      catch (e) { captionProvenance.status = 'unavailable'; captionProvenance.reason = e.code || e.message; }
    }
    const captionUnavailable = captionProvenance.status === 'unavailable';
    const destination = r?.brief?.destination?.label === 'fact' ? r.brief.destination.text : null;
    const reviewed = (m.enhancement.reviewedArtifacts || []).find(a =>
      a.sha256 === s.sha256 && a.packetSha256 === s.packetSha256 &&
      a.captionSha256 === captionHash && a.destination === destination);
    const stale = (m.enhancement.reviewedArtifacts || []).find(a => s.file && a.path === path.resolve(base, s.file));
    const independentReview = captionUnavailable ?
      { status: 'unavailable', reason: 'Optional caption provenance unavailable; no exact-version independent judgment' } :
      reviewed && s.status === 'complete' &&
      m.enhancement.summary.reviewStatus === 'completed' && reviewed.status === 'reviewed' ?
      { status: 'reviewed', candidateId: reviewed.candidateId, decision: reviewed.decision,
        reason: reviewed.reason, receiptPath: reviewed.receiptPath, receiptSha256: reviewed.receiptSha256 } :
      { status: stale ? 'stale' : m.enhancement.summary.reviewStatus === 'completed' ? 'not-reviewed' :
        m.enhancement.summary.reviewStatus, reason: stale ? 'Export/caption differs or prior review is no longer usable' :
        'No independent judgment bound to these exact bytes; core final QA remains separate' };
    const packet = (m.packetProvenance || []).find(p => p.masterId === s.masterId);
    const group = m.batchSummary?.distinctConceptCount !== null &&
      m.batchReview?.final?.groups?.find(g => g.slotIds.includes(s.id));
    return { slotId: s.id, status: s.status, conceptId: c?.id ?? null, masterId: s.masterId ?? null,
      creativeMode: m.creativeMode, conceptGroupId: s.status === 'complete' ? group?.id ?? null : null,
      grounding: packet?.grounding ?? null, inspirationSources: packet?.selectedReferences ?? [],
      previousVersionControl: packet?.previousVersionControl ?? null,
      variant: s.variant ?? null, briefPath: m.strategyPath, proofIds: c?.proofIds ?? [],
      hypothesis: c ? { label: 'hypothesis', text: c.hypothesis } : { label: 'unavailable', text: 'No linked concept record' },
      output: { path: s.file ?? null, sha256: ['complete','draft'].includes(s.status) ? s.sha256 : null },
      captionPath: s.captionPath ?? null, captionSha256: captionHash, captionProvenance, destination,
      identitySha256: s.status === 'complete' && !captionUnavailable ? sha(canonicalJSON([s.sha256, captionHash, destination])) : null,
      roughSelectionReview: independentReview,
      independentReview: s.finalVisualReview ?? {status:'not-reviewed',reason:'Core final image review is separate from optional rough selection'},
      humanJudgment: { status: 'unrated' }, measurement: { status: 'untested', context: null } };
  }));
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  try {
    const [command, file, a, c, ...rest] = process.argv.slice(2);
    check(file, 'Usage: enhancement.mjs begin manifest kind seconds | end manifest complete|interrupted | status manifest | defer manifest kind deferred|unavailable reason | review-input manifest output.json | validate manifest');
    const m = await load(file), base = path.dirname(path.resolve(file)), b = m.enhancement.budget;
    validateRunIdentity(m);
    let result;
    if (command === 'begin') { result = beginBlock(b, a, c === undefined ? 30 : Number(c)); if (!result.admitted) process.exitCode = 2; }
    else if (command === 'end') result = endBlock(b, a);
    else if (command === 'defer') { deferWork(b, a, c, rest.join(' ')); result = b.deferrals.at(-1); }
    else if (command === 'status') result = budgetSummary(b);
    else if (command === 'review-input') {
      const outputPath=path.resolve(a),input=await prepareReview(m,base,outputPath);
      result={outputPath,sha256:sha(await fs.readFile(outputPath)),candidateCount:input.candidates.length};
    }
    else if (command === 'validate') {
      await finishEnhancement(m, base); result = m.enhancement.summary;
      if (!result.validRecords) process.exitCode = 1;
    }
    else throw Error('UNKNOWN_ENHANCEMENT_COMMAND');
    m.enhancement.timing = budgetSummary(b);
    await save(file, m);
    console.log(JSON.stringify(commandOutput(command, result), null, 2));
  } catch { console.error('ENHANCEMENT_COMMAND_FAILED'); process.exitCode = 1; }
}
