import fs from 'node:fs/promises';
import {execFile} from 'node:child_process';
import {createRequire} from 'node:module';
import {promisify} from 'node:util';
import {pathToFileURL} from 'node:url';
import path from 'node:path';

const require=createRequire(import.meta.url);
const run=promisify(execFile);
const available=async fn=>{try{await fn();return true;}catch{return false;}};

export function dependencyReport(dependencies) {
  const required=['sharp'];
  const missingRequired=required.filter(name=>!dependencies[name]);
  return {status:missingRequired.length?'missing':'ready',dependencies,required,missingRequired,
    capabilities:{localLayerFinishing:dependencies.playwright && dependencies.pythonFontTools,
      localWoff2Finishing:dependencies.playwright && dependencies.pythonFontTools && dependencies.pythonWoff2,
      finalPixelOCR:dependencies.tesseract}};
}

export function chromiumExecutablePath(chromium,env=process.env) {
  return env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH || chromium.executablePath();
}

export async function runtimeDependencies() {
  const python=process.env.STATIC_AD_PYTHON || 'python3';
  const dependencies={
    sharp:await available(async()=>require('sharp').versions),
    playwright:await available(async()=>{
      const {chromium}=require('playwright');
      await fs.access(chromiumExecutablePath(chromium));
    }),
    tesseract:await available(async()=>run('tesseract',['--version'])),
    pythonFontTools:await available(async()=>run(python,['-c','import fontTools'])),
    pythonWoff2:await available(async()=>run(python,['-c','import fontTools; import brotli'])),
  };
  return dependencyReport(dependencies);
}

if(process.argv[1] && import.meta.url===pathToFileURL(path.resolve(process.argv[1])).href) {
  const result=await runtimeDependencies();
  console.log(JSON.stringify(result,null,2));
  if(result.status!=='ready')process.exitCode=1;
}
