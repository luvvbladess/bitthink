import {sha} from './runtime.mjs';

const text=x=>typeof x==='string' && !!x.trim();

export function retainedRequest(request) {
  if(!text(request?.exactText))throw Error('BRIEF_REQUEST');
  const {brand,product,placement,width,height,requestedCount}=request;
  const metadata=Object.fromEntries(Object.entries({brand,product,placement,width,height,requestedCount})
    .filter(([,value])=>value!==undefined));
  return {exactTextSha256:sha(request.exactText),...metadata};
}
