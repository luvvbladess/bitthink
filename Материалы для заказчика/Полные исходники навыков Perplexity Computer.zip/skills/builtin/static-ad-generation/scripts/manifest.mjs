import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { loadJSON, saveJSON, fingerprint, skillRoot, assert, sha } from './runtime.mjs';
import { preflight } from './preflight.mjs';
import { newBudget, budgetSummary, finishEnhancement, creativeRecords } from './enhancement.mjs';
import { defaultMasterCeiling, validateMode, validatePacket, batchSummary, validateRunIdentity } from './concept-contract.mjs';
import { finalReviewSummary } from './final-review.mjs';
import {recordGeneration,selectModel,validateHistoricalCall,validateSlotProduction,validateProductionBudgets,callHash,imageFirstVersion} from './image-first.mjs';
import {conceptRun,conceptPhase,validateContinuation} from './run-continuation.mjs';
import {placementRequired,checkPlacement} from './placement.mjs';
import {retainedRequest} from './request-record.mjs';

export async function initManifest(runDir, brief) {
  const m = await loadJSON(path.join(skillRoot, 'templates/run-manifest.json'));
  validateRunIdentity(m);
  assert(brief.request?.brand?.trim(), 'BRIEF_REQUEST');
  m.request = {...m.request,...retainedRequest(brief.request)};
  assert(Number.isInteger(m.request.requestedCount) && m.request.requestedCount > 0, 'REQUESTED_COUNT');
  assert(Number.isInteger(m.request.width) && Number.isInteger(m.request.height) &&
    m.request.width > 0 && m.request.height > 0, 'REQUEST_DIMENSIONS');
  assert(!brief.mode || ['standard', 'fast', 'exploration'].includes(brief.mode), 'RUN_MODE');
  assert(!brief.deliveryMode || ['concepts','finals'].includes(brief.deliveryMode),'DELIVERY_MODE');
  m.deliveryMode=brief.deliveryMode || 'concepts';
  m.mode = brief.mode || 'standard';
  m.creativeMode = brief.creativeMode ?? 'exploration';
  m.creativeModeReason = brief.creativeModeReason ?? null;
  m.research.mode = brief.researchMode || 'live';
  m.research.limits = m.mode === 'fast' ? { seconds: 240, queries: 3, pages: 4, ads: 4 } :
    { seconds: 480, queries: 6, pages: 8, ads: 8 };
  m.skill.loadedId = brief.loadedId ?? null;
  m.enhancement.budget = newBudget(brief.enhancementBudget);
  m.enhancement.timing = budgetSummary(m.enhancement.budget);
  m.maxMasters = brief.maxMasters ?? defaultMasterCeiling(m.creativeMode, m.request.requestedCount);
  m.masterOverrideReason = brief.masterOverrideReason ?? null;
  validateMode(m);
  m.strategyPath = brief.strategyPath ?? null;
  m.brandIntake = brief.brandIntake ?? m.brandIntake;
  m.placementProfile = brief.placementProfile ?? m.placementProfile;
  if(brief.budgets) m.budgets={...m.budgets,...brief.budgets};
  m.budgetOverrideReason=brief.budgetOverrideReason ?? null;
  validateProductionBudgets(m);
  m.finalReview.producerContextId = brief.producerContextId ?? null;
  const fp = await fingerprint();
  m.skill.packageFingerprint = { algorithm: fp.algorithm, hash: fp.hash };
  m.skill.fingerprintFiles = fp.files;
  m.startedAt = new Date().toISOString();
  m.runId = `rf-${m.startedAt.replace(/[^0-9]/g, '')}`;
  m.environment = { node: process.version, platform: process.platform, architecture: process.arch };
  m.slots = Array.from({ length: m.request.requestedCount }, (_, i) => ({
    id: `ad-${i + 1}`, status: 'pending', masterId: null, variant: null,
    file: null, plan: null, metrics: null, preflight: null, captionPath: null, production:null, qa: {}, failures: []
  }));
  for(const [id,p] of Object.entries(brief.slotPlacementProfiles || {})) {
    const s=m.slots.find(s=>s.id===id);assert(s,'PLACEMENT_SLOT_REQUIRED');s.placementProfile=p;
  }
  await fs.mkdir(runDir, { recursive: true });
  const dest = path.join(runDir, 'run-manifest.json');
  // Never overwrite a previous run record.
  await fs.writeFile(dest, JSON.stringify(m, null, 2) + '\n', { flag: 'wx' });
  return m;
}

export async function finalizeManifest(file) {
  let m = await loadJSON(file); const base = path.dirname(path.resolve(file));
  if(conceptPhase(m)) {
    const {conceptInventory}=await import('./concept-first.mjs');
    await conceptInventory(file);return loadJSON(file);
  }
  let full=null;
  if(conceptRun(m)) {
    const {conceptIntegrity,selectedFinalView}=await import('./concept-first.mjs');
    await conceptIntegrity(m,base);full=m;m=selectedFinalView(m);
  }
  // Init/finalize CLI is unchanged; deliberately do not relabel archived runs.
  validateRunIdentity(m);
  await validateContinuation(m);
  assert(m.skill.packageFingerprint?.hash && m.skill.fingerprintFiles?.length, 'NO_PACKAGE_FINGERPRINT');
  validateMode(m);
  assert(Number.isInteger(m.request?.requestedCount) && m.request.requestedCount > 0, 'REQUESTED_COUNT');
  assert(Array.isArray(m.slots) && m.slots.length <= m.request.requestedCount, 'EXCESS_SLOTS');
  const ids = new Set(m.slots.map(s => s.id));
  assert(ids.size === m.slots.length, 'DUPLICATE_SLOT_ID');
  while (m.slots.length < m.request.requestedCount) {
    let id = `missing-${m.slots.length + 1}`;
    while (ids.has(id)) id += '-x';
    ids.add(id); m.slots.push({ id, status: 'failed', failures: ['Missing promised output'] });
  }
  const packets = new Map(), hashes = new Set();
  const gates = ['truthAndRights', 'referenceComparison', 'mobileAndFullSize', 'detail'];
  for (const s of m.slots) {
    s.failures ||= [];
    if (!['complete','draft'].includes(s.status)) {
      s.status = s.status === 'blocked' ? 'blocked' : 'failed';
      if (!s.failures.length) s.failures.push('Output not completed');
      continue;
    }
    s.status = 'complete'; // Provisional technical eligibility; independent review below may only downgrade it.
    try {
      assert(s.masterId && (m.creativeMode === 'exploration' && s.variant === null ||
        s.variant?.lever && s.variant?.change &&
        ['cosmetic', 'message', 'multi-change-exploration'].includes(s.variant.kind)), 'MASTER_OR_VARIANT_RECORD');
      assert(s.file && s.plan && s.metrics && s.preflight, 'MISSING_OUTPUT_PATHS');
      for (const gate of gates) {
        const q = s.qa?.[gate];
        assert(q?.status === 'pass' && ['human', 'agent-vision'].includes(q.reviewerType) && q.note?.trim(), `MANUAL_GATE ${gate}`);
      }
      const report = await preflight(path.resolve(base, s.plan), path.resolve(base, s.file), path.resolve(base, s.metrics));
      await saveJSON(path.resolve(base, s.preflight), report);
      assert(report.status === 'pass', report.errors.join('; '));
      assert(report.actualDimensions[0] === m.request.width && report.actualDimensions[1] === m.request.height, 'REQUEST_EXPORT_DIMENSIONS');
      assert(!hashes.has(report.exportHash), 'DUPLICATE_OUTPUT_BYTES');
      s.sha256 = report.exportHash;
      s.captionSha256 = null;
      if (s.captionRequired) assert(s.captionPath && (await fs.readFile(path.resolve(base, s.captionPath), 'utf8')).trim(), 'MISSING_REQUIRED_CAPTION');
      if (s.captionPath) {
        try { s.captionSha256 = sha(await fs.readFile(path.resolve(base, s.captionPath))); }
        catch (e) { if (s.captionRequired) throw e; }
      }
      const plan = await loadJSON(path.resolve(base, s.plan));
      const pp = path.resolve(path.dirname(path.resolve(base, s.plan)), plan.referencePacket);
      const packet = validatePacket(await loadJSON(pp));
      assert(packet.masterId === s.masterId, 'PACKET_MASTER_MISMATCH');
      assert(packet.grounding !== 'technical-fixture', 'TECHNICAL_FIXTURE_NOT_DELIVERABLE');
      assert(packet.targetBrand === m.request.brand, 'PACKET_TARGET_BRAND');
      s.productionProvenance=await validateSlotProduction(m,s,base,plan,packet,await loadJSON(path.resolve(base,s.metrics)));
      packets.set(pp, packet);
      s.packetSha256 = sha(await fs.readFile(pp));
      s.technicalQA = report;
      hashes.add(report.exportHash);
    } catch (e) { s.status = 'failed'; s.failures.push(e.message); }
  }
  // Include declared packets for failed/unused masters too.
  for (const pp of m.referencePackets || []) {
    const abs = path.resolve(base, pp);
    try { packets.set(abs, await loadJSON(abs)); }
    catch (e) { m.failures.push({ kind: 'packet', path: pp, reason: e.message }); }
  }
  m.referencePackets = [...packets.keys()];
  const collect = key => [...packets.values()].flatMap(p => (p[key] || []).map(value => ({ masterId: p.masterId, grounding: p.grounding, value })));
  m.selectedSources = collect('selectedReferences');
  m.permissionDecisions = collect('sources');
  m.imageRoles = collect('imageRoles');
  m.invariants = collect('invariants');
  m.allowedChanges = collect('allowedChanges');
  m.sourceClaimProvenance = [...collect('claims'), ...collect('copy')];
  m.packetProvenance = await Promise.all([...packets].map(async ([packetPath, p]) => ({
    masterId: p.masterId, packetPath, sha256: sha(await fs.readFile(packetPath)), grounding: p.grounding,
    groundingException: p.groundingException ?? null, inspirationLimitation: p.inspirationLimitation ?? null,
    selectedReferences: p.selectedReferences, previousVersionControl: p.previousVersionControl ?? null
  })));
  const strategy = await finishEnhancement(m, base);
  m.enhancement.timing = budgetSummary(m.enhancement.budget);
  // Missing/deferred enhancements never substitute for (or bypass) the original per-final gates.
  if (strategy?.status === 'complete') {
    for (const s of m.slots.filter(s => s.status === 'complete')) {
      const concept = strategy.concepts.find(c => c.masterIds.includes(s.masterId) && c.decision !== 'rejected');
      const packet = [...packets.values()].find(p => p.masterId === s.masterId);
      if (!concept || packet?.strategy?.conceptId !== concept.id ||
        typeof packet.strategy.briefPath !== 'string' ||
        path.resolve(base, packet.strategy.briefPath) !== path.resolve(base, m.strategyPath) ||
        !Array.isArray(packet.strategy.briefFields) || !packet.strategy.briefFields.length ||
        !packet.strategy.briefFields.every(k => concept.briefFields.includes(k)) ||
        !Array.isArray(packet.strategy.proofIds) || !packet.strategy.proofIds.length ||
        !packet.strategy.proofIds.every(id => concept.proofIds.includes(id))) {
        s.status = 'failed'; s.failures.push('MASTER_BRIEF_PROOF_LINK');
      }
    }
  }
  const calls = m.generationCalls || [];
  for (const c of calls) assert(c.id && c.tool && c.route && Array.isArray(c.inputImages) &&
    Number.isInteger(c.imageCount) && c.imageCount >= 0 && Number.isFinite(c.elapsedSeconds) && c.elapsedSeconds >= 0, 'GENERATION_CALL_RECORD');
  m.generationSummary = { callCount: calls.length, imageCount: calls.reduce((n, c) => n + c.imageCount, 0),
    runtimeSeconds: calls.reduce((n, c) => n + c.elapsedSeconds, 0) };
  if(imageFirstVersion(m)) {
    const productionErrors=[];
    for(const c of calls)try {
      assert(c.recordSha256===callHash(c),'GENERATION_RECORD_UNREGISTERED');
      await validateHistoricalCall(c,base,m);
    }catch(e){productionErrors.push(`${c.id}: ${e.message}`);}
    try {validateProductionBudgets(m,[...new Map([...packets.values()].map(p=>[p.masterId,p])).values()]);}
    catch(e){productionErrors.push(e.message);}
    if(productionErrors.length) {
      m.failures.push({kind:'production',reasons:productionErrors});
      for(const s of m.slots.filter(s=>['complete','draft'].includes(s.status))) {s.status='failed';s.failures.push(...productionErrors);}
    }
  }
  m.finalReview.summary = await finalReviewSummary(m,base);
  for (const s of m.slots.filter(s => s.status === 'complete')) {
    const review = m.finalReview.summary.states[s.id];
    s.finalVisualReview = review;
    if (review?.status !== 'cleared') {
      s.status = review?.status === 'rejected' ? 'failed' : 'draft';
      s.failures.push(review?.reason || 'Separate final image review required');
    }
  }
  if(placementRequired(m)) {
    m.visualClearedCount=m.slots.filter(s=>s.status==='complete').length;
    for(const s of m.slots.filter(s=>s.status==='complete')) {
      s.placementClearance=await checkPlacement(m,s,base,await fs.readFile(path.resolve(base,s.file)),
        await loadJSON(path.resolve(base,s.metrics)),s.finalVisualReview);
      // Feed local + independent visual pass may be creative-cleared, explicitly NOT placement-cleared.
      if(!s.placementClearance.deliveryEligible) {s.status='draft';s.failures.push(...s.placementClearance.errors);}
    }
    m.placementClearedCount=m.slots.filter(s=>s.placementClearance?.status==='placement-cleared' && s.status==='complete').length;
  }
  m.actualCount = m.slots.filter(s => s.status === 'complete').length;
  m.draftCount = m.slots.filter(s => s.status === 'draft').length;
  m.failedCount = m.request.requestedCount - m.actualCount;
  m.batchSummary = batchSummary(m);
  m.distinctConceptCount = m.batchSummary.distinctConceptCount;
  m.conceptShortfall = m.batchSummary.conceptShortfall;
  m.failures = [...m.failures.filter(f => !['slot', 'batch'].includes(f.kind)),
    ...m.slots.filter(s => s.status !== 'complete').map(s => ({ kind: 'slot', id: s.id, status: s.status, reasons: s.failures })),
    ...(m.batchSummary.status === 'fail' ? [{ kind: 'batch', reasons: m.batchSummary.reasons }] : [])];
  m.finishedAt = new Date().toISOString();
  assert(Number.isFinite(Date.parse(m.startedAt)), 'START_TIME');
  m.runtimeSeconds = (Date.parse(m.finishedAt) - Date.parse(m.startedAt)) / 1000;
  m.creativeRecords = await creativeRecords(m, strategy, base);
  m.status = m.failedCount || m.batchSummary.status !== 'pass' ? 'incomplete' : 'complete';
  if(full) {
    // Project the user's selected scope through ALL original gates, then merge without resetting the request or unselected slots.
    const selected=new Map(m.slots.map(s=>[s.id,s]));
    full.slots=full.slots.map(s=>selected.get(s.id) || s);
    full.selectedFinalSummary={requestedCount:m.request.requestedCount,actualCount:m.actualCount,failedCount:m.failedCount,
      batchSummary:m.batchSummary,status:m.status};
    for(const k of ['actualCount','draftCount','visualClearedCount','placementClearedCount','finalReview','generationSummary'])full[k]=m[k];
    full.qualityClearedCount=m.actualCount;
    full.finalizationFailures=m.failures;full.status=m.status;
    full.finishedAt=m.finishedAt;full.runtimeSeconds=m.runtimeSeconds;
    // Original failure history remains append-only; finalization's derived failures live in their own summary.
    await saveJSON(file,full);return full;
  }
  m.qualityClearedCount=m.actualCount;
  await saveJSON(file, m);
  return m;
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  try {
    const [command, arg, briefPath, callId, index] = process.argv.slice(2);
    let result;
    if (command === 'init' && arg && briefPath) result = await initManifest(path.resolve(arg), await loadJSON(briefPath));
    else if (command === 'finalize' && arg) result = await finalizeManifest(path.resolve(arg));
    else if (command === 'fingerprint') result = await fingerprint();
    else if(['record-generation','select-model'].includes(command) && arg && briefPath) {
      const m=await loadJSON(arg),base=path.dirname(path.resolve(arg));validateRunIdentity(m);
      result=command==='record-generation' ? await recordGeneration(m,base,await loadJSON(briefPath)) :
        await selectModel(m,base,briefPath,callId,index===undefined?0:Number(index));
      await saveJSON(arg,m);
      if(result.validationError)process.exitCode=1;
    }
    else throw Error('Usage: manifest.mjs init runDir brief.json | finalize manifest | fingerprint | record-generation manifest call.json | select-model manifest slot-id call-id [output-index]');
    const output=command==='fingerprint' ? result : {command,
      manifestPath:command==='init'?path.resolve(arg,'run-manifest.json'):path.resolve(arg),
      status:result.status ?? null,validationError:result.validationError ?? null};
    console.log(JSON.stringify(output, null, 2));
    if (result.status === 'incomplete') process.exitCode = 1;
  } catch { console.error('MANIFEST_COMMAND_FAILED'); process.exitCode = 1; }
}
