// Deterministic evidence/measurement checks, NOT visual understanding or identity authentication.
import fs from 'node:fs/promises';
import path from 'node:path';
import {isRaster,rasterBox} from './image-first.mjs';
import {sharp} from './raster-runtime.mjs';
import {assert as check,sameJSON,sha} from './runtime.mjs';
const text = x => typeof x === 'string' && !!x.trim();
const hashOK = x => typeof x === 'string' && /^[a-f0-9]{64}$/.test(x);
const dateOK = x => text(x) && Number.isFinite(Date.parse(x));
const point = p => Array.isArray(p) && p.length === 2 && p.every(Number.isFinite);
export const boxOK = b => Array.isArray(b) && b.length === 4 && b.every(Number.isFinite) && b[2] > 0 && b[3] > 0;
const contains = (b, p) => p[0] >= b[0] && p[1] >= b[1] && p[0] <= b[0] + b[2] && p[1] <= b[1] + b[3];
const inBox = (b, outer) => boxOK(b) && contains(outer, b.slice(0, 2)) && contains(outer, [b[0]+b[2], b[1]+b[3]]);
const unique = (xs, label) => {
  check(Array.isArray(xs), label);
  const ids = new Set();
  for (const x of xs) { check(text(x.id) && !ids.has(x.id), label); ids.add(x.id); }
};
export function validateEligibility(e, brand) {
  check(text(brand) && text(e?.advertiser) && e.targetBrand === brand, 'ADVERTISER_TARGET');
  check(['own-brand', 'verified-direct-competitor'].includes(e.relationship), 'ADVERTISER_INELIGIBLE');
  const same = e.advertiser.trim().toLowerCase() === brand.trim().toLowerCase();
  check(e.relationship === 'own-brand' ? same : !same, 'ADVERTISER_RELATIONSHIP');
  if (!same) check(['productCategory', 'audience', 'useCase'].every(k => text(e.competitiveOverlap?.[k])), 'COMPETITOR_OVERLAP');
  check(dateOK(e.verifiedAt) && Array.isArray(e.evidence) && e.evidence.length > 0, 'ADVERTISER_EVIDENCE');
  for (const x of e.evidence) check(/^https?:\/\//.test(x.url) && dateOK(x.retrievedAt) &&
    text(x.localPath) && hashOK(x.sha256) && text(x.excerpt), 'ADVERTISER_FETCHED_EVIDENCE');
}
function measure(kind, a, b, dimensions) {
  const [w, h] = dimensions, A = a.box, B = b.box;
  if (kind === 'width-ratio') return A[2] / B[2];
  if (kind === 'height-ratio') return A[3] / B[3];
  if (kind === 'gap-x') return (B[0] - A[0] - A[2]) / w;
  if (kind === 'gap-y') return (B[1] - A[1] - A[3]) / h;
  if (kind === 'font-ratio') {
    check(a.fontSize > 0 && b.fontSize > 0, 'CONTRACT_TYPE_MEASURE');
    return a.fontSize / b.fontSize;
  }
  if (kind === 'overlap-fraction') return Math.max(0, Math.min(A[0]+A[2],B[0]+B[2])-Math.max(A[0],B[0])) *
    Math.max(0, Math.min(A[1]+A[3],B[1]+B[3])-Math.max(A[1],B[1])) / (A[2]*A[3]);
  throw Error('CONTRACT_RELATIONSHIP_KIND');
}
export function validateContractShape(p) {
  if (p.grounding === 'technical-fixture') return; // Renderer tests only; delivery rejects this grounding.
  const v = p.visualContract;
  check(v?.schemaVersion === 2 && Array.isArray(v.references), 'MEASURED_CONTRACT_REQUIRED');
  const complete = p.selectedReferences.filter(r => r.sourceType === 'ad' && r.observedContext.completeness === 'complete');
  const expected = p.grounding === 'ad-reference' ? complete.map(r => r.id) : [null];
  check(v.references.length === expected.length && new Set(v.references.map(c => c.referenceId)).size === expected.length &&
    expected.every(id => v.references.some(c => c.referenceId === id)), 'CONTRACT_REFERENCE_COVERAGE');
  for (const c of v.references) {
    check(text(c.image?.path) && hashOK(c.image.sha256) && Number.isInteger(c.image.width) && c.image.width > 0 &&
      Number.isInteger(c.image.height) && c.image.height > 0 && text(c.context) && text(c.adaptation), 'CONTRACT_IMAGE_CONTEXT');
    unique(c.regions, 'CONTRACT_REGIONS');
    check(c.regions.length > 0, 'CONTRACT_REGIONS');
    for (const r of c.regions) check(text(r.role) && text(r.observation) &&
      inBox(r.box, [0,0,c.image.width,c.image.height]) &&
      (r.fontSize === undefined || Number.isFinite(r.fontSize) && r.fontSize > 0), 'CONTRACT_REGION_MEASUREMENT');
    check(Array.isArray(c.mapping) && c.mapping.length === c.regions.length &&
      new Set(c.mapping.map(m => m.regionId)).size === c.regions.length, 'CONTRACT_MAPPING');
    for (const m of c.mapping) {
      check(c.regions.some(r => r.id === m.regionId) &&
        (text(m.rasterRegionId) ? m.zoneIds===undefined && m.assetIds===undefined :
          Array.isArray(m.zoneIds) && m.zoneIds.length>0 && Array.isArray(m.assetIds)) &&
        inBox(m.outputBox,[0,0,1,1]) && Number.isFinite(m.boxTolerance) && m.boxTolerance >= 0 && m.boxTolerance <= .02, 'CONTRACT_MAPPING');
    }
    unique(c.relationships, 'CONTRACT_RELATIONSHIPS');
    unique(c.allowedDeviations, 'CONTRACT_DEVIATIONS');
    check(c.regions.length === 1 || c.relationships.length > 0, 'CONTRACT_RELATIONSHIPS');
    for (const d of c.allowedDeviations) check(c.relationships.some(r => r.id === d.relationshipId) &&
      Number.isFinite(d.outputValue) && text(d.reason), 'CONTRACT_DEVIATION');
    for (const r of c.relationships) {
      const a = c.regions.find(x => x.id === r.from), b = c.regions.find(x => x.id === r.to);
      check(a && b && a !== b && Number.isFinite(r.referenceValue) &&
        Number.isFinite(r.tolerance) && r.tolerance >= 0 && r.tolerance <= .1, 'CONTRACT_RELATIONSHIP');
      check(Math.abs(measure(r.kind, a, b, [c.image.width,c.image.height])-r.referenceValue) <= .001, 'FABRICATED_MEASUREMENT');
      check(c.allowedDeviations.filter(d => d.relationshipId === r.id).length <= 1, 'CONTRACT_DEVIATION');
    }
    unique(c.devices, 'CONTRACT_DEVICES');
    for (const d of c.devices) {
      check(text(d.function) && text(d.context) && ['native','precomposed','raster'].includes(d.implementation) &&
        Array.isArray(d.regionIds) && d.regionIds.length && d.regionIds.every(id => c.regions.some(r => r.id === id)) &&
        Array.isArray(d.requiredParts) && d.requiredParts.length, 'INDISPENSABLE_DEVICE');
      for (const part of d.requiredParts) check(text(part.name) && (d.implementation==='raster' ?
        Array.isArray(part.rasterRegionIds) && part.rasterRegionIds.length && text(part.observation) && !part.zoneIds && !part.capabilities :
        Array.isArray(part.zoneIds) && part.zoneIds.length && Array.isArray(part.capabilities) && part.capabilities.length), 'DEVICE_PART');
      if (d.implementation === 'precomposed') check(text(d.assetId), 'PRECOMPOSED_ASSET');
    }
  }
}
async function pin(base, record) {
  const bytes = await fs.readFile(path.resolve(base, record.path ?? record.localPath));
  check(sha(bytes) === record.sha256, 'FIDELITY_INPUT_STALE');
  return bytes;
}
const union = boxes => {
  const x = Math.min(...boxes.map(b => b[0])), y = Math.min(...boxes.map(b => b[1]));
  return [x,y,Math.max(...boxes.map(b => b[0]+b[2]))-x,Math.max(...boxes.map(b => b[1]+b[3]))-y];
};
export async function validateFidelityInputs(p, plan, geo, base, loaded, capabilities) {
  for (const ref of p.selectedReferences.filter(r => r.sourceType === 'ad')) {
    validateEligibility(ref.eligibility, p.targetBrand);
    for (const e of ref.eligibility.evidence) {
      const bytes = await pin(base, e);
      check(bytes.toString('utf8').includes(e.excerpt), 'ADVERTISER_EVIDENCE_EXCERPT');
    }
  }
  if (p.grounding !== 'technical-fixture') for (const c of p.visualContract.references) {
    const bytes = await pin(base,c.image), meta = await sharp(bytes).metadata();
    check(meta.width === c.image.width && meta.height === c.image.height, 'CONTRACT_IMAGE_DIMENSIONS');
    const ref = p.selectedReferences.find(r => r.id === c.referenceId);
    if (c.referenceId !== null) check(ref && path.resolve(base,ref.path) === path.resolve(base,c.image.path), 'CONTRACT_IMAGE_REFERENCE');
    else check((p.imageRoles || []).some(a => path.resolve(base,a.path) === path.resolve(base,c.image.path)), 'ASSET_LED_CONTRACT_IMAGE');
    const mapped = new Map();
    for (const m of c.mapping) {
      if(m.rasterRegionId) {
        const region=plan.rasterRegions?.find(r=>r.id===m.rasterRegionId);
        check(isRaster(plan) && region,'RASTER_MAPPING_REQUIRES_MODEL_PIXELS');
        const outputBox=rasterBox(region,plan),normalized=outputBox.map((n,i)=>n/(i%2?plan.canvas.height:plan.canvas.width));
        check(normalized.every((n,i)=>Math.abs(n-m.outputBox[i])<=m.boxTolerance+1e-6),'MAPPED_RASTER_GEOMETRY');
        mapped.set(m.regionId,{box:outputBox});continue;
      }
      const zones = m.zoneIds.map(id => plan.zones.find(z => z.id === id));
      check(zones.every(Boolean) && new Set(m.zoneIds).size === m.zoneIds.length &&
        m.assetIds.every(id => loaded.some(a => !a.isFont && a.id === id)), 'MAPPED_COMPONENT_MISSING');
      check(m.assetIds.every(id => zones.some(z => z.assetId === id)), 'MAPPED_ASSET_UNUSED');
      const outputBox=union(zones.map(z => transformedBox(geo.boxes[z.id],z.rotation)));
      const normalized=outputBox.map((n,i)=>n / (i%2 ? plan.canvas.height:plan.canvas.width));
      check(normalized.every((n,i)=>Math.abs(n-m.outputBox[i]) <= m.boxTolerance+1e-6), 'MAPPED_GEOMETRY');
      mapped.set(m.regionId, {box:outputBox,
        fontSize:zones.length === 1 && zones[0].type === 'text' ? zones[0].fontSize : undefined});
    }
    for (const r of c.relationships) {
      if (r.kind === 'font-ratio') continue; // Actual fitted text sizes are checked after browser rendering.
      const expected = c.allowedDeviations.find(d => d.relationshipId === r.id)?.outputValue ?? r.referenceValue;
      check(Math.abs(measure(r.kind,mapped.get(r.from),mapped.get(r.to),[plan.canvas.width,plan.canvas.height])-expected) <= r.tolerance + 1e-6,
        `COMPOSITION_RELATIONSHIP ${r.id}`);
    }
    for (const d of c.devices) {
      if(d.implementation==='raster') {
        check(isRaster(plan) && d.requiredParts.every(part=>part.rasterRegionIds.every(id=>plan.rasterRegions.some(r=>r.id===id))),
          'RASTER_DEVICE_OBSERVATIONS_REQUIRED');
        continue;
      }
      for (const part of d.requiredParts) for (const id of part.zoneIds) {
        const z = plan.zones.find(z => z.id === id);
        check(z && part.capabilities.every(cap => capabilities[z.type]?.includes(cap) &&
          (cap === z.type || z[cap] !== undefined)), `DEVICE_CAPABILITY ${d.id}/${part.name}`);
      }
      if (d.implementation === 'precomposed') {
        const a = plan.assets.find(a => a.id === d.assetId);
        check(a?.role === 'component' && d.requiredParts.every(part => part.zoneIds.every(id =>
          plan.zones.find(z => z.id === id)?.assetId === a.id)), 'PRECOMPOSED_MAPPING');
      }
    }
  }
  for (const f of p.sourceFeatures || []) {
    const a = loaded.find(a => a.id === f.assetId && !a.isFont);
    check(a && hashOK(f.sourceSha256) && a.hash === f.sourceSha256 && text(f.name) && text(f.visibleEvidence) &&
      sameJSON(f.sourceSize,a.dimensions) && inBox(f.region,[0,0,...a.dimensions]) &&
      point(f.point) && contains(f.region,f.point), 'SOURCE_FEATURE_RECORD');
  }
  unique(p.sourceFeatures || [], 'SOURCE_FEATURE_IDS');
}
export function validateRenderedFidelity(packet,plan,textMetrics) {
  if(packet.grounding === 'technical-fixture') return;
  for(const c of packet.visualContract.references) for(const r of c.relationships.filter(r=>r.kind==='font-ratio')) {
    const actual = regionId => {
      const m=c.mapping.find(m=>m.regionId===regionId);
      check(!m.rasterRegionId,'RASTER_FONT_SIZE_NOT_MEASURABLE: use observed ink height/width relationships, not CSS font sizes');
      const z=m.zoneIds.length===1 && plan.zones.find(z=>z.id===m.zoneIds[0]);
      const size=z?.type==='text' && textMetrics.find(t=>t.id===z.id)?.size;
      check(Number.isFinite(size) && size>0,'RENDERED_TYPE_MEASURE');return size;
    };
    const expected=c.allowedDeviations.find(d=>d.relationshipId===r.id)?.outputValue ?? r.referenceValue;
    check(Math.abs(actual(r.from)/actual(r.to)-expected)<=r.tolerance+1e-6,`RENDERED_TYPE_RELATIONSHIP ${r.id}`);
  }
}
export function rotatePoint(p, box, degrees = 0) {
  const t = degrees * Math.PI / 180, x = p[0]-box[0]-box[2]/2, y = p[1]-box[1]-box[3]/2;
  return [box[0]+box[2]/2+x*Math.cos(t)-y*Math.sin(t),box[1]+box[3]/2+x*Math.sin(t)+y*Math.cos(t)];
}
export function transformedBox(b, degrees = 0) {
  const points = [[b[0],b[1]],[b[0]+b[2],b[1]],[b[0],b[1]+b[3]],[b[0]+b[2],b[1]+b[3]]].map(p => rotatePoint(p,b,degrees));
  return union(points.map(p => [...p,0,0]));
}
export function sourceToCanvas(sourcePoint, dimensions, zone, box) {
  const crop = zone.crop ?? [0,0,...dimensions];
  check(inBox(crop,[0,0,...dimensions]) && contains(crop,sourcePoint), 'FEATURE_CROPPED_OUT');
  const scale = (zone.fit === 'cover' ? Math.max : Math.min)(box[2]/crop[2],box[3]/crop[3]);
  const p = [box[0]+(box[2]-crop[2]*scale)*zone.position[0]/100+(sourcePoint[0]-crop[0])*scale,
    box[1]+(box[3]-crop[3]*scale)*zone.position[1]/100+(sourcePoint[1]-crop[1])*scale];
  check(contains(box,p), 'FEATURE_NOT_VISIBLE');
  const r = zone.radius || 0;
  if (r) {
    const nearest = [Math.max(box[0]+r,Math.min(p[0],box[0]+box[2]-r)),Math.max(box[1]+r,Math.min(p[1],box[1]+box[3]-r))];
    check(Math.hypot(p[0]-nearest[0],p[1]-nearest[1]) <= r, 'FEATURE_CLIPPED_BY_RADIUS');
  }
  return rotatePoint(p,box,zone.rotation);
}
export function resolveCallouts(plan, packet, loaded, geo, inkBoxes) {
  return (plan.callouts || []).map(c => {
    const f = packet.sourceFeatures?.find(f => f.id === c.featureId), image = plan.zones.find(z => z.id === c.imageZoneId),
      label = plan.zones.find(z => z.id === c.label.zoneId);
    check(f && image?.type === 'image' && image.assetId === f.assetId && label?.type === 'text', 'CALLOUT_SOURCE_LABEL');
    const asset = loaded.find(a => a.id === f.assetId && !a.isFont);
    check(asset && asset.hash === f.sourceSha256, 'CALLOUT_SOURCE_STALE');
    const box = inkBoxes[label.id];
    check(boxOK(box), 'CALLOUT_LABEL_INK_REQUIRED');
    const t = c.label.offset ?? .5, gap = c.label.gap ?? 2;
    const start = c.label.anchor === 'left' ? [box[0]-gap,box[1]+box[3]*t] :
      c.label.anchor === 'right' ? [box[0]+box[2]+gap,box[1]+box[3]*t] :
      c.label.anchor === 'top' ? [box[0]+box[2]*t,box[1]-gap] : [box[0]+box[2]*t,box[1]+box[3]+gap];
    const end = sourceToCanvas(f.point,asset.dimensions,image,geo.boxes[image.id]);
    const points = c.mode === 'fixed' ? c.points : [start,...(c.bends || []),end];
    check(points?.length >= 2 && points.every(point) &&
      Math.hypot(points[0][0]-start[0],points[0][1]-start[1]) <= .75 &&
      Math.hypot(points.at(-1)[0]-end[0],points.at(-1)[1]-end[1]) <= .75, 'CALLOUT_ENDPOINT_MISMATCH');
    const margin = c.strokeWidth/2;
    check(points.every(p => contains([margin,margin,plan.canvas.width-2*margin,plan.canvas.height-2*margin],p)) &&
      Math.hypot(end[0]-start[0],end[1]-start[1]) >= 4, 'CALLOUT_BOUNDS_OR_LENGTH');
    return {id:c.id,featureId:f.id,labelZoneId:label.id,points,start,end,stroke:c.stroke,strokeWidth:c.strokeWidth};
  });
}
