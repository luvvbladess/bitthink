// Shared record checks only. No ad recognition, semantic similarity scoring or external calls.
import {conceptIdentity} from './run-continuation.mjs';
import { validateEligibility, validateContractShape } from './fidelity.mjs';
import {assert as check} from './runtime.mjs';
const text = x => typeof x === 'string' && !!x.trim();
const hashOK = x => typeof x === 'string' && /^[a-f0-9]{64}$/.test(x);
const dateOK = x => text(x) && Number.isFinite(Date.parse(x));

export function validateRunIdentity(m) {
  // 1.5 receipts remain historical; accepting them does not upgrade their route or creative evidence.
  const original = m.skill?.name === 'reference-first-static-ads-v1-5' && ['1.5.0','1.6.0','1.7.0','1.7.1'].includes(m.skill.version);
  const standalone = m.skill?.name === 'reference-first-static-ads-v1-7-1' && m.skill.version === '1.7.1';
  check(original || standalone || conceptIdentity(m), 'SKILL_IDENTITY');
  if(m.execution || m.continuation)check(m.skill.version==='1.7.0' && m.execution?.version==='1.7.1' &&
    m.continuation?.artifact,'CONTINUATION_RECORD_REQUIRED');
}
export function defaultMasterCeiling(mode, count) {
  check(['exploration', 'variants'].includes(mode), 'CREATIVE_MODE');
  check(Number.isInteger(count) && count > 0, 'REQUESTED_COUNT');
  return mode === 'exploration' ? count : 3;
}
export function validateMode(m) {
  const ceiling = defaultMasterCeiling(m.creativeMode, m.request?.requestedCount);
  check(m.creativeMode !== 'variants' || text(m.creativeModeReason), 'VARIANTS_DIRECTION_REQUIRED');
  check(m.mode !== 'exploration' || m.creativeMode === 'exploration', 'CONFLICTING_CREATIVE_MODE');
  check(Number.isInteger(m.maxMasters) && m.maxMasters > 0 &&
    (m.maxMasters === ceiling || text(m.masterOverrideReason)), 'MASTER_OVERRIDE_AUTHORITY');
}
export function validateCommunication(c) {
  check(c && ['buyerQuestion', 'promise', 'mechanism'].every(k => text(c[k])), 'CONCEPT_COMMUNICATION');
}
function permission(x) {
  check(['owned', 'authorized', 'structure-only', 'unknown'].includes(x.permissionStatus) &&
    text(x.permissionBasis) && ['cleared', 'not-cleared', 'not-needed'].includes(x.modelUploadPermission),
  'REFERENCE_PERMISSION');
}
export function actualAd(x) {
  return x.sourceType === 'ad' && ['static', 'video'].includes(x.observedContext?.mediaFormat) &&
    x.observedContext?.completeness === 'complete';
}
export function validatePacketEvidence(p) {
  check(['ad-reference', 'photo-grounded', 'technical-fixture'].includes(p.grounding), 'GROUNDING');
  validateCommunication(p.communication);
  check(Array.isArray(p.selectedReferences), 'TYPED_REFERENCES');
  const ids = new Set();
  for (const x of p.selectedReferences) {
    check(text(x.id) && !ids.has(x.id), 'REFERENCE_ID'); ids.add(x.id);
    check(['ad', 'photo', 'historical-study', 'unverified'].includes(x.sourceType), 'SOURCE_TYPE');
    const o = x.observedContext;
    check(o && ['static', 'video', 'photo', 'unknown'].includes(o.mediaFormat) &&
      ['complete', 'partial', 'unverified'].includes(o.completeness) && text(o.note), 'OBSERVED_CONTEXT');
    check(text(x.path), 'VIEWABLE_REFERENCE_REQUIRED');
    permission(x);
    if (x.sourceType === 'ad') {
      check(['static', 'video'].includes(o.mediaFormat) && o.completeness !== 'unverified', 'AD_FORMAT_UNVERIFIED');
      check(text(x.url) && /^https?:\/\//.test(x.url) && dateOK(x.retrievedAt), 'AD_SOURCE_PROVENANCE');
      validateEligibility(x.eligibility, p.targetBrand); // EVERY ad, including partial observations.
    }
    if (x.sourceType === 'photo') check(o.mediaFormat === 'photo', 'PHOTO_FORMAT');
    if (x.sourceType === 'unverified') check(o.completeness !== 'complete', 'UNVERIFIED_COMPLETE');
  }
  if (p.grounding === 'ad-reference') check(p.selectedReferences.some(actualAd), 'ACTUAL_AD_INSPIRATION_REQUIRED');
  if (p.grounding === 'photo-grounded') {
    check(['asset-led-request', 'approved-fallback'].includes(p.groundingException?.kind) &&
      text(p.groundingException.basis) && text(p.inspirationLimitation), 'PHOTO_GROUNDING_AUTHORITY');
  }
  const c = p.previousVersionControl;
  check(['not-requested', 'missing', 'provided'].includes(c?.status) && text(c.reason), 'CONTROL_STATUS');
  if (c.status === 'provided') {
    check(text(c.path) && text(c.origin) && dateOK(c.retrievedAt), 'CONTROL_PROVENANCE');
    permission(c);
  }
  else check(!c.path && !c.sha256, 'MISSING_CONTROL_WITH_ARTIFACT');
  return p;
}
export function validatePacket(p) {
  validatePacketEvidence(p);
  validateContractShape(p);
  return p;
}

export function validateGroups(groups, ids, key) {
  check(Array.isArray(groups), 'BATCH_GROUPS');
  const groupIds = new Set(), seen = new Set(), expected = new Set(ids);
  check(expected.size === ids.length, 'BATCH_DUPLICATE_INPUT');
  for (const g of groups) {
    check(text(g.id) && !groupIds.has(g.id) && text(g.reason) &&
      Array.isArray(g[key]) && g[key].length > 0, 'BATCH_GROUP_RECORD');
    groupIds.add(g.id);
    for (const id of g[key]) {
      check(expected.has(id) && !seen.has(id), 'BATCH_GROUP_COVERAGE'); seen.add(id);
    }
  }
  check(seen.size === expected.size, 'BATCH_GROUP_COVERAGE');
  return groups.length;
}
function judgment(x) {
  check(['pass', 'fail'].includes(x?.status) && ['human', 'agent-vision'].includes(x.reviewerType) &&
    text(x.reviewerId) && dateOK(x.reviewedAt) && text(x.note), 'BATCH_VISUAL_JUDGMENT_REQUIRED');
}
export function batchSummary(m) {
  const slots = m.slots.filter(s => s.status === 'complete'), reasons = [];
  let count = slots.length ? null : 0, redundant = null;
  try {
    const pre = m.batchReview?.preRender, final = m.batchReview?.final;
    judgment(pre); judgment(final);
    check(Array.isArray(pre.masterIds) && new Set(pre.masterIds).size === pre.masterIds.length &&
      slots.every(s => pre.masterIds.includes(s.masterId)), 'BATCH_PRERENDER_COVERAGE');
    check(Date.parse(final.reviewedAt) >= Date.parse(pre.reviewedAt), 'BATCH_TIME_ORDER');
    check(Array.isArray(final.artifacts) && final.artifacts.length === slots.length, 'BATCH_ARTIFACT_COVERAGE');
    const seen = new Set();
    for (const a of final.artifacts) {
      const s = slots.find(s => s.id === a.slotId);
      check(s && !seen.has(a.slotId), 'BATCH_ARTIFACT_COVERAGE'); seen.add(a.slotId);
      check(hashOK(a.sha256) && a.sha256 === s.sha256 &&
        hashOK(a.packetSha256) && a.packetSha256 === s.packetSha256 &&
        a.captionSha256 === (s.captionSha256 ?? null), 'BATCH_ARTIFACT_STALE');
    }
    count = validateGroups(final.groups, slots.map(s => s.id), 'slotIds');
    redundant = slots.length - count;
    if (pre.status !== 'pass' || final.status !== 'pass') reasons.push('BATCH_VISUAL_GATE_FAILED');
    if (m.creativeMode === 'exploration' && redundant > 0) reasons.push('EXPLORATION_NEAR_DUPLICATES');
    if (new Set(slots.map(s => s.masterId)).size > m.maxMasters) reasons.push('MASTER_CAP');
  } catch (e) { reasons.push(e.message); }
  const shortfall = m.creativeMode === 'exploration' ? m.request.requestedCount - (count ?? 0) : null;
  if (shortfall > 0) reasons.push('EXPLORATION_CONCEPT_SHORTFALL');
  return { status: reasons.length ? 'fail' : 'pass', distinctConceptCount: count,
    conceptShortfall: shortfall, redundantFileCount: redundant, reasons,
    limits: 'Recorded visual grouping and byte/coverage consistency only; not semantic proof or human approval.' };
}
