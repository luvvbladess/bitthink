// Deterministic routing only. No rights inference, image judgment, media call or reviewer simulation.
import {conceptRepairRoute} from './concept-first.mjs';
import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {admitGeneration} from './generation-admission.mjs';
import {validateProductionBudgets,deterministicRepairCount} from './image-first.mjs';
import {placementRequired} from './placement.mjs';
import {validateContinuation,conceptPhase,conceptRun} from './run-continuation.mjs';
import {intakePlan} from './intake.mjs';
import {sharp} from './raster-runtime.mjs';
import {assert as check,loadJSON as load,sha} from './runtime.mjs';
export {intakeQuestions} from './intake.mjs';
export {admitGeneration};
const text=x=>typeof x==='string' && !!x.trim();
const safeReasonCodes=new Set(['TOTAL_IMAGE_OR_CALL_CAP','INITIAL_IMAGE_OR_ROUGH_CAP','REPAIR_RESERVE',
  'GENERATIVE_REPAIR_CAP','CONCEPT_MATERIAL_REPAIR_RESERVATION_REQUIRED','DETERMINISTIC_REPAIR_CAP',
  'NO_ORIGINAL_MODEL_CALL','ROUGH_CAP']);
const routingReasonCode=(result,f={})=>!text(result.reason)?undefined:safeReasonCodes.has(result.reason)?result.reason:({
    'inspect-final-pixels':'FINAL_PIXEL_INSPECTION_REQUIRED',
    'placement-preview-pending':'PLACEMENT_PREVIEW_REQUIRED',
    'classify-rejection':'REJECTION_CLASSIFICATION_REQUIRED',
    'independent-review':'INDEPENDENT_REVIEW_REQUIRED',
    hold:f.rightsBlocked===true || f.identityUnrecoverable===true?'RIGHTS_OR_IDENTITY_HOLD':'REPAIR_NOT_ALLOWED'
  }[result.action] || 'ROUTING_DETAIL_RECORDED');
const saveRecord=async(file,value)=>{
  check(text(file),'INTAKE_EFFECTIVE_OUTPUT_REQUIRED');
  const dest=path.resolve(file),data=JSON.stringify(value,null,2)+'\n';
  await fs.writeFile(dest,data,{flag:'wx'});return {path:dest,sha256:sha(data)};
};

export function inputAuthority({taskBasis,input:i}) {
  check(i && text(i.provenance),'INPUT_PROVENANCE_REQUIRED');
  const held=reason=>({permissionStatus:'unknown',permissionBasis:reason,
    modelUploadPermission:'not-cleared',modelUploadBasis:null,action:'resolve-or-omit'});
  if(i.denied===true || i.knownRestrictions?.length)return held('Explicit denial or known restriction; do not override with routine task authority');
  const e=i.existingClearance;
  if(e) {
    check(text(e.basis) && typeof e.reuse==='boolean' && typeof e.modelInput==='boolean','SCOPED_CLEARANCE_REQUIRED');
    if(!e.reuse)return held(e.basis);
    return {permissionStatus:'authorized',permissionBasis:e.basis,
      modelUploadPermission:e.modelInput?'cleared':'not-cleared',modelUploadBasis:e.modelInput?e.basis:null,
      action:e.modelInput?'use-in-task':'local-only'};
  }
  const ordinaryModel=i.ordinaryOfficialProductModel===true && i.firstParty===true && i.brandMatches===true &&
    !i.newLikeness && !i.publicFigure && !i.newEndorsement && !i.likenessModified;
  if(i.distinctiveThirdParty || i.likeness && !ordinaryModel || i.newLikeness || i.publicFigure ||
    i.newEndorsement || i.likenessModified || i.sensitive || i.private)
    return held('Specific compatible clearance needed for restricted creative, likeness or sensitive/private material');
  if(i.firstParty===true && i.brandMatches===true && text(taskBasis)) {
    const basis=`Task-authorized first-party use: ${taskBasis}; provenance: ${i.provenance}. Not a legal-license finding.`;
    return {permissionStatus:'authorized',permissionBasis:basis,
      modelUploadPermission:'cleared',modelUploadBasis:basis,action:'use-in-task'};
  }
  return held('No verified first-party task scope or compatible existing clearance; structure-only study or omit');
}
export async function sourceQuality(s) {
  check(text(s.path) && text(s.note),'SOURCE_OBSERVATION_REQUIRED');
  const meta=await sharp(s.path).metadata();
  check(['png','jpeg','webp'].includes(meta.format) && (!meta.pages || meta.pages===1),'SOURCE_IMAGE_FORMAT');
  const crop=s.crop || [0,0,meta.width,meta.height];
  check(Array.isArray(crop) && crop.length===4 && crop.every(Number.isInteger) && crop[0]>=0 && crop[1]>=0 &&
    crop[2]>0 && crop[3]>0 && crop[0]+crop[2]<=meta.width && crop[1]+crop[3]<=meta.height,'SOURCE_CROP');
  check(Array.isArray(s.outputSize) && s.outputSize.length===2 && s.outputSize.every(v=>Number.isFinite(v) && v>0),'SOURCE_OUTPUT_SIZE');
  check(['clean','jagged','halo','unknown'].includes(s.edges) &&
    ['sufficient','insufficient','unknown'].includes(s.detail),'SOURCE_VISUAL_OBSERVATION');
  let action;
  if(s.edges==='unknown' || s.detail==='unknown' || typeof s.backgroundMatch!=='boolean' ||
    typeof s.identityRecoverable!=='boolean')action='inspect';
  else if(meta.orientation && meta.orientation!==1)action='hygiene';
  else if(s.edges==='clean' && s.detail==='sufficient' && s.backgroundMatch && s.identityRecoverable)action='use';
  else if(s.higherQualityAvailable===true)action='use-higher-quality-original';
  else if(!s.identityRecoverable)action='hold';
  else if(s.hygienePossible===true)action='hygiene';
  else action='bounded-master-cleanup';
  return {...s,path:path.resolve(s.path),sha256:sha(await fs.readFile(s.path)),
    nativeDimensions:[meta.width,meta.height],crop,
    hasAlpha:Boolean(meta.hasAlpha),effectiveScale:Math.max(s.outputSize[0]/crop[2],s.outputSize[1]/crop[3]),
    action,modelAdmissionRequired:action==='bounded-master-cleanup',
    limits:'Dimensions are measured; edge, identity, detail and background judgments are supplied observations, not automatic vision.'};
}
export function repairRoute(m,s,f,reviewState) {
  if(conceptPhase(m))return conceptRepairRoute(m,s,f);
  check(s && ['none','review-hold','typography','source-quality','product-identity','composition','caption','placement'].includes(f.kind) &&
    text(f.note),'REPAIR_FINDING_REQUIRED');
  if(f.kind==='placement' && ['inventory-missing','inventory-uncertain'].includes(f.placementIssue))
    return {action:'inspect-final-pixels',reason:f.note};
  if(f.kind==='placement' && f.placementIssue==='preview-missing')
    return {action:'placement-preview-pending',reason:'Obtain genuine intended-placement preview without creating/publishing account objects; do not edit valid pixels.'};
  if(f.rightsBlocked===true || f.identityUnrecoverable===true)return {action:'hold',reason:f.note};
  if(f.kind==='none' || f.kind==='review-hold') {
    if(reviewState?.status==='rejected')return {action:'classify-rejection',reason:reviewState.reason};
    return {action:reviewState?.status==='cleared'?'delivery-check':
      f.reviewerUnavailable===true?'hold':'independent-review',reason:reviewState?.reason || f.note};
  }
  try {validateProductionBudgets(m);} catch(e) {return {action:'hold',reason:e.message};}
  const used=deterministicRepairCount(m,s);
  const local=f.kind==='caption' || f.localSafe===true &&
    ['typography','product-identity','source-quality','placement'].includes(f.kind);
  if(local && used<m.budgets.maxDeterministicRepairsPerFinal)
    return {action:f.kind==='caption'?'caption-repair':'deterministic-repair',used,requiresFreshReview:true};
  if(f.kind==='caption')return {action:'hold',reason:'DETERMINISTIC_REPAIR_CAP'};
  const original=m.generationCalls.find(c=>c.masterId===s.masterId && !c.repairOf);
  if(!original)return {action:'hold',reason:'NO_ORIGINAL_MODEL_CALL'};
  const admission=admitGeneration(m,{kind:'repair',slotId:s.id,masterId:s.masterId,repairOf:original.id});
  return admission.admitted ? {action:'generative-repair',repairOf:original.id,
    model:['source-quality','product-identity'].includes(f.kind)?'GPT Image 2.5 Sunburst':'GPT Image 2.5 Flare',
    requiresFreshReview:true} : {action:'hold',reason:admission.reason};
}
export function deliverySelection(m,states,{previewRequest=null}={}) {
  check(!conceptPhase(m),'CONCEPT_DELIVERY_REQUIRES_BYTE_CHECKED_INVENTORY');
  if(previewRequest!==null)check(previewRequest.explicit===true && text(previewRequest.basis),'EXPLICIT_PREVIEW_REQUEST_REQUIRED');
  // A valid cleared subset may have a shortfall; other batch failures still hold normal delivery.
  const batchHold=!m.batchSummary || m.batchSummary.reasons.some(r=>r!=='EXPLORATION_CONCEPT_SHORTFALL');
  const cleared=[],previews=[],withheld=[];
  for(const s of m.slots) {
    const state=states[s.id] || s.finalVisualReview;
    const eligible=!batchHold && s.status==='complete' && state?.status==='cleared' && states[s.id]?.status==='cleared' &&
      (!placementRequired(m) || s.placementClearance?.deliveryEligible===true);
    const item={slotId:s.id,file:s.file || null,captionPath:s.captionPath || null};
    if(eligible)cleared.push({...item,status:'creative-cleared',
      ...(placementRequired(m)?{placementStatus:s.placementClearance.status,placementLabel:s.placementClearance.label}:{})});
    else {
      const held={...item,status:state?.status==='rejected'?'rejected':s.status,
        reason:s.failures?.at(-1) || state?.reason || (batchHold?'Batch gate held':'Not cleared')};
      withheld.push(held);
      if(s.file && previewRequest)previews.push({...held,label:'Unapproved draft'});
    }
  }
  return {requestedCount:m.request.requestedCount,clearedCount:cleared.length,
    shortfall:m.request.requestedCount-cleared.length,distinctConceptCount:m.distinctConceptCount,
    cleared,previews,withheld};
}
export async function deliveryInventory(file,options={}) {
  const before=await load(file);
  if(conceptPhase(before)) {
    const {conceptInventory}=await import('./concept-first.mjs');return conceptInventory(file);
  }
  const {finalizeManifest}=await import('./manifest.mjs');
  const {finalReviewSummary}=await import('./final-review.mjs');
  let m=await finalizeManifest(file);const base=path.dirname(path.resolve(file));
  if(conceptRun(m)) {
    const {selectedFinalView}=await import('./concept-first.mjs');
    const full=m;m=selectedFinalView(m);m.batchSummary=full.selectedFinalSummary.batchSummary;
  }
  const inventory=deliverySelection(m,(await finalReviewSummary(m,base)).states,options);
  // A non-null path is not evidence that a failed render produced a file.
  inventory.previews=(await Promise.all(inventory.previews.map(async s=>{
    try {check((await fs.stat(path.resolve(base,s.file))).isFile(),'NOT_FILE');return s;}catch{return null;}
  }))).filter(Boolean);
  return inventory;
}
if(process.argv[1] && import.meta.url===pathToFileURL(path.resolve(process.argv[1])).href) {
  try {
    const [command,file,extra]=process.argv.slice(2);
    let result;
    if(command==='intake')result=intakePlan(await load(file));
    else if(command==='authority')result=inputAuthority(await load(file));
    else if(command==='source')result=await sourceQuality(await load(file));
    else if(command==='admit') {const m=await load(file);await validateContinuation(m);result=admitGeneration(m,await load(extra));}
    else if(command==='next') {
      const m=await load(file),f=await load(extra),s=m.slots.find(s=>s.id===f.slotId);
      if(conceptPhase(m)) {
        const {beginConceptRepair}=await import('./concept-first.mjs');
        result=await beginConceptRepair(file,f);
      } else {
      const {finalReviewSummary}=await import('./final-review.mjs');
      // Inspect a failed candidate without changing its saved status or historical rejection.
      const view=structuredClone(m),current=view.slots.find(x=>x.id===f.slotId);
      if(current?.file)current.status='draft';
      const summary=await finalReviewSummary(view,path.dirname(path.resolve(file)));
      result=repairRoute(m,s,f,summary.states[f.slotId]);
      }
    } else if(command==='deliveries')result=await deliveryInventory(file,extra?{previewRequest:await load(extra)}:{});
    else throw Error('Usage: finish-first.mjs intake input.json effective-output.json | authority|source input.json | admit|next manifest input.json | deliveries manifest [explicit-preview-request.json]');
    let output=result;
    if(command==='intake')output={status:result.status,ready:result.ready,unresolvedIds:result.unresolvedIds,
      pendingIds:result.pendingIds,blockerIds:result.blockers.map(b=>b.id),effectiveArtifact:await saveRecord(extra,result.effective),
      questions:result.questions,form:result.form};
    else if(command==='authority')output={permissionStatus:result.permissionStatus,
      modelUploadPermission:result.modelUploadPermission,action:result.action};
    else if(command==='source')output={action:result.action,sha256:result.sha256,nativeDimensions:result.nativeDimensions,
      effectiveScale:result.effectiveScale,modelAdmissionRequired:result.modelAdmissionRequired};
    else if(command==='next')output={action:result.action,repairOf:result.repairOf,model:result.model,
      requiresFreshReview:result.requiresFreshReview,requiresFreshConceptCheck:result.requiresFreshConceptCheck,
      reason:routingReasonCode(result,await load(extra))};
    console.log(JSON.stringify(output,null,2));
    if(result.admitted===false)process.exitCode=2;
  } catch {console.error('FINISH_COMMAND_FAILED');process.exitCode=1;}
}
