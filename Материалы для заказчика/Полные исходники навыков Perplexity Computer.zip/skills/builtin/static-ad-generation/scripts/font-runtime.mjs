import {execFile} from 'node:child_process';

export function inspectFont({python,script,font,family,weight,style,text}) {
  return new Promise((resolve,reject)=>{
    const child=execFile(python,[script,font,'--family',family,'--weight',String(weight),'--style',style],
      {encoding:'utf8'},(error,stdout)=>{
        if(error)return reject(Error('FONT_INSPECTION_FAILED'));
        try {resolve(JSON.parse(stdout));} catch {reject(Error('FONT_INSPECTION_FAILED'));}
      });
    child.stdin.on('error',()=>{});
    child.stdin.end(text);
  });
}
