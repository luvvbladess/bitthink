// Core final image-review receipts. Hashes establish freshness, not reviewer identity or visual truth.
import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { validateRunIdentity, validatePacket, validateGroups } from './concept-contract.mjs';
import {assert as check,canonicalJSON,fingerprint,loadJSON as load,sameJSON,sha} from './runtime.mjs';
import {isRaster,resolveProduction,nonModelException,validateProductionBudgets,imageFirstVersion} from './image-first.mjs';
import {placementRequired,placementSnapshot} from './placement.mjs';
import {finishFirstVersion,validateContinuation,conceptRun,conceptIdentity,conceptVersion} from './run-continuation.mjs';
import {preflight} from './preflight.mjs';
const text = x => typeof x === 'string' && !!x.trim();
const hashOK = x => typeof x === 'string' && /^[a-f0-9]{64}$/.test(x);
// Identity of delivered content only: paths, slot IDs and producer metadata cannot reset rejection.
const deliveredContentKey = inspected => {
  check(hashOK(inspected.final?.sha256) && (inspected.caption === null || hashOK(inspected.caption?.sha256)),
    'FINAL_REVIEW_DELIVERED_CONTENT');
  return sha(canonicalJSON({imageSha256:inspected.final.sha256,captionSha256:inspected.caption?.sha256 ?? null}));
};
const stamp = x => { check(text(x) && Number.isFinite(Date.parse(x)), 'FINAL_REVIEW_TIME'); return Date.parse(x); };
const groupingTask = 'batchGroups is a COMPLETE partition of inspected slot IDs by same/near-duplicate buyer communication. Distinct ads are singleton groups. Never group by brand, campaign or review-batch membership. An empty array is not a complete partition.';
export const criteria = ['advertiserRelevance','compositionFunction','contractFaithfulness','featureAttachments','brandExecution'];
export const modelCriteria = ['generatedCopyIdentity','finishingRegression'];
export const criteriaFor = c => [...criteria,...(c.inspected.production?.modelOutput ? modelCriteria : [])];
async function pinned(base, p, hash) {
  const bytes = await fs.readFile(path.resolve(base,p));
  check(hashOK(hash) && sha(bytes) === hash, 'FINAL_REVIEW_RECEIPT_CHANGED');
  return JSON.parse(bytes);
}
async function artifact(base, p) {
  const full = path.resolve(base,p);
  return {path:full,sha256:sha(await fs.readFile(full))};
}
export async function snapshot(s, base, m=null) {
  check(!s.captionRequired || text(s.captionPath), 'FINAL_REVIEW_REQUIRED_CAPTION');
  const layout = await artifact(base,s.plan), plan = await load(layout.path);
  const packet = await artifact(path.dirname(layout.path),plan.referencePacket), p = validatePacket(await load(packet.path));
  check(p.grounding !== 'technical-fixture', 'TECHNICAL_FIXTURE_NOT_DELIVERABLE');
  const root = path.dirname(packet.path);
  const refs = await Promise.all(p.selectedReferences.map(async r => ({id:r.id,...await artifact(root,r.path)})));
  const assets = await Promise.all(plan.assets.map(async a => ({id:a.id,...await artifact(path.dirname(layout.path),a.path)})));
  const fonts = await Promise.all(plan.fonts.map(async a => ({id:a.id,...await artifact(path.dirname(layout.path),a.path)})));
  const evidence = [];
  for (const r of p.selectedReferences.filter(r => r.sourceType === 'ad'))
    for (const [i,e] of r.eligibility.evidence.entries()) evidence.push({id:`${r.id}-${i}`,...await artifact(root,e.localPath)});
  const control = p.previousVersionControl.status === 'provided' ? await artifact(root,p.previousVersionControl.path) : null;
  let production;
  if(plan.schemaVersion===2) {
    production=await resolveProduction(plan,p,path.dirname(layout.path),m);
    const report=await preflight(layout.path,path.resolve(base,s.file),path.resolve(base,s.metrics));
    check(report.status==='pass',`FINAL_REVIEW_TECHNICAL_HOLD ${report.errors.join('; ')}`);
    production.metrics=await artifact(base,s.metrics);
    production.exportHistory=s.production?.exports || [];
    // Includes originals even when they were NOT uploaded or locally composited.
    production.identityAssets=await Promise.all((p.imageRoles || []).map(async a=>({assetId:a.assetId,role:a.role,
      ...await artifact(root,a.path)})));
    if(finishFirstVersion(m))production.brandFonts=await Promise.all(p.sources.filter(s=>s.fontEvidence).map(async s=>({
      sourceId:s.id,evidence:s.fontEvidence,...await artifact(root,s.localPath)
    })));
    if(m)validateProductionBudgets(m);
  } else if(imageFirstVersion(m)) {
    check(s.production?.route==='non-model','IMAGE_FIRST_PLAN_REQUIRED');nonModelException(s.production.exception);
    // Do not change the legacy inspected-object shape: existing rejection/clarification receipts stay valid.
  }
  return {slotId:s.id,final:await artifact(base,s.file),layout,packet,references:refs,assets,fonts,evidence,control,
    ...(production ? {production} : {}),
    ...(placementRequired(m)?{placement:await placementSnapshot(m,s,base)}:{}),
    captionRequired:Boolean(s.captionRequired),
    caption:s.captionPath ? await artifact(base,s.captionPath) : null};
}
export async function prepareFinalReview(m,base,file) {
  await validateContinuation(m);
  validateRunIdentity(m);
  check(text(m.finalReview?.producerContextId), 'FINAL_PRODUCER_CONTEXT_REQUIRED');
  let selected=null;
  if(conceptRun(m)) {
    const {selectedFinalView}=await import('./concept-first.mjs');
    selected=selectedFinalView(m);
  }
  const candidates = [];
  for (const s of m.slots.filter(s => (!selected || selected.slots.some(x=>x.id===s.id)) && ['complete','draft'].includes(s.status))) {
    const inspected = await snapshot(s,base,m), p = await load(inspected.packet.path), plan = await load(inspected.layout.path);
    check(p.targetBrand === m.request.brand, 'FINAL_REVIEW_TARGET_BRAND');
    candidates.push({slotId:s.id,inspected,grounding:p.grounding,groundingException:p.groundingException,
      inspirationLimitation:p.inspirationLimitation,controlStatus:p.previousVersionControl.status,
      inspirations:p.selectedReferences.map(r => ({id:r.id,sourceType:r.sourceType,url:r.url,retrievedAt:r.retrievedAt,
        observedContext:r.observedContext,eligibility:r.eligibility,permissionStatus:r.permissionStatus,
        permissionBasis:r.permissionBasis,modelUploadPermission:r.modelUploadPermission})),
      // Factual/rights context, not producer selection or composition rationales.
      copy:p.copy,claims:p.claims,sources:p.sources,
      sourceFeatures:p.sourceFeatures || [],callouts:plan.callouts || [],
      ...(isRaster(plan) ? {identityAssetIds:[...new Set([...(p.imageRoles || []).filter(a=>
        ['product','product-identity','logo','logo-identity'].includes(a.role)).map(a=>a.assetId),
        ...plan.assets.filter(a=>['product','logo'].includes(a.role)).map(a=>a.id)])],
        localCopyIds:plan.zones.filter(z=>z.type==='text').map(z=>z.copyId)} : {})});
  }
  check(candidates.length > 0,'FINAL_REVIEW_NO_FINALS');
  const request=selected?.request || m.request;
  const input = {schemaVersion:1,preparedAt:new Date().toISOString(),request:{brand:request.brand,product:request.product,
    placement:request.placement,width:request.width,height:request.height,requestedCount:request.requestedCount},creativeMode:m.creativeMode,
    task:'Separate image-based full-ad QA. Inspect actual final and reference images first, without producer selection rationale. Write imageFirstObservations before reading packet/layout. Then inspect the exact packet/layout bytes in inspected, comparing claimed regions/devices to reference and output: reject semantically fabricated or plain-panel substitutions. Check every advertiser and retained media state; assets/photos/studies are not actual ad inspirations. Inspect named source features, both connector endpoints, brand/logo/font execution and complete batch including every required/present caption and its destinations against retained evidence. Packet/layout paths are phase-two inspection, not evidence of visual success. Read priorReviews in phase two. After any previous rejection, each passing result needs repairResolution explaining how the prior defect was resolved in the delivered image/caption, or why this candidate was unaffected; inspect the whole ad even for caption-only repairs. Return templates/final-review.json: actual inspected hashes, every criterion, timestamp, genuine reviewer provenance and batchGroups. Changed hashes do not prove a repair is correct or prevent a bad reviewer from rubber-stamping it; do not claim actual image inspection from this schema. No performance or human-approval inference. Local preparation does not authorize upload.',
    priorReviews:(m.finalReview.attempts || []).filter(a=>a.outputPath).map(a=>({attemptId:a.id,
      input:{path:a.inputPath,sha256:a.inputSha256},response:{path:a.outputPath,sha256:a.outputSha256},
      ...(a.groupingClarifications ? {groupingClarifications:a.groupingClarifications} : {})})),
    candidates};
  input.task += ` Review-only assignment: inspect files and return findings to the parent. Do not prepare, register or finalize a run, edit input/manifest/production files, or reset attempts. The parent saves the response and administers records. ${groupingTask}`;
  input.task += ' For raster candidates inspect selected modelOutput and final side by side with the reference, at mobile/full size and 200% identity detail. Complete generatedCopyIdentity and finishingRegression criteria. Enumerate every visible headline, price, offer, disclaimer, logo and product label, including unexpected invented text. Return copyChecks for every approved copy ID (observedText, verdict, note, lettering:verified|permitted-substitution|unverified, letteringBasis), identityChecks for every identityAssetId (verdict,note), and unexpectedText:[{text,note}]. Incorrect or unreadable words, unverified lettering, unexpected claims or distorted identity fail; OCR and prompt font names are not font proof. A permitted substitution must match the copy.fontSubstitution disclosure/authority. Verified lettering requires comparison to authorized artwork or the actual local font, not trusting a generated approximation. Finishing must preserve the model-created composition, hierarchy, lighting, treatment and selling argument; a token model background covered by a rebuilt ad fails regardless of record checks. Native export still needs crop/quality comparison. A product insertion without upload clearance is acceptable only with credible perspective, lighting and integration. Pixel-window preservation proves unchanged pixels outside patches, not preservation of meaning inside them.';
  if(finishFirstVersion(m))input.task += ' Check actual source dimensions/effective product size and original-versus-final silhouette, rims/handles, alpha edges, reflections and backgrounds at 200%; reject jagged edges, matte fringe, mismatched integration and patch residue. Inspect brandFonts evidence when present: verified official website fonts are valid brand choices, not proof of reference-ad type. Compare letterforms/weight, word and letter spacing, line breaks, line height and mobile breathing room; fitting is not enough. Official wordmarks must be unmodified artwork, not retyped. Give concrete repair findings, not an invitation to deliver failures.';
  if(placementRequired(m))input.task += ' Separately return placementReview:{verdict:pass|fail|hold,inventorySha256,profileSha256,fullBoxesInspected:true|false,adsManagerPreviewInspected:true|false,note}. Inspect actual final pixels first, then placement profile, OCR artifact, completed inventory and overlay. Enumerate missed text, logos, essential labels and key elements; reject uncertain/clipped boxes or any full extent outside the safe box (not just centers), after crop/resize. Visually verify OCR corrections/exclusions, word/label completeness and every edge. Use fail for actual overlap/clipping; hold for missing evidence. Creative and placement clearance are separate: house margins are not platform numeric bounds and require genuine Ads Manager preview/guardrail evidence for placement clearance. Inspect a supplied preview of this exact final and named placement; otherwise adsManagerPreviewInspected:false. No self-written JSON authenticates vision, OCR completeness or a real platform preview.';
  await fs.writeFile(file,JSON.stringify(input,null,2)+'\n',{flag:'wx'});
  m.finalReview.attempts ||= [];
  const attempt = {id:`final-review-${m.finalReview.attempts.length+1}`,inputPath:path.resolve(file),
    inputSha256:sha(await fs.readFile(file)),outputPath:null,outputSha256:null,assignment:null};
  m.finalReview.attempts.push(attempt);
  return input;
}
export async function recordFinalReview(m,base,id,assignmentFile,outputFile) {
  validateRunIdentity(m);
  const a = m.finalReview?.attempts?.find(a => a.id === id);
  check(a && !a.outputPath,'FINAL_REVIEW_APPEND_ONLY');
  const assignment = await artifact(base,assignmentFile), output = await artifact(base,outputFile);
  // Assignment/response must be the parent's saved records; do not synthesize a reviewer in production.
  // Validate the complete proposed receipt before changing the append-only attempt.
  // A malformed response stays a separate failed artifact, not a registered visual rejection.
  const proposed = {...a,assignment,outputPath:output.path,outputSha256:output.sha256};
  const {input,response} = await reviewReceipt(m,base,proposed);
  for (const c of input.candidates) {
    perAdFailure(c,response.results.find(r=>r.slotId===c.slotId));
    const slot = m.slots.find(s=>s.id===c.slotId);
    check(slot && ['complete','draft'].includes(slot.status) &&
      sameJSON(await snapshot(slot,base,m),c.inspected), 'FINAL_REVIEW_STALE_INPUTS');
  }
  a.assignment = assignment; a.outputPath = output.path; a.outputSha256 = output.sha256;
  return a;
}
function parentProvenance(m,a) {
  check(a.suppliedBy === 'parent' && text(a.origin) && text(a.reviewerId) && text(a.tool) &&
    text(a.reviewerContextId) && a.producerContextId === m.finalReview.producerContextId &&
    a.reviewerContextId !== a.producerContextId && ['separate-agent','human'].includes(a.reviewerType),
  'FINAL_REVIEW_PARENT_PROVENANCE');
}
async function reviewReceipt(m,base,attempt) {
  const input=await pinned(base,attempt.inputPath,attempt.inputSha256);
  const response=await pinned(base,attempt.outputPath,attempt.outputSha256);
  const a=await pinned(base,attempt.assignment?.path,attempt.assignment?.sha256);
  parentProvenance(m,a);
  check(response.schemaVersion === 1 && response.inputSha256 === attempt.inputSha256 &&
    response.method === 'image-comparison' && response.imageFirst === true &&
    ['reviewerId','reviewerContextId','reviewerType','tool'].every(k => response[k] === a[k]), 'FINAL_REVIEW_PROVENANCE');
  check(stamp(response.reviewedAt) >= stamp(input.preparedAt) &&
    stamp(response.reviewedAt) >= stamp(a.assignedAt) && stamp(response.reviewedAt) <= Date.now(), 'FINAL_REVIEW_TIME_ORDER');
  check(Array.isArray(response.results) && response.results.length === input.candidates.length &&
    new Set(response.results.map(r=>r.slotId)).size === response.results.length, 'FINAL_REVIEW_COVERAGE');
  validateGroups(response.batchGroups,input.candidates.map(c=>c.slotId),'slotIds');
  return {input,response,a};
}
function perAdFailure(c,r) {
  check(r && sameJSON(r.inspected,c.inspected) && text(r.imageFirstObservations) &&
    r.packetAndLayoutInspected === true && ['pass','fail'].includes(r.verdict), 'FINAL_REVIEW_INSPECTION');
  const required=criteriaFor(c);
  for (const k of required) {
    const v=r.criteria?.[k];
    check(v && text(v.note) && (['pass','fail'].includes(v.verdict) ||
      v.verdict === 'na' && (k === 'featureAttachments' && !c.callouts.length ||
        k === 'advertiserRelevance' && c.grounding === 'photo-grounded')), `FINAL_REVIEW_CRITERION ${k}`);
  }
  if(c.inspected.production?.modelOutput) {
    check(Array.isArray(r.copyChecks) && r.copyChecks.length===c.copy.length &&
      new Set(r.copyChecks.map(x=>x.copyId)).size===c.copy.length && Array.isArray(r.unexpectedText),'GENERATED_COPY_REVIEW_COVERAGE');
    let incorrect=r.unexpectedText.length>0;
    for(const copy of c.copy) {
      const x=r.copyChecks.find(x=>x.copyId===copy.id);
      check(x && typeof x.observedText==='string' && ['pass','fail'].includes(x.verdict) && text(x.note) &&
        ['verified','permitted-substitution','unverified'].includes(x.lettering) && text(x.letteringBasis),'GENERATED_COPY_REVIEW');
      if(x.lettering==='permitted-substitution') {
        const f=copy.fontSubstitution;
        check(f?.disclosed===true && ['requested','actual','reason','permissionBasis'].every(k=>text(f[k])),'GENERATED_FONT_SUBSTITUTION_AUTHORITY');
      }
      if(x.observedText!==copy.text || x.lettering==='unverified') check(x.verdict==='fail','GENERATED_COPY_FALSE_PASS');
      incorrect ||= x.verdict==='fail';
    }
    check(Array.isArray(r.identityChecks) && r.identityChecks.length===c.identityAssetIds.length &&
      new Set(r.identityChecks.map(x=>x.assetId)).size===c.identityAssetIds.length,'GENERATED_IDENTITY_REVIEW_COVERAGE');
    for(const id of c.identityAssetIds) {
      const x=r.identityChecks.find(x=>x.assetId===id);
      check(x && ['pass','fail'].includes(x.verdict) && text(x.note),'GENERATED_IDENTITY_REVIEW');
      incorrect ||= x.verdict==='fail';
    }
    if(incorrect)check(r.criteria.generatedCopyIdentity.verdict==='fail','GENERATED_IDENTITY_FALSE_PASS');
  }
  const fail=required.some(k=>r.criteria[k].verdict==='fail');
  check(r.verdict === (fail ? 'fail':'pass'),'FINAL_REVIEW_VERDICT_MISMATCH');
  return fail;
}
async function groupingClarification(m,base,attempt,receipt,entry) {
  const {input,response,a:originalAssignment}=receipt;
  check(input.creativeMode==='exploration' && response.batchGroups.some(g=>g.slotIds.length>1),
    'GROUPING_CLARIFICATION_NOT_APPLICABLE');
  for(const c of input.candidates) {
    const r=response.results.find(r=>r.slotId===c.slotId);
    check(!perAdFailure(c,r) && r.verdict==='pass' && criteriaFor(c).every(k=>r.criteria[k].verdict==='pass'),
      'GROUPING_CLARIFICATION_PER_AD_NOT_ALL_PASS');
  }
  const q=await pinned(base,entry.artifact?.path,entry.artifact?.sha256);
  const a=await pinned(base,entry.assignment?.path,entry.assignment?.sha256);
  parentProvenance(m,a);
  const allowed=new Set(['_use','schemaVersion','kind','originalAttemptId','originalInputSha256','originalResponseSha256',
    'reviewerId','reviewerContextId','reviewerType','tool','clarifiedAt','protocolMisunderstanding','reason',
    'imageReinspected','candidates','batchGroups']);
  check(Object.keys(q).every(k=>allowed.has(k)) && q.schemaVersion===1 && q.kind==='grouping-protocol-clarification',
    'GROUPING_CLARIFICATION_GROUPING_ONLY');
  check(q.originalAttemptId===attempt.id && hashOK(q.originalInputSha256) &&
    q.originalInputSha256===attempt.inputSha256 && hashOK(q.originalResponseSha256) &&
    q.originalResponseSha256===attempt.outputSha256,'GROUPING_CLARIFICATION_BINDING');
  check(['reviewerId','reviewerContextId','reviewerType','tool'].every(k=>q[k]===originalAssignment[k] && a[k]===q[k]),
    'GROUPING_CLARIFICATION_SAME_REVIEWER');
  check(q.protocolMisunderstanding===true && text(q.reason) && q.imageReinspected===true,
    'GROUPING_CLARIFICATION_DECLARATION');
  check(stamp(a.assignedAt)>=stamp(response.reviewedAt) && stamp(q.clarifiedAt)>stamp(response.reviewedAt) &&
    stamp(q.clarifiedAt)>=stamp(a.assignedAt) && stamp(q.clarifiedAt)<=stamp(entry.registeredAt) &&
    stamp(entry.registeredAt)<=Date.now(),'GROUPING_CLARIFICATION_TIME_ORDER');
  check(Array.isArray(q.candidates) && q.candidates.length===input.candidates.length &&
    new Set(q.candidates.map(c=>c.slotId)).size===q.candidates.length,'GROUPING_CLARIFICATION_COVERAGE');
  for(const c of input.candidates) {
    const inspected=q.candidates.find(x=>x.slotId===c.slotId);
    check(inspected && sameJSON(inspected.inspected,c.inspected),'GROUPING_CLARIFICATION_INSPECTION_BINDING');
    const s=m.slots.find(s=>s.id===c.slotId);
    check(s && sameJSON(await snapshot(s,base,m),c.inspected),'GROUPING_CLARIFICATION_STALE_INPUTS');
  }
  validateGroups(q.batchGroups,input.candidates.map(c=>c.slotId),'slotIds');
  return q;
}
export async function recordGroupingClarification(m,base,id,assignmentFile,clarificationFile) {
  validateRunIdentity(m);
  const attempt=m.finalReview?.attempts?.find(a=>a.id===id);
  check(attempt?.outputPath && (!attempt.groupingClarifications || attempt.groupingClarifications.length===0),
    'GROUPING_CLARIFICATION_APPEND_ONLY');
  const entry={assignment:await artifact(base,assignmentFile),artifact:await artifact(base,clarificationFile),
    registeredAt:new Date().toISOString()};
  await groupingClarification(m,base,attempt,await reviewReceipt(m,base,attempt),entry);
  attempt.groupingClarifications=[entry]; // Original input, response and assignment remain untouched.
  return entry;
}
export async function continueGroupingClarification(sourceFile,destinationFile,id,assignmentFile,clarificationFile) {
  const source=path.resolve(sourceFile),destination=path.resolve(destinationFile),base=path.dirname(source);
  check(source!==destination && path.dirname(destination)===base,'GROUPING_CONTINUATION_NEW_SIBLING_REQUIRED');
  const bytes=await fs.readFile(source),m=JSON.parse(bytes);
  check((m.skill?.name==='reference-first-static-ads-v1-5' && ['1.5.0-private.2','1.5.0-private.3','1.5.0','1.6.0','1.7.0','1.7.1'].includes(m.skill.version)) ||
    (m.skill?.name==='reference-first-static-ads-v1-7-1' && m.skill.version==='1.7.1') || conceptIdentity(m),
    'GROUPING_CONTINUATION_VERSION');
  const sourceSkill=structuredClone(m.skill),fp=await fingerprint();
  // Legacy continuation stays a historical 1.5 identity, never becomes image-first.
  // Keep its original package identity; record the executing helper separately.
  m.skill={...m.skill,version:m.skill.version.startsWith('1.5.')?'1.5.0':m.skill.version};
  m.reviewContinuations ||= [];
  m.reviewContinuations.push({kind:'grouping-protocol-clarification',sourceManifest:{path:source,sha256:sha(bytes)},
    sourceSkill,executedWith:{version:conceptIdentity(m)?conceptVersion:'1.7.1',packageFingerprint:{algorithm:fp.algorithm,hash:fp.hash}},createdAt:new Date().toISOString()});
  const clarification=await recordGroupingClarification(m,base,id,assignmentFile,clarificationFile);
  // Preserve all slots, receipts, run identity, research/repair ledgers and prior failures. Finalization recomputes status.
  await fs.writeFile(destination,JSON.stringify(m,null,2)+'\n',{flag:'wx'});
  return {continuationPath:destination,originalManifest:{path:source,sha256:sha(bytes)},attemptId:id,clarification};
}
export async function finalReviewSummary(m,base) {
  const live = m.slots.filter(s => ['complete','draft'].includes(s.status));
  const states = Object.fromEntries(live.map(s => [s.id,{status:'draft',reason:'Missing separate final image review'}]));
  const rejected = new Set(), placementRejected=new Set(), receipts = [], errors = [];
  for (const attempt of m.finalReview?.attempts || []) {
    if (!attempt.outputPath) continue;
    const followsRejection = rejected.size > 0;
    const followsPlacementRejection=placementRejected.size>0;
    try {
      const receipt=await reviewReceipt(m,base,attempt),{input,response,a}=receipt;
      let groups=response.batchGroups,clarification=null;
      if(attempt.groupingClarifications !== undefined) {
        try {
          check(Array.isArray(attempt.groupingClarifications) && attempt.groupingClarifications.length===1,
            'GROUPING_CLARIFICATION_APPEND_ONLY');
          clarification=await groupingClarification(m,base,attempt,receipt,attempt.groupingClarifications[0]);
          groups=clarification.batchGroups;
        } catch(e) { errors.push(`${attempt.id}: ${e.message}`); } // Invalid corrections never suppress original rejections.
      }
      for (const c of input.candidates) {
        const r=response.results.find(r=>r.slotId===c.slotId);
        const fail=perAdFailure(c,r);
        const redundant = input.creativeMode === 'exploration' &&
          groups.some(g=>g.slotIds.includes(c.slotId) && g.slotIds.length>1);
        const contentKey = deliveredContentKey(c.inspected);
        const placementKey=c.inspected.placement ? c.inspected.final.sha256+':'+c.inspected.placement.profileSha256:null;
        if(placementKey && r.placementReview?.verdict==='fail')placementRejected.add(placementKey);
        if (fail || redundant) rejected.add(contentKey);
        const slot=live.find(s=>s.id===c.slotId);
        if (!slot) continue;
        const current=await snapshot(slot,base,m);
        if (rejected.has(deliveredContentKey(current))) {
          states[slot.id]={status:'rejected',reason:'Rejected delivered image+caption content requires an actual content repair and fresh separate full-ad review'};
          continue;
        }
        if (!sameJSON(current,c.inspected)) { states[slot.id]={status:'draft',reason:'Stale final/caption/reference/packet/layout/asset inputs'}; continue; }
        if (followsRejection && !text(r.repairResolution)) {
          states[slot.id]={status:'draft',reason:'FINAL_REVIEW_REPAIR_EXPLANATION_REQUIRED'};continue;
        }
        states[slot.id] = fail || redundant || rejected.has(contentKey) ?
          {status:'rejected',reason:'Rejected delivered image+caption content requires an actual content repair and fresh separate full-ad review'} :
          {status:'cleared',reviewedAt:response.reviewedAt,reviewerId:a.reviewerId,
            deliveredContentSha256:contentKey,repairResolution:r.repairResolution ?? null,
            receiptPath:attempt.outputPath,receiptSha256:attempt.outputSha256,inspected:current,
            ...(placementRequired(m)?{placementReview:placementRejected.has(placementKey) ?
              {...r.placementReview,verdict:'fail',note:'Rejected placement pixels/profile require actual pixel repair and fresh independent review'} :
              followsPlacementRejection && !text(r.repairResolution) ?
                {...r.placementReview,verdict:'hold',note:'PLACEMENT_REPAIR_EXPLANATION_REQUIRED'} : r.placementReview ?? null}:{})};
      }
      receipts.push({id:attempt.id,reviewedAt:response.reviewedAt,batchGroups:groups,
        ...(clarification ? {originalBatchGroups:response.batchGroups,groupingClarification:attempt.groupingClarifications[0]} : {})});
    } catch(e) { errors.push(`${attempt.id}: ${e.message}`); }
  }
  // An invalid historical receipt cannot be erased by a later producer-written pass.
  if (errors.length) for (const id of Object.keys(states)) states[id]={status:'draft',reason:errors.join('; ')};
  // Apply history across filenames/slot reassignment, even with no replay or only metadata changes.
  for (const s of live) {
    try {
      const current=await snapshot(s,base,m),contentKey=deliveredContentKey(current);
      if(rejected.has(contentKey)) states[s.id]={status:'rejected',deliveredContentSha256:contentKey,
        reason:'Rejected delivered image+caption content cannot be cleared by notes, renaming, reassignment or unchanged replay'};
    } catch(e) { states[s.id]={status:'draft',reason:e.message}; }
  }
  return {states,receipts,errors,limits:'Hashes/provenance check record consistency only, not reviewer identity, actual image inspection, creative meaning or semantic correctness of caption repairs. A repair explanation is required after rejection but its truth is not machine-proven; changed bytes do not prevent a bad reviewer from rubber-stamping them.'};
}
if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  try {
    const [command,file,...args]=process.argv.slice(2), m=await load(file),base=path.dirname(path.resolve(file));
    let result;
    if (command==='prepare' && args.length===1) result=await prepareFinalReview(m,base,path.resolve(args[0]));
    else if(command==='record' && args.length===3) result=await recordFinalReview(m,base,...args);
    else if(command==='clarify-grouping' && args.length===4) result=await continueGroupingClarification(file,...args);
    else if(command==='check') result=await finalReviewSummary(m,base);
    else throw Error('Usage: final-review.mjs prepare manifest input.json | record manifest attempt-id assignment.json response.json | clarify-grouping source-manifest NEW-sibling-manifest attempt-id assignment.json clarification.json | check manifest');
    if(!['check','clarify-grouping'].includes(command)) await fs.writeFile(file,JSON.stringify(m,null,2)+'\n');
    const output={command,manifestPath:path.resolve(file),
      status:command==='check' ? result.errors.length || Object.values(result.states).some(s=>s.status!=='cleared') ? 'held':'cleared':'recorded',
      ...(command==='prepare'?{inputPath:path.resolve(args[0]),attemptId:m.finalReview.attempts.at(-1).id}:{}),
      ...(command==='record'?{attemptId:result.id}:{}),
      ...(command==='clarify-grouping'?{continuationPath:result.continuationPath,attemptId:result.attemptId}:{}),
      ...(command==='check'?{errors:result.errors,states:Object.fromEntries(Object.entries(result.states).map(([id,state])=>[id,state.status]))}:{}),
    };
    console.log(JSON.stringify(output,null,2));
    if(command==='check' && (result.errors.length || Object.values(result.states).some(s=>s.status!=='cleared'))) process.exitCode=1;
  } catch {console.error('FINAL_REVIEW_COMMAND_FAILED');process.exitCode=1;}
}
