// Concept eligibility only. Supplied image judgments are not automated vision, final QA or launch clearance.
import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {sharp} from './raster-runtime.mjs';
import {assert as check,canonicalJSON,sameJSON,sha,loadJSON as load,saveJSON as save} from './runtime.mjs';
import {validateConceptGeneration,validateHistoricalCall,validateProductionBudgets} from './image-first.mjs';
import {admitGeneration} from './generation-admission.mjs';
import {conceptRun,conceptPhase,validateContinuation} from './run-continuation.mjs';
import {validateRunIdentity,validateMode,validatePacketEvidence,validateCommunication} from './concept-contract.mjs';
import {resolvePlacementProfile,validateProfile,profileHash,generationMapping} from './placement.mjs';
const text=x=>typeof x==='string' && !!x.trim();
const digest=x=>sha(canonicalJSON(x));
const safeReasonCodes=new Set(['CONCEPT_ONE_CORRECTION_PASS','TOTAL_IMAGE_OR_CALL_CAP','REPAIR_RESERVE',
  'GENERATIVE_REPAIR_CAP','CONCEPT_MATERIAL_REPAIR_RESERVATION_REQUIRED','ROUGH_CAP']);
const routingReasonCode=(result,f={})=>!text(result.reason)?undefined:safeReasonCodes.has(result.reason)?result.reason:({
    'concept-check':'CONCEPT_CHECK_REQUIRED',
    hold:['unknown','rights'].includes(f.category) || f.rightsBlocked || f.identityUnrecoverable?
      'RIGHTS_OR_UNKNOWN_HOLD':'CONCEPT_REPAIR_NOT_ALLOWED'
  }[result.action] || 'ROUTING_DETAIL_RECORDED');
const stamp=x=>text(x) && Number.isFinite(Date.parse(x)) && Date.parse(x)<=Date.now();
const ownKeys=(x,keys)=>x && typeof x==='object' && !Array.isArray(x) && Object.keys(x).every(k=>keys.includes(k));
export const essentialChecks=['identity','claims','rights','essentialLegibility','essentialContent','sellingIdea'];
export const minorIssues=['spacing','halo','faint-residue','reference-metadata','house-margin','font-match','incidental-prop-crop'];
export const materialIssues=['product-identity','claim','price','package','logo','essential-legibility','clipping','misleading-content'];
const issues=[...minorIssues,...materialIssues,'rights','unknown'];
const checkArchiveDirectory='concept-checks';
const softHistory=/^(COMPOSITION_RELATIONSHIP|MAPPED_GEOMETRY|MAPPED_RASTER_GEOMETRY|REFERENCE_MEASUREMENT|TYPOGRAPHIC_SPACING|SOURCE_EDGE_ALPHA|HOUSE_MARGIN|FAINT_RESIDUE)( |$)/;
async function pin(base,file,expected=null) {
  check(text(file),'CONCEPT_FILE_REQUIRED');const full=path.resolve(base,file),data=await fs.readFile(full),hash=sha(data);
  check(!expected || hash===expected,'CONCEPT_BYTES_CHANGED');return {path:full,sha256:hash};
}
export async function archiveConceptCheck(base,file,expected=null) {
  const source=await pin(base,file,expected),data=await fs.readFile(source.path);
  const directory=path.resolve(base,checkArchiveDirectory),dest=path.join(directory,`${source.sha256}.json`);
  await fs.mkdir(directory,{recursive:true});
  try {await fs.writeFile(dest,data,{flag:'wx'});} catch(e) {if(e.code!=='EEXIST')throw e;}
  return pin(base,dest,source.sha256);
}
async function image(base,file,expected) {
  const a=await pin(base,file,expected),m=await sharp(a.path).metadata();
  check(['png','jpeg','webp'].includes(m.format) && (!m.pages || m.pages===1) && (!m.orientation || m.orientation===1),
    'CONCEPT_SINGLE_NORMALIZED_IMAGE');
  check((await sharp(a.path).stats()).isOpaque,'CONCEPT_OPAQUE_IMAGE');
  return {...a,width:m.width,height:m.height,pixelsSha256:sha(await sharp(a.path).ensureAlpha().raw().toBuffer())};
}
export async function conceptIntegrity(m,base) {
  validateRunIdentity(m);await validateContinuation(m);validateMode(m);
  check(conceptRun(m) && m.skill.packageFingerprint?.hash && m.skill.fingerprintFiles?.length,'CONCEPT_RUN_REQUIRED');
  check(Number.isInteger(m.request.requestedCount) && m.request.requestedCount>0 && Array.isArray(m.slots) &&
    m.slots.length<=m.request.requestedCount && new Set(m.slots.map(s=>s.id)).size===m.slots.length &&
    m.slots.every(s=>text(s.id)),'CONCEPT_SLOT_COVERAGE');
  validateProductionBudgets(m);
  for(const c of m.generationCalls)await validateHistoricalCall(c,base,m);
  for(const s of m.slots) {
    const e=s.concept;
    if(!e)continue;
    check(Array.isArray(e.exports) && Array.isArray(e.checks) && Array.isArray(e.repairs) && e.repairs.length<=1,'CONCEPT_LEDGER');
    for(const x of [...e.exports,...e.checks,...e.repairs])check(x.recordSha256===digest(Object.fromEntries(
      Object.entries(x).filter(([k])=>k!=='recordSha256'))),'CONCEPT_RECORD_CHANGED');
  }
  const repairs=m.slots.flatMap(s=>(s.concept?.repairs || []).map(r=>({masterId:s.masterId,...r})));
  check(new Set(repairs.map(r=>r.masterId)).size===repairs.length,'CONCEPT_ONE_CORRECTION_PASS');
}
async function packetInputs(m,c,base) {
  const packet=await pin(base,c.packetPath,c.packetSha256),p=await load(packet.path),root=path.dirname(packet.path);
  validatePacketEvidence(p);validateCommunication(p.communication);
  check(!['fail','unknown'].includes(p.manualReview?.truthAndRights),'CONCEPT_PACKET_TRUTH_OR_RIGHTS_HOLD');
  // Optional deferred measurements can be absent; records that exist must at least have their declared container shape.
  check(p.visualContract===null || p.visualContract===undefined || p.visualContract.schemaVersion===2 &&
    Array.isArray(p.visualContract.references),'CONCEPT_MALFORMED_REFERENCE_METADATA');
  check(p.schemaVersion===1 && p.grounding!=='technical-fixture' && p.targetBrand===m.request.brand &&
    p.masterId===c.masterId && p.route===c.route && Array.isArray(p.sources) && p.sources.length &&
    Array.isArray(p.copy) && Array.isArray(p.claims) && Array.isArray(p.imageRoles),'CONCEPT_PACKET');
  for(const list of [p.sources,p.copy,p.claims])check(list.every(x=>text(x.id)) && new Set(list.map(x=>x.id)).size===list.length,'CONCEPT_RECORD_IDS');
  const sources=[];
  for(const s of p.sources) {
    check(['owned','authorized'].includes(s.permissionStatus) && text(s.permissionBasis) &&
      !s.denied && !s.knownRestrictions?.length,'CONCEPT_SOURCE_RIGHTS');
    if(s.localPath!==null && s.localPath!==undefined)sources.push({id:s.id,...await pin(root,s.localPath,s.sha256)});
    else {check(text(s.url),'CONCEPT_SOURCE_LOCATION');sources.push({id:s.id,url:s.url,retrievedAt:s.retrievedAt ?? null});}
  }
  const ids=p.sources.map(s=>s.id),claimIds=p.claims.map(c=>c.id);
  for(const c of p.copy)check(text(c.text) && ['verified','non-factual'].includes(c.evidenceStatus) &&
    Array.isArray(c.sourceIds) && c.sourceIds.every(id=>ids.includes(id)) &&
    (c.evidenceStatus==='non-factual' || c.sourceIds.length>0) &&
    (!c.claimIds || Array.isArray(c.claimIds) && c.claimIds.every(id=>claimIds.includes(id))),'CONCEPT_COPY_UNVERIFIED');
  for(const c of p.claims)check(c.substantiationDecision==='verified' && text(c.exactEvidence) &&
    Array.isArray(c.sourceIds) && c.sourceIds.length && c.sourceIds.every(id=>ids.includes(id)) &&
    (!c.expiry || Number.isFinite(Date.parse(c.expiry)) && Date.parse(c.expiry)>Date.now()),'CONCEPT_CLAIM_UNVERIFIED_OR_EXPIRED');
  const references=[],evidence=[],identities=[];
  for(const r of p.selectedReferences) {
    references.push({id:r.id,...await pin(root,r.path,r.sha256)});
    if(r.sourceType==='ad')for(const e of r.eligibility.evidence) {
      const a=await pin(root,e.localPath,e.sha256);
      check((await fs.readFile(a.path,'utf8')).includes(e.excerpt),'ADVERTISER_EVIDENCE_EXCERPT');evidence.push(a);
    }
  }
  for(const a of p.imageRoles) {
    check(ids.includes(a.sourceId),'CONCEPT_IDENTITY_SOURCE');
    check(a.quality?.identityRecoverable!==false && a.quality?.action!=='hold','CONCEPT_IDENTITY_SOURCE_HOLD');
    identities.push({assetId:a.assetId,role:a.role,...await pin(root,a.path,a.sha256)});
  }
  const control=p.previousVersionControl.status==='provided'?await pin(root,p.previousVersionControl.path,p.previousVersionControl.sha256):null;
  return {packet,sources,references,evidence,identities,control,communication:p.communication};
}
function append(list,record) {const value={...record,recordSha256:digest(record)};list.push(value);return value;}
function conceptSlot(m,id) {
  const s=m.slots.find(s=>s.id===id);check(s,'CONCEPT_SLOT_REQUIRED');
  s.concept ||= {exports:[],checks:[],repairs:[]};return s;
}
export async function exportConcept(file,input,stem) {
  const m=await load(file),base=path.dirname(path.resolve(file));check(conceptPhase(m),'CONCEPT_EXPORT_PHASE');
  await conceptIntegrity(m,base);
  check(ownKeys(input,['slotId','generationCallId','outputIndex']),'CONCEPT_EXPORT_FIELDS');
  const s=conceptSlot(m,input.slotId),c=m.generationCalls.find(c=>c.id===input.generationCallId),i=input.outputIndex ?? 0;
  check(c && c.slotId===s.id && (!s.masterId || s.masterId===c.masterId) && Number.isInteger(i) && i>=0 && i<c.imageCount,'CONCEPT_EXPORT_LINEAGE');
  await validateConceptGeneration(c,base,m);const inputs=await packetInputs(m,c,base);
  const source=await image(base,c.outputPaths[i],c.outputHashes[i]),profile=resolvePlacementProfile(m,{slotId:s.id});
  validateProfile(profile);check(c.placementProfileSha256===profileHash(profile),'CONCEPT_PLACEMENT_CHANGED');
  // Compute the crop from ACTUAL bytes. Do not change c.generationGeometry/outputGeometry or its recorded failure.
  const geometry=generationMapping(profile,{canvasAspect:[source.width,source.height],cropAnchor:'center',resize:'aspect-preserving'},source.width,source.height);
  const production={generationCallId:c.id,generationCallSha256:c.recordSha256,source,profileSha256:profileHash(profile),geometry};
  const [left,top,width,height]=geometry.crop;
  const png=await sharp(source.path).extract({left,top,width,height}).resize(profile.width,profile.height).removeAlpha().png().toBuffer();
  const previous=s.concept.exports.at(-1);
  // Renaming the same export is not another concept or a budget reset.
  if(previous && previous.export.sha256===sha(png) && sameJSON(previous.production,production))return previous;
  if(previous)check(s.concept.repairs.length===1 && !s.concept.exports.slice(1).length,'CONCEPT_ONE_CORRECTION_PASS');
  if(c.repairOf)check(s.concept.repairs.some(r=>r.kind==='generative' && r.repairOf===c.repairOf),'CONCEPT_REPAIR_NOT_RESERVED');
  const dest=path.resolve(`${stem}.png`);await fs.mkdir(path.dirname(dest),{recursive:true});
  await fs.writeFile(dest,png,{flag:'wx'});
  s.masterId=c.masterId;
  const record=append(s.concept.exports,{exportedAt:new Date().toISOString(),modelOutput:{path:source.path,sha256:source.sha256},production,inputs,
    export:await image(base,dest,sha(png))});
  await save(file,m);return record;
}
export async function conceptSnapshot(m,s,base) {
  const e=s.concept?.exports?.at(-1);check(e,'CONCEPT_EXPORT_REQUIRED');
  const c=m.generationCalls.find(c=>c.id===e.production.generationCallId);
  await validateConceptGeneration(c,base,m);
  check(c.recordSha256===e.production.generationCallSha256 && c.masterId===s.masterId && c.slotId===s.id,'CONCEPT_LINEAGE_CHANGED');
  const source=await image(base,e.production.source.path,e.production.source.sha256);
  check(c.outputHashes.includes(source.sha256),'CONCEPT_SOURCE_LINEAGE');
  const inputs=await packetInputs(m,c,base);check(sameJSON(inputs,e.inputs),'CONCEPT_SOURCE_BINDING_CHANGED');
  const profile=resolvePlacementProfile(m,{slotId:s.id});
  check(profileHash(profile)===e.production.profileSha256,'CONCEPT_PLACEMENT_CHANGED');
  const geometry=generationMapping(profile,{canvasAspect:[source.width,source.height],cropAnchor:'center',resize:'aspect-preserving'},source.width,source.height);
  check(sameJSON(geometry,e.production.geometry),'CONCEPT_GEOMETRY_CHANGED');
  const output=await image(base,e.export.path,e.export.sha256);
  check(sameJSON(output,e.export) && output.width===m.request.width && output.height===m.request.height,'CONCEPT_EXPORT_DIMENSIONS');
  const [left,top,width,height]=geometry.crop;
  const expected=await sharp(source.path).extract({left,top,width,height}).resize(profile.width,profile.height).removeAlpha().png().toBuffer();
  check(sha(expected)===output.sha256,'CONCEPT_NATIVE_EXPORT_CHANGED');
  check(!s.captionRequired || text(s.captionPath),'CONCEPT_REQUIRED_CAPTION');
  const caption=s.captionPath?await pin(base,s.captionPath):null;
  if(caption)check(text(await fs.readFile(caption.path,'utf8')),'CONCEPT_EMPTY_CAPTION');
  const history={status:s.status,failures:s.failures || [],qa:s.qa || {},finalVisualReview:s.finalVisualReview || null,
    finalAttempts:m.finalReview?.attempts || []};
  return {slotId:s.id,masterId:s.masterId,exportRecordSha256:e.recordSha256,source,output,inputs,
    captionRequired:Boolean(s.captionRequired),caption,profileSha256:profileHash(profile),history};
}
export function checkConcept(record,current) {
  check(ownKeys(record,['schemaVersion','slotId','inspected','inspectedAt','reviewerType','reviewerId','imageAndSourcesInspected','checks','issues','communicationGroup','groupNote']), 'CONCEPT_CHECK_FIELDS');
  check(record.schemaVersion===1 && record.slotId===current.slotId && sameJSON(record.inspected,current),'CONCEPT_CHECK_STALE');
  check(stamp(record.inspectedAt) && ['human','agent-vision'].includes(record.reviewerType) && text(record.reviewerId) &&
    record.imageAndSourcesInspected===true && text(record.communicationGroup) && text(record.groupNote),'CONCEPT_ACTUAL_INSPECTION_REQUIRED');
  check(ownKeys(record.checks,essentialChecks) && essentialChecks.every(k=>record.checks[k] &&
    ownKeys(record.checks[k],['status','note']) && ['pass','fail','unknown'].includes(record.checks[k].status) && text(record.checks[k].note)),
    'CONCEPT_CHECKS_MISSING_OR_MALFORMED');
  check(Array.isArray(record.issues) && record.issues.every(i=>ownKeys(i,['category','note','surface']) && issues.includes(i.category) && text(i.note) &&
    (i.surface===undefined || ['image','caption'].includes(i.surface)) &&
    (i.surface!=='caption' || ['claim','price','misleading-content'].includes(i.category))),
    'CONCEPT_ISSUES_MALFORMED');
  const reasons=essentialChecks.filter(k=>record.checks[k].status!=='pass').map(k=>`CHECK_${k}`);
  // A pass in another field never cancels a real defect. Minor-only issues do not create a repair loop.
  reasons.push(...record.issues.filter(i=>!minorIssues.includes(i.category)).map(i=>`ISSUE_${i.category}`));
  const h=current.history;
  if(h) {
    for(const f of h.failures)if(typeof f!=='string' || !softHistory.test(f))reasons.push('UNCLASSIFIED_OR_MATERIAL_HISTORY');
    if(['failed','blocked'].includes(h.status) && !h.failures.length)reasons.push('UNKNOWN_HISTORICAL_FAILURE');
    for(const [k,v] of Object.entries(h.qa))if(v.status!=='pass' && v.status!=='na')reasons.push(`HISTORICAL_QA_${k}`);
    // Do not reopen rejected finals as concepts. Legacy runs never enter this path at all.
    if(h.finalVisualReview || h.finalAttempts.length)reasons.push('STRICT_REVIEW_HISTORY_REQUIRES_FINAL_PATH');
  }
  return {status:reasons.length?'held':'concept-ready',reasons};
}
export async function prepareConceptCheck(file,slotId,dest) {
  const m=await load(file),base=path.dirname(path.resolve(file));await conceptIntegrity(m,base);
  check(conceptPhase(m),'CONCEPT_CHECK_PHASE');const s=conceptSlot(m,slotId),inspected=await conceptSnapshot(m,s,base);
  const template=await load(new URL('../templates/concept-check.json',import.meta.url));
  const value={...template,slotId,inspected};await fs.writeFile(dest,JSON.stringify(value,null,2)+'\n',{flag:'wx'});return value;
}
export async function recordConceptCheck(file,checkFile) {
  const m=await load(file),base=path.dirname(path.resolve(file));await conceptIntegrity(m,base);
  check(conceptPhase(m),'CONCEPT_CHECK_PHASE');const submitted=await pin(base,checkFile),r=await load(submitted.path),s=conceptSlot(m,r.slotId);
  const current=await conceptSnapshot(m,s,base),state=checkConcept(r,current);
  const previous=s.concept.checks.at(-1);
  if(previous && (previous.inspected.output.sha256!==current.output.sha256 ||
    previous.inspected.caption?.sha256!==current.caption?.sha256))
    check(s.concept.repairs.length===1 && !s.concept.checks.some(a=>Date.parse(a.recordedAt)>=Date.parse(s.concept.repairs[0].startedAt) &&
      (a.inspected.output.sha256!==s.concept.checks[0].inspected.output.sha256 ||
       a.inspected.caption?.sha256!==s.concept.checks[0].inspected.caption?.sha256)),'CONCEPT_MATERIAL_REPAIR_RESERVATION_REQUIRED');
  check(Date.parse(r.inspectedAt)>=Date.parse(s.concept.exports.at(-1).exportedAt),'CONCEPT_INSPECTION_BEFORE_EXPORT');
  // Store genuine failed checks too. A new note cannot clear an unchanged material rejection.
  const artifact=await archiveConceptCheck(base,submitted.path,submitted.sha256);
  append(s.concept.checks,{artifact,inspected:current,state,recordedAt:new Date().toISOString()});await save(file,m);return state;
}
// Default to an image defect. Only explicitly caption-scoped copy findings can be resolved by caption bytes.
export function unchangedMaterial(record,prior,current) {
  const sameImage=prior.output.pixelsSha256===current.output.pixelsSha256;
  const sameCaption=prior.caption?.sha256===current.caption?.sha256;
  const hard=record.issues.filter(i=>[...materialIssues,'rights'].includes(i.category));
  if(hard.some(i=>i.surface==='caption'?sameCaption:sameImage))return true;
  return essentialChecks.some(k=>record.checks[k].status==='fail' &&
    (k==='claims' && hard.length && hard.every(i=>i.surface==='caption')?sameCaption:sameImage));
}
export async function conceptState(m,s,base) {
  try {
    const current=await conceptSnapshot(m,s,base),records=s.concept.checks;check(records.length,'CONCEPT_CHECK_REQUIRED');
    for(const a of records) {
      await pin(base,a.artifact.path,a.artifact.sha256);const r=await load(a.artifact.path),v=checkConcept(r,a.inspected);
      check(sameJSON(v,a.state),'CONCEPT_CHECK_RECORD_CHANGED');
      check(v.status!=='held' || !unchangedMaterial(r,a.inspected,current),'CONCEPT_REJECTED_CONTENT_UNCHANGED');
    }
    const a=records.at(-1);check(sameJSON(a.inspected,current),'CONCEPT_CHECK_STALE');return {...a.state,check:a,inspected:current};
  } catch(e){return {status:'held',reasons:[e.message]};}
}
export async function conceptInventory(file) {
  const m=await load(file),base=path.dirname(path.resolve(file));check(conceptPhase(m),'CONCEPT_DELIVERY_PHASE');
  let error=null;try{await conceptIntegrity(m,base);}catch(e){error=e.message;}
  const concepts=[],withheld=[],hashes=new Set(),groups=new Set();
  for(const s of m.slots || []) {
    const state=error?{status:'held',reasons:[error]}:await conceptState(m,s,base);
    if(state.status==='concept-ready') {
      const r=await load(state.check.artifact.path),key=state.inspected.output.pixelsSha256;
      if(hashes.has(key) || m.creativeMode==='exploration' && groups.has(r.communicationGroup)) {
        withheld.push({slotId:s.id,reason:'DUPLICATE_CONCEPT'});continue;
      }
      hashes.add(key);groups.add(r.communicationGroup);
      concepts.push({slotId:s.id,file:state.inspected.output.path,sha256:state.inspected.output.sha256,
        captionPath:state.inspected.caption?.path ?? null,captionSha256:state.inspected.caption?.sha256 ?? null,
        label:'Ad concept',status:'concept-ready'});
    } else withheld.push({slotId:s.id,reason:state.reasons.join('; ')});
  }
  const missing=Math.max(0,m.request.requestedCount-(m.slots?.length || 0));
  m.conceptReadyCount=concepts.length;
  m.generationSummary={callCount:m.generationCalls.length,imageCount:m.generationCalls.reduce((n,c)=>n+c.imageCount,0),
    runtimeSeconds:m.generationCalls.reduce((n,c)=>n+c.elapsedSeconds,0)};
  // Never copy concept readiness into strict counts, slot status, review or failure history.
  m.conceptSummary={requestedCount:m.request.requestedCount,conceptReadyCount:concepts.length,
    distinctConceptCount:groups.size,shortfall:m.request.requestedCount-concepts.length,missingSlotCount:missing};
  await save(file,m);return {...m.conceptSummary,concepts,cleared:[],previews:[],withheld};
}
export function conceptRepairRoute(m,s,f) {
  check(s && text(f.note) && issues.includes(f.category),'CONCEPT_FINDING_CATEGORY');
  if(minorIssues.includes(f.category))return {action:'concept-check',reason:'Minor polish: do not repair before concept delivery'};
  if(['unknown','rights'].includes(f.category) || f.rightsBlocked || f.identityUnrecoverable)return {action:'hold',reason:f.note};
  const used=m.slots.some(x=>x.masterId===s.masterId && x.concept?.repairs?.length) ||
    m.generationCalls.some(c=>c.masterId===s.masterId && c.repairOf);
  if(used)return {action:'hold',reason:'CONCEPT_ONE_CORRECTION_PASS'};
  return {action:f.correction==='caption'?'caption-repair':'generative-repair',reason:f.note,requiresFreshConceptCheck:true};
}
export async function beginConceptRepair(file,f) {
  const m=await load(file),base=path.dirname(path.resolve(file));await conceptIntegrity(m,base);check(conceptPhase(m),'CONCEPT_REPAIR_PHASE');
  const s=conceptSlot(m,f.slotId),route=conceptRepairRoute(m,s,f);if(!['generative-repair','caption-repair'].includes(route.action))return route;
  const a=s.concept.checks.at(-1);check(a,'CONCEPT_REPAIR_CHECK_REQUIRED');
  await pin(base,a.artifact.path,a.artifact.sha256);const r=await load(a.artifact.path),current=await conceptSnapshot(m,s,base);
  check(sameJSON(a.inspected,current) && checkConcept(r,current).status==='held' && r.issues.some(i=>i.category===f.category),
    'CONCEPT_MATERIAL_FINDING_REQUIRED');
  const parent=m.generationCalls.find(c=>c.masterId===s.masterId && !c.repairOf);check(parent,'CONCEPT_REPAIR_PARENT');
  if(route.action==='caption-repair') {
    check(r.issues.some(i=>i.category===f.category && i.surface==='caption'),'CONCEPT_CAPTION_FINDING_REQUIRED');
    append(s.concept.repairs,{kind:'caption',repairOf:parent.id,finding:a.artifact,category:f.category,note:f.note,startedAt:new Date().toISOString()});
    m.failures.push({kind:'caption-repair',slotId:s.id,startedAt:new Date().toISOString(),reason:f.note});
    validateProductionBudgets(m);await save(file,m);return route;
  }
  // Admission uses the normal six/nine/per-master limits, not a second allowance.
  const reservation=append(s.concept.repairs,{kind:'generative',repairOf:parent.id,finding:a.artifact,
    category:f.category,note:f.note,startedAt:new Date().toISOString()});
  const admission=admitGeneration(m,{kind:'repair',slotId:s.id,masterId:s.masterId,repairOf:parent.id});
  if(!admission.admitted)s.concept.repairs.pop();else await save(file,m);
  return admission.admitted?{...route,repairOf:parent.id,reservationSha256:reservation.recordSha256,
    model:['product-identity','package','logo'].includes(f.category)?'GPT Image 2.5 Sunburst':'GPT Image 2.5 Flare'}:
    {action:'hold',reason:admission.reason};
}
export function selectedFinalView(m) {
  check(conceptRun(m) && m.finalSelection,'EXPLICIT_FINAL_SELECTION_REQUIRED');const x=m.finalSelection;
  check(x.explicit===true && text(x.basis) && stamp(x.selectedAt) && Array.isArray(x.slotIds) && x.slotIds.length &&
    new Set(x.slotIds).size===x.slotIds.length && x.slotIds.every(id=>m.slots.some(s=>s.id===id)) &&
    x.recordSha256===digest(Object.fromEntries(Object.entries(x).filter(([k])=>k!=='recordSha256'))),'FINAL_SELECTION_RECORD');
  const v=structuredClone(m);v.slots=v.slots.filter(s=>x.slotIds.includes(s.id));
  v.request={...v.request,requestedCount:v.slots.length};
  v.masterOverrideReason ||= `Explicit final selection: ${x.basis}`;
  return v;
}
export async function selectFinals(file,selection) {
  const m=await load(file),base=path.dirname(path.resolve(file));await conceptIntegrity(m,base);
  check(conceptPhase(m) && selection.explicit===true && text(selection.basis),'EXPLICIT_FINAL_SELECTION_REQUIRED');
  // Selection is scope only. It grants no status, checks, new budget, fresh run or publication authority.
  m.finalSelection={explicit:true,basis:selection.basis,slotIds:selection.slotIds,selectedAt:new Date().toISOString()};
  m.finalSelection.recordSha256=digest(m.finalSelection);selectedFinalView(m);await save(file,m);
  return {selectedSlotIds:selection.slotIds,action:'strict-final-production-and-independent-review',
    note:'Keep this manifest, all slots/calls/budgets/history. Export selected ads through schema 2; do not promote concept checks.'};
}
if(process.argv[1] && import.meta.url===pathToFileURL(path.resolve(process.argv[1])).href) {
  try {
    const [cmd,file,a,b]=process.argv.slice(2);let result;
    if(cmd==='export')result=await exportConcept(file,await load(a),b);
    else if(cmd==='prepare')result=await prepareConceptCheck(file,a,b);
    else if(cmd==='check')result=await recordConceptCheck(file,a);
    else if(cmd==='deliveries')result=await conceptInventory(file);
    else if(cmd==='next')result=await beginConceptRepair(file,await load(a));
    else if(cmd==='select-finals')result=await selectFinals(file,await load(a));
    else throw Error('Usage: concept-first.mjs export manifest input.json stem | prepare manifest slot-id new-check.json | check manifest check.json | deliveries manifest | next manifest finding.json | select-finals manifest selection.json');
    let output=result;
    if(cmd==='export')output={slotId:(await load(a)).slotId,path:result.export.path,sha256:result.export.sha256};
    else if(cmd==='prepare')output={slotId:a,inputPath:path.resolve(b),sha256:sha(await fs.readFile(path.resolve(b)))};
    else if(cmd==='next')output={action:result.action,repairOf:result.repairOf,model:result.model,
      requiresFreshReview:result.requiresFreshReview,requiresFreshConceptCheck:result.requiresFreshConceptCheck,
      reason:routingReasonCode(result,await load(a))};
    console.log(JSON.stringify(output,null,2));
  } catch {console.error('CONCEPT_COMMAND_FAILED');process.exitCode=1;}
}
