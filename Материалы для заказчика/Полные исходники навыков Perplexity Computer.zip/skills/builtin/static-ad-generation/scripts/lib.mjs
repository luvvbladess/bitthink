// Higher-level composition helpers for render-ad, preflight and regression tests.
import fs from 'node:fs/promises';
import path from 'node:path';
import { validatePacket } from './concept-contract.mjs';
import { validateFidelityInputs, transformedBox } from './fidelity.mjs';
import {isRaster,validateRoutePlan,resolveProduction} from './image-first.mjs';
import {finishFirstVersion} from './run-continuation.mjs';
import {inspectFont} from './font-runtime.mjs';
import {sharp} from './raster-runtime.mjs';
import {assert, fingerprint, loadJSON, saveJSON, sha, skillRoot} from './runtime.mjs';

export {assert, fingerprint, loadJSON, saveJSON, sha, sharp, skillRoot};
export const overlaps = (a, b) => a[0] < b[0] + b[2] && a[0] + a[2] > b[0] &&
  a[1] < b[1] + b[3] && a[1] + a[3] > b[1];
const inside = (a, b) => a[0] >= b[0] && a[1] >= b[1] &&
  a[0] + a[2] <= b[0] + b[2] && a[1] + a[3] <= b[1] + b[3];
const num = (x, lo, hi) => Number.isFinite(x) && x >= lo && x <= hi;
const idOK = x => typeof x === 'string' && /^[a-z][a-z0-9_-]*$/i.test(x);
const colorOK = x => typeof x === 'string' && /^#[0-9a-f]{6}$/i.test(x);
const keys = (obj, allowed, where) => {
  assert(obj && typeof obj === 'object' && !Array.isArray(obj), `${where}: expected object`);
  for (const key of Object.keys(obj)) assert(allowed.includes(key), `${where}: unsupported field ${key}`);
};
const unique = (items, label) => {
  assert(Array.isArray(items), `${label}: expected array`);
  const ids = new Set();
  for (const item of items) {
    assert(idOK(item.id) && !ids.has(item.id), `${label}: invalid/duplicate id`);
    ids.add(item.id);
  }
};
const boxOK = box => Array.isArray(box) && box.length === 4 &&
  box.every(Number.isFinite) && box[2] > 0 && box[3] > 0;

// Public, executable whitelist: adding a property requires implementation + regression coverage.
export const capabilities = Object.freeze({
  group: ['group','fill','radius','borderWidth','borderColor'],
  shape: ['shape','fill','radius','borderWidth','borderColor','rotation'],
  image: ['image','assetId','fit','position','crop','radius','rotation'],
  text: ['text','copyId','fontId','fontSize','minFontSize','lineHeight','letterSpacing','wordSpacing','color','align','minContrast','contrastNote'],
  line: ['line','points','stroke','strokeWidth','rotation'],
  path: ['path','commands','stroke','strokeWidth','fill','rotation']
});

export function geometry(plan) {
  const byId = new Map(plan.zones.map(z => [z.id, z]));
  const absolute = new Map();
  const ancestors = (id, seen = new Set()) => {
    assert(!seen.has(id), 'PARENT_CYCLE'); seen.add(id);
    const zone = byId.get(id);
    if (!zone.parent) return [];
    const p = byId.get(zone.parent);
    assert(p && ['group','shape','image'].includes(p.type) && !p.rotation, `INVALID_PARENT ${id}`);
    assert(p.z < zone.z, `PARENT_LAYER ${id}`);
    return [p.id, ...ancestors(p.id, seen)];
  };
  for (const z of plan.zones) {
    const chain = ancestors(z.id);
    const b = [...z.box];
    for (const p of chain) { b[0] += byId.get(p).box[0]; b[1] += byId.get(p).box[1]; }
    absolute.set(z.id, b);
  }
  const errors = [];
  const canvas = [0, 0, plan.canvas.width, plan.canvas.height];
  for (const z of plan.zones) {
    const b = transformedBox(absolute.get(z.id), z.rotation);
    if (!inside(b, canvas)) errors.push(`OUTSIDE_CANVAS ${z.id}`);
    if (z.parent && !inside(b, absolute.get(z.parent))) errors.push(`OUTSIDE_PARENT ${z.id}`);
    for (const e of plan.exclusions || []) {
      if (e.roles.includes(z.role) && overlaps(b, e.box)) errors.push(`SAFE_AREA ${z.id} ${e.id}`);
    }
  }
  const declared = new Set();
  for (const pair of plan.overlaps || []) {
    const a = byId.get(pair.back), b = byId.get(pair.front);
    assert(a && b && a.z < b.z && pair.reason?.trim(), 'INVALID_LAYER_DECLARATION');
    declared.add([a.id, b.id].sort().join('|'));
  }
  for (let i = 0; i < plan.zones.length; i++) for (let j = i + 1; j < plan.zones.length; j++) {
    const a = plan.zones[i], b = plan.zones[j];
    if (!overlaps(transformedBox(absolute.get(a.id),a.rotation), transformedBox(absolute.get(b.id),b.rotation))) continue;
    if (ancestors(a.id).includes(b.id) || ancestors(b.id).includes(a.id)) continue;
    if (!declared.has([a.id, b.id].sort().join('|'))) errors.push(`UNDECLARED_OVERLAP ${a.id} ${b.id}`);
  }
  return { boxes: Object.fromEntries(absolute), errors };
}

export function validatePlan(p) {
  keys(p, ['schemaVersion', 'id', 'canvas', 'referencePacket', 'fonts', 'assets', 'zones', 'overlaps', 'exclusions', 'callouts',
    ...(p.schemaVersion===2 ? ['production','rasterRegions'] : [])], 'plan');
  assert([1,2].includes(p.schemaVersion) && idOK(p.id) && typeof p.referencePacket === 'string', 'PLAN_HEADER');
  keys(p.canvas, ['width', 'height', 'background'], 'canvas');
  assert(Number.isInteger(p.canvas.width) && num(p.canvas.width, 1, 4096) &&
    Number.isInteger(p.canvas.height) && num(p.canvas.height, 1, 4096) && colorOK(p.canvas.background), 'CANVAS');
  unique(p.fonts, 'fonts'); unique(p.assets, 'assets'); unique(p.zones, 'zones');
  if(p.schemaVersion===2) validateRoutePlan(p);
  assert(p.zones.length > 0 || isRaster(p), 'NO_ZONES');
  for (const f of p.fonts) {
    keys(f, ['id', 'path', 'weight', 'style', 'sourceId', 'sha256', 'substitution','expectedFamily','expectedPostScriptName'], 'font');
    assert(typeof f.path === 'string' && idOK(f.sourceId) && Number.isInteger(f.weight) &&
      num(f.weight, 100, 900) && ['normal', 'italic'].includes(f.style), 'FONT_SPEC');
    if (f.substitution) assert(f.substitution.requested && f.substitution.actual &&
      f.substitution.reason && f.substitution.disclosed === true, 'UNDISCLOSED_FONT_SUBSTITUTION');
    if(f.expectedFamily!==undefined)assert(typeof f.expectedFamily==='string' && f.expectedFamily.trim(),'FONT_EXPECTED_FAMILY');
    if(f.expectedPostScriptName!==undefined)assert(typeof f.expectedPostScriptName==='string' && f.expectedPostScriptName.trim(),'FONT_EXPECTED_POSTSCRIPT');
  }
  for (const a of p.assets) {
    keys(a, ['id', 'path', 'role', 'sourceId', 'sha256', 'component'], 'asset');
    assert(typeof a.path === 'string' && idOK(a.sourceId) &&
      ['product', 'logo', 'photo', 'evidence', 'illustration', 'component'].includes(a.role), 'ASSET_SPEC');
    if (a.role === 'component') {
      keys(a.component, ['origin','copyIds','fontIds','verification'], 'component');
      assert(a.component.origin?.trim() && a.component.verification?.trim() &&
        Array.isArray(a.component.copyIds) && Array.isArray(a.component.fontIds), 'COMPONENT_PROVENANCE');
    } else assert(a.component === undefined, 'UNEXPECTED_COMPONENT');
  }
  const zs = new Set();
  for (const z of p.zones) {
    const common = ['id', 'type', 'box', 'parent', 'z', 'role'];
    const specific = (capabilities[z.type] || []).filter(k => k !== z.type || k === 'text');
    keys(z, [...common, ...specific], `zone ${z.id}`);
    assert(capabilities[z.type] && boxOK(z.box), 'ZONE_TYPE_OR_BOX');
    assert(Number.isInteger(z.z) && !zs.has(z.z), 'Z_MUST_BE_UNIQUE_INTEGER'); zs.add(z.z);
    assert(idOK(z.role) && (!z.parent || idOK(z.parent)), 'ZONE_ROLE_OR_PARENT');
    if (z.type === 'shape') assert(colorOK(z.fill), 'SHAPE_FILL');
    if (z.type === 'group' && z.fill !== undefined) assert(colorOK(z.fill), 'GROUP_FILL');
    if (z.radius !== undefined) assert(num(z.radius,0,Math.min(z.box[2],z.box[3])/2), 'RADIUS');
    if (z.rotation !== undefined) assert(num(z.rotation,-180,180), 'ROTATION');
    if (z.borderWidth !== undefined || z.borderColor !== undefined)
      assert(num(z.borderWidth,.5,Math.min(z.box[2],z.box[3])/2) && colorOK(z.borderColor), 'BORDER');
    if (['line','path'].includes(z.type)) {
      assert(colorOK(z.stroke) && num(z.strokeWidth,.5,32), 'STROKE');
      if (z.fill !== undefined) assert(z.type === 'path' && colorOK(z.fill), 'PATH_FILL');
      const commands = z.type === 'line' ? z.points?.map((p,i) => [i ? 'L':'M',...p]) : z.commands;
      assert(Array.isArray(commands) && commands.length >= 2 && commands.length <= 128 && commands[0][0] === 'M', 'PATH_COMMANDS');
      for (const cmd of commands) {
        assert(Array.isArray(cmd) && ({M:3,L:3,Q:5,C:7,Z:1})[cmd[0]] === cmd.length, 'PATH_COMMAND');
        for (let i=1;i<cmd.length;i+=2) assert(num(cmd[i],z.strokeWidth/2,z.box[2]-z.strokeWidth/2) &&
          num(cmd[i+1],z.strokeWidth/2,z.box[3]-z.strokeWidth/2), 'PATH_BOUNDS');
      }
    }
    if (z.type === 'image') {
      assert(p.assets.some(a => a.id === z.assetId) && ['contain', 'cover'].includes(z.fit), 'IMAGE_SPEC');
      assert(Array.isArray(z.position) && z.position.length === 2 && z.position.every(x => num(x, 0, 100)), 'IMAGE_POSITION');
      if (z.crop !== undefined) assert(boxOK(z.crop) && z.crop.every(Number.isInteger) && z.crop[0] >= 0 && z.crop[1] >= 0, 'IMAGE_CROP');
    }
    if (z.type === 'text') {
      assert(typeof z.text === 'string' && z.text.trim() && idOK(z.copyId) &&
        p.fonts.some(f => f.id === z.fontId) && colorOK(z.color), 'TEXT_SPEC');
      assert(Number.isInteger(z.fontSize) && num(z.fontSize, 1, 512) &&
        Number.isInteger(z.minFontSize) && num(z.minFontSize, 1, z.fontSize), 'FONT_SIZE');
      assert(num(z.lineHeight, 0.8, 3) && num(z.letterSpacing, -10, 50) &&
        ['left', 'center', 'right'].includes(z.align), 'TEXT_STYLE');
      if(z.wordSpacing!==undefined)assert(num(z.wordSpacing,-10,50),'WORD_SPACING');
      assert([3, 4.5, 7].includes(z.minContrast) &&
        (z.minContrast !== 3 || z.contrastNote?.trim()), 'CONTRAST_THRESHOLD');
    }
  }
  unique(p.callouts || [], 'callouts');
  for (const c of p.callouts || []) {
    keys(c, ['id','featureId','imageZoneId','label','mode','points','bends','stroke','strokeWidth'], 'callout');
    keys(c.label, ['zoneId','anchor','offset','gap'], 'label anchor');
    assert(idOK(c.featureId) && idOK(c.imageZoneId) && idOK(c.label.zoneId) &&
      ['left','right','top','bottom'].includes(c.label.anchor) && num(c.label.offset ?? .5,0,1) &&
      num(c.label.gap ?? 2,0,8) && ['derived','fixed'].includes(c.mode) &&
      colorOK(c.stroke) && num(c.strokeWidth,1,16), 'CALLOUT_SPEC');
    assert(c.mode === 'fixed' ? Array.isArray(c.points) && !c.bends : !c.points, 'CALLOUT_MODE');
    const points = c.points || c.bends || [];
    assert(Array.isArray(points) && points.length <= 32 && points.every(p => Array.isArray(p) && p.length === 2 && p.every(Number.isFinite)), 'CALLOUT_POINTS');
  }
  for (const pair of p.overlaps || []) keys(pair, ['back', 'front', 'reason'], 'overlap');
  for (const e of p.exclusions || []) {
    keys(e, ['id', 'box', 'roles', 'basis'], 'exclusion');
    assert(idOK(e.id) && boxOK(e.box) && Array.isArray(e.roles) && e.roles.length &&
      e.roles.every(idOK) && e.basis?.trim(), 'EXCLUSION_SPEC');
  }
  const g = geometry(p);
  assert(!g.errors.length, g.errors.join('; '));
  if(isRaster(p)) for(const f of p.production.finishing) for(const id of f.zoneIds) {
    const z=p.zones.find(z=>z.id===id);
    assert(inside(transformedBox(g.boxes[id],z.rotation),f.box),`FINISHING_LAYER_OUTSIDE_REGION ${id}`);
  }
  return g;
}

export async function readInputs(planPath) {
  const bytes = await fs.readFile(planPath);
  const plan = JSON.parse(bytes);
  const geo = validatePlan(plan);
  const base = path.dirname(path.resolve(planPath));
  const packetPath = path.resolve(base, plan.referencePacket);
  const packetBytes = await fs.readFile(packetPath);
  const packet = JSON.parse(packetBytes);
  assert(packet.schemaVersion === 1 && idOK(packet.masterId) && packet.sources?.length &&
    Array.isArray(packet.selectedReferences) &&
    Array.isArray(packet.imageRoles) && Array.isArray(packet.invariants) &&
    Array.isArray(packet.allowedChanges) && Array.isArray(packet.copy), 'REFERENCE_PACKET');
  validatePacket(packet);
  unique(packet.sources, 'packet sources'); unique(packet.copy, 'packet copy');
  if(plan.schemaVersion===2) for(const c of packet.copy) {
    assert(typeof c.text==='string' && c.text.trim() && ['verified','non-factual'].includes(c.evidenceStatus) &&
      Array.isArray(c.sourceIds) && c.sourceIds.every(id=>packet.sources.some(s=>s.id===id)) &&
      (c.evidenceStatus!=='verified' || c.sourceIds.length),`GENERATED_COPY_UNVERIFIED ${c.id}`);
  }
  for (const z of plan.zones.filter(z => z.type === 'text')) {
    const copy = packet.copy.find(c => c.id === z.copyId);
    assert(copy && copy.text === z.text, `COPY_MISMATCH ${z.id}`);
    assert(['verified', 'non-factual'].includes(copy.evidenceStatus), `COPY_UNVERIFIED ${z.id}`);
    assert(Array.isArray(copy.sourceIds) && copy.sourceIds.every(id => packet.sources.some(s => s.id === id)), 'COPY_SOURCE');
    if (copy.evidenceStatus === 'verified') assert(copy.sourceIds.length, 'FACT_WITHOUT_SOURCE');
  }
  const loaded = [];
  if(plan.schemaVersion===2) {
    const m=await loadJSON(path.resolve(base,plan.production.manifestPath));
    if(finishFirstVersion(m))for(const f of plan.fonts.filter(f=>plan.zones.some(z=>z.fontId===f.id)))
      assert(f.expectedFamily && /^[a-f0-9]{64}$/.test(f.sha256 || ''),`EXACT_FONT_RECORD_REQUIRED ${f.id}`);
  }
  for (const item of [...plan.assets, ...plan.fonts]) {
    const source = packet.sources.find(s => s.id === item.sourceId);
    assert(source && ['owned', 'authorized'].includes(source.permissionStatus) &&
      source.permissionBasis?.trim(), `ASSET_PERMISSION ${item.id}`);
    const fullPath = path.resolve(base, item.path);
    const data = await fs.readFile(fullPath);
    const hash = sha(data);
    if (item.sha256) assert(item.sha256 === hash, `INPUT_HASH ${item.id}`);
    const isFont = plan.fonts.includes(item);
    let fontInspection;
    if(isFont && item.expectedFamily) {
      const text=plan.zones.filter(z=>z.fontId===item.id).map(z=>z.text).join('\n');
      const python=process.env.STATIC_AD_PYTHON || 'python3';
      fontInspection=await inspectFont({python,script:path.join(skillRoot,'scripts/font-inspect.py'),font:fullPath,
        family:item.expectedFamily,weight:item.weight,style:item.style,text});
      assert(fontInspection.sha256===hash,`FONT_BYTES_CHANGED ${item.id}`);
    }
    let dimensions;
    if (!isFont) {
      const m = await sharp(data).metadata();
      assert(['png', 'jpeg', 'webp'].includes(m.format) && !m.pages, `UNSUPPORTED_IMAGE ${item.id}`);
      assert(!m.orientation || m.orientation === 1, 'NORMALIZE_IMAGE_ORIENTATION');
      dimensions = [m.width,m.height];
      for (const z of plan.zones.filter(z => z.type === 'image' && z.assetId === item.id && z.crop))
        assert(inside(z.crop,[0,0,...dimensions]), 'IMAGE_CROP_BOUNDS');
      if (item.role === 'component') {
        assert(item.component.copyIds.every(id => packet.copy.some(c => c.id === id && ['verified','non-factual'].includes(c.evidenceStatus) &&
            Array.isArray(c.sourceIds) && c.sourceIds.every(id=>packet.sources.some(s=>s.id===id)) &&
            (c.evidenceStatus!=='verified' || c.sourceIds.length>0))) &&
          (!item.component.copyIds.length || item.component.fontIds.length>0) &&
          item.component.fontIds.every(id => plan.fonts.some(f => f.id === id)), 'COMPONENT_COPY_FONT');
      }
    }
    loaded.push({ ...item, fullPath, hash, data, isFont, ...(dimensions ? {dimensions} : {}),
      ...(fontInspection ? {fontInspection} : {}) });
  }
  const production=plan.schemaVersion===2 ? await resolveProduction(plan,packet,base) : null;
  await validateFidelityInputs(packet,plan,geo,path.dirname(packetPath),loaded,capabilities);
  return { plan, packet, geo, loaded, production, planHash: sha(bytes), packetHash: sha(packetBytes), packetPath };
}

const luminance = rgb => rgb.map(v => v / 255).map(v => v <= .04045 ? v / 12.92 : ((v + .055) / 1.055) ** 2.4)
  .reduce((n, v, i) => n + v * [.2126, .7152, .0722][i], 0);
export function localContrast(background, mask, final, color, threshold) {
  const rgb = color.slice(1).match(/../g).map(x => parseInt(x, 16));
  const fgLum = luminance(rgb), values = [];
  let failures = 0, occluded = 0;
  for (let i = 0; i < mask.length; i += 3) {
    if (mask[i] < 192) continue; // Glyph interiors, not a bounding-box mean.
    const bg = Array.from(background.subarray(i, i + 3)), bgLum = luminance(bg);
    const ratio = (Math.max(bgLum, fgLum) + .05) / (Math.min(bgLum, fgLum) + .05);
    values.push(ratio);
    if (ratio < threshold) failures++;
    const alpha = mask[i] / 255;
    // Opposite-polarity font antialiasing has different edge coverage. Only
    // compare fully covered cores; treat mismatch as a warning, not proof.
    if (mask[i] === 255 && rgb.some((v, c) => Math.abs(final[i + c] - (v * alpha + bg[c] * (1 - alpha))) > 18)) occluded++;
  }
  values.sort((a, b) => a - b);
  const quantile = q => values.length ? values[Math.floor((values.length - 1) * q)] : null;
  return { samples: values.length, minimum: quantile(0), p05: quantile(.05), median: quantile(.5),
    maximum: quantile(1), belowThreshold: failures, threshold, suspectedOccludedPixels: occluded,
    status: values.length && !failures ? 'pass' : 'fail',
    limits: 'Glyph interiors >=75% mask coverage only. Opposite-polarity antialiasing differs; occlusion is a warning heuristic only. No human legibility, photographic truth or accessibility certification.' };
}
