// Dependency-free runtime primitives shared by the static-ad domain modules.
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';

export const skillRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
export const canonicalJSON = value => JSON.stringify(value, (_, nested) =>
  nested && typeof nested === 'object' && !Array.isArray(nested) ?
    Object.fromEntries(Object.entries(nested).sort(([a], [b]) => a.localeCompare(b))) : nested);
export const sameJSON = (left, right) => canonicalJSON(left) === canonicalJSON(right);
export const loadJSON = async file => JSON.parse(await fs.readFile(file, 'utf8'));
export const saveJSON = async (file, data) => {
  await fs.mkdir(path.dirname(file), {recursive: true});
  await fs.writeFile(file, JSON.stringify(data, null, 2) + '\n');
};
export const assert = (condition, message) => { if (!condition) throw Error(message); };

export async function fingerprint(root = skillRoot) {
  const files = [];
  async function walk(dir) {
    for (const entry of (await fs.readdir(dir, {withFileTypes: true})).sort((a, b) => a.name < b.name ? -1 : 1)) {
      assert(!entry.isSymbolicLink(), 'PACKAGE_SYMLINK');
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) await walk(full);
      else if (entry.isFile()) files.push({path: path.relative(root, full).split(path.sep).join('/'), sha256: sha(await fs.readFile(full))});
    }
  }
  await walk(root);
  files.sort((a, b) => a.path < b.path ? -1 : 1);
  return {algorithm: 'sha256-sorted-path-and-file-hashes-v1', hash: sha(canonicalJSON(files)), files};
}
