import {validateProductionBudgets} from './image-first.mjs';
import {intakeAdmission} from './intake.mjs';
import {resolvePlacementProfile,validateProfile} from './placement.mjs';
import {finishFirstVersion,conceptPhase} from './run-continuation.mjs';
import {assert as check} from './runtime.mjs';

const text=x=>typeof x==='string' && !!x.trim();

export function admitGeneration(m,{kind,masterId,slotId=null,requestedImages=1,repairOf=null}) {
  check(['initial','repair'].includes(kind) && text(masterId) &&
    Number.isInteger(requestedImages) && requestedImages>0,'ADMISSION_REQUEST');
  check(finishFirstVersion(m),'FINISH_FIRST_RUN_REQUIRED');
  const intakeHold=intakeAdmission(m);if(intakeHold)return intakeHold;
  try {validateProductionBudgets(m);validateProfile(resolvePlacementProfile(m,{slotId,masterId}));} catch(e) {return {admitted:false,reason:e.message};}
  const calls=m.generationCalls,b=m.budgets,images=calls.reduce((n,c)=>n+c.imageCount,0);
  const initial=calls.filter(c=>!c.repairOf).reduce((n,c)=>n+c.imageCount,0);
  const reserveImages=Math.max(0,b.maxTotalGeneratedImages-b.maxInitialGeneratedImages);
  const reserveCalls=Math.max(0,b.maxGenerationCalls-b.maxInitialGeneratedImages);
  let reason=null;
  if(calls.length+1>b.maxGenerationCalls || images+requestedImages>b.maxTotalGeneratedImages)
    reason='TOTAL_IMAGE_OR_CALL_CAP';
  if(kind==='initial') {
    check(repairOf===null,'INITIAL_IS_NOT_REPAIR');
    if(initial+requestedImages>b.maxInitialGeneratedImages ||
      initial+requestedImages>b.maxCompleteRoughs)reason='INITIAL_IMAGE_OR_ROUGH_CAP';
    // Failed initial calls still cannot consume the positions reserved for repair.
    if(calls.filter(c=>!c.repairOf).length+1>b.maxGenerationCalls-reserveCalls ||
      initial+requestedImages>b.maxTotalGeneratedImages-reserveImages)reason='REPAIR_RESERVE';
  } else {
    const parent=calls.find(c=>c.id===repairOf && c.masterId===masterId && !c.repairOf);
    check(parent,'REPAIR_ORIGINAL_PARENT_REQUIRED');
    if(calls.filter(c=>c.masterId===masterId && c.repairOf).length>=b.maxGenerativeRepairsPerMaster)
      reason='GENERATIVE_REPAIR_CAP';
  }
  if(conceptPhase(m) && kind==='repair') {
    const s=m.slots.find(s=>slotId?s.id===slotId:s.masterId===masterId);
    if(!s?.concept?.repairs?.some(r=>r.kind==='generative' && r.repairOf===repairOf))reason='CONCEPT_MATERIAL_REPAIR_RESERVATION_REQUIRED';
  }
  return {admitted:!reason,reason,reserved:{calls:reserveCalls,images:reserveImages},
    remaining:{calls:b.maxGenerationCalls-calls.length,images:b.maxTotalGeneratedImages-images}};
}
