// Intake record controls, not intent recognition or proof that an answer/tool call occurred.
import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {currentConceptIdentity} from './run-continuation.mjs';
import {assert as check,sha} from './runtime.mjs';

const text=x=>typeof x==='string' && !!x.trim();
export const intakeIds=['creativeDirection','assetLibrary','guidelines'];
const resolved=new Set(['provided','declined','defaulted']);
const pending=new Set(['asked','awaiting-answer']);
const statuses=new Set(['unknown','missing',...resolved,...pending]);
const definitions=[
  {id:'creativeDirection',header:'Direction',
    question:'What do you have in mind for these ads? Share notes, a product or offer to focus on, or reference ads you like, or let me choose.',
    options:[
      {label:'Choose for me',description:'Research the brand and create different ad concepts.'},
      {label:'Promote an offer',description:'Build around the offer you specify in your notes.'},
      {label:'Iterate an existing ad',description:'Create variations of the ad you attach or identify.'}
    ]},
  {id:'assetLibrary',header:'Assets',
    question:'Do you have product photos, logos, or an asset library you would like me to use? Upload files or share a library URL.',
    options:[
      {label:'Use official assets',description:'Find suitable assets on the brand’s official website.'},
      {label:'Use attached assets only',description:'Use only the assets you supply for this task.'}
    ]},
  {id:'guidelines',header:'Guidelines',
    question:'Any brand guidelines, fonts, or colors to follow? Upload a guide or font files, share a URL, or add notes.',
    options:[
      {label:'Follow the website',description:'Infer the brand style from its official website.'},
      {label:'No specific guidelines',description:'Use the available brand evidence; no additional guide is required.'}
    ]}
].map(q=>({...q,allow_attachments:true,free_text_only:false,multi_select:false}));

export function intakePlan(s) {
  check(s && s.attachmentsChecked===true && s.reusableContextChecked===true,'CHECK_EXISTING_INPUTS_FIRST');
  check(text(s.taskKey),'INTAKE_TASK_KEY_REQUIRED');
  const official=typeof s.officialAssetsDecision==='string'
    ? {basis:s.officialAssetsDecision} : s.officialAssetsDecision;
  if(official)check(text(official.basis) && (official.scope===undefined ||
    Array.isArray(official.scope) && official.scope.length>0 &&
    official.scope.every(k=>['assetLibrary','guidelines'].includes(k))),'INTAKE_DECISION_BASIS');
  const defaults=s.defaultsDecision;
  if(defaults)check(text(defaults.basis) && text(defaults.taskKey) &&
    Array.isArray(defaults.scope) && defaults.scope.length>0 &&
    defaults.scope.every(k=>intakeIds.includes(k)),'INTAKE_DEFAULT_SCOPE');
  const effective={},questions=[],pendingIds=[],unresolvedIds=[];
  for(const definition of definitions) {
    const id=definition.id,record=s[id] || {status:'unknown'};
    check(record && statuses.has(record.status),'INTAKE_STATUS');
    if(!['unknown','missing'].includes(record.status))check(text(record.basis),'INTAKE_DECISION_BASIS');
    if(pending.has(record.status))check(text(record.taskKey),'PENDING_TASK_KEY_REQUIRED');
    // Brand knowledge can carry over; creative intent and outstanding prompts cannot.
    const stale=(id==='creativeDirection' && (resolved.has(record.status) || pending.has(record.status)) ||
      pending.has(record.status)) && record.taskKey!==s.taskKey;
    let input=stale?{status:'unknown'}:structuredClone(record);
    // Explicit field decisions/restrictions win over broader defaults.
    if(!resolved.has(input.status) && !pending.has(input.status)) {
      const useDefaults=defaults?.taskKey===s.taskKey && defaults.scope.includes(id);
      const useOfficial=id!=='creativeDirection' && official &&
        (!official.scope || official.scope.includes(id));
      if(useDefaults || useOfficial)input={status:'defaulted',
        basis:useDefaults?defaults.basis:official.basis,taskKey:s.taskKey};
    }
    effective[id]=input;
    if(resolved.has(input.status))continue;
    unresolvedIds.push(id);
    if(pending.has(input.status))pendingIds.push(id);
    else questions.push(structuredClone(definition));
  }
  const blockers=s.blockers ?? [];
  check(Array.isArray(blockers) && blockers.every(b=>text(b.id) && text(b.basis)),'INTAKE_BLOCKERS');
  if(s.cancelled===true)check(text(s.cancellationBasis),'INTAKE_CANCELLATION_BASIS');
  const status=s.cancelled===true?'cancelled':blockers.length?'blocked':
    pendingIds.length?'awaiting-answer':questions.length?'ask':'ready';
  const askQuestions=status==='ask'?questions:[];
  return {status,ready:status==='ready',unresolvedIds,pendingIds,blockers:structuredClone(blockers),
    effective,questions:askQuestions,
    form:status==='ask'?{
      title:'A little direction before I make the ads. You can use the defaults for anything you do not have.',
      questions:structuredClone(askQuestions)
    }:null};
}

// Retained array API for callers; an empty list is NOT proof of readiness. Use intakePlan.
export const intakeQuestions=s=>intakePlan(s).questions;
export function intakeAdmission(m) {
  if(!currentConceptIdentity(m))return null;
  try {
    const p=intakePlan(m.brandIntake);
    return p.ready?null:{admitted:false,reason:`INTAKE_${p.status.toUpperCase().replaceAll('-','_')}`,
      unresolvedIds:p.unresolvedIds,pendingIds:p.pendingIds,blockers:p.blockers};
  } catch(e) {return {admitted:false,reason:e.message};}
}

if(process.argv[1] && import.meta.url===pathToFileURL(path.resolve(process.argv[1])).href) {
  try {
    const [inputPath,effectivePath]=process.argv.slice(2);
    check(inputPath && effectivePath,'Usage: intake.mjs /run/intake.json /run/effective-intake.json');
    const result=intakePlan(JSON.parse(await fs.readFile(inputPath,'utf8')));
    const effectiveData=JSON.stringify(result.effective,null,2)+'\n',effectiveFile=path.resolve(effectivePath);
    await fs.writeFile(effectiveFile,effectiveData,{flag:'wx'});
    console.log(JSON.stringify({status:result.status,ready:result.ready,unresolvedIds:result.unresolvedIds,
      pendingIds:result.pendingIds,blockerIds:result.blockers.map(b=>b.id),
      effectiveArtifact:{path:effectiveFile,sha256:sha(effectiveData)},
      questions:result.questions,form:result.form},null,2));
  } catch {console.error('INTAKE_COMMAND_FAILED');process.exitCode=1;}
}
