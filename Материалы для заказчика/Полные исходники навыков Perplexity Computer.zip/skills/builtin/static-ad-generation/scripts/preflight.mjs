import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { readInputs } from './lib.mjs';
import {sharp} from './raster-runtime.mjs';
import {assert,canonicalJSON,loadJSON,sameJSON,saveJSON,sha} from './runtime.mjs';
import { resolveCallouts, validateRenderedFidelity } from './fidelity.mjs';
import {isRaster,verifyRasterExport,rasterMeasurements} from './image-first.mjs';
import {checkPlacement,placementRequired} from './placement.mjs';

export async function preflight(planPath, pngPath, metricsPath) {
  const errors = [], warnings = [];
  const input = await readInputs(planPath); // Revalidate sources, geometry, copy and local bytes.
  const metrics = await loadJSON(metricsPath);
  try { validateRenderedFidelity(input.packet,input.plan,metrics.texts || []); }
  catch(e) { errors.push(e.message); }
  const png = await fs.readFile(pngPath), actual = await sharp(png).metadata();
  if (actual.format !== 'png' || actual.width !== input.plan.canvas.width || actual.height !== input.plan.canvas.height) errors.push('EXPORT_DIMENSIONS_OR_FORMAT');
  if (metrics.planHash !== input.planHash) errors.push('PLAN_CHANGED');
  if (metrics.packetHash !== input.packetHash) errors.push('PACKET_CHANGED');
  if (metrics.exportHash !== sha(png)) errors.push('EXPORT_CHANGED');
  if(isRaster(input.plan)) {
    try {
      const {basePNG}=await verifyRasterExport(input.production,input.plan.canvas,png);
      const expected=await rasterMeasurements(input.production,basePNG,png);
      if(canonicalJSON(expected)!==canonicalJSON(metrics.raster))errors.push('RASTER_LINEAGE_OR_MEASUREMENTS_CHANGED');
      if(metrics.texts?.length!==input.plan.zones.filter(z=>z.type==='text').length)errors.push('FICTITIOUS_RASTER_TEXT_METRICS');
    } catch(e) {errors.push(e.message);}
    warnings.push('Inspect every baked-in word, offer, label and logo against evidence. No DOM/font/contrast check verifies generated text or identity; compare selected model output to final for finishing regression.');
  }
  for (const a of input.loaded) {
    if (!metrics.inputs?.some(i => i.id === a.id && i.isFont === a.isFont && i.hash === a.hash)) errors.push(`INPUT_CHANGED ${a.id}`);
  }
  try {
    const ink = Object.fromEntries((metrics.texts || []).map(t => [t.id,t.inkBox]));
    const expected = resolveCallouts(input.plan,input.packet,input.loaded,input.geo,ink);
    if (!sameJSON(expected,metrics.callouts || [])) errors.push('CALLOUT_GEOMETRY_CHANGED');
  } catch(e) { errors.push(e.message); }
  for (const z of input.plan.zones.filter(z => z.type === 'text')) {
    const m = metrics.texts?.find(m => m.id === z.id);
    if (!m?.fits || !Number.isFinite(m.size) || m.size < z.minFontSize || m.size > z.fontSize) errors.push(`TEXT_FIT ${z.id}`);
    if (!m?.renderedFonts?.length || m.renderedFonts.some(f => !f.isCustomFont)) errors.push(`FONT_USAGE ${z.id}`);
    const f=input.plan.fonts.find(f=>f.id===z.fontId);
    if(f.expectedFamily && !m?.renderedFonts?.every(x=>x.familyName===f.expectedFamily))errors.push(`FONT_RENDERED_FAMILY ${z.id}`);
    if(f.expectedPostScriptName && !m?.renderedFonts?.every(x=>x.postScriptName===f.expectedPostScriptName))errors.push(`FONT_RENDERED_POSTSCRIPT ${z.id}`);
    if(z.wordSpacing!==undefined || f.expectedFamily) {
      const t=m?.typography;
      if(!t || t.wordSpacingPx!==(z.wordSpacing ?? 0) || t.letterSpacingPx!==z.letterSpacing ||
        Math.abs(t.lineHeightPx-m.size*z.lineHeight)>.01 || t.fontWeight!==String(f.weight) ||
        t.fontStyle!==f.style || t.explicitLineCount!==z.text.split('\n').length)
        errors.push(`TYPOGRAPHY_MEASUREMENT ${z.id}`);
    }
    if (m?.contrast?.status !== 'pass' || !m.contrast.samples) errors.push(`LOCAL_CONTRAST ${z.id}`);
    if (m?.contrast?.suspectedOccludedPixels) warnings.push(`INSPECT_TEXT_OCCLUSION ${z.id}: core pixels differ; antialiasing can also cause mismatches`);
    if (m?.size < z.fontSize) warnings.push(`TEXT_FITTED ${z.id}: ${z.fontSize}px to ${m.size}px; inspect optical relationship`);
  }
  let placement=null;
  if(input.production?.manifestPath) {
    const m=await loadJSON(input.production.manifestPath),s=m.slots.find(s=>s.id===input.production.slotId);
    if(placementRequired(m))placement=await checkPlacement(m,s,path.dirname(input.production.manifestPath),png,metrics);
  }
  warnings.push('Manual gates remain: rights, actual brand font/artwork, truth, optical quality, thumbnail, label and reference parity. Technical pass does not imply placement clearance.');
  return { schemaVersion: 1, id: input.plan.id, status: errors.length ? 'fail' : 'pass',
    checkedAt: new Date().toISOString(), pngPath: path.resolve(pngPath), planPath: path.resolve(planPath),
    metricsPath: path.resolve(metricsPath), exportHash: sha(png),
    actualDimensions: [actual.width, actual.height], errors, warnings,...(placement?{placement}:{}),
    limits: 'Replays raster crop/export pixels and checks consistency of actual local-layer browser measurements; not an independent image judgment or tamper-proof certification. No DOM checks apply to baked-in text. Re-export/review after changes.' };
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  try {
    assert(process.argv.length === 6, 'Usage: node preflight.mjs plan.json final.png final.metrics.json report.json');
    const report = await preflight(...process.argv.slice(2, 5));
    await saveJSON(process.argv[5], report); console.log(JSON.stringify(report, null, 2));
    if (report.status !== 'pass') process.exitCode = 1;
  } catch { console.error('PREFLIGHT_COMMAND_FAILED'); process.exitCode = 1; }
}
