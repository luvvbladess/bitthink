import fs from 'node:fs/promises';
import path from 'node:path';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
import { readInputs, localContrast } from './lib.mjs';
import {sharp} from './raster-runtime.mjs';
import {assert,saveJSON,sha} from './runtime.mjs';
import { preflight } from './preflight.mjs';
import { resolveCallouts } from './fidelity.mjs';
import {isRaster,rasterBase,rasterMeasurements,verifyRasterExport,exportReceipt,imageFirstVersion} from './image-first.mjs';
import {placementRequired,renderPlacement,resolvePlacementProfile} from './placement.mjs';

// Preserve failed schema-2 attempts in the existing failures array, never in another ledger.
async function retainRenderFailure(planPath,stem,error,startedAt) {
  try {
    const p=JSON.parse(await fs.readFile(planPath,'utf8'));
    if(p.schemaVersion!==2 || !p.production?.manifestPath)return;
    const file=path.resolve(path.dirname(path.resolve(planPath)),p.production.manifestPath);
    const m=JSON.parse(await fs.readFile(file,'utf8'));
    if(!imageFirstVersion(m))return;
    const s=m.slots.find(s=>s.id===p.production.slotId);if(!s)return;
    const exports=s.production?.exports || [],output=path.resolve(`${stem}.png`);
    m.failures ||= [];
    m.failures.push({kind:'render',slotId:s.id,planPath:path.resolve(planPath),outputPath:output,startedAt,
      failedAt:new Date().toISOString(),reason:error,
      // An export receipt already consumes its pass; do not double-count it, or a repeated stem.
      countsAsRepair:exports.length>0 && !exports.some(e=>e.file===output) && error!=='EXPORT_NEW_STEM_REQUIRED'});
    await fs.writeFile(file,JSON.stringify(m,null,2)+'\n');
  } catch {console.error('RENDER_FAILURE_RETENTION_FAILED');}
}
export async function render(planPath,stem) {
  const proposed=JSON.parse(await fs.readFile(planPath,'utf8'));
  if(proposed.schemaVersion===3 && proposed.purpose==='ad-concept') {
    const {exportConcept}=await import('./concept-first.mjs');
    const record=await exportConcept(path.resolve(path.dirname(path.resolve(planPath)),proposed.manifestPath),proposed.input,stem);
    return {concept:record,report:{status:'concept-exported',errors:[],note:'Actual image/source correctness check still required; not final clearance'}};
  }
  const startedAt=new Date().toISOString();
  try {
    const result=await renderImpl(planPath,stem);
    if(result.report.status!=='pass')await retainRenderFailure(planPath,stem,result.report.errors.join('; '),startedAt);
    return result;
  } catch(e) {await retainRenderFailure(planPath,stem,e.message,startedAt);throw e;}
}
export function renderSucceeded(status) {
  return status === 'pass' || status === 'concept-exported';
}
async function renderImpl(planPath, stem) {
  const started = Date.now();
  const p=JSON.parse(await fs.readFile(planPath,'utf8'));
  if(p.schemaVersion===2) {
    const {conceptPhase}=await import('./run-continuation.mjs');
    const m=JSON.parse(await fs.readFile(path.resolve(path.dirname(path.resolve(planPath)),p.production.manifestPath),'utf8'));
    assert(!conceptPhase(m),'CONCEPT_USE_NATIVE_EXPORT_PLAN_OR_SELECT_FINALS');
  }
  const input = await readInputs(planPath);
  const { plan, geo, loaded } = input;
  const basePNG=isRaster(plan) ? await rasterBase(input.production,plan.canvas) : null;
  const finish = async (finalPNG,measurement,environment,callouts=[],labelInk={}) => {
    const metadata=await sharp(finalPNG).metadata();
    assert(metadata.width===plan.canvas.width && metadata.height===plan.canvas.height,'EXPORT_DIMENSIONS');
    if(basePNG) await verifyRasterExport(input.production,plan.canvas,finalPNG);
    const metrics={schemaVersion:plan.schemaVersion,id:plan.id,planHash:input.planHash,packetHash:input.packetHash,
      exportHash:sha(finalPNG),exportDimensions:[metadata.width,metadata.height],geometry:geo,callouts,labelInk,
      ...measurement,inputs:loaded.map(({data,...a})=>a),environment,runtimeSeconds:(Date.now()-started)/1000,
      ...(basePNG ? {raster:await rasterMeasurements(input.production,basePNG,finalPNG)} : {})};
    await fs.mkdir(path.dirname(path.resolve(stem)),{recursive:true});
    if(plan.schemaVersion===2) {
      // Never let exporting overwrite selected originals, prior exports or review inputs.
      for(const file of [`${stem}.png`,`${stem}.metrics.json`,`${stem}.preflight.json`])
        try {await fs.access(file);throw Error('EXPORT_NEW_STEM_REQUIRED');} catch(e) {if(e.code!=='ENOENT')throw e;}
      const m=JSON.parse(await fs.readFile(input.production.manifestPath,'utf8'));
      if(placementRequired(m))metrics.placement=await renderPlacement(resolvePlacementProfile(m,{slotId:plan.production.slotId}),finalPNG,stem);
      await exportReceipt(plan,input.packet,path.dirname(path.resolve(planPath)),metrics,stem);
    }
    await fs.writeFile(`${stem}.png`,finalPNG);
    await saveJSON(`${stem}.metrics.json`,metrics);
    const report=await preflight(planPath,`${stem}.png`,`${stem}.metrics.json`);
    await saveJSON(`${stem}.preflight.json`,report);
    return {metrics,report};
  };
  if(plan.production?.route==='native-raster') return finish(basePNG,{texts:[],loadedFontIds:[]},
    {node:process.version,chromium:null,renderer:'native-raster-v1'});
  const {chromium}=createRequire(import.meta.url)('playwright');
  const browser = await chromium.launch({ headless: true, channel: 'chromium',
    ...(process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH ? { executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH } : {}) });
  try {
    const page = await browser.newPage({ viewport: { width: plan.canvas.width, height: plan.canvas.height }, deviceScaleFactor: 1 });
    await page.route('**/*', route => route.abort()); // Rendering never downloads assets or executes supplied HTML.
    await page.setContent('<!doctype html><html><head><meta charset="utf-8"></head><body></body></html>');
    const resources = loaded.map(a => ({ id: a.id, isFont: a.isFont, weight: a.weight, style: a.style,
      uri: `data:${a.isFont ? 'application/octet-stream' : 'image/' + (path.extname(a.path).slice(1) === 'jpg' ? 'jpeg' : path.extname(a.path).slice(1))};base64,${a.data.toString('base64')}` }));
    if(basePNG)resources.push({rasterBase:true,uri:`data:image/png;base64,${basePNG.toString('base64')}`});
    for (const z of plan.zones.filter(z => z.type === 'image' && z.crop)) {
      const a = loaded.find(a => !a.isFont && a.id === z.assetId), [left,top,width,height] = z.crop;
      const data = await sharp(a.data).extract({left,top,width,height}).png().toBuffer();
      resources.push({zoneId:z.id,uri:`data:image/png;base64,${data.toString('base64')}`});
    }
    const measurement = await page.evaluate(async ({ plan, boxes, resources }) => {
      const css = document.createElement('style');
      css.textContent = '*{box-sizing:border-box}html,body{margin:0;padding:0}body{overflow:hidden}';
      document.head.appendChild(css);
      const board = document.createElement('div');
      board.id = 'board';
      Object.assign(board.style, { position: 'relative', width: `${plan.canvas.width}px`,
        height: `${plan.canvas.height}px`, backgroundColor: plan.canvas.background, overflow: 'hidden' });
      document.body.appendChild(board);
      const base=resources.find(r=>r.rasterBase);
      if(base) {
        // This is the actual selected model output, not an invented full-canvas image zone.
        const img=document.createElement('img');img.id='raster-base';img.src=base.uri;
        Object.assign(img.style,{position:'absolute',inset:'0',width:'100%',height:'100%',zIndex:'-2147483648'});
        // Isolate the stacking context so negative-z base stays above the board background.
        board.style.isolation='isolate';board.appendChild(img);await img.decode();
      }
      const fontFaces = {};
      for (const f of plan.fonts.filter(f => plan.zones.some(z => z.fontId === f.id))) {
        const r = resources.find(r => r.id === f.id && r.isFont);
        const family = `rf_${f.id}`;
        const face = new FontFace(family, `url("${r.uri}")`, { weight: String(f.weight), style: f.style });
        await face.load(); document.fonts.add(face);
        if (face.status !== 'loaded') throw Error(`FONT_NOT_LOADED ${f.id}`);
        fontFaces[f.id] = family;
      }
      await document.fonts.ready;
      const texts = [];
      for (const z of [...plan.zones].sort((a, b) => a.z - b.z)) {
        const box = boxes[z.id], outer = document.createElement('div');
        outer.id = `zone_${z.id}`; outer.dataset.zone = z.id;
        Object.assign(outer.style, { position: 'absolute', left: `${box[0]}px`, top: `${box[1]}px`,
          width: `${box[2]}px`, height: `${box[3]}px`, zIndex: String(z.z) });
        if (z.fill) outer.style.backgroundColor = z.fill;
        if (z.radius !== undefined) outer.style.borderRadius = `${z.radius}px`;
        if (z.rotation) outer.style.transform = `rotate(${z.rotation}deg)`;
        if (z.borderWidth) {
          // Inset border does not change the measured content box.
          const border = document.createElement('div');
          Object.assign(border.style,{position:'absolute',inset:'0',border:`${z.borderWidth}px solid ${z.borderColor}`,
            borderRadius:`${z.radius || 0}px`,pointerEvents:'none'});
          outer.appendChild(border);
        }
        board.appendChild(outer);
        if (z.type === 'image') {
          outer.style.overflow = 'hidden';
          const img = document.createElement('img');
          img.src = (resources.find(r => r.zoneId === z.id) || resources.find(r => r.id === z.assetId && !r.isFont)).uri;
          Object.assign(img.style, { display: 'block', width: '100%', height: '100%',
            objectFit: z.fit, objectPosition: `${z.position[0]}% ${z.position[1]}%` });
          outer.appendChild(img); await img.decode();
          if (!img.naturalWidth) throw Error(`IMAGE_DECODE ${z.id}`);
        }
        if (['line','path'].includes(z.type)) {
          outer.style.backgroundColor = 'transparent';
          const svg = document.createElementNS('http://www.w3.org/2000/svg','svg');
          svg.setAttribute('width',box[2]); svg.setAttribute('height',box[3]);
          const p = document.createElementNS(svg.namespaceURI,'path');
          const commands = z.type === 'line' ? z.points.map((p,i) => [i ? 'L':'M',...p]) : z.commands;
          p.setAttribute('d',commands.map(c => c.join(' ')).join(' '));
          p.setAttribute('stroke',z.stroke); p.setAttribute('stroke-width',z.strokeWidth);
          p.setAttribute('stroke-linecap','round'); p.setAttribute('stroke-linejoin','round');
          p.setAttribute('fill',z.fill || 'none'); svg.appendChild(p); outer.appendChild(svg);
        }
        if (z.type !== 'text') continue;
        const f = plan.fonts.find(f => f.id === z.fontId);
        const text = document.createElement('div');
        text.id = `text_${z.id}`;
        text.textContent = z.text; // Never innerHTML, interpolated markup or user CSS.
        Object.assign(text.style, { width: '100%', fontFamily: fontFaces[f.id], fontWeight: String(f.weight),
          fontStyle: f.style, fontSynthesis: 'none', lineHeight: String(z.lineHeight),
          letterSpacing: `${z.letterSpacing}px`, wordSpacing: `${z.wordSpacing ?? 0}px`, color: z.color, textAlign: z.align,
          whiteSpace: 'pre-wrap', overflowWrap: 'normal' });
        outer.appendChild(text);
        await document.fonts.load(`${f.style} ${f.weight} ${z.fontSize}px "${fontFaces[f.id]}"`, z.text);
        const measure = size => {
          text.style.fontSize = `${size}px`;
          const r = document.createRange(); r.selectNodeContents(text);
          const rects = [...r.getClientRects()].map(r => ({ x: r.x, y: r.y, width: r.width, height: r.height }));
          const natural = text.getBoundingClientRect();
          const fits = natural.height <= box[3] + .01 && text.scrollWidth <= box[2] + .01 &&
            rects.every(r => r.x >= box[0] - .01 && r.x + r.width <= box[0] + box[2] + .01);
          return { size, fits, lineRects: rects, naturalHeight: natural.height, scrollWidth: text.scrollWidth };
        };
        // Explicit floor failure; never return an overflowing minimum size.
        let best = measure(z.minFontSize);
        if (!best.fits) throw Error(`TEXT_OVERFLOW ${z.id} at minimum ${z.minFontSize}px`);
        let lo = z.minFontSize + 1, hi = z.fontSize;
        while (lo <= hi) {
          const mid = Math.floor((lo + hi) / 2), m = measure(mid);
          if (m.fits) { best = m; lo = mid + 1; } else hi = mid - 1;
        }
        best = measure(best.size);
        const computed=getComputedStyle(text),wordRects=[];
        for(const [wordIndex,word] of [...z.text.matchAll(/\S+/g)].entries()) {
          const range=document.createRange();
          range.setStart(text.firstChild,word.index);range.setEnd(text.firstChild,word.index+word[0].length);
          wordRects.push({wordIndex,rects:[...range.getClientRects()].map(r=>({x:r.x,y:r.y,width:r.width,height:r.height}))});
        }
        texts.push({ id: z.id, fontId: z.fontId, requestedSize: z.fontSize, ...best,
          typography:{fontFamily:computed.fontFamily,fontWeight:computed.fontWeight,fontStyle:computed.fontStyle,
            lineHeightPx:parseFloat(computed.lineHeight),letterSpacingPx:parseFloat(computed.letterSpacing)||0,
            wordSpacingPx:parseFloat(computed.wordSpacing)||0,explicitLineCount:z.text.split('\n').length,wordRects} });
      }
      await document.fonts.ready;
      await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
      return { texts, loadedFontIds: Object.keys(fontFaces) };
    }, { plan, boxes: geo.boxes, resources });
    const cdp = await page.context().newCDPSession(page);
    await cdp.send('DOM.enable'); await cdp.send('CSS.enable');
    const doc = await cdp.send('DOM.getDocument');
    for (const t of measurement.texts) {
      const { nodeId } = await cdp.send('DOM.querySelector', { nodeId: doc.root.nodeId, selector: `#text_${t.id}` });
      const { fonts } = await cdp.send('CSS.getPlatformFontsForNode', { nodeId });
      t.renderedFonts = fonts;
      assert(fonts.length && fonts.every(f => f.isCustomFont && f.glyphCount > 0), `FONT_FALLBACK ${t.id}`);
      const expected=plan.fonts.find(f=>f.id===t.fontId);
      if(expected.expectedFamily)assert(fonts.every(f=>f.familyName===expected.expectedFamily),`FONT_RENDERED_FAMILY ${t.id}`);
      if(expected.expectedPostScriptName)assert(fonts.every(f=>f.postScriptName===expected.expectedPostScriptName),`FONT_RENDERED_POSTSCRIPT ${t.id}`);
    }
    const screenshot = () => page.screenshot({ type: 'png', animations: 'disabled' });
    const raw = async png => (await sharp(png).removeAlpha().raw().toBuffer());
    const labelInk = {};
    for (const id of new Set((plan.callouts || []).map(c => c.label.zoneId))) {
      const z = plan.zones.find(z => z.id === id);
      assert(z?.type === 'text', 'CALLOUT_LABEL');
      await page.evaluate(id => {
        for (const el of document.querySelectorAll('[data-zone]')) el.style.visibility = el.dataset.zone === id ? 'visible' : 'hidden';
        document.getElementById('board').style.backgroundColor = '#000000';
        const base=document.getElementById('raster-base');if(base)base.style.visibility='hidden';
        document.getElementById(`text_${id}`).style.color = '#ffffff';
      },id);
      const pixels = await raw(await screenshot());
      let l=plan.canvas.width,t=plan.canvas.height,r=-1,b=-1;
      for (let i=0;i<pixels.length;i+=3) if (pixels[i] > 0) {
        const n=i/3,x=n%plan.canvas.width,y=Math.floor(n/plan.canvas.width);
        l=Math.min(l,x);r=Math.max(r,x);t=Math.min(t,y);b=Math.max(b,y);
      }
      labelInk[id]=[l,t,r-l+1,b-t+1];
      await page.evaluate(({id,color,bg}) => {
        for (const el of document.querySelectorAll('[data-zone]')) el.style.visibility='visible';
        document.getElementById('board').style.backgroundColor=bg;
        const base=document.getElementById('raster-base');if(base)base.style.visibility='visible';
        document.getElementById(`text_${id}`).style.color=color;
      },{id,color:z.color,bg:plan.canvas.background});
    }
    const callouts = resolveCallouts(plan,input.packet,loaded,geo,labelInk);
    await page.evaluate(({callouts,width,height,zIndex}) => {
      for (const c of callouts) {
        const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');
        svg.dataset.zone=`callout_${c.id}`;
        svg.setAttribute('width',width);svg.setAttribute('height',height);
        Object.assign(svg.style,{position:'absolute',left:'0',top:'0',pointerEvents:'none',zIndex:String(zIndex)});
        const p=document.createElementNS(svg.namespaceURI,'polyline');
        p.setAttribute('points',c.points.map(p=>p.join(',')).join(' '));
        p.setAttribute('stroke',c.stroke);p.setAttribute('stroke-width',c.strokeWidth);
        p.setAttribute('stroke-linecap','round');p.setAttribute('stroke-linejoin','round');p.setAttribute('fill','none');
        svg.appendChild(p);document.getElementById('board').appendChild(svg);
      }
    },{callouts,width:plan.canvas.width,height:plan.canvas.height,zIndex:Math.max(...plan.zones.map(z=>z.z))+1});
    let finalPNG = await screenshot();
    if(basePNG) {
      // Copy only documented patch windows; no browser color/render drift outside them reaches export.
      const patches=await Promise.all(plan.production.finishing.map(async f=>{
        const [left,top,width,height]=f.box;
        return {input:await sharp(finalPNG).extract({left,top,width,height}).png().toBuffer(),left,top};
      }));
      finalPNG=await sharp(basePNG).composite(patches).png().toBuffer();
    }
    const finalRaw = await raw(finalPNG);
    for (const t of measurement.texts) {
      const z = plan.zones.find(z => z.id === t.id);
      await page.evaluate(id => { document.getElementById(`zone_${id}`).style.visibility = 'hidden'; }, t.id);
      const background = await raw(await screenshot());
      await page.evaluate(({ id }) => {
        for (const el of document.querySelectorAll('[data-zone]')) el.style.visibility = el.dataset.zone === id ? 'visible' : 'hidden';
        document.getElementById('board').style.backgroundColor = '#000000';
        const base=document.getElementById('raster-base');if(base)base.style.visibility='hidden';
        document.getElementById(`text_${id}`).style.color = '#ffffff';
      }, { id: t.id });
      const mask = await raw(await screenshot());
      // Range rectangles include font leading, not just ink. Inspect actual glyph
      // pixels separately instead of rejecting legitimate ascender/leading metrics.
      let left = plan.canvas.width, top = plan.canvas.height, right = -1, bottom = -1;
      for (let i = 0; i < mask.length; i += 3) if (mask[i] > 0) {
        const pixel = i / 3, x = pixel % plan.canvas.width, y = Math.floor(pixel / plan.canvas.width);
        left = Math.min(left, x); right = Math.max(right, x);
        top = Math.min(top, y); bottom = Math.max(bottom, y);
      }
      const box = geo.boxes[t.id];
      t.inkBox = [left, top, right - left + 1, bottom - top + 1];
      assert(right >= left && left >= Math.floor(box[0]) && top >= Math.floor(box[1]) &&
        right + 1 <= Math.ceil(box[0] + box[2]) && bottom + 1 <= Math.ceil(box[1] + box[3]), `TEXT_INK_OVERFLOW ${t.id}`);
      assert(left > 0 && top > 0 && right < plan.canvas.width - 1 && bottom < plan.canvas.height - 1,
        `TEXT_AT_EXPORT_EDGE ${t.id}: move inward to rule out clipped ink`);
      t.contrast = localContrast(background, mask, finalRaw, z.color, z.minContrast);
      await page.evaluate(({ id, color, background }) => {
        for (const el of document.querySelectorAll('[data-zone]')) el.style.visibility = 'visible';
        document.getElementById('board').style.backgroundColor = background;
        const base=document.getElementById('raster-base');if(base)base.style.visibility='visible';
        document.getElementById(`text_${id}`).style.color = color;
      }, { id: t.id, color: z.color, background: plan.canvas.background });
    }
    return finish(finalPNG,measurement,{node:process.version,chromium:browser.version(),
      renderer:basePNG?'raster-local-finishing-v1':'playwright-css-zones-v1'},callouts,labelInk);
  } finally { await browser.close(); }
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  try {
    assert(process.argv.length === 4, 'Usage: node render-ad.mjs plan.json /output/stem');
    const result = await render(process.argv[2], process.argv[3]),{report}=result;
    const output=report.status==='concept-exported'?
      {status:report.status,pngPath:result.concept.export.path,sha256:result.concept.export.sha256,errors:report.errors}:
      {status:report.status,pngPath:`${process.argv[3]}.png`,metricsPath:`${process.argv[3]}.metrics.json`,
        preflightPath:`${process.argv[3]}.preflight.json`,errors:report.errors,warnings:report.warnings};
    console.log(JSON.stringify(output, null, 2));
    if (!renderSucceeded(report.status)) process.exitCode = 1;
  } catch { console.error('RENDER_COMMAND_FAILED'); process.exitCode = 1; }
}
