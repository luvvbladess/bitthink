// Paid-image placement mechanics, not authenticated vision, OCR completeness or Meta certification.
// No network, account writes or model calls. All adaptations require their own final-pixel evidence.
import {executionVersion,integrationVersion} from './run-continuation.mjs';
import fs from 'node:fs/promises';
import path from 'node:path';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {pathToFileURL} from 'node:url';
import {sharp} from './raster-runtime.mjs';
import {assert as check,canonicalJSON,loadJSON as load,sha as hash} from './runtime.mjs';
const run=promisify(execFile);
const text=x=>typeof x==='string' && !!x.trim();
const date=x=>text(x) && Number.isFinite(Date.parse(x)) && Date.parse(x)<=Date.now();
const box=b=>Array.isArray(b) && b.length===4 && b.every(Number.isFinite) && b[2]>0 && b[3]>0;
const inside=(b,o)=>box(b) && b[0]>=o[0] && b[1]>=o[1] && b[0]+b[2]<=o[0]+o[2] && b[1]+b[3]<=o[1]+o[3];
const metaVersion='meta-paid-image-2026-09-10';
const metaHelp='https://www.facebook.com/business/help/980593475366490';
const metaGuides={
  'instagram-story':'https://www.facebook.com/business/ads-guide/update/image/instagram-story',
  'facebook-story':'https://www.facebook.com/business/ads-guide/update/image/facebook-story',
  'instagram-reels':'https://www.facebook.com/business/ads-guide/update/image/instagram-reels',
  'facebook-reels':'https://www.facebook.com/business/ads-guide/update/image/facebook-facebook-reels'
};
const tiktokVersion='tiktok-ad-network-image-2026-09-15';
const tiktokHelp='https://ads.tiktok.com/resources/help/article/specifications-for-pangle-ad-assets';
const tiktokImageSizes=new Set(['1200x628','640x640','720x1280']);
export const placementRequired=m=>{
  if(!m)return false;
  const v=executionVersion(m);
  if(integrationVersion(m))return true;
  if(['1.5.0-private.2','1.5.0-private.3','1.5.0','1.6.0'].includes(v))return false;
  const n=/^(\d+)\.(\d+)\.(\d+)$/.exec(v || '');
  check(n && (+n[1]>1 || +n[1]===1 && +n[2]>=7),'UNSUPPORTED_PLACEMENT_RUN_VERSION');
  return true;
};
export const profileHash=p=>hash(canonicalJSON(p));
export function resolvePlacementProfile(m,{slotId=null,masterId=null,call=null}={}) {
  if(call?.placementBindingSha256) {
    const b=m.placementBindings?.find(x=>x.callId===call.id);
    check(b && b.artifact.sha256===call.placementBindingSha256 && b.slotId===call.slotId &&
      b.masterId===call.masterId && b.profileSha256===profileHash(b.profile),'PLACEMENT_CALL_BINDING_CHANGED');
    validateProfile(b.profile);return b.profile;
  }
  if(call && m.continuation?.inheritedCallIds?.includes(call.id))return m.continuation.sourcePlacementProfile;
  const slots=m.slots || [],matches=slots.filter(s=>slotId?s.id===slotId:masterId && s.masterId===masterId);
  check(!slotId || matches.length===1,'PLACEMENT_SLOT_REQUIRED');
  check(matches.length<=1,'PLACEMENT_MASTER_SLOT_AMBIGUOUS');
  const p=matches[0]?.placementProfile ?? m.placementProfile;
  validateProfile(p);return p;
}
export async function bindPlacement(m,base,{callId,slotId,masterId}) {
  const {integrationVersion,validateContinuation}=await import('./run-continuation.mjs');
  check(integrationVersion(m),'PLACEMENT_BINDING_VERSION');await validateContinuation(m);
  check(/^[a-z0-9_-]+$/i.test(callId || '') && text(masterId) &&
    !m.generationCalls.some(c=>c.id===callId) && !(m.placementBindings || []).some(b=>b.callId===callId),
    'PLACEMENT_BINDING_APPEND_ONLY');
  const s=m.slots.find(s=>s.id===slotId);check(s && (!s.masterId || s.masterId===masterId),'PLACEMENT_SLOT_MASTER');
  const p=resolvePlacementProfile(m,{slotId}),h=profileHash(p);
  check(p.width===m.request.width && p.height===m.request.height,'PLACEMENT_REQUEST_DIMENSIONS');
  check((m.placementBindings || []).filter(b=>b.slotId===slotId).every(b=>b.profileSha256===h),
    'PLACEMENT_PROFILE_FROZEN');
  const b={callId,slotId,masterId,createdAt:new Date().toISOString(),profile:structuredClone(p),profileSha256:h};
  const bytes=Buffer.from(JSON.stringify(b,null,2)+'\n'),dir=path.join(base,'placement-bindings');
  await fs.mkdir(dir,{recursive:true});const file=path.join(dir,`${callId}.json`);
  await fs.writeFile(file,bytes,{flag:'wx'});
  s.masterId=masterId;m.placementBindings ||= [];m.placementBindings.push({...b,artifact:{path:file,sha256:hash(bytes)}});
  return {slotId,placementBindingSha256:hash(bytes),placementProfileSha256:h,createdAt:b.createdAt};
}
export async function validatePlacementBinding(m,c,base) {
  const {integrationVersion}=await import('./run-continuation.mjs');
  if(!integrationVersion(m) || m.continuation?.inheritedCallIds?.includes(c.id))return;
  const b=m.placementBindings?.find(x=>x.callId===c.id);
  check(b && c.placementBindingSha256===b.artifact?.sha256,'PLACEMENT_BEFORE_CALL_BINDING_REQUIRED');
  const a=await pin(base,b.artifact,'PLACEMENT_BINDING_ARTIFACT_CHANGED'),v=JSON.parse(a.data);
  check(canonicalJSON(v)===canonicalJSON(Object.fromEntries(Object.entries(b).filter(([k])=>k!=='artifact'))) &&
    c.slotId===b.slotId && c.masterId===b.masterId && b.profileSha256===profileHash(b.profile) &&
    date(b.createdAt) && Date.parse(b.createdAt)<=Date.parse(c.startedAt),'PLACEMENT_BINDING_CHANGED_OR_LATE');
  resolvePlacementProfile(m,{call:c});
}
export function safeBox(p) {
  const {width:w,height:h,insetsPercent:i}=p;
  check(Number.isInteger(w) && Number.isInteger(h) && w>0 && h>0 && i &&
    ['top','bottom','left','right'].every(k=>Number.isInteger(i[k]) && i[k]>=0 && i[k]<100) &&
    i.left+i.right<100 && i.top+i.bottom<100,'PLACEMENT_BOUNDARIES');
  // Integer products first: floor(H*60/100), never H*(1-.4).
  const x=Math.ceil(w*i.left/100),y=Math.ceil(h*i.top/100);
  return [x,y,Math.floor(w*(100-i.right)/100)-x,Math.floor(h*(100-i.bottom)/100)-y];
}
export function validateProfile(p) {
  const meta=p?.platform==='meta' &&
    [...Object.keys(metaGuides),'instagram-feed','facebook-feed'].includes(p.paidPlacement);
  const tiktok=p?.platform==='tiktok' && p.paidPlacement==='tiktok-ad-network-image';
  check(p?.schemaVersion===1 && (meta || tiktok),'NAMED_PAID_PLACEMENT_REQUIRED');
  check(typeof p.hasDisclaimer==='boolean','PLACEMENT_SOURCE_VERSION');
  const vertical=meta && Object.hasOwn(metaGuides,p.paidPlacement),b=safeBox(p);
  if(vertical) {
    const bottom=p.paidPlacement.endsWith('reels') && p.hasDisclaimer?40:35;
    check(p.width*16===p.height*9,'NAMED_9_BY_16_PLACEMENT_DIMENSIONS');
    check(p.boundaryKind==='meta-recommendation' &&
      canonicalJSON(p.insetsPercent)===canonicalJSON({top:14,bottom,left:6,right:6}) &&
      p.source.url===metaGuides[p.paidPlacement] && p.source.version===metaVersion &&
      p.source.verifiedAt==='2026-09-10' && p.source.method==='indexed-meta-page-text' &&
      (!p.hasDisclaimer || !p.paidPlacement.endsWith('reels') || p.source.disclaimerUrl===metaHelp),
      'PLACEMENT_POLICY_MISMATCH');
  } else if(meta) {
    check(p.boundaryKind==='house' && text(p.houseBasis) && p.source.url===metaHelp &&
      p.source.version===metaVersion && p.source.verifiedAt==='2026-09-10' &&
      p.source.method==='indexed-meta-page-text','FEED_HOUSE_NOT_META_MARGIN');
  } else {
    check(tiktokImageSizes.has(`${p.width}x${p.height}`),'TIKTOK_IMAGE_DIMENSIONS');
    check(p.boundaryKind==='house' && text(p.houseBasis) && p.source.url===tiktokHelp &&
      p.source.version===tiktokVersion && p.source.verifiedAt==='2026-09-15' &&
      p.source.method==='official-tiktok-page-text','TIKTOK_IMAGE_PLACEMENT_POLICY_MISMATCH');
  }
  check(b[2]>0 && b[3]>0,'EMPTY_SAFE_BOX');
  return {profileSha256:profileHash(p),safeBox:b,requiresPreview:!vertical};
}
export function makeProfile({platform,paidPlacement,width,height,hasDisclaimer=false,houseInsetsPercent,houseBasis}) {
  check(['meta','tiktok'].includes(platform) && text(paidPlacement),'NAMED_PAID_PLACEMENT_REQUIRED');
  const tiktok=platform==='tiktok',vertical=!tiktok && Object.hasOwn(metaGuides,paidPlacement);
  const p={schemaVersion:1,platform,paidPlacement,width,height,hasDisclaimer,
    boundaryKind:vertical?'meta-recommendation':'house',
    insetsPercent:vertical?{top:14,bottom:paidPlacement.endsWith('reels') && hasDisclaimer?40:35,left:6,right:6}:houseInsetsPercent,
    source:tiktok?{url:tiktokHelp,version:tiktokVersion,verifiedAt:'2026-09-15',method:'official-tiktok-page-text'}:
      {url:metaGuides[paidPlacement] || metaHelp,version:metaVersion,verifiedAt:'2026-09-10',method:'indexed-meta-page-text',
        ...(vertical && paidPlacement.endsWith('reels') && hasDisclaimer?{disclaimerUrl:metaHelp}:{})},
    ...(!vertical?{houseBasis}:{})};
  validateProfile(p);return p;
}
export function placementPrompt(p) {
  const {safeBox:[x,y,w,h]}=validateProfile(p);
  return `${p.platform.toUpperCase()} PAID IMAGE PLACEMENT: ${p.paidPlacement}; canvas ${p.width}x${p.height}. Exact inward-rounded safe box: x=${x}..${x+w}, y=${y}..${y+h} ([${x},${y},${w},${h}]). Keep the FULL bounds of every visible word, price, disclaimer, logo, essential product label and key creative element wholly inside this box after final crop/resize. Background may bleed outside. Do not clip, hide or move mandatory copy outside the box. Boundary basis: ${p.boundaryKind}; ${p.source.version}.`;
}
export function generationInstruction(p,g,{legacy=false}={}) {
  validateProfile(p);
  check(Array.isArray(g?.canvasAspect) && g.canvasAspect.length===2 &&
    g.canvasAspect.every(n=>Number.isInteger(n) && n>0) &&
    g.cropAnchor==='center' && g.resize==='aspect-preserving','GENERATION_CROP_MAPPING_REQUIRED');
  const mapping=` Export uses the largest centered exact ${p.width}:${p.height} crop that fits the actual master, then aspect-preserving resize to ${p.width}x${p.height}; never stretch. Keep all essential content inside the final safe box mapped through this crop/resize, not merely inside the raw canvas. Extra master area is crop/background bleed only.`;
  if(legacy)return placementPrompt(p)+` Generate a ${g.canvasAspect.join(':')} COMPLETE master.`+mapping;
  return `ACTUAL GENERATION CANVAS: ${g.canvasAspect.join(':')}. Generate the COMPLETE master at this aspect, NOT the later export dimensions. `+
    placementPrompt(p).replace(`canvas ${p.width}x${p.height}`,`LATER FINAL EXPORT ${p.width}x${p.height}`)+mapping;
}
export function generationMapping(p,g,width,height) {
  generationInstruction(p,g);
  check(Number.isInteger(width) && Number.isInteger(height) && width>0 && height>0 &&
    Math.abs(width/height-g.canvasAspect[0]/g.canvasAspect[1])<.01,'GENERATION_CANVAS_ASPECT_MISMATCH');
  const gcd=(a,b)=>b?gcd(b,a%b):a,d=gcd(p.width,p.height),rw=p.width/d,rh=p.height/d;
  const n=Math.floor(Math.min(width/rw,height/rh)),cw=n*rw,ch=n*rh;
  check(n>0,'GENERATION_CROP_TOO_SMALL');
  const crop=[Math.floor((width-cw)/2),Math.floor((height-ch)/2),cw,ch],b=safeBox(p),scale=cw/p.width;
  return {width,height,crop,finalDimensions:[p.width,p.height],finalSafeBox:b,
    nativeSafeBox:[crop[0]+b[0]*scale,crop[1]+b[1]*scale,b[2]*scale,b[3]*scale]};
}
export function validateGenerationPlacement(m,c,requestValues,dimensions=[]) {
  if(!placementRequired(m))return;
  const p=resolvePlacementProfile(m,{call:c,slotId:c.slotId,masterId:c.masterId}),{profileSha256}=validateProfile(p);
  const legacy=m.skill?.version==='1.7.0' && (!m.execution || m.continuation?.inheritedCallIds?.includes(c.id));
  check(p.width===m.request.width && p.height===m.request.height,'PLACEMENT_REQUEST_DIMENSIONS');
  check(c.placementProfileSha256===profileSha256 &&
    requestValues.some(v=>v.includes(generationInstruction(p,c.generationGeometry,{legacy}))),'GENERATION_SAFE_BOX_INSTRUCTION_REQUIRED');
  check(Array.isArray(c.outputGeometry) && c.outputGeometry.length===dimensions.length &&
    dimensions.every(([w,h],i)=>canonicalJSON(c.outputGeometry[i])===canonicalJSON(generationMapping(p,c.generationGeometry,w,h))),
    'GENERATION_ACTUAL_OUTPUT_GEOMETRY');
}
async function pin(base,a,code) {
  check(text(a?.path) && /^[a-f0-9]{64}$/.test(a.sha256 || ''),code);
  const file=path.resolve(base,a.path),data=await fs.readFile(file);
  check(hash(data)===a.sha256,code);return {path:file,sha256:a.sha256,data};
}
export function parseOCR(tsv) {
  const lines=tsv.trimEnd().split(/\r?\n/),head=lines.shift()?.split('\t');
  check(head?.includes('conf') && head?.includes('text'),'OCR_TSV_FORMAT');
  return lines.map((l,i)=>({id:`ocr-${i+1}`,v:Object.fromEntries(l.split('\t').map((v,j)=>[head[j],v]))}))
    .filter(x=>x.v.level==='5' && text(x.v.text)).map(({id,v})=>({id,text:v.text,
      box:[+v.left,+v.top,+v.width,+v.height],confidence:+v.conf}));
}
export function inventoryCheck(p,i,final) {
  const {safeBox:b,profileSha256}=validateProfile(p),errors=[];
  if(i?.schemaVersion!==1 || i.coordinateSpace!=='final-pixels' || i.profileSha256!==profileSha256 ||
    i.final?.sha256!==final.sha256 || i.final?.width!==p.width || i.final?.height!==p.height ||
    final.width!==p.width || final.height!==p.height)errors.push('PLACEMENT_INVENTORY_STALE_EXPORT_OR_PROFILE');
  if(!date(i?.observedAt) || i.ocr?.status!=='complete' || i.ocr?.finalSha256!==final.sha256 ||
    !Array.isArray(i.ocr?.words) || !text(i.ocr?.tool) || i.visual?.status!=='complete' ||
    !text(i.visual?.reviewerId) || !text(i.visual?.note) || i.visual?.allTextEnumerated!==true ||
    i.visual?.allKeyElementsEnumerated!==true || i.visual?.fullBoxesAfterCropResize!==true)
    errors.push('PLACEMENT_INVENTORY_INCOMPLETE');
  const items=Array.isArray(i?.items)?i.items:[],ids=new Set();
  for(const a of items) {
    if(!text(a.id) || ids.has(a.id) || !['copy','price','disclaimer','logo','essential-label','key-element'].includes(a.kind) ||
      a.uncertain!==false || a.clipped!==false || !box(a.box))errors.push(`PLACEMENT_UNCERTAIN_OR_CLIPPED ${a.id}`);
    ids.add(a.id);
    if(!inside(a.box,[0,0,p.width,p.height]))errors.push(`PLACEMENT_CLIPPED ${a.id}`);
    if(!inside(a.box,b))errors.push(`PLACEMENT_FULL_BOX_OUTSIDE ${a.id}`);
  }
  if(p.hasDisclaimer && !items.some(a=>a.kind==='disclaimer'))errors.push('PLACEMENT_DISCLAIMER_MISSING');
  if(!p.hasDisclaimer && items.some(a=>a.kind==='disclaimer'))errors.push('PLACEMENT_UNDECLARED_DISCLAIMER');
  for(const w of i?.ocr?.words || []) {
    const matches=items.filter(a=>a.ocrIds?.includes(w.id)),ex=(i.ocr.exclusions || []).find(e=>e.ocrId===w.id);
    if(ex && text(ex.reason) && ex.visualConfirmed===true && !matches.length)continue;
    if(!matches.length)errors.push(`PLACEMENT_UNACCOUNTED_OCR ${w.id}`);
    if(w.confidence<60 && !matches.some(a=>text(a.ocrResolution)))errors.push(`PLACEMENT_UNCERTAIN_OCR ${w.id}`);
    // Word bounds cannot disappear inside a center-point or smaller producer inventory box.
    if(!matches.some(a=>inside(w.box,a.box) || text(a.ocrResolution)))errors.push(`PLACEMENT_OCR_BOX_NOT_COVERED ${w.id}`);
  }
  return {localStatus:errors.length?'fail':'pass',errors,safeBox:b,profileSha256};
}
export async function overlay(p,png,items=[]) {
  const {safeBox:[x,y,w,h]}=validateProfile(p);
  const rectangles=items.filter(a=>box(a.box)).map(a=>`<rect x="${a.box[0]}" y="${a.box[1]}" width="${a.box[2]}" height="${a.box[3]}" fill="none" stroke="${inside(a.box,[x,y,w,h])?'#00bbdd':'#ff2020'}" stroke-width="3"/>`).join('');
  const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="${p.width}" height="${p.height}"><path d="M0 0H${p.width}V${p.height}H0Z M${x} ${y}V${y+h}H${x+w}V${y}Z" fill="#ff3030" fill-opacity=".25" fill-rule="evenodd"/><rect x="${x}" y="${y}" width="${w}" height="${h}" fill="none" stroke="#00bb44" stroke-width="3"/>${rectangles}</svg>`;
  return sharp(png).composite([{input:Buffer.from(svg)}]).png().toBuffer();
}
export async function renderPlacement(p,png,stem) {
  const info=validateProfile(p),meta=await sharp(png).metadata();
  check(meta.width===p.width && meta.height===p.height,'PLACEMENT_EXPORT_DIMENSIONS');
  const data=await overlay(p,png),file=path.resolve(`${stem}.placement-overlay.png`);
  await fs.writeFile(file,data,{flag:'wx'});
  return {...info,finalSha256:hash(png),overlay:{path:file,sha256:hash(data)},status:'inventory-required'};
}
export async function inspectExport(m,s,base,stem) {
  const p=resolvePlacementProfile(m,{slotId:s.id}),info=validateProfile(p),file=path.resolve(base,s.file),png=await fs.readFile(file);
  const meta=await sharp(png).metadata();
  check(meta.width===p.width && meta.height===p.height,'PLACEMENT_EXPORT_DIMENSIONS');
  const language=process.env.STATIC_AD_OCR_LANG || 'eng';
  const {stdout}=await run('tesseract',[file,'stdout','-l',language,'tsv'],{maxBuffer:16*1024*1024});
  const words=parseOCR(stdout).map(({text:_,...word})=>word),i={schemaVersion:1,coordinateSpace:'final-pixels',profileSha256:info.profileSha256,
    final:{path:file,sha256:hash(png),width:meta.width,height:meta.height},observedAt:new Date().toISOString(),
    ocr:{status:'complete',tool:'tesseract',language,finalSha256:hash(png),words,exclusions:[]},
    visual:{status:'pending',reviewerId:null,note:null,allTextEnumerated:false,allKeyElementsEnumerated:false,fullBoxesAfterCropResize:false},
    items:words.map(w=>({id:w.id,kind:'copy',box:w.box,ocrIds:[w.id],uncertain:w.confidence<60,clipped:false}))};
  const dest=path.resolve(`${stem}.placement.json`);await fs.writeFile(dest,JSON.stringify(i,null,2)+'\n',{flag:'wx'});
  return {inventoryPath:dest,note:'Draft OCR inventory only. Inspect actual final pixels; add logos, labels/key elements and missed text, resolve uncertainty, save a new completed version, then record. No visual or placement clearance.'};
}
export async function placementSnapshot(m,s,base) {
  const p=resolvePlacementProfile(m,{slotId:s.id}),info=validateProfile(p),e=s.placementEvidence;
  if(!e)return {profile:p,...info,evidence:null};
  const i=await pin(base,e.inventory,'PLACEMENT_INVENTORY_CHANGED'),value=JSON.parse(i.data);
  const o=await pin(base,e.overlay,'PLACEMENT_OVERLAY_CHANGED');
  let preview=null;
  if(value.adsManagerPreview) {
    const a=await pin(base,value.adsManagerPreview.artifact,'PLACEMENT_PREVIEW_CHANGED');
    preview={...value.adsManagerPreview,artifact:{path:a.path,sha256:a.sha256}};
  }
  return {profile:p,...info,evidence:{inventory:{path:i.path,sha256:i.sha256},
    overlay:{path:o.path,sha256:o.sha256},ocr:{status:value.ocr?.status,tool:value.ocr?.tool,language:value.ocr?.language},preview}};
}
export async function checkPlacement(m,s,base,png,metrics,review=null) {
  if(!placementRequired(m))return null;
  const held=error=>({status:'held',localStatus:'fail',errors:[error],deliveryEligible:false});
  try {
    const p=resolvePlacementProfile(m,{slotId:s.id}),info=validateProfile(p),meta=await sharp(png).metadata();
    const final={sha256:hash(png),width:meta.width,height:meta.height};
    check(metrics.placement?.profileSha256===info.profileSha256 &&
      metrics.placement?.finalSha256===final.sha256,'PLACEMENT_EXPORT_PROFILE_CHANGED');
    const initial=await pin(base,metrics.placement.overlay,'PLACEMENT_EXPORT_OVERLAY_CHANGED');
    check(initial.sha256===hash(await overlay(p,png)),'PLACEMENT_EXPORT_OVERLAY_MISMATCH');
    const snap=await placementSnapshot(m,s,base);
    if(!snap.evidence)return held('PLACEMENT_FINAL_PIXEL_INVENTORY_REQUIRED');
    const i=await load(snap.evidence.inventory.path),local=inventoryCheck(p,i,final);
    check(snap.evidence.overlay.sha256===hash(await overlay(p,png,i.items)),'PLACEMENT_INVENTORY_OVERLAY_MISMATCH');
    if(local.localStatus!=='pass')return {...local,status:'held',deliveryEligible:false};
    if(!review)return {...local,status:'awaiting-independent-review',deliveryEligible:false};
    const r=review.placementReview;
    if(review.status!=='cleared' || r?.verdict!=='pass' || r.fullBoxesInspected!==true || !text(r.note) ||
      r.inventorySha256!==snap.evidence.inventory.sha256 || r.profileSha256!==info.profileSha256)
      return {...local,status:'held',deliveryEligible:false,errors:['PLACEMENT_INDEPENDENT_REVIEW_REQUIRED']};
    if(info.requiresPreview) {
      const a=i.adsManagerPreview;
      const valid=a?.platform===p.platform && a.paidPlacement===p.paidPlacement && a.finalSha256===final.sha256 &&
        a.width===p.width && a.height===p.height && a.profileSha256===info.profileSha256 &&
        date(a.capturedAt) && Date.parse(a.capturedAt)>=Date.parse(i.observedAt) &&
        text(a.existingAdOrCreativeId) && text(a.reviewerId) && text(a.note) &&
        a.safeZoneGuardrailInspected===true && a.verdict==='pass' && r.adsManagerPreviewInspected===true;
      if(!valid)return {...local,status:'preview-pending',deliveryEligible:true,
        label:`Creative cleared; house-margin checks passed. ${p.platform==='meta'?'Meta':'TikTok Ads Manager'} placement preview pending.`,
        errors:['ADS_MANAGER_PLACEMENT_PREVIEW_REQUIRED']};
    }
    return {...local,status:'placement-cleared',deliveryEligible:true,
      label:'Creative and specified placement checks cleared; not platform approval.'};
  } catch(e) {return held(e.message);}
}
export async function recordInventory(m,s,base,file,stem) {
  const i=await load(file),png=await fs.readFile(path.resolve(base,s.file)),meta=await sharp(png).metadata();
  const p=resolvePlacementProfile(m,{slotId:s.id});
  const result=inventoryCheck(p,i,{sha256:hash(png),width:meta.width,height:meta.height});
  const data=await overlay(p,png,i.items),dest=path.resolve(`${stem}.inventory-overlay.png`);
  await fs.writeFile(dest,data,{flag:'wx'});
  const evidence={inventory:{path:path.resolve(file),sha256:hash(await fs.readFile(file))},
    overlay:{path:dest,sha256:hash(data)},registeredAt:new Date().toISOString()};
  s.placementEvidenceHistory ||= [];s.placementEvidenceHistory.push(evidence);s.placementEvidence=evidence;
  return {...result,note:'Evidence registered, not cleared. Fresh independent image-first review is required.'};
}
if(process.argv[1] && import.meta.url===pathToFileURL(path.resolve(process.argv[1])).href) {
  // bind -> continuation -> lib/image-first imports this module; finish module evaluation first.
  void (async()=>{
  try {
    const [cmd,file,id,arg,stem]=process.argv.slice(2);let result;
    if(cmd==='profile') {
      const input=await load(file),p=makeProfile(input),generationGeometry=input.generationGeometry;
      result={placementProfile:p,...validateProfile(p),generationGeometry,instruction:generationInstruction(p,generationGeometry)};
    }
    else if(cmd==='mapping') {
      const m=await load(file),c=await load(id),base=path.dirname(path.resolve(file));
      result={outputGeometry:await Promise.all(c.outputPaths.map(async f=>{
        const a=await sharp(path.resolve(base,f)).metadata();
        return generationMapping(resolvePlacementProfile(m,{call:c,slotId:c.slotId,masterId:c.masterId}),c.generationGeometry,a.width,a.height);
      }))};
    }
    else if(cmd==='bind') {
      const m=await load(file);result=await bindPlacement(m,path.dirname(path.resolve(file)),await load(id));
      await fs.writeFile(file,JSON.stringify(m,null,2)+'\n');
    }
    else {
      const m=await load(file),base=path.dirname(path.resolve(file)),s=m.slots.find(s=>s.id===id);
      check(s,'PLACEMENT_SLOT_REQUIRED');
      if(cmd==='inspect')result=await inspectExport(m,s,base,arg);
      else if(cmd==='record') {result=await recordInventory(m,s,base,arg,stem);await fs.writeFile(file,JSON.stringify(m,null,2)+'\n');}
      else if(cmd==='check')result=await checkPlacement(m,s,base,await fs.readFile(path.resolve(base,s.file)),
        await load(path.resolve(base,s.metrics)),s.finalVisualReview);
      else throw Error('Usage: placement.mjs profile input.json | bind manifest binding-request.json | mapping manifest call.json | inspect manifest slot new-stem | record manifest slot completed-inventory.json new-stem | check manifest slot');
    }
    console.log(JSON.stringify(result,null,2));
  } catch {console.error('PLACEMENT_COMMAND_FAILED');process.exitCode=1;}
  })();
}
