// Image-first route/lineage mechanics. Records do NOT authenticate a provider, rights or visual meaning.
// No media invocation occurs here. Keep original tool requests/responses and actual inspection separate.
import fs from 'node:fs/promises';
import path from 'node:path';
import {placementRequired,validateProfile,validateGenerationPlacement,resolvePlacementProfile,profileHash,validatePlacementBinding} from './placement.mjs';
import {integrationVersion,finishFirstVersion,validateContinuation,executionVersion} from './run-continuation.mjs';
import {sharp} from './raster-runtime.mjs';
import {assert as check,canonicalJSON,loadJSON as load,sameJSON,sha} from './runtime.mjs';
const text = x => typeof x === 'string' && !!x.trim();
const hashOK = x => typeof x === 'string' && /^[a-f0-9]{64}$/.test(x);
const box = b => Array.isArray(b) && b.length===4 && b.every(Number.isFinite) && b[2]>0 && b[3]>0;
const inside = (b,o) => box(b) && b[0]>=o[0] && b[1]>=o[1] && b[0]+b[2]<=o[0]+o[2] && b[1]+b[3]<=o[1]+o[3];
const keys = (o,ks,code) => check(o && typeof o==='object' && !Array.isArray(o) && Object.keys(o).every(k=>ks.includes(k)),code);
const date = x => text(x) && Number.isFinite(Date.parse(x));
const purposes = ['font','spelling','disclaimer','logo','product-identity'];
export const isRaster = p => p.schemaVersion===2 && ['native-raster','raster-finishing'].includes(p.production?.route);
export const imageFirstVersion = m => ['1.6.0','1.7.0'].includes(executionVersion(m)) || integrationVersion(m);
export const callHash = c => sha(canonicalJSON(Object.fromEntries(Object.entries(c).filter(([k])=>k!=='recordSha256'))));
export function nonModelException(e) {
  check(['explicit-user-request','approved-exception'].includes(e?.kind) && text(e.basis), 'NON_MODEL_AUTHORITY_REQUIRED');
}
export function validateRoutePlan(p) {
  keys(p.production,['route','manifestPath','slotId','crop','roughInspection','finishing','exception'],'PRODUCTION_FIELDS');
  check(text(p.production.manifestPath) && text(p.production.slotId), 'PRODUCTION_RUN_BINDING');
  if (p.production.route==='non-model') {
    nonModelException(p.production.exception);
    check(!p.rasterRegions?.length && !p.production.finishing?.length && !p.production.crop && !p.production.roughInspection,'NON_MODEL_RASTER_FIELDS');
    return;
  }
  check(isRaster(p) && !p.production.exception,'PRODUCTION_ROUTE');
  const crop=p.production.crop;
  check(box(crop) && crop.every(Number.isInteger) && crop[0]>=0 && crop[1]>=0 &&
    crop[2]*p.canvas.height===crop[3]*p.canvas.width,'ASPECT_PRESERVING_CROP_REQUIRED');
  const r=p.production.roughInspection;
  keys(r,['modelOutputSha256','inspectedAt','reviewerType','note'],'ROUGH_INSPECTION_FIELDS');
  check(hashOK(r.modelOutputSha256) && date(r.inspectedAt) && Date.parse(r.inspectedAt)<=Date.now() &&
    ['human','agent-vision'].includes(r.reviewerType) && text(r.note),'COMPLETE_ROUGH_INSPECTION_REQUIRED');
  check(Array.isArray(p.rasterRegions),'RASTER_REGIONS');
  const ids=new Set();
  for(const r of p.rasterRegions) {
    keys(r,['id','sourceBox','observation'],'RASTER_REGION_FIELDS');
    check(text(r.id) && !ids.has(r.id) && box(r.sourceBox) && text(r.observation),'RASTER_REGION_OBSERVATION');
    ids.add(r.id);
  }
  check(Array.isArray(p.production.finishing),'FINISHING_RECORDS');
  if(p.production.route==='native-raster') check(!p.zones.length && !p.production.finishing.length && !p.callouts?.length,'NATIVE_RASTER_HAS_LOCAL_LAYERS');
  else check(p.zones.length>0 && p.production.finishing.length>0,'FINISHING_REQUIRED');
  // No new callout construction over model output. Baked-in connectors are raster observations.
  check(!p.callouts?.length,'MODEL_CONNECTORS_REQUIRE_IMAGE_EDIT');
  const seen=new Set(), names=new Set();
  for(const f of p.production.finishing) {
    keys(f,['id','purpose','regionId','box','zoneIds','reason'],'FINISHING_FIELDS');
    check(text(f.id) && !names.has(f.id) && purposes.includes(f.purpose) && ids.has(f.regionId) && text(f.reason) &&
      inside(f.box,[0,0,p.canvas.width,p.canvas.height]) && f.box.every(Number.isInteger) &&
      !(f.box[0]===0 && f.box[1]===0 && f.box[2]===p.canvas.width && f.box[3]===p.canvas.height) &&
      Array.isArray(f.zoneIds) && f.zoneIds.length,'LOCAL_FINISHING_REGION_REQUIRED');
    names.add(f.id);
    for(const id of f.zoneIds) {
      check(!seen.has(id) && p.zones.some(z=>z.id===id),'FINISHING_LAYER_COVERAGE');seen.add(id);
    }
  }
  check(seen.size===p.zones.length,'FINISHING_LAYER_COVERAGE');
}
export function rasterBox(r,p) {
  const [x,y,w,h]=p.production.crop, b=r.sourceBox;
  check(inside(b,[x,y,w,h]),'RASTER_REGION_CROPPED_OUT');
  const scale=p.canvas.width/w;
  return [(b[0]-x)*scale,(b[1]-y)*scale,b[2]*scale,b[3]*scale];
}
async function pin(base,a,code) {
  check(text(a?.path) && hashOK(a.sha256),code);
  const full=path.resolve(base,a.path),data=await fs.readFile(full);
  check(sha(data)===a.sha256,code);
  return {path:full,sha256:a.sha256,data};
}
function receiptValues(data) {
  const raw=data.toString('utf8');
  try {
    const values=[],walk=x=>{if(typeof x==='string')values.push(x);else if(x && typeof x==='object')Object.values(x).forEach(walk);};
    walk(JSON.parse(raw));return [raw,...values];
  } catch {return [raw];}
}
async function inspectGenerationCall(c,base,m=null,{eligibility=true}={}) {
  check(text(c.id) && text(c.masterId) && text(c.tool) && ['complete-ad-generation','complete-ad-edit'].includes(c.route) &&
    ['complete','failed'].includes(c.status) && c.completeAd===true && date(c.startedAt) && date(c.endedAt) &&
    Date.parse(c.endedAt)>=Date.parse(c.startedAt) && Date.parse(c.endedAt)<=Date.now() &&
    Number.isFinite(c.elapsedSeconds) && c.elapsedSeconds>=0 &&
    Math.abs(c.elapsedSeconds-(Date.parse(c.endedAt)-Date.parse(c.startedAt))/1000)<.001 &&
    Number.isInteger(c.imageCount) && c.imageCount>=0 && Number.isInteger(c.requestedImages) && c.requestedImages>0 &&
    Array.isArray(c.inputImages) && Array.isArray(c.outputPaths) && Array.isArray(c.outputHashes) &&
    Array.isArray(c.outputOrigins) && c.outputPaths.length===c.imageCount && c.outputHashes.length===c.imageCount &&
    c.outputOrigins.length===c.imageCount && (c.status!=='complete' || c.imageCount>0) &&
    (c.repairOf===null || text(c.repairOf)), 'GENERATION_CALL_RECORD');
  const request=await pin(base,c.requestReceipt,'GENERATION_REQUEST_RECEIPT');
  const response=await pin(base,c.responseReceipt,'GENERATION_RESPONSE_RECEIPT');
  const requestValues=receiptValues(request.data),responseValues=receiptValues(response.data);
  const pp=path.resolve(base,c.packetPath),p=await load(pp),root=path.dirname(pp);
  if(c.packetSha256)check(sha(await fs.readFile(pp))===c.packetSha256,'GENERATION_PACKET_CHANGED');
  check(p.masterId===c.masterId,'GENERATION_PACKET_MASTER');
  const inputs=[];
  for(const a of c.inputImages) {
    check(['composition','exact-sku','logo','treatment','base-photo'].includes(a.role) &&
      text(a.submittedAs) && requestValues.some(v=>v.includes(a.submittedAs)),'GENERATION_INPUT_RECEIPT');
    check(Boolean(a.referenceId)!==Boolean(a.sourceId),'GENERATION_INPUT_AUTHORITY');
    const owner=a.referenceId ? p.selectedReferences.find(r=>r.id===a.referenceId) : p.sources.find(s=>s.id===a.sourceId);
    check(owner?.modelUploadPermission==='cleared' && text(owner.modelUploadBasis) &&
      ['owned','authorized'].includes(owner.permissionStatus) && text(owner.permissionBasis),'MODEL_UPLOAD_NOT_CLEARED');
    const paths=a.referenceId ? [owner.path] : [owner.localPath,...(p.imageRoles || []).filter(r=>r.sourceId===a.sourceId).map(r=>r.path)];
    const actual=await pin(base,a,'GENERATION_INPUT_CHANGED');
    check(paths.filter(Boolean).some(v=>path.resolve(root,v)===actual.path),'GENERATION_INPUT_AUTHORITY');
    inputs.push({path:actual.path,sha256:actual.sha256,role:a.role,sourceId:a.sourceId ?? null,referenceId:a.referenceId ?? null,
      permissionStatus:owner.permissionStatus,permissionBasis:owner.permissionBasis,modelUploadPermission:owner.modelUploadPermission,modelUploadBasis:owner.modelUploadBasis});
  }
  const outputs=[],dimensions=[];
  for(let i=0;i<c.outputPaths.length;i++) {
    check(text(c.outputOrigins[i]) && responseValues.some(v=>v.includes(c.outputOrigins[i])),'GENERATION_OUTPUT_RECEIPT');
    const a=await pin(base,{path:c.outputPaths[i],sha256:c.outputHashes[i]},'GENERATION_OUTPUT_CHANGED');
    const meta=await sharp(a.data).metadata();
    check(['png','jpeg','webp'].includes(meta.format) && (!meta.pages || meta.pages===1),'GENERATION_OUTPUT_IMAGE');
    outputs.push({path:a.path,sha256:a.sha256});
    dimensions.push([meta.width,meta.height]);
  }
  await validatePlacementBinding(m,c,base);
  let eligibilityError=null;
  try {validateGenerationPlacement(m,c,requestValues,dimensions);}catch(e){eligibilityError=e.message;}
  if(c.recordSha256) {
    check(callHash(c)===c.recordSha256,'GENERATION_RECORD_CHANGED');
    if(!c.validationError)check(sameJSON(c.inputClearances,inputs),'GENERATION_INPUT_CLEARANCE_CHANGED');
  }
  if(eligibility && eligibilityError)throw Error(eligibilityError);
  return {requestReceipt:{path:request.path,sha256:request.sha256},responseReceipt:{path:response.path,sha256:response.sha256},inputs,outputs,eligibilityError};
}
export async function validateGenerationCall(c,base,m=null) {
  check(!c.validationError,'GENERATION_RECORDED_FAILURE');
  return inspectGenerationCall(c,base,m);
}
export const recoverableEligibilityErrors=Object.freeze([
  'GENERATION_CANVAS_ASPECT_MISMATCH','GENERATION_ACTUAL_OUTPUT_GEOMETRY','GENERATION_SAFE_BOX_INSTRUCTION_REQUIRED'
]);
export function assertSelectedCallSlot(slot,call) {
  check(call.slotId===slot.id,'SELECTED_CALL_SLOT_MISMATCH');
}
export async function validateHistoricalCall(c,base,m,{allowRecoverable=integrationVersion(m)}={}) {
  check(c.recordSha256===callHash(c),'GENERATION_RECORD_UNREGISTERED');
  if(!c.validationError)return validateGenerationCall(c,base,m);
  check(allowRecoverable && recoverableEligibilityErrors.includes(c.validationError) &&
    !m.slots.some(s=>s.production?.generationCallId===c.id),'GENERATION_RECORDED_FAILURE');
  const evidence=await inspectGenerationCall(c,base,m,{eligibility:false});
  check(evidence.eligibilityError===c.validationError,'GENERATION_REJECTION_NOT_REPRODUCED');
  return {...evidence,retainedRejected:true};
}
// Concept-only variance allowance. Reproduce the original failure; never rewrite its aspect/status/hash.
export async function validateConceptGeneration(c,base,m) {
  const {conceptPhase}=await import('./run-continuation.mjs');
  check(conceptPhase(m) && c?.status==='complete' && c.recordSha256===callHash(c),'CONCEPT_CALL_LINEAGE');
  if(!c.validationError)return validateGenerationCall(c,base,m);
  check(['GENERATION_CANVAS_ASPECT_MISMATCH','GENERATION_ACTUAL_OUTPUT_GEOMETRY'].includes(c.validationError),
    'CONCEPT_CALL_NOT_RECOVERABLE');
  const evidence=await inspectGenerationCall(c,base,m,{eligibility:false});
  check(evidence.eligibilityError===c.validationError,'GENERATION_REJECTION_NOT_REPRODUCED');
  // Both geometry errors occur only AFTER the real request's placement/generation instruction check.
  return {...evidence,retainedRejected:true};
}
export async function recordGeneration(m,base,record) {
  await validateContinuation(m);
  check(imageFirstVersion(m),'IMAGE_FIRST_RUN_REQUIRED');
  check(text(record.id) && !m.generationCalls.some(c=>c.id===record.id),'GENERATION_APPEND_ONLY');
  const c=structuredClone(record);
  try {
    if(integrationVersion(m))c.packetSha256=sha(await fs.readFile(path.resolve(base,c.packetPath)));
    const validated=await validateGenerationCall(c,base,m);
    c.inputClearances=validated.inputs;
    if(c.repairOf) check(m.generationCalls.some(x=>x.id===c.repairOf && x.masterId===c.masterId),'GENERATIVE_REPAIR_PARENT');
  } catch(e) {c.validationError=e.message;m.failures.push({kind:'generation',id:c.id,reason:e.message});}
  c.recordSha256=callHash(c);
  // Always retain real calls, including over-budget/failed ones. Finalization blocks an overrun.
  m.generationCalls.push(c);
  return c;
}
export async function selectModel(m,base,slotId,callId,index=0) {
  await validateContinuation(m);
  check(imageFirstVersion(m),'IMAGE_FIRST_RUN_REQUIRED');
  const s=m.slots.find(s=>s.id===slotId),c=m.generationCalls.find(c=>c.id===callId);
  check(s && c?.status==='complete' && !c.validationError && c.recordSha256===callHash(c) && Number.isInteger(index) && index>=0 && index<c.imageCount,'SELECT_MODEL_LINEAGE');
  assertSelectedCallSlot(s,c);
  await validateGenerationCall(c,base,m);
  if(placementRequired(m))check(c.placementProfileSha256===profileHash(resolvePlacementProfile(m,{slotId})),
    'SELECTED_CALL_PLACEMENT_MISMATCH');
  check(!s.masterId || s.masterId===c.masterId,'SELECT_MODEL_MASTER');
  const bytes=await fs.readFile(path.resolve(base,c.outputPaths[index])),hash=sha(bytes);
  const folder=path.join(base,'model-outputs');await fs.mkdir(folder,{recursive:true});
  const dest=path.join(folder,`${hash}${path.extname(c.outputPaths[index])}`);
  try {await fs.writeFile(dest,bytes,{flag:'wx'});} catch(e) {if(e.code!=='EEXIST')throw e;check(sha(await fs.readFile(dest))===hash,'IMMUTABLE_MODEL_OUTPUT_CHANGED');}
  check(!s.production || s.production.route==='model','PRODUCTION_ROUTE_CHANGED');
  s.masterId=c.masterId;
  s.production={route:'model',generationCallId:c.id,generationCallSha256:c.recordSha256,
    modelOutput:{path:dest,sha256:hash},exports:s.production?.exports || []};
  return s.production;
}
export async function resolveProduction(p,packet,planBase,mOverride=null) {
  check(p.schemaVersion===2,'IMAGE_FIRST_PLAN_REQUIRED');
  const manifestPath=path.resolve(planBase,p.production.manifestPath),base=path.dirname(manifestPath),m=mOverride || await load(manifestPath);
  await validateContinuation(m);
  check(imageFirstVersion(m),'IMAGE_FIRST_RUN_REQUIRED');
  if(placementRequired(m)) {
    const profile=resolvePlacementProfile(m,{slotId:p.production.slotId});validateProfile(profile);
    check(profile.width===p.canvas.width && profile.height===p.canvas.height,'PLACEMENT_EXPORT_DIMENSIONS');
  }
  const s=m.slots.find(s=>s.id===p.production.slotId);
  check(s && s.masterId===packet.masterId,'PRODUCTION_SLOT_MASTER');
  if(p.production.route==='non-model') {
    nonModelException(p.production.exception);
    check(s.production?.route==='non-model' && sameJSON(s.production.exception,p.production.exception),'NON_MODEL_SLOT_AUTHORITY');
    return {manifestPath,slotId:s.id,route:'non-model',exception:p.production.exception};
  }
  const prod=s.production,c=m.generationCalls.find(c=>c.id===prod?.generationCallId);
  check(prod?.route==='model' && c?.status==='complete' && c.masterId===packet.masterId &&
    c.route===packet.route && c.recordSha256===callHash(c) && prod.generationCallSha256===c.recordSha256,'MODEL_GENERATION_LINEAGE');
  assertSelectedCallSlot(s,c);
  const evidence=await validateGenerationCall(c,base,m),model=await pin(base,prod.modelOutput,'IMMUTABLE_MODEL_OUTPUT_CHANGED');
  const outputIndex=c.outputHashes.indexOf(model.sha256);
  check(outputIndex>=0 && p.production.roughInspection.modelOutputSha256===model.sha256 &&
    Date.parse(p.production.roughInspection.inspectedAt)>=Date.parse(c.endedAt),'SELECTED_MODEL_OUTPUT_LINEAGE');
  if(placementRequired(m))check(c.placementProfileSha256===profileHash(resolvePlacementProfile(m,{slotId:s.id})),
    'SELECTED_CALL_PLACEMENT_MISMATCH');
  if(placementRequired(m))check(c.outputGeometry?.[outputIndex] && sameJSON(p.production.crop,c.outputGeometry[outputIndex].crop),
    'DECLARED_GENERATION_CROP_MISMATCH');
  // Use a separate immutable copy, never the mutable provider download or the final file.
  check(!c.outputPaths.some(v=>path.resolve(base,v)===model.path) &&
    path.dirname(model.path)===path.join(base,'model-outputs'),'IMMUTABLE_MODEL_COPY_REQUIRED');
  const meta=await sharp(model.data).metadata();
  check(['png','jpeg','webp'].includes(meta.format) && (!meta.pages || meta.pages===1) &&
    (!meta.orientation || meta.orientation===1),'NORMALIZE_MODEL_ORIENTATION');
  check(inside(p.production.crop,[0,0,meta.width,meta.height]),'MODEL_CROP_BOUNDS');
  const stats=await sharp(model.data).stats();check(stats.isOpaque,'OPAQUE_COMPLETE_MODEL_AD_REQUIRED');
  const regions=p.rasterRegions.map(r=>({...r,box:rasterBox(r,p)}));
  for(const f of p.production.finishing) {
    const region=regions.find(r=>r.id===f.regionId);
    check(inside(f.box,region.box),'FINISHING_OUTSIDE_OBSERVED_REGION');
    if(['product-identity','logo'].includes(f.purpose)) {
      const ids=f.zoneIds.map(id=>p.zones.find(z=>z.id===id)?.assetId).filter(Boolean);
      const role=f.purpose==='logo'?'logo':'product';
      check(ids.some(id=>p.assets.find(a=>a.id===id)?.role===role),`${role.toUpperCase()}_FINISHING_ASSET_REQUIRED`);
    }
  }
  return {manifestPath,slotId:s.id,route:p.production.route,generationCallId:c.id,generationCallSha256:c.recordSha256,
    modelOutput:{path:model.path,sha256:model.sha256},nativeDimensions:[meta.width,meta.height],
    crop:p.production.crop,roughInspection:p.production.roughInspection,finishing:p.production.finishing,regions,
    ...evidence};
}
export async function rasterBase(production,canvas) {
  const [left,top,width,height]=production.crop;
  return sharp(production.modelOutput.path).extract({left,top,width,height})
    .resize(canvas.width,canvas.height,{fit:'inside'}).toColourspace('srgb').removeAlpha().png().toBuffer();
}
export async function rasterMeasurements(production,basePNG,finalPNG) {
  const regions=[];
  for(const r of production.regions) {
    const [x,y,w,h]=r.box,rect={left:Math.floor(x),top:Math.floor(y),width:Math.ceil(x+w)-Math.floor(x),height:Math.ceil(y+h)-Math.floor(y)};
    const pixels=async png=>sha(await sharp(png).extract(rect).removeAlpha().raw().toBuffer());
    regions.push({...r,basePixelsSha256:await pixels(basePNG),finalPixelsSha256:await pixels(finalPNG)});
  }
  return {...production,regions,baseExportSha256:sha(basePNG),
    limits:'Region boxes are attributed pixel observations, not detected objects or DOM zones. Region hashes pin pixels, not meaning. Local font/fit/contrast checks never verify baked-in copy, exact font or product identity.'};
}
export async function verifyRasterExport(production,canvas,finalPNG) {
  const meta=await sharp(finalPNG).metadata();
  check(meta.width===canvas.width && meta.height===canvas.height,'RASTER_EXPORT_DIMENSIONS');
  // RGB equality alone must not hide an alpha-only change outside a declared patch.
  check((await sharp(finalPNG).stats()).isOpaque,'RASTER_EXPORT_MUST_BE_OPAQUE');
  const basePNG=await rasterBase(production,canvas);
  const a=await sharp(basePNG).removeAlpha().raw().toBuffer(),b=await sharp(finalPNG).removeAlpha().raw().toBuffer();
  check(a.length===b.length,'RASTER_EXPORT_DIMENSIONS');
  let changed=0;
  for(let i=0;i<a.length;i+=3) {
    if(a[i]===b[i] && a[i+1]===b[i+1] && a[i+2]===b[i+2])continue;
    changed++;
    const n=i/3,x=n%canvas.width,y=Math.floor(n/canvas.width);
    check(production.finishing.some(f=>x>=f.box[0] && y>=f.box[1] && x<f.box[0]+f.box[2] && y<f.box[1]+f.box[3]),'RASTER_CHANGED_OUTSIDE_FINISHING');
  }
  return {basePNG,changedPixels:changed};
}
export async function exportReceipt(p,packet,planBase,metrics,stem) {
  const prod=await resolveProduction(p,packet,planBase),m=await load(prod.manifestPath),s=m.slots.find(s=>s.id===prod.slotId);
  check(![s.production.modelOutput?.path,...(prod.outputs || []).map(o=>o.path),
    ...(s.production.exports || []).map(e=>e.file)].includes(path.resolve(`${stem}.png`)),'MODEL_OUTPUT_OVERWRITE');
  s.production.exports ||= [];
  const record={planHash:metrics.planHash,packetHash:metrics.packetHash,exportHash:metrics.exportHash,
    modelOutput:prod.modelOutput ?? null,generationCallSha256:prod.generationCallSha256 ?? null,
    crop:prod.crop ?? null,finishing:prod.finishing ?? [],file:path.resolve(`${stem}.png`),metrics:path.resolve(`${stem}.metrics.json`),
    ...(placementRequired(m)?{placement:metrics.placement}:{})};
  const previous=s.production.exports.at(-1);
  // Repeat of the identical export is not another repair; changed exports retain every prior record.
  if(!previous || !sameJSON(Object.fromEntries(Object.entries(previous).filter(([k])=>k!=='exportedAt')),record))
    s.production.exports.push({...record,exportedAt:new Date().toISOString()});
  await fs.writeFile(prod.manifestPath,JSON.stringify(m,null,2)+'\n');
  return record;
}
export function deterministicRepairCount(m,s) {
  const byModel=new Map();
  for(const e of [...(s.concept?.exports || []),...(s.production?.exports || [])]) {
    const key=e.modelOutput?.sha256 || e.production?.source?.sha256 || 'non-model';
    byModel.set(key,(byModel.get(key) || 0)+1);
  }
  return [...byModel.values()].reduce((n,count)=>n+Math.max(0,count-1),0) +
    (m.failures || []).filter(f=>f.slotId===s.id && (f.kind==='render' && f.countsAsRepair ||
      finishFirstVersion(m) && f.kind==='caption-repair')).length;
}
export function validateProductionBudgets(m,packets=[]) {
  if(!imageFirstVersion(m))return;
  const defaults={maxCompleteRoughs:6,maxInitialGeneratedImages:6,maxTotalGeneratedImages:9,maxGenerationCalls:9,maxGenerativeRepairsPerMaster:1,maxDeterministicRepairsPerFinal:2};
  for(const [k,v] of Object.entries(defaults)) check(Number.isInteger(m.budgets[k]) && m.budgets[k]>=0 &&
    (m.budgets[k]===v || text(m.budgetOverrideReason)),'PRODUCTION_BUDGET_AUTHORITY');
  const calls=m.generationCalls || [];
  check(new Set(calls.map(c=>c.id)).size===calls.length,'GENERATION_DUPLICATE_ID');
  check(calls.length<=m.budgets.maxGenerationCalls &&
    calls.reduce((n,c)=>n+c.imageCount,0)<=m.budgets.maxTotalGeneratedImages &&
    calls.filter(c=>!c.repairOf).reduce((n,c)=>n+c.imageCount,0)<=m.budgets.maxInitialGeneratedImages,'GENERATION_BUDGET_EXCEEDED');
  if(finishFirstVersion(m))check(calls.filter(c=>!c.repairOf).length<=
    Math.min(m.budgets.maxGenerationCalls,m.budgets.maxInitialGeneratedImages),'REPAIR_RESERVE');
  for(const master of new Set(calls.map(c=>c.masterId)))
    check(calls.filter(c=>c.masterId===master && c.repairOf).length<=m.budgets.maxGenerativeRepairsPerMaster,'GENERATIVE_REPAIR_CAP');
  for(const c of calls) if(c.repairOf)check(calls.some(x=>x.id===c.repairOf && x.masterId===c.masterId &&
    (!finishFirstVersion(m) || !x.repairOf) && Date.parse(x.endedAt)<=Date.parse(c.startedAt)),'GENERATIVE_REPAIR_PARENT');
  check(packets.reduce((n,p)=>n+(p.selection?.completeRoughs?.length || 0),0)<=m.budgets.maxCompleteRoughs,'ROUGH_CAP');
  for(const s of m.slots) {
    // A model repair is counted in calls, not as a deterministic repair; count changed local exports per model selection.
    check(deterministicRepairCount(m,s)<=m.budgets.maxDeterministicRepairsPerFinal,'DETERMINISTIC_REPAIR_CAP');
  }
}
export async function validateSlotProduction(m,s,base,plan,packet,metrics) {
  if(!imageFirstVersion(m))return null;
  // Legacy schema remains usable for an explicitly authorized deterministic exception, never a token model call.
  if(plan.schemaVersion===1) {
    check(s.production?.route==='non-model','IMAGE_FIRST_PLAN_REQUIRED');nonModelException(s.production.exception);
    return {route:'non-model',exception:s.production.exception};
  }
  check(plan.production.slotId===s.id && path.resolve(path.dirname(path.resolve(base,s.plan)),plan.production.manifestPath)===(m.execution?.manifestPath || path.join(base,'run-manifest.json')),
    'PRODUCTION_MANIFEST_BINDING');
  const prod=await resolveProduction(plan,packet,path.dirname(path.resolve(base,s.plan)),m);
  check(s.production.exports?.some(e=>e.planHash===metrics.planHash && e.packetHash===metrics.packetHash && e.exportHash===metrics.exportHash &&
    e.modelOutput?.sha256===(prod.modelOutput?.sha256) && sameJSON(e.crop,prod.crop ?? null) &&
    sameJSON(e.finishing,prod.finishing ?? []) && e.generationCallSha256===(prod.generationCallSha256 ?? null) &&
    e.file===path.resolve(base,s.file)),'PRODUCTION_EXPORT_RECEIPT_REQUIRED');
  return prod;
}
