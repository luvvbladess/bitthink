// Explicit 1.7.0 -> 1.7.1 execution continuation. Never initializes a new budget or edits its source.
import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {assert as check,fingerprint,loadJSON as load,sameJSON,sha} from './runtime.mjs';
export const executionVersion=m=>m?.execution?.version ?? m?.skill?.version;
export const conceptVersion='1.9.0';
export const priorConceptVersion='1.8.0';
export const legacyConceptVersion='1.8.0-private.20260910';
export const currentConceptIdentity=m=>m?.skill?.name==='static-ad-generation' && m.skill.version===conceptVersion;
export const conceptIdentity=m=>currentConceptIdentity(m) ||
  (m?.skill?.name==='reference-first-static-ads-v1-8-0' && m.skill.version===priorConceptVersion) ||
  (m?.skill?.name==='reference-first-static-ads-v1-7-1' && m.skill.version===legacyConceptVersion);
export const conceptRun=m=>conceptIdentity(m) && m.deliveryMode==='concepts';
export const conceptPhase=m=>conceptRun(m) && !m.finalSelection;
export const integrationVersion=m=>['1.7.1',legacyConceptVersion,priorConceptVersion,conceptVersion].includes(executionVersion(m));
export const finishFirstVersion=m=>['1.7.0','1.7.1',legacyConceptVersion,priorConceptVersion,conceptVersion].includes(executionVersion(m));
const prefix=(a,b,code)=>check(Array.isArray(a) && Array.isArray(b) && a.length>=b.length &&
  b.every((x,i)=>sameJSON(x,a[i])),code);
export function validateContinuationState(m,source,record) {
  check(source.skill?.name==='reference-first-static-ads-v1-5' && source.skill.version==='1.7.0' &&
    !source.execution && !source.continuation,'CONTINUATION_SOURCE_VERSION');
  check(sameJSON(m.skill,source.skill) && sameJSON(m.execution,record.execution),'CONTINUATION_IDENTITY_CHANGED');
  for(const k of ['runId','startedAt','request','budgets','budgetOverrideReason','maxMasters','masterOverrideReason',
    'mode','creativeMode','creativeModeReason','placementProfile','brandIntake'])
    check(sameJSON(m[k],source[k]),`CONTINUATION_RESET ${k}`);
  check(sameJSON(m.research.limits,source.research.limits),'CONTINUATION_RESEARCH_LIMIT_RESET');
  for(const k of ['queries','pagesOpened','adsViewed','elapsedSeconds'])
    check(m.research[k]>=source.research[k],`CONTINUATION_RESEARCH_RESET ${k}`);
  prefix(m.generationCalls,source.generationCalls,'CONTINUATION_CALL_HISTORY_CHANGED');
  prefix(m.finalReview.attempts,source.finalReview.attempts,'CONTINUATION_REVIEW_HISTORY_CHANGED');
  for(const f of source.failures.filter(f=>!['slot','batch'].includes(f.kind)))
    check(m.failures.some(x=>sameJSON(x,f)),'CONTINUATION_FAILURE_HISTORY_CHANGED');
  if(source.enhancement.budget) {
    for(const [k,v] of Object.entries(source.enhancement.budget))
      if(!['blocks','deferrals','reviewDisposition','lastEventAt'].includes(k))
        check(sameJSON(m.enhancement.budget[k],v),`CONTINUATION_ENHANCEMENT_RESET ${k}`);
    prefix(m.enhancement.budget.blocks,source.enhancement.budget.blocks,'CONTINUATION_ENHANCEMENT_HISTORY_CHANGED');
    prefix(m.enhancement.budget.deferrals,source.enhancement.budget.deferrals,'CONTINUATION_ENHANCEMENT_HISTORY_CHANGED');
  }
  check(sameJSON(m.slots.map(s=>s.id),source.slots.map(s=>s.id)),'CONTINUATION_SLOT_RESET');
  for(const old of source.slots) {
    const s=m.slots.find(s=>s.id===old.id);
    if(old.masterId || record.slotMasters?.[old.id])check(s.masterId===(record.slotMasters?.[old.id] ?? old.masterId),
      'CONTINUATION_MASTER_CHANGED');
    check(sameJSON(s.placementProfile,record.slotProfiles[old.id] ?? old.placementProfile),'CONTINUATION_PROFILE_CHANGED');
    prefix(s.production?.exports || [],old.production?.exports || [],'CONTINUATION_EXPORT_HISTORY_CHANGED');
    prefix(s.failures || [],old.failures || [],'CONTINUATION_SLOT_FAILURE_CHANGED');
    prefix(s.placementEvidenceHistory || [],old.placementEvidenceHistory || [],'CONTINUATION_PLACEMENT_HISTORY_CHANGED');
  }
  return true;
}
export async function validateContinuation(m) {
  if(!m.execution && !m.continuation)return;
  check(m.execution?.version==='1.7.1' && m.continuation?.artifact,'CONTINUATION_RECORD_REQUIRED');
  const a=m.continuation.artifact,bytes=await fs.readFile(a.path);
  check(sha(bytes)===a.sha256,'CONTINUATION_RECORD_CHANGED');
  const r=JSON.parse(bytes),sourceBytes=await fs.readFile(r.sourceManifest.path);
  check(sha(sourceBytes)===r.sourceManifest.sha256,'CONTINUATION_SOURCE_CHANGED');
  check(sameJSON(m.continuation.inheritedCallIds,r.inheritedCallIds) &&
    sameJSON(m.continuation.sourcePlacementProfile,r.sourcePlacementProfile),'CONTINUATION_HISTORY_BINDING_CHANGED');
  validateContinuationState(m,JSON.parse(sourceBytes),r);
  for(const a of r.callPackets)check(sha(await fs.readFile(a.path))===a.sha256,'CONTINUATION_PACKET_CHANGED');
  const fp=await fingerprint();
  check(m.execution.packageFingerprint.hash===fp.hash && sameJSON(m.execution.fingerprintFiles,fp.files),
    'CONTINUATION_EXECUTION_PACKAGE_CHANGED');
}
export async function continueRun(sourceFile,destinationFile,correctionFile) {
  const sourcePath=path.resolve(sourceFile),dest=path.resolve(destinationFile),base=path.dirname(sourcePath);
  check(dest!==sourcePath && path.dirname(dest)===base,'CONTINUATION_NEW_SIBLING_REQUIRED');
  for(const f of [dest,`${dest}.continuation.json`])
    try {await fs.access(f);throw Error('CONTINUATION_APPEND_ONLY');}catch(e){if(e.code!=='ENOENT')throw e;}
  const bytes=await fs.readFile(sourcePath),source=JSON.parse(bytes),c=await load(correctionFile);
  check(c.sourceManifestSha256===sha(bytes) && c.sourcePackageFingerprint===source.skill?.packageFingerprint?.hash &&
    typeof c.reason==='string' && c.reason.trim() && c.slotProfiles && typeof c.slotProfiles==='object' &&
    !Array.isArray(c.slotProfiles),'CONTINUATION_EXPLICIT_SOURCE_AND_REASON');
  check(source.skill?.version==='1.7.0' && !source.execution && !source.continuation,'CONTINUATION_SOURCE_VERSION');
  check(source.slots.every(s=>!s.production?.exports?.length),'CONTINUATION_PRE_EXPORT_ONLY');
  const {validateHistoricalCall,validateProductionBudgets}=await import('./image-first.mjs');
  // A continuation never grants an integrity/rights waiver.
  for(const call of source.generationCalls)await validateHistoricalCall(call,base,source,{allowRecoverable:true});
  validateProductionBudgets(source);
  const {validateProfile}=await import('./placement.mjs');
  const slotMasters=c.slotMasters || {};
  for(const [id,master] of Object.entries(slotMasters)) {
    const s=source.slots.find(s=>s.id===id);
    check(s && typeof master==='string' && master.trim() && (!s.masterId || s.masterId===master),
      'CONTINUATION_MASTER_ASSIGNMENT');
  }
  const callSlots=Object.fromEntries(source.generationCalls.map(call=>{
    const matches=source.slots.filter(s=>(slotMasters[s.id] ?? s.masterId)===call.masterId);
    check(matches.length===1,'CONTINUATION_SOURCE_CALL_SLOT_REQUIRED');
    return [call.id,matches[0].id];
  }));
  for(const [id,p] of Object.entries(c.slotProfiles)) {
    const s=source.slots.find(s=>s.id===id);check(s,'CONTINUATION_PROFILE_SLOT');
    validateProfile(p);check(p.width===source.request.width && p.height===source.request.height,'PLACEMENT_REQUEST_DIMENSIONS');
    const calls=source.generationCalls.filter(x=>callSlots[x.id]===id);
    check(calls.every(x=>x.validationError),'CONTINUATION_VALID_CALL_PROFILE_FROZEN');
  }
  const fp=await fingerprint(),m=structuredClone(source);
  m.execution={version:'1.7.1',manifestPath:dest,packageFingerprint:{algorithm:fp.algorithm,hash:fp.hash},fingerprintFiles:fp.files};
  for(const [id,master] of Object.entries(slotMasters))m.slots.find(s=>s.id===id).masterId=master;
  for(const [id,p] of Object.entries(c.slotProfiles))m.slots.find(s=>s.id===id).placementProfile=p;
  const r={kind:'finish-first-integration-continuation',createdAt:new Date().toISOString(),reason:c.reason,
    sourceManifest:{path:sourcePath,sha256:sha(bytes)},sourceSkill:source.skill,execution:m.execution,
    inheritedCallIds:source.generationCalls.map(x=>x.id),sourcePlacementProfile:source.placementProfile,slotProfiles:c.slotProfiles,slotMasters,
    callPackets:await Promise.all(source.generationCalls.map(async x=>{
      const file=path.resolve(base,x.packetPath);return {path:file,sha256:sha(await fs.readFile(file))};
    }))};
  const rb=Buffer.from(JSON.stringify(r,null,2)+'\n');
  m.continuation={artifact:{path:`${dest}.continuation.json`,sha256:sha(rb)},
    inheritedCallIds:r.inheritedCallIds,sourcePlacementProfile:r.sourcePlacementProfile};
  validateContinuationState(m,source,r);
  await fs.writeFile(`${dest}.continuation.json`,rb,{flag:'wx'});
  await fs.writeFile(dest,JSON.stringify(m,null,2)+'\n',{flag:'wx'});
  return {manifestPath:dest,sourceManifest:r.sourceManifest,execution:m.execution,
    callCount:m.generationCalls.length,imageCount:m.generationCalls.reduce((n,x)=>n+x.imageCount,0),
    note:'Original identity, history, start time and budgets preserved. New bindings, exports and fresh review required.'};
}
if(process.argv[1] && import.meta.url===pathToFileURL(path.resolve(process.argv[1])).href) {
  // Do not suspend this module's evaluation: dynamic imports below import this module back.
  void (async()=>{
  try {
    const [command,source,dest,correction]=process.argv.slice(2);
    check(command==='continue' && source && dest && correction,'Usage: run-continuation.mjs continue source-manifest new-sibling-manifest correction.json');
    console.log(JSON.stringify(await continueRun(source,dest,correction),null,2));
  }catch{console.error('CONTINUATION_COMMAND_FAILED');process.exitCode=1;}
  })();
}
