# Deliver the ads

For new concept runs, normal delivery is **every** standalone **Ad concept** file/caption returned in `concepts` by `finish-first.mjs deliveries`, under `references/concept-first.md`; no draft-preview authorization is needed. Never call them launch-ready. The cleared-only rules below govern selected finals, explicit-final and legacy runs; they do not block initial concept delivery.

## Selected finals and legacy runs

Read this section before sharing final ads. Outputs on this path are **quality-cleared standalone ads only**, with required captions. Keep failed attempts, held drafts, references, comparisons and audit records internal. A request to create, test or evaluate ads is not a request for failed-draft previews or comparison boards. Preserve truth, rights and scoped upload restrictions.

1. **Inventory every requested slot.** Read each slot's recorded export, packet and review status. Distinguish rendered, quality-cleared, visually rejected, review-held and never rendered. `actualCount` is quality-cleared delivery, not a count of all existing images. A file is cleared only when `status:"complete"` and `finalVisualReview.status:"cleared"` both hold.
2. **Finish before sharing.** Route observed failures through `references/brand-inputs-finishing.md`'s bounded repair loop and fresh independent review. Do not ask whether to repair an already found defect. Run `node skills/static-ad-generation/scripts/finish-first.mjs deliveries /run/run-manifest.json`; it finalizes/rechecks current records and returns `cleared`, `previews` (empty by default) and an internal withheld inventory. Share only `cleared` files in normal delivery, preserving their bytes.
3. **Do not surface failed attempts by default.** An optional batch download contains only cleared ads and their required captions, never rejected/held drafts, sources or QA records. Retain all attempts internally; a file existing or looking attractive does not clear it. Never delete a rejection, relabel status or reset a budget to improve the handoff.
4. **Report shortfalls truthfully.** Briefly state cleared versus requested count and material blockers, distinguishing visual/technical failure from unavailable/stale review. Do not attach fake thumbnails or substitute duplicates. If no ads cleared, say so; do not omit that brand's outcome or deliver its failed drafts as consolation.
5. **Keep the handoff brief.** Include required captions/destinations and material usage limitations. Neutral status labels belong outside the artwork. For requested variants, distinguish files from concept groups without a mandatory report. No publishing to ad accounts.

Example: “4 of 6 ads cleared review. Two are withheld after the repair limit: one product-edge defect and one typography defect.” Share the four cleared files only; keep all six slots and failed attempts in the internal inventory.

**Placement is a separate status.** Follow `references/placement-safe-zones.md`. Missing/uncertain final-pixel inventory, boundary violations and missing independent placement review are withheld. A house-margin creative with passed local full-box and independent visual checks but no actual Ads Manager preview may be shared only with its returned platform-specific `placementLabel`. This is not placement clearance or platform approval. `visualClearedCount`, delivered `actualCount` and `placementClearedCount` can differ; never describe six visually cleared ads as six placement-cleared ads without required preview evidence. Overlays remain internal.

## Only when draft/diagnostic previews are explicitly requested

For “Show me the rejected drafts” or “Show the current draft for diagnosis,” pass an actual request record as the optional third argument to `deliveries`: `{"explicit":true,"basis":"exact user preview request"}`. Share only the requested preview scope from `previews`, labeled **Unapproved draft**, with a brief reason (visual/technical failure versus review hold). Use separate `drafts/` and `cleared/` folders only for an explicitly requested mixed download. Do not count previews as cleared ads, stop necessary repair by default, or treat user preview feedback as clearance. Inspectable files and honest status are sufficient for a diagnostic preview; it need not pass production QA.

## Only when comparisons are explicitly requested

For “Show the ads beside their inspiration” or an explicit evaluation-comparison request, share comparison pairs in addition to the standalone ads:

1. Put the retained actual inspiration on the left and the unchanged cleared ad on the right, at equal image width with original aspect ratios. Use neutral labels outside the artwork and the actual advertiser name. Record the export/hash shown. Include rejected/held drafts only if the user also explicitly requested them; a comparison request alone does not widen preview scope.
2. Pair multiple indispensable inspirations separately if needed. Do not crop, redraw or replace the source to make the match seem closer. If a reference is missing, say **Inspiration unavailable**; for an authorized photo-grounded exception, say **Production asset, not an inspiration ad**. Never borrow an unrelated ad or previous version to fill the left panel.
3. Add one sentence per concept about borrowed/changed structure and its source URL. Keep production assets and previous-version controls separately labeled; no mandatory large report.

Record explicit user feedback on the exact version and scope. Positive design feedback does not rewrite historical QA, establish rights or claim accuracy, authorize publication, or prove performance. If none cleared, report that outcome without unsolicited failed-draft attachments.
