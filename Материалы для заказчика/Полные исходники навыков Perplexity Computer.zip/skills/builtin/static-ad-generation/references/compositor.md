# Compositor and run record

For new concept runs, use “Run initialization” here, then `references/concept-first.md` for native export/check/delivery. The schema-2 raster/local finishing, exact typography, reference geometry and finalization instructions below are the strict selected-final/legacy path, not prerequisites for first concept sharing.

At initialization read only “Run initialization.” Read “Raster export and localized finishing” after inspecting the complete model rough; read local layer details only when a correction or explicit non-model exception requires them. The image model creates the ad; helpers export it and finish necessary regions, **not design its composition**.

## Run initialization

Use Node 20+ and resolvable `sharp`. Local-layer finishing additionally needs `playwright`, Chromium and Python font tooling; when that capability is unavailable, preserve unchanged whole-ad pixels through `native-raster` and hold finals that require local repair. Optional `PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH` selects an existing browser. Never install into or mutate the skill. Internal helpers `scripts/lib.mjs`, `scripts/image-first.mjs`, `scripts/concept-contract.mjs` and `scripts/fidelity.mjs` handle schema, lineage, geometry and pixels—not creative meaning, rights or authentic reviewer identity.

Run in a separate output directory. All paths below are examples; replace them with absolute paths:

```sh
node skills/static-ad-generation/scripts/manifest.mjs init /run /run/brief.json
node skills/static-ad-generation/scripts/render-ad.mjs /run/master-a/layout.json /run/ad-1
node skills/static-ad-generation/scripts/preflight.mjs /run/master-a/layout.json /run/ad-1.png /run/ad-1.metrics.json /run/ad-1.preflight.json
node skills/static-ad-generation/scripts/manifest.mjs finalize /run/run-manifest.json
```

`brief.json` shape:
```json
{"request":{"exactText":"The current user request; hashed and discarded during initialization.","brand":"Brand","product":"Product","placement":"feed","width":1080,"height":1350,"requestedCount":6},"mode":"standard","creativeMode":"exploration","researchMode":"live","loadedId":null}
```

Init copies `templates/run-manifest.json`, creates exactly the requested slots, records UTC start, Node environment and SHA-256 over **every regular package file**. The fingerprint is SHA-256 of JSON-encoded, path-sorted `{path,sha256}` records, including assets/tests; symlinks fail. `manifest.mjs fingerprint` recomputes it for audit. Do not write run outputs inside the skill or hard-code an unknowable future saved ID.

Init creates the 180-second optional enhancement ledger; read `references/strategy-budget.md` before using `scripts/enhancement.mjs`. Set `strategyPath` to the run-local `templates/strategy-record.json` copy. Missing optional strategy is deferred, not a pass. Separate final image QA is outside that ledger. New runs pin **1.9.0** with explicit `deliveryMode:"concepts"`; retain the resolved `brandIntake` from `references/intake.md`, including notes and reference purposes. Historical runs retain their identity and receipts. For an explicitly authorized pre-export 1.7.0 integration continuation, read `references/placement-safe-zones.md` and run `scripts/run-continuation.mjs`; never reinitialize budgets. Grouping clarification remains separate under `references/fidelity.md`.

Read `references/placement-safe-zones.md` before generation. Supply the run fallback `placementProfile` and optional `slotPlacementProfiles` map in the brief. In 1.7.1 each call first needs `placement.mjs bind`, then the returned `slotId`, `placementBindingSha256`, `placementProfileSha256`, declared `generationGeometry` and measured `outputGeometry`. Preserve the whole generated instruction in actual receipts. The final crop must match the declared centered aspect-preserving crop. Native and localized exports share placement gates. Explicit non-model production uses schema 2; schema-1 examples are historical fixtures, not a bypass.

`creativeMode` defaults to `exploration`, independently of research pace `mode:"standard|fast"` (legacy `mode:"exploration"` remains an exploration alias). Exploration derives `maxMasters` from requested count; it needs no override reason. For requested iterations use `creativeMode:"variants",creativeModeReason:"actual requested direction or selected concepts"`; variants retain a default ceiling of three masters. An explicit user change accepts `maxMasters` plus `masterOverrideReason`. These ceilings do not expand research, rough, image, repair or review budgets. `scripts/concept-contract.mjs` supplies the shared deterministic mode, typed-source and batch consistency checks internally; do not infer semantic approval from them.

## Raster export and localized finishing

1. Retain the actual tool invocation and unchanged response outside the skill. Fill `templates/generation-call.json`: actual tool/model/settings (unknown model/settings null), packet path/master, `complete-ad-generation|complete-ad-edit`, `completeAd:true`, UTC start/end and elapsed seconds computed from that difference, inputs, outputs/hashes and their original returned paths/URLs. Failed calls use `status:"failed"` and actual output count, including zero; keep receipts. `repairOf` is that master's prior call ID. Complete ad is a visual requirement, not established by a boolean.
2. Register every call, then select its real output:

   ```sh
   node skills/static-ad-generation/scripts/manifest.mjs record-generation /run/run-manifest.json /run/call-1.json
   node skills/static-ad-generation/scripts/manifest.mjs select-model /run/run-manifest.json ad-1 image-call-1 0
   ```

   Paths **inside call records resolve from the run directory**. Receipts are `{path,sha256}`. `outputPaths`, `outputHashes`, `outputOrigins` are parallel arrays of length `imageCount`; `outputOrigins` are actual strings retained in the response. Each input is `{path,sha256,role,submittedAs,sourceId}` or uses `referenceId` instead of `sourceId`, never both. `submittedAs` is the actual tool argument path/URL visible in the request; `role` is `composition|exact-sku|logo|treatment|base-photo`. Input bytes must match the packet reference or source/imageRoles path; record reuse and `modelUploadBasis` using the brand-input spoke's task-authority rule, not repeated confirmations. Written-brief-only inputs use `inputImages:[]`. For a repair, add the original immutable model base as a source with provenance to its actual call and inherited in-scope permission; include it only if actually submitted. Helpers cannot discover undeclared inputs.

   Registration appends to `generationCalls[]` with captured `inputClearances` and a record hash. Invalid attempted calls remain with `validationError` and block clearance; never edit them into a pass. Use a new record for a real subsequent invocation, not a duplicate to erase failure. Selection writes a byte-identical, content-addressed copy under `/run/model-outputs/` without overwriting; the slot binds `generationCallId`, call hash and `modelOutput:{path,sha256}`. Keep provider outputs and receipts too. Hashes establish consistency, not proof the provider executed a call.
3. Copy `templates/image-first-plan.json`. Native raster uses `schemaVersion:2`, `production.route:"native-raster"`, manifest/slot binding, and **empty zones/fonts/assets** when no local layers exist. `production.crop:[x,y,w,h]` is an integer rectangle in native model pixels. Its aspect must equal the target canvas exactly; use the entire image when compatible. Otherwise compose for and inspect an aspect-preserving crop. Never stretch 3:4 into 4:5. Opaque single-frame PNG/JPEG/WebP with normalized orientation is supported. Use the unchanged selected model bytes; do not preprocess or replace that immutable original.
4. Inspect the rough first and fill `roughInspection:{modelOutputSha256,inspectedAt,reviewerType:"human|agent-vision",note}`. `rasterRegions:[{id,sourceBox,observation}]` contains actual observed model-pixel regions, not intended DOM boxes; all must remain within the crop. Map reference regions to these IDs using `references/fidelity.md`. Use `font-ratio` only for actual local text; measured raster ink height/width expresses baked-in hierarchy honestly.
5. If necessary, switch to `production.route:"raster-finishing"` and add real local zones plus `finishing:[{id,purpose,regionId,box,zoneIds,reason}]`. `purpose` is `font|spelling|disclaimer|logo|product-identity`. `regionId` names an observed raster region; `box` is an integer **final-canvas** patch inside it. Every local zone must belong to exactly one patch and fit within it. No whole-canvas patch, arbitrary HTML or new connector construction is accepted. A patch may include an erasure shape and replacement lettering/logo/product. No aesthetic/coverage quota is imposed: actual review rejects reconstruction even when its patch geometry is legal. Crop-only changes remain native export.

   Example localized correction on an inspected pale headline region:
   ```json
   {"id":"correct-heading","purpose":"spelling","regionId":"headline","box":[60,60,960,200],"zoneIds":["erase-typo","exact-heading"],"reason":"Correct observed spelling only; retain scale, placement and hierarchy"}
   ```
   Define those real `shape`/`text` zones with exact copy and the actual inspected font under `references/brand-inputs-finishing.md`. Flat erasure is safe only on a genuinely matching flat region; seams, residual letters or textured-background mismatch require another admitted repair, not a preflight waiver. Product insertion needs a `product` asset and credible integration.
6. Run render/preflight with a **new output stem**. Native export skips Chromium. Finishing copies only declared patch pixels onto the actual model base and checks every other pixel unchanged. Metrics record native dimensions, crop, region hashes and actual local font/fit/contrast results; baked-in text receives **no fictitious DOM/font metrics**. Exports append to `slots[].production.exports`; failures remain in `failures[]`. Budget overruns block finalization. Reload the saved manifest after helper commands; never overwrite automatic history with stale JSON. These hashes cannot prove semantic preservation.

For an explicit non-model request/approved exception, set slot `production:{route:"non-model",exception:{kind:"explicit-user-request|approved-exception",basis:"actual authority"},exports:[]}`. A schema-2 plan uses the same exception, manifest and slot binding, no raster fields, and actual local zones; it gets automatic export history. Legacy schema-1 plans still render for technical/historical use and can finalize in a new run **only** with this explicit slot exception; maintain their existing repair history manually. An unrelated model call cannot authorize them.

## Local layer input schema (version 1; also used by version 2 zones)

Copy `assets/examples/layout-plan.json` and `assets/examples/reference-packet.json` into a run only when learning/testing the format. Before running the example, replace the null fixture-font paths in both files with the same absolute path to an available Noto Sans font. `assets/examples/neutral-shapes.png` is test art, not a brand asset or an ad template. The example deliberately uses an asymmetric side image and local text zone; derive production positions from the selected reference instead.

The executable validator is `validatePlan` in `scripts/lib.mjs`, automatically run before rendering and preflight. Unsupported layout properties fail instead of being silently ignored.

| Field | Contract |
|---|---|
| `schemaVersion`, `id` | `1` for legacy deterministic plans; `2` adds the production/raster fields above. Unique token (`a-z`, digits, `_`, `-`, starting with a letter). |
| `canvas` | `{width,height,background}`; exact integer pixels, 1–4096 each; opaque `#RRGGBB`. Device scale factor is 1. |
| `referencePacket` | Path to completed packet JSON, relative to the layout file or absolute. |
| `fonts[]` | `{id,path,weight,style,sourceId,sha256?,substitution,expectedFamily?,expectedPostScriptName?}`. Local TTF/OTF/WOFF/WOFF2; weight 100–900, `normal`/`italic`. New 1.7 schema-2 local text requires SHA-256 and inspected `expectedFamily`; add static-face PostScript name when known. `scripts/font-inspect.py` checks declared family, intrinsic/variable weight, style and glyph coverage before load; Chromium checks actual rendered identity. No synthetic bold/italic. `substitution` is null or `{requested,actual,reason,disclosed:true}`. |
| `assets[]` | `{id,path,role,sourceId,sha256?}`. Local PNG/JPEG/WebP, no animated/multipage/remote assets; normalize EXIF orientation before measuring. Role: `product`, `logo`, `photo`, `evidence`, `illustration`, `component`. Components additionally need `component:{origin,copyIds,fontIds,verification}`; verify permitted pixels, original authorship, exact copy and real font files. Record provenance when rasterizing audited official SVGs. |
| `zones[]` common | `{id,type,role,box:[x,y,w,h],z,parent?}`. Positive dimensions; unique integer `z` gives global back-to-front order. Positions are parent-relative when `parent` is set. Parent is a non-text zone with a lower z; child must stay inside it. Zones render as flat positioned elements with validated semantic nesting, so inherited CSS cannot silently change the plan. |
| `group` / `shape` | `fill` hex; optional for group, required for shape. Optional `radius` (0–half shorter side), inset `borderWidth`/`borderColor` together. Group containment does not clip children. |
| `image` | `assetId`, `fit:"contain|cover"`, `position:[0..100,0..100]`; optional integer source-pixel `crop:[x,y,w,h]`, `radius` clipping. Aspect ratio preserved; feature transforms use the exact crop/fit/position. |
| `line` / `path` | `stroke` hex, `strokeWidth` .5–32; line `points:[[x,y],...]` or path `commands:[["M",x,y],["L",x,y],["Q",cx,cy,x,y],["C",c1x,c1y,c2x,c2y,x,y],["Z"]]`. Zone-local coordinates inside half-stroke margins; 2–128 commands starting with M. Optional opaque path `fill`. No markup. |
| Leaf rotation | `rotation` −180…180 degrees about box center for shape/image/line/path only. No text/group rotation or rotated parents. Rotated bounds are checked for canvas, safe areas and overlaps. |
| `text` | `text`, `copyId`, `fontId`, `fontSize`, `minFontSize` (integer pixel floor), `lineHeight` (.8–3 ratio), `letterSpacing` (-10–50 px), optional `wordSpacing` (-10–50 px, default 0), `color` opaque hex, `align:left/center/right`, `minContrast:4.5` (or 7; 3 requires `contrastNote`). Literal newlines pin intended breaks; actual line/word rectangles and computed spacing are measured. Set min=max to prohibit shrinking; crowded but fitting text still fails visual QA. |
| `overlaps[]` | `{back,front,reason}` for intentional intersections outside ancestor containment. Back/front must match actual z order. All undeclared intersecting bounding boxes fail; transparent margins can cause conservative findings. Document legitimate layering, do not blanket-allow all pairs. |
| `exclusions[]` | `{id,box,roles,basis}`. Placement-specific keep-out rectangles in canvas pixels; relevant role intersections fail. `basis` records current specification/source. Empty for no additional mask; do not invent feed restrictions. |

The executable `capabilities` registry rejects unknown **local layer** fields. No arbitrary HTML/CSS, SVG markup, script, filter, shadow, gradient-text or star API exists. This does not restrict what the image model can create in the complete raster ad. For essential effects use the model, not a template simplification. Authorized precomposed local components still need copy/font provenance. If localized correction cannot preserve the ad, request a model edit or reject within caps.

### Working component example

On a 480×360 canvas these zones draw a rounded query field and curved magnifier:

```json
[
  {"id":"query-field","type":"shape","role":"ui","box":[20,20,220,44],"z":1,"fill":"#ffffff","radius":22,"borderWidth":1,"borderColor":"#20352b"},
  {"id":"search-icon","type":"path","role":"ui","box":[30,30,24,24],"z":2,"stroke":"#20352b","strokeWidth":2,
   "commands":[["M",16,9],["C",16,18,2,18,2,9],["C",2,1,16,1,16,9],["M",14,15],["L",22,22]]}
]
```

Declare `overlaps:[{back:"query-field",front:"search-icon",reason:"Magnifier inside query field"}]`; add literal query/suggestion text with real font/copy IDs and surrounding context. This is not a complete search ad. For fixed coordinates, copy computed `metrics.callouts[].points` into `mode:"fixed"` and rerender. Preflight still checks both ends; a changed crop must not silently reuse the old coordinates.

## Packet, outputs and limits

Complete the packet before production: communication, grounding, typed references, source/permission records, roles, invariants, exact copy/claims and selection. Measure the reference before briefing; measure model raster mappings after rough inspection, never fabricate future observations. Keep all visible intended text in `copy`; each local text must exactly match its `copyId`. Unverified copy is blocked for both routes. A permitted lettering substitute uses copy `fontSubstitution:{requested,actual,reason,permissionBasis,disclosed:true}`. A prompt font name is not verification. Asset/font source IDs still need authorized reuse. Claim/permission fields are attributed records, not automatically verified truth.

The renderer loads local bytes, creates literal text, waits for real FontFace loads, fits within the declared floor and checks rendered font identity/fallback. Logical line/word rectangles and actual raster ink bounds are separate; visible ink outside its zone or touching the export edge fails. It writes `stem.png`, `.metrics.json`, `.preflight.json`; a nonzero exit or `status:fail` means **not quality-cleared**, even with a PNG. Route the failure to bounded repair. Only an explicit diagnostic/draft request may surface an uncleared export. Early input/font/overflow errors throw before export; unsupported glyphs fail. Byte metadata and loaded family do not establish actual brand/ad-font correctness; corroborate the evidence and review the pixels.

Each text zone is temporarily hidden for a background capture and isolated as a glyph mask. Local contrast uses pixels beneath glyph interiors, not a region's mean. It reports min/p05/median/max, failing pixels and suspected occlusion; thresholds and sampling limits are explicit. Occlusion is a manual-inspection warning, not a certified detection: antialiasing changes with text polarity. Re-render after any fixes, including panels. The preflight command rechecks local bytes, geometry, export hash and actual PNG dimensions against recorded metrics; it is not an independent browser rerender or security attestation.

## Finish the run manifest

Update research outcome/count/time/limits, intake, permission decisions, substitutions and reference packets throughout the run. Use the registration/selection contract for image-first calls; retain historical shapes unchanged in old runs. Count discarded images and failed calls; never fabricate provider identifiers.

For each slot, fill `masterId`, output/plan/metrics/preflight paths and producer `qa` entries: `truthAndRights`, `referenceComparison`, `mobileAndFullSize`, `detail`. Each is `{status:"pass"|"fail",reviewerType:"human"|"agent-vision",note:"specific observation"}`. These cannot replace separate final image QA. Exploration's first execution uses `variant:null`; requested versions use `variant:{lever,change,kind}` (`cosmetic`, `message`, `multi-change-exploration`; baseline lever may be `none`). Set `captionRequired:true`/`captionPath` if needed. Provisional complete/draft slots enter `scripts/final-review.mjs`; only current accepted review can clear delivery. Retain blocked/failed slots and all repair/review history.

Fill `batchReview.preRender` and `batchReview.final` using `references/production.md`'s exact grouping/artifact shapes. `actualCount` and `failedCount` reconcile files; `distinctConceptCount` is the recorded complete-ad group count (null if unverified), and `conceptShortfall` is requested count minus that count in exploration, null in variants. `batchSummary` reports coverage/staleness/overlap failures separately; six complete files in two groups cannot give exploration `status:"complete"`. Supplied grouping is visual judgment, not algorithmic similarity detection.

Finalize reruns technical/lineage checks, manual gates and dimensions, rejects duplicate bytes and reconciles all slots. It closes interrupted enhancement blocks and derives creative records. Image-first runs check call/image/rough/repair ceilings; 1.7 uses `finish-first.mjs admit/next` before work to preserve repair capacity. Admission cannot preempt tools or discover omitted work. Independent review binds original model/input/finishing and final bytes, never revised exports or siblings. Use `finish-first.mjs deliveries` for the cleared-only sharing inventory. Six files are not six cleared concepts; no helper authenticates subjective QA or rights.
