# Routing and optional creative intake

Read at the start of a new ad task and when the user supplies new direction. This changes interaction only: retain Astra's integrated copy/art direction, reference research, whole-ad generation, delivery gates and repair limits. Do not turn the answers into a new copywriting stage, density target or fixed layout recipe.

## Route the request

- **New static ads:** "Make ads for [brand]," "Create Instagram static creatives," or "Make ads like this for my product." Use this skill alone; do not load an older ad-production skill alongside it.
- **Existing-ad variations:** "Make three versions of this ad" is variants, not a new six-concept exploration. Identify the source ad and requested changes from context first.
- **Adjacent work:** Do not route video, email, landing pages, campaign diagnosis, generic marketing help, or a brand name without ad-creation intent here. Do not silently convert an explicit video request into static.
- **Blocking ambiguity:** Ask for the brand/site only if absent or ambiguous after checking context. If ambiguous media or an unavailable existing ad prevents the requested work, resolve that specific gap. Do not ask a blanket goals/audience/budget questionnaire.

The description guides model selection of the skill, not a deterministic keyword router. For a version comparison, use separate fresh tasks and record the loaded version explicitly.

## One missing-only clarification

1. Check attachments, earlier answers/declines and relevant reusable brand context. Keep the real origin of decisions. Reuse brand assets/guidelines for that brand, not stale campaign direction or offers. Create a stable `taskKey` for this ad task; retain it through resumed turns and repairs, change it for a new campaign/task.
2. Start from the `brandIntake` shape in `templates/run-manifest.json`. Fill checked flags, task key and any resolved fields from real context. Run `node skills/static-ad-generation/scripts/finish-first.mjs intake /run/intake.json /run/effective-intake.json` (or the standalone `scripts/intake.mjs` with the same two paths). The result contains `status`, an `effectiveArtifact` path/hash, question IDs and a tool-ready `form`; the normalized records are written to that run-local artifact rather than stdout.
3. If `status:"ask"`, send the returned `form` in **one `request_user_input` call**. It contains up to three separate questions: direction, assets, guidelines. All allow attachments and free-text responses; concrete choices provide defaults. Do not ask three serial rounds or add a second "anything else?" question. Preserve scope if a supplied reference already resolves direction but not assets.
4. Record dispatched questions as `awaiting-answer`, with their `taskKey`, actual basis and available interaction reference. Persist pending state around dispatch so a resumed run does not infer an answer. If dispatch fails, restore those fields to unresolved; do not claim the question was shown. `awaiting-answer` returns no new form and blocks generation. Legacy `asked` also means pending, not resolved; when recovering one in the same task, bind it to that task key from real context.
5. Map the actual answers into the fields below, preserving verbatim notes, attachments/URLs and restrictions. Re-run the helper. Save `effective` records into `brandIntake` without dropping checked flags, task key, blockers, notes or provenance. Proceed only on `ready`; retain pending fields on partial responses. Silence is not a skip. An explicit "skip the rest" defaults only the remaining questions in this task.
6. State scope and material assumptions briefly, without requesting approval. Respect supplied count/product/placement; otherwise retain six 1080×1350 feed concepts and select a clearly featured product with a stated assumption. Resolve and bind the named placement before generation. Continue straight to research and complete images, not copy or concept approval.

### Answer handling

| Input | Record and behavior |
|---|---|
| Notes or a complete brief | `creativeDirection:{status:"provided",basis,taskKey,notes,references:[]}`. Preserve product, occasion, audience, tone, mandatory text and avoid-list when supplied; do not demand every field. |
| "Choose for me" | Direction `defaulted`, with the user's actual answer as basis and current task key. Use varied reference-led concepts; do not infer asset permission or skip other unanswered fields. |
| "Promote an offer" | Preserve the choice and any terms in notes. Verify terms from supplied/official evidence. If the requested offer remains unknown, add a material blocker and ask only for the missing terms; never invent a discount or quietly change an offer-led request to evergreen. |
| "Iterate an existing ad" | Preserve reference and changes; initialize `creativeMode:"variants"` with the user's basis. If the source is not identifiable/accessibly inspectable, request that ad only; do not synthesize a supposed original. |
| "Use official assets" / "Follow the website" | Resolve only the corresponding question. A broader pre-existing `officialAssetsDecision` resolves assets and guidelines, unless explicitly scoped to one. It does not resolve creative direction. |
| "Use attached assets only" | Preserve this restriction in `assetLibrary.notes`. If none is attached, add a blocker and request the files; no silent official-asset fallback. |
| "None", "skip", "no specific guidelines" | `declined` or `defaulted` with real basis. Use official discovery where permitted; do not repeat the declined question. |
| "Use the website and choose everything" | `defaultsDecision:{basis,taskKey,scope:["creativeDirection","assetLibrary","guidelines"]}`. Pre-fill applicable fields or use helper defaults; never override explicit per-field restrictions. When this answers pending questions, resolve those fields explicitly too. |
| Supplied link cannot be read | Try the applicable normal read path. If optional, explain the limitation and continue only under an already authorized fallback. If essential or exclusive, request an upload/access fix for that input, not the whole intake again. |

Statuses: `unknown|missing|awaiting-answer|asked|provided|declined|defaulted`. Every non-unknown/missing status needs `basis`; resolved direction and pending questions require the current `taskKey`. Reuse the existing `brandIntake` object, not a second approval ledger. `blockers:[{id,basis}]` records unresolved material gaps; clear each only after an answer or explicit scope change. Cancellation uses `cancelled:true,cancellationBasis`; stop work, do not treat it as "choose for me."

Example resolved input (illustrative, never fabricate this decision):

```json
{
  "attachmentsChecked": true,
  "reusableContextChecked": true,
  "taskKey": "current-ad-task",
  "creativeDirection": {
    "status": "provided",
    "basis": "Current request and attached inspiration",
    "taskKey": "current-ad-task",
    "notes": "A gifting focus. No discount or urgency.",
    "references": [{"location": "/run/reference.png", "use": "inspiration", "note": "User likes the product scale"}]
  },
  "assetLibrary": {"status": "defaulted", "basis": "User chose Use official assets"},
  "guidelines": {"status": "declined", "basis": "User said no additional guidelines"},
  "officialAssetsDecision": null,
  "defaultsDecision": null,
  "blockers": []
}
```

## Use the direction without weakening the ad workflow

Inspect references and preserve what the user values: imagery, tone, layout or selling approach. If not specified, treat them as inspiration, not permission for literal copying. Record reference purpose separately from product/logo assets. Uploaded images are neither proven winners nor automatic source/claim/upload clearance; existing research eligibility and authority rules still apply. Photos remain photos; `photo-grounded` needs the original explicit asset-led request or approved fallback.

Carry the resolved notes, restrictions and reference purposes into the producer's existing strategy/packet and generation brief. Do not replace them with a generic "benefit-led" tag. Offer selection is not proof of terms; a testimonial request is not evidence of a quote. Resolve conflicts with truthful source bounds before freeze. A late answer updates only affected work; retain prior receipts and budgets, never restart the whole batch silently.

Deliver every helper-ready standalone image directly in the conversation with its caption and essential limitations. Do not substitute a Google Drive link, JSON, copy document or contact sheet for the ads. Ask for feedback on the images; explicit selection can begin the existing finalization route. Variants and repairs do not restart onboarding. No publishing or ad-account connection is required merely to create concepts.
