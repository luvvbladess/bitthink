# Perplexity Computer Analytics

Inspect Computer usage analytics with the `pplx analytics computer` command group.

Run `pplx analytics` subcommands inside the `bash` tool with `api_credentials=["pplx-sdk"]` (the analytics credential attaches automatically); use `--help` on any level to inspect current options.

- `pplx analytics computer usage get` prints usage-over-time datasets as JSON — credit usage by default, with other dataset kinds and the aggregation window selectable via flags. Pass `--datasets` (comma-separated, several per call) to choose: `credit_usage` (credits, 1 credit = 1¢), `query_volume` (queries, splittable by Search vs Computer and by Project or Comet), `daily_active_users` (distinct members who queried that UTC day), or the thread-counting datasets `connectors`, `artifacts`, `skills`, `spaces`, `workflows`, `task_durations`. `--scope org` (default) is the organization-wide view and requires org insights access; `--scope user` is the caller's own usage. Pass `--user-email <email>` to read a specific member's usage; this also requires org insights access and returns that member's per-user data regardless of `--scope`.
- `pplx analytics computer leaderboard get` prints the paginated member credit-usage leaderboard as JSON.
- `pplx analytics computer table get --dataset <name>` ranks **members** for one dataset over the window, highest first, paginated. Use this when the question is *which people*, rather than a trend over time. `--dataset` takes exactly one of `credit_usage` (credits per member) or `query_volume` (queries per member) — there is no per-member table for `daily_active_users`. One dataset per call; ask twice for two tables. `--limit` (1-1000, default 50) and `--cursor` page through the rows, and the response's `next_cursor` is what to pass back.

On `usage get`, `query_volume` and `daily_active_users` are organization-wide only: they aggregate per organization and have no per-user rows, so do not request them with `--scope user` or `--user-email`. For per-member query volume use `table get`, which reads a different, per-member dataset.

`table get` ranks by each member's total for the dataset. For `query_volume` that total spans Search and Computer; the split lives in each row's `by_categories.Feature`. A question about one feature's top users therefore cannot be answered from the first page — collect every page and re-sort by that breakdown, or say the ranking is by total queries.

The same dataset name means a different grain on each command: on `usage get` `query_volume` is the organization's daily total, while on `table get` it is per member. Pick the command by the shape of the answer — a trend over days, or a ranking of people.

`daily_active_users` reports one distinct-member count per UTC day. Those counts are not additive: a member active on several days appears in each day's count, so summing the days does not give the number of distinct members over the window. It has no per-member table, since a distinct count does not attribute to individuals.

Identity is implicit from the session; do not pass an org id or the user's identity. Organization-wide reads require org insights access, which org admins hold and which an org can also grant a member through roles. The leaderboard and `table get --dataset credit_usage` additionally admit ordinary members when the org has made the leaderboard visible to them. On an authorization error, report the requested result as unavailable first. Every available retry changes whose data comes back, so a retry is a different answer offered alongside that, never a substitute for it.

- Targeting another member (`--user-email`): do not retry. Dropping the flag returns the caller's own usage, which is not that member's, and keeping it fails identically — the handler resolves the same org-insights gate before scope is read.
- Organization-wide `usage get`: the caller's own usage is available instead, labelled as theirs. Drop `query_volume` and `daily_active_users` from that retry, which have no per-user form and would come back zero-filled or rejected, and report those as organization-wide and unavailable. If nothing remains, do not retry.
- `leaderboard get` and `table get`: no `--scope` flag and no per-caller equivalent. Report the ranking as unavailable. A personal trend is not a ranking of members.