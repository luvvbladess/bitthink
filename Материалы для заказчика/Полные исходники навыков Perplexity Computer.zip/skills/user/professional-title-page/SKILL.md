---
name: professional-title-page
description: "Титульные листы DOCX: горизонтальное и вертикальное центрирование названия, единственные город и год в нижнем колонтитуле, нумерация со второй страницы. Применять при создании отчётов, ТЗ и записок; не использовать для редактирования основного текста."
---

# Правильный титульный лист DOCX (python-docx)

Правила выработаны на живых документах. Не «улучшать» без явной просьбы — если пользователь просит именно эти пункты, применяй как есть.

## Обязательные условия «нормального» титула

1. **Название и подзаголовок — строго по центру по горизонтали и как единый блок по вертикали**, без красной строки. Центр блока должен совпадать с серединой полезной высоты страницы с допуском не более 10 мм.
2. **Город и год — прижаты к низу страницы**, по центру, в нижнем колонтитуле титульной страницы (а не пустыми параграфами и не в теле).
3. **Номер страницы на титуле не выводится**, но на всех остальных страницах — стоит.
4. **Год указывается ровно один раз.** Не выводи одновременно полную дату в теле титула и год в колонтитуле. По умолчанию используй в колонтитуле две строки: населённый пункт и четырёхзначный год. Полную календарную дату выводи только по явному требованию пользователя и тогда не дублируй год отдельной строкой.
5. Если населённый пункт нельзя однозначно определить из названия объекта, исходного документа или явного указания пользователя, спроси его до сборки. Не подставляй город пользователя, компании или среды выполнения.

## Проверенные приёмы

### 1. Название и подзаголовок по центру

Самая частая ошибка: при `WD_ALIGN_PARAGRAPH.CENTER` оставляют `first_line_indent = Mm(12.5)` (красная строка), из-за чего строка визуально смещается вправо на 12.5 мм. Кажется «не по центру».

Правильно: при центрировании обязательно **выключать красную строку**.

```python
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Pt, Mm

def par(doc, text="", *, align=None, indent=True, size=14, bold=False, ...):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    if indent:
        pf.first_line_indent = Mm(12.5)   # красная строка
    p.alignment = align if align is not None else WD_ALIGN_PARAGRAPH.JUSTIFY
    ...

# Для названия и подзаголовка на титуле — ОБЯЗАТЕЛЬНО indent=False
par(doc, "ОТЧЁТ",
    align=WD_ALIGN_PARAGRAPH.CENTER, indent=False, bold=True, size=20)
par(doc, "по первичному анализу исходных материалов",
    align=WD_ALIGN_PARAGRAPH.CENTER, indent=False, size=16)
```

Не полагайся только на вертикальное выравнивание секции: LibreOffice может сохранить `w:vAlign`, но визуально его проигнорировать. Основной межредакторный механизм — невидимая таблица 1×1 высотой 245 мм при полях 20 мм сверху и снизу. Ячейка выравнивается по вертикали по центру, а название и подзаголовок помещаются внутрь неё:

```python
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_ROW_HEIGHT_RULE

table = doc.add_table(rows=1, cols=1)
table.alignment = WD_TABLE_ALIGNMENT.CENTER
table.autofit = False
hide_table_borders(table)
row = table.rows[0]
row.height = Mm(245)
row.height_rule = WD_ROW_HEIGHT_RULE.EXACTLY
cell = table.cell(0, 0)
cell.width = Mm(180)  # текстовая зона A4 при полях 20/10 мм; у таблицы tblInd = 0 и поля ячейки 0 (w:left/w:right)
cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
set_cell_margins(cell, top=0, start=0, bottom=0, end=0)

title_p = cell.paragraphs[0]
title_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
title_p.paragraph_format.first_line_indent = Mm(0)
# Добавить название.

subtitle_p = cell.add_paragraph()
subtitle_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
subtitle_p.paragraph_format.first_line_indent = Mm(0)
# Добавить подзаголовок.
```

После формирования первой секции дополнительно включи вертикальное выравнивание её содержимого по центру. Элемент `w:vAlign` нельзя просто добавлять в конец `sectPr`: это нарушает порядок элементов OOXML и может дать невалидный DOCX. Вставляй его в допустимое место:

```python
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

def center_section_content_vertically(section):
    sectPr = section._sectPr
    old = sectPr.find(qn("w:vAlign"))
    if old is not None:
        sectPr.remove(old)
    v_align = OxmlElement("w:vAlign")
    v_align.set(qn("w:val"), "center")
    sectPr.insert_element_before(
        v_align,
        "w:noEndnote", "w:titlePg", "w:textDirection", "w:bidi",
        "w:rtlGutter", "w:docGrid", "w:printerSettings", "w:sectPrChange",
    )
```

Применяй функцию только к титульной секции. Не создавай над заголовком пустые параграфы для имитации вертикального центра.

### 2. Город и год — в нижний колонтитул титульной страницы

Не пустыми параграфами, не пробелами, не «примерным» количеством переносов строки — они смещаются при любых правках. Правильный способ:

- Титульный лист выносится в отдельную секцию документа (первая секция).
- У неё включается «особый колонтитул первой страницы» (`different_first_page_header_footer = True`) — это стандартный переключатель Word.
- Город и год пишутся именно в этот колонтитул. Он показывается только на первой (титульной) странице секции, а не на всём документе.
- Стандартный колонтитул титульной секции остаётся пустым.

```python
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Pt

def set_first_page_special_footer(section, lines):
    """Кладёт строки (город, год) в колонтитул первой страницы секции.
    Обычный колонтитул секции остаётся пустым — на первой странице не показывается."""
    section.different_first_page_header_footer = True
    ff = section.first_page_footer
    # очищаем от заглушки
    for _p in list(ff.paragraphs):
        _p._element.getparent().remove(_p._element)
    for line in lines:
        p = ff.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        pf = p.paragraph_format
        pf.space_before = Pt(0)
        pf.space_after = Pt(0)
        pf.line_spacing = 1.15
        r = p.add_run(line)
        r.font.name = "Times New Roman"
        r.font.size = Pt(14)
```

Применение:

```python
set_first_page_special_footer(doc.sections[0], ["Абхазия", "2026"])
```

### 3. Номер страницы в футере — только на второй и далее секциях

Титульная секция — без номера страницы. Основная секция (со следующей после титула страницы) — с номером страницы в футере. Основная секция создаётся через разрыв секции.

```python
from docx.enum.section import WD_SECTION
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

def add_page_num_footer(section):
    footer = section.footer
    p = footer.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run()
    run.font.name = "Times New Roman"
    run.font.size = Pt(12)
    fc1 = OxmlElement('w:fldChar'); fc1.set(qn('w:fldCharType'), 'begin')
    it  = OxmlElement('w:instrText'); it.set(qn('xml:space'), 'preserve'); it.text = 'PAGE'
    fc2 = OxmlElement('w:fldChar'); fc2.set(qn('w:fldCharType'), 'end')
    run._r.append(fc1); run._r.append(it); run._r.append(fc2)

# ---- Порядок в скрипте ----
title_sec = doc.sections[0]
# ... вывод только названия и подзаголовка через par(..., indent=False) ...

# Разрыв секции — новая страница = начало основной секции
main_sec = doc.add_section(WD_SECTION.NEW_PAGE)
add_page_num_footer(main_sec)                        # номер страницы для основной секции

# Только ПОСЛЕ создания основной секции ставим колонтитул первой страницы титула.
# После разрыва секции титульная секция — это doc.sections[0].
set_first_page_special_footer(doc.sections[0], ["Абхазия", "2026"])
center_section_content_vertically(doc.sections[0])
```

## Что НЕ работает и делать не надо

- Ставить «Абхазия / 2026» через пачку пустых параграфов в теле титула. При любом изменении шрифта или полей они смещаются, и город с годом висят в середине страницы.
- Печатать дату под подзаголовком, а затем повторять год внизу. Это дублирование и нарушение структуры титула.
- Забывать `indent=False` при `align=CENTER`. Текст будет визуально уходить вправо.
- Полагаться только на `w:vAlign`. В LibreOffice это свойство может не дать визуального центрирования; полноформатная таблица 1×1 обязательна.
- Добавлять `w:vAlign` в конец `sectPr`. Используй `insert_element_before(...)`, иначе документ может не пройти OOXML-валидацию.
- Пытаться вручную создавать отдельные footer-файлы в контейнере DOCX через низкоуровневые манипуляции. Стандартный переключатель «особый колонтитул первой страницы» решает задачу и корректно поддерживается Word, LibreOffice и PDF-конвертером.

## Проверка после сборки

Перед выдачей всегда:

1. `libreoffice --headless --convert-to pdf <файл>.docx`
2. Открыть PDF, посмотреть глазами:
   - страница 1 в полноэкранном масштабе: середина общего блока «название + подзаголовок» находится в пределах 10 мм от середины полезной высоты страницы;
   - внизу страницы 1 находятся город и год, а в теле титула нет даты или повторного года;
   - год встречается на странице 1 ровно один раз; номера страницы нет;
   - страница 2: номер «2» в футере по центру;
   - последняя страница: правильный номер, футер не потерян.
3. Проверить XML и структуру: титульный блок находится в невидимой таблице 1×1 с точной высотой и вертикальным выравниванием ячейки; у первой секции есть `w:vAlign w:val="center"` и особый колонтитул первой страницы; у центрированных абзацев нет красной строки.
4. Если что-то не так — чинить и пересобирать, не отдавать пользователю сырое.

## Единый постконтроль

После использования выполни короткий внутренний постконтроль без дополнительных вызовов. Фиксируй улучшение только при обнаружении повторной операции, ошибки или подтверждённого реально более быстрого способа. Если такого сигнала нет, ничего не фиксируй.
