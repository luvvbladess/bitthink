# Технические заметки по PyMuPDF для нанесения пометок

Накопленные нюансы, найденные в процессе итераций с реальным чертежом.

## Пунктирные линии

**Работает:**

```python
import fitz
RED = (0.85, 0.05, 0.10)
page.draw_rect(rect, color=RED, width=1.0, dashes="[3 2] 0")
```

**НЕ работает** (пунктир не рендерится, получается сплошная линия):

```python
shape = page.new_shape()
shape.draw_rect(rect)
shape.finish(color=RED, width=1.0, dashes="[3 2] 0")
shape.commit()
```

Формат `dashes`: `"[on off] phase"`. Значения в пунктах. Для более плотного штриха — `"[2 1] 0"`, для более редкого — `"[5 3] 0"`.

## Поиск текста для позиционирования пометок

`page.search_for(text)` возвращает список `Rect` для найденных вхождений.

**Ловушки:**

- Кириллица и латиница не смешиваются. Позиционное обозначение «A1» (латиница) не найдётся по запросу с кириллической «А1» и наоборот. Проверяй обе кодировки:

  ```python
  hits = page.search_for("A1") or page.search_for("А1")
  ```

- Поиск чувствителен к пробелам и переносам. Обозначение «R 1» в PDF (с пробелом) не найдётся по «R1».
- Если элемент состоит из нескольких текстовых фрагментов (например, «X» на одной глифе, «T1» на другой), `search_for` найдёт только их сочетание, если они в одном текстовом блоке.

**Fallback**: использовать `page.get_text("dict")` и обходить блоки/строки/спаны вручную.

## Центрирование текста в кружке

```python
import fitz

def draw_number_circle(page, cx, cy, number, r=14):
    RED = (0.85, 0.05, 0.10)
    WHITE = (1, 1, 1)
    # Круг: белая заливка, красный контур
    page.draw_circle(fitz.Point(cx, cy), r, color=RED, fill=WHITE, width=1.4)
    # Текст: центрирование по метрике
    s = str(number)
    fs = 12
    w = fitz.get_text_length(s, fontname="hebo", fontsize=fs)
    x = cx - w / 2
    y = cy + fs * 0.36  # эмпирическая поправка на baseline
    page.insert_text(fitz.Point(x, y), s, fontname="hebo", fontsize=fs, color=RED)
```

Шрифт `hebo` = Helvetica-Bold, встроенный в PyMuPDF, работает без установки.

## Стрелка от кружка к обводке

Строится по двум точкам: `start` — на границе кружка со стороны обводки, `end` — на ближайшей точке границы прямоугольника обводки.

```python
import math

def nearest_point_on_rect(rect, px, py):
    x = max(rect.x0, min(px, rect.x1))
    y = max(rect.y0, min(py, rect.y1))
    return fitz.Point(x, y)

def draw_arrow(page, cx, cy, r, target_rect):
    RED = (0.85, 0.05, 0.10)
    end = nearest_point_on_rect(target_rect, cx, cy)
    # Начало стрелки — на границе кружка со стороны end
    dx, dy = end.x - cx, end.y - cy
    d = math.hypot(dx, dy)
    if d < r + 2:
        return  # кружок и обводка соприкасаются, стрелка не нужна
    start = fitz.Point(cx + dx / d * r, cy + dy / d * r)
    page.draw_line(start, end, color=RED, width=0.8)
    # Наконечник
    ang = math.atan2(dy, dx)
    L, W = 6, 4
    p1 = fitz.Point(end.x - L * math.cos(ang) + W * math.sin(ang),
                    end.y - L * math.sin(ang) - W * math.cos(ang))
    p2 = fitz.Point(end.x - L * math.cos(ang) - W * math.sin(ang),
                    end.y - L * math.sin(ang) + W * math.cos(ang))
    page.draw_polyline([p1, end, p2], color=RED, width=0.8)
```

## Проверка результата

Всегда рендерь PDF после разметки в JPEG и открывай через `read`, чтобы визуально убедиться:

```bash
pdftoppm -jpeg -r 130 result.pdf result_page
```

Затем `read` каждой страницы `result_page-1.jpg`, `result_page-2.jpg`. Смотри — не наезжает ли обводка на текст, не перекрывает ли кружок элемент, идёт ли стрелка к правильному месту.

## Типичные ошибки

- **Обводка на «Победит» / «Свет» / «Финдер»** — правая граница слишком широкая, задевает соседний столбец таблицы. Проверить `rect.x1`, сузить.
- **Кружок наезжает на элемент** — сдвинуть кружок в свободное поле (обычно вправо-вверх от обводки).
- **Стрелка через текст** — либо перенести кружок в другую сторону, либо укоротить стрелку и подвинуть end ближе к границе обводки.
- **Замечание на неправильном листе** — проверить, что `page = doc[page_no]` соответствует реальному листу с элементом.
