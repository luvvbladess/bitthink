#!/usr/bin/env python3
# Эталонный скрипт нанесения пометок нормоконтроля на PDF.
# Копировать в /home/user/workspace/, адаптировать под конкретный чертёж:
#   - SRC / DST — исходный и выходной PDF
#   - список REMARKS — координаты обводок, кружков, номеров, целей стрелок

import fitz
import math

# ---------- параметры стиля ----------
RED = (0.85, 0.05, 0.10)
WHITE = (1, 1, 1)
DASH = "[3 2] 0"
FRAME_WIDTH = 1.0
CIRCLE_R = 14
CIRCLE_WIDTH = 1.4
ARROW_WIDTH = 0.8
FONT = "hebo"          # Helvetica-Bold
FONT_SIZE = 12
ARROW_HEAD_L = 6
ARROW_HEAD_W = 4


# ---------- геометрия ----------
def nearest_point_on_rect(rect, px, py):
    x = max(rect.x0, min(px, rect.x1))
    y = max(rect.y0, min(py, rect.y1))
    return fitz.Point(x, y)


# ---------- элементарные рисовалки ----------
def draw_frame(page, rect):
    """Пунктирная красная обводка."""
    page.draw_rect(rect, color=RED, width=FRAME_WIDTH, dashes=DASH)


def draw_number_circle(page, cx, cy, number):
    """Кружок с номером в центре."""
    page.draw_circle(fitz.Point(cx, cy), CIRCLE_R,
                     color=RED, fill=WHITE, width=CIRCLE_WIDTH)
    s = str(number)
    w = fitz.get_text_length(s, fontname=FONT, fontsize=FONT_SIZE)
    x = cx - w / 2
    y = cy + FONT_SIZE * 0.36
    page.insert_text(fitz.Point(x, y), s,
                     fontname=FONT, fontsize=FONT_SIZE, color=RED)


def draw_arrow(page, cx, cy, target_rect):
    """Стрелка от кружка к ближайшей точке обводки."""
    end = nearest_point_on_rect(target_rect, cx, cy)
    dx, dy = end.x - cx, end.y - cy
    d = math.hypot(dx, dy)
    if d < CIRCLE_R + 2:
        return
    start = fitz.Point(cx + dx / d * CIRCLE_R, cy + dy / d * CIRCLE_R)
    page.draw_line(start, end, color=RED, width=ARROW_WIDTH)
    ang = math.atan2(dy, dx)
    L, W = ARROW_HEAD_L, ARROW_HEAD_W
    p1 = fitz.Point(end.x - L * math.cos(ang) + W * math.sin(ang),
                    end.y - L * math.sin(ang) - W * math.cos(ang))
    p2 = fitz.Point(end.x - L * math.cos(ang) - W * math.sin(ang),
                    end.y - L * math.sin(ang) + W * math.cos(ang))
    page.draw_polyline([p1, end, p2], color=RED, width=ARROW_WIDTH)


# ---------- полный маркер ----------
def annotate(page, remark):
    """
    remark = {
      "n": 1,                           # номер замечания
      "frame": (x0, y0, x1, y1),        # прямоугольник обводки элемента
      "circle": (cx, cy),               # центр кружка с номером (снаружи frame)
    }
    """
    rect = fitz.Rect(*remark["frame"])
    cx, cy = remark["circle"]
    draw_frame(page, rect)
    draw_arrow(page, cx, cy, rect)         # сначала стрелка (под кружком)
    draw_number_circle(page, cx, cy, remark["n"])


# ---------- пример использования ----------
if __name__ == "__main__":
    SRC = "input.pdf"
    DST = "input-normokontrol.pdf"

    # Замечания: список словарей. Разбит по страницам через ключ "page"
    # (0-based). Заполняется под конкретный чертёж.
    REMARKS = [
        # {"page": 0, "n": 1, "frame": (100, 100, 200, 130), "circle": (240, 80)},
        # {"page": 0, "n": 2, "frame": (300, 400, 380, 430), "circle": (420, 380)},
        # {"page": 1, "n": 3, "frame": (150, 200, 260, 240), "circle": (300, 180)},
    ]

    doc = fitz.open(SRC)
    for r in REMARKS:
        page = doc[r["page"]]
        annotate(page, r)
    doc.save(DST)
    doc.close()
    print(f"Saved: {DST}")
