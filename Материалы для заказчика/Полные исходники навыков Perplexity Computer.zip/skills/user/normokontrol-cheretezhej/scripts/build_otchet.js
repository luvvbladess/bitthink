// Эталонный сборщик отчёта нормоконтроля в Word по ГОСТ Р 7.0.97-2016.
// Требует npm-пакет 'docx'. Проверено: docx@8.x работает в песочнице.
//
// Использование:
//   1. Скопировать в /home/user/workspace/build_otchet.js
//   2. Заполнить константы DOC_INFO и массив REMARKS
//   3. Запустить: node build_otchet.js
//
// Никаких таблиц. Только нумерованный список замечаний. Русский, Times New Roman 12 pt.

const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
  LevelFormat, PageOrientation, convertMillimetersToTwip,
} = require("docx");
const fs = require("fs");

// ---------- заполнить под каждый проект ----------
const DOC_INFO = {
  designation: "УОБВ-СВ-250-ШЭ-000.00",     // обозначение изделия
  changeMark: "изм. а2",                     // литера изменения
  docKinds: "Э3 и ПЭ3",                      // какие документы проверялись
  productName: "Шкаф электропитания и распределения СУБВ-СВ-500",
  organization: "ООО «БИТШИП»",
  inspector: "М.Ю. Юдин",
  inspectorRole: "инженер-конструктор",
  outputFile: "Otchet_normokontrolya.docx",
};

const STANDARDS_USED = [
  "ГОСТ 2.104-2006 «Основные надписи»",
  "ГОСТ 2.105-2019 «Общие требования к текстовым документам»",
  "ГОСТ 2.201-80 «Обозначение изделий и конструкторских документов»",
  "ГОСТ 2.301-68 «Форматы»",
  "ГОСТ 2.303-68 «Линии»",
  "ГОСТ 2.304-81 «Шрифты чертёжные»",
  "ГОСТ 2.316-2008 «Правила нанесения надписей, технических требований и таблиц»",
  "ГОСТ 2.701-2008 «Схемы. Виды и типы. Общие требования»",
  "ГОСТ 2.702-2011 «Правила выполнения электрических схем»",
  "ГОСТ 2.710-81 «Обозначения буквенно-цифровые в электрических схемах»",
  "ГОСТ Р 7.0.97-2016 «Организационно-распорядительная документация. Требования к оформлению»",
];

// Каждое замечание — объект с текстом. Нумерация проставляется автоматически.
// Формулировка: «Место. Суть. Норма: ГОСТ N-YYYY, п. X.Y. Действие.»
const REMARKS = [
  // "Лист 1, зона B3. Позиционное обозначение «K1» отсутствует в перечне элементов ПЭ3. Норма: ГОСТ 2.702-2011, п. 6.1. Действие: добавить строку в ПЭ3 или удалить УГО со схемы.",
  // "Лист 2, основная надпись. В графе 4 указана литера «А», однако в извещении № 117 установлена литера «а2». Норма: ГОСТ 2.104-2006, п. 4.1; ГОСТ 2.503-2013. Действие: привести литеру в соответствие с извещением.",
];

// ---------- вспомогательные функции ----------
const TNR = "Times New Roman";
const SIZE_BODY = 24;      // half-points → 12 pt
const SIZE_HEADING = 28;   // half-points → 14 pt

function p(text, opts = {}) {
  return new Paragraph({
    alignment: opts.align || AlignmentType.JUSTIFIED,
    spacing: { line: 240, before: 0, after: 120 },
    indent: opts.noIndent ? undefined : { firstLine: convertMillimetersToTwip(12.5) },
    children: [
      new TextRun({
        text,
        font: TNR,
        size: SIZE_BODY,
        bold: !!opts.bold,
      }),
    ],
  });
}

function h(text) {
  return new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 240, after: 240 },
    children: [new TextRun({ text, font: TNR, size: SIZE_HEADING, bold: true })],
  });
}

function listItem(text) {
  return new Paragraph({
    alignment: AlignmentType.JUSTIFIED,
    spacing: { line: 240, after: 120 },
    numbering: { reference: "remarks", level: 0 },
    children: [new TextRun({ text, font: TNR, size: SIZE_BODY })],
  });
}

// ---------- сборка ----------
const title = `Отчёт нормоконтроля ${DOC_INFO.designation} ${DOC_INFO.docKinds} (${DOC_INFO.changeMark})`;

const body = [
  h(title),
  p(`Изделие: ${DOC_INFO.productName}.`, { noIndent: true }),
  p(`Обозначение документа: ${DOC_INFO.designation} ${DOC_INFO.docKinds} (${DOC_INFO.changeMark}).`, { noIndent: true }),
  p(`Организация-исполнитель: ${DOC_INFO.organization}.`, { noIndent: true }),
  p(""),
  h("1. Замечания нормоконтроля"),
  ...(REMARKS.length
    ? REMARKS.map(listItem)
    : [p("Замечаний не выявлено.")]),
  p(""),
  h("2. Использованные стандарты"),
  ...STANDARDS_USED.map((s) => p("— " + s, { noIndent: true })),
  p(""),
  p(""),
  p(`${DOC_INFO.inspectorRole}, ${DOC_INFO.organization}    ______________    ${DOC_INFO.inspector}`, { noIndent: true, align: AlignmentType.LEFT }),
  p("        (должность, организация)                  (подпись)                (расшифровка)", { noIndent: true, align: AlignmentType.LEFT }),
];

const doc = new Document({
  numbering: {
    config: [
      {
        reference: "remarks",
        levels: [
          {
            level: 0,
            format: LevelFormat.DECIMAL,
            text: "%1.",
            alignment: AlignmentType.START,
            style: {
              paragraph: { indent: { left: convertMillimetersToTwip(10), hanging: convertMillimetersToTwip(8) } },
              run: { font: TNR, size: SIZE_BODY },
            },
          },
        ],
      },
    ],
  },
  sections: [
    {
      properties: {
        page: {
          margin: {
            top: convertMillimetersToTwip(20),
            right: convertMillimetersToTwip(10),
            bottom: convertMillimetersToTwip(20),
            left: convertMillimetersToTwip(20),
          },
          size: { orientation: PageOrientation.PORTRAIT },
        },
      },
      children: body,
    },
  ],
});

Packer.toBuffer(doc).then((buf) => {
  fs.writeFileSync(DOC_INFO.outputFile, buf);
  console.log("Saved:", DOC_INFO.outputFile);
});
