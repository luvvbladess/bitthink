# Современный натуральный звук вместо «звуков 90-х»

Пользователь жалуется, что инструменты звучат «противно, искусственно, как в 90-х». Причина — в самом Style: модели драм-машин и синтезаторов, слова `analog`, `vintage`, `FM`, `sawtooth`, `organ`, `tape`, `synthetic` и `classic … house`. Suno воспринимает их как указание на ретро-пресеты: пластмассовую бочку, плоские клэпы, «органный» бас, дешёвое хаус-пиано. Отрицания со старыми словами («no 909», «no organ») тоже работают плохо: Suno ловит само слово.

## Правило

Если пользователь не просит ретро прямо, описывай звук современным продакшном 2020-х: `polished modern 2020s production, high-fidelity natural-sounding instruments`. Названия оборудования из отчёта слушателя (909, 808, M1, TX81Z, FM, saw) переводи в описание тембра и роли. В Style эти названия не переноси.

## Замены

| Не пиши | Пиши |
|---|---|
| `909 kick`, `909-style kick`, `drum machine kick` | `deep modern kick with a soft natural transient and clean tail` |
| `909 open hats`, `TR-808 hi-hats` | `crisp natural open hat on every offbeat` |
| `synthetic handclaps`, `layered claps` | `real recorded handclaps and finger snaps` |
| `drum machine with live feel` | `modern drums with live recorded percussion, shaker and soft hand percussion` |
| `FM bass`, `FM pluck`, `organ bass`, `saw and square bass` | `deep clean modern sub bass, round and smooth` / `warm modern plucked bass` |
| `analog saw pad`, `analog poly pads` | `lush warm modern pads with soft evolving texture` |
| `electric piano stabs`, `organ stabs`, `M1 piano` | `soft felt piano chords`, `warm modern keys` |
| `analog synth arpeggio` | `clean modern plucked arpeggio with soft attack` |
| `vintage`, `retro`, `classic house`, `old-school` | `contemporary`, `modern 2020s` |
| `tape hiss`, `vinyl crackle`, `lo-fi`, `band-limited vintage EQ` | `warm natural recording, full bandwidth` |
| `analog saturation`, `gritty`, `distorted` (на синтезаторах) | `smooth warm harmonics` |
| `bright forward top` | `smooth clean modern air, wide and expensive` |

| `jazz`, `noir jazz`, `jazz extended chords`, `smooth` | `modern cinematic electronica`, `sparse minor chords` — слово `jazz` с саксофоном даёт смус-джаз 80–90-х |
| `expressive mournful saxophone`, просто `saxophone` | `one real tenor saxophone in the low and middle register, dark airy tone with audible breath and reed noise, sparse long tones and short fragmented phrases with lots of space, almost no vibrato, no trills, no fast runs` + в отрицаниях `no soprano saxophone, no smooth jazz, no new age` |
| `music box`, `celesta`, `bell-like motif` | `a few high felt-piano notes with long reverb, slightly off grid` — шкатулка звучит как ROM-пресет и «детская погремушка» |
| `electric keys with tremolo and chorus` | `warm felt piano with soft hammers and pedal noise` |
| `sub bass, moving between root notes` (без уточнений) | `deep pure sine sub bass with real weight at 30 to 60 Hz, no slides, no fretless bass` |
| `soft drum groove`, `drum samples` | `modern downtempo electronica kit, textured top loop of shakers, cloth, clicks and foley, ghost notes, fills and small variations every few bars, humanized micro-timing` |
| `pad`, `ambient pad` | `evolving granular textures and reversed reverb swells with gentle filter movement, never static` |

Пример провала: промпт с `noir jazz saxophone`, `jazz extended chords`, `music box`, `electric keys with tremolo` дал соло сопрано-саксофона в духе смус-джаза 90-х, бас-фретлесс со слайдами, ROM-шкатулку и статичный однотактовый бит — пользователь назвал это «детский сад» и «старьё».

## Отрицания в поле «Стили» не работают

В режиме «Простой» Suno читает `no fretless bass`, `no smooth jazz`, `no new age`, `no music box` как упоминание и подставляет именно это. «Distant Oohs» после такого промпта снова дал фретлесс, ROM-сакс и шкатулку-колокольчик. Нежелательный звук не называй даже с `no` — вытесняй его точным описанием нужного. Отрицания допустимы только для общих вещей без тембра (`no rap`, `no lead singer`). Если пользователь хочет исключений, предложи режим Custom с отдельным полем Exclude Styles.

## Опасная связка «саксофон + вокализы + эмбиент»

`saxophone` + `wordless female ooh and aah`/`choir-like swells` + `ambient downtempo`/`electronica`/`film score`/`post-rock` Suno сводит к нью-эйджу и смус-джазу 1988–1996: сакс из ROM-пресета с LFO-вибрато, пианино в духе M1, хоровой пэд в стиле Enigma, фретлесс, цифровой холл. Пользователь слышит это как «французскую электронику 90-х» и «безвкусицу». Для таких референсов используй современную подачу:
- жанр — `contemporary emotional chill beats with a cinematic sound, 2020s bedroom-producer electronic scene, modern sampler-based sound design`, без слов `electronica`, `ambient downtempo`, `film score`, `new age`;
- сакс — `a real tenor saxophone recording chopped and resampled into short phrases, heavy breath, key clicks and reed noise, some pitched down, some reversed, granular smear, sparse fragments with long silences`;
- вокал — `short chopped formant-shifted vocal fragments, fairly dry` вместо хоровых «ooh/aah»;
- пианино — `intimately recorded felted upright piano, highs rolled off, warm and muffled`;
- бас — `deep saturated sub bass with a long smooth tail`;
- ударные — `loose behind-the-beat swing, dry snappy rimshots, organic foley top loop`;
- пространство — `shimmer reverb on pads, short close room on piano and saxophone, kick and sub completely dry`.

## Когда ретро допустимо

Только если пользователь прямо просит звук 80-х или 90-х, или «как в оригинале» относится именно к винтажному тембру. В этом случае оборудование описывается без брендов, как и раньше.

## Проверка

`python3 scripts/lint_prompt.py FILE` — сообщит о ретро-словах, длине, стоп-хвосте и запрещённых именах.
