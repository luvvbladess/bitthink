# Дескрипторы и приёмы

Читай при первом использовании навыка в сессии или когда нужно расширить палитру.

## Порядок Style (закреплённый)

`Genre → Era/Scene → BPM → Key/Meter → Mood → Instruments/Gear → Vocal → Production/Mixing → Structural cue`

Каждый блок — один-два дескриптора. Всего 4–7 сильных, не больше.

## Genre / Scene (примеры плотных ярлыков)

- shoegaze, dream pop, chamber pop, baroque pop
- synthwave, darksynth, italo-disco, coldwave
- boom bap hip hop, trap soul, lo-fi hip hop, drift phonk, edit phonk
- neo soul, alt-R&B, PBR&B
- post-punk, math rock, midwest emo, screamo
- Afrobeat, highlife, funk-rock, g-funk
- ambient, drone, IDM, downtempo, trip-hop
- indie folk, chamber-folk, americana, alt-country
- sad indie pop, bedroom pop, hyperpop
- ключ к оригинальности — стыковка сцен: «early-2000s Parisian downtempo», «post-Soviet urban melancholy», «late-1960s Afrobeat + French chamber pop»

## Era / Scene (без имён)

- 1960s Motown, 1970s Philly soul, 1970s Paris studio, 1980s British new wave, 1980s LA hair metal, 1990s New York boom bap, 1990s Seattle grunge, early-2000s French touch, 2010s indie, late-2010s SoundCloud rap, 2020s bedroom pop, retrofuturistic 1980s

## BPM и метр

- Указывай число или диапазон: `103 BPM`, `72–80 BPM`.
- Метр — только если небанальный: `6/8`, `12/8`, `5/4`, `7/8`.

## Тональность

- Только если подтверждена: `A minor`, `F# minor`, `C minor with major-seventh voicings`, `E minor/major shifts`.

## Mood (не более двух)

melancholic, euphoric, haunting, triumphant, bittersweet, nostalgic, ethereal, hypnotic, cinematic, aggressive, sultry, atmospheric, intimate, expansive, weightless, sensual, wistful, angular, cold, warm, gritty, transcendent.

## Инструменты и оборудование

Чем конкретнее, тем ближе попадёт. Примеры:

- Клавиши: Yamaha CP-80 electric grand, Rhodes MK1 electric piano, Wurlitzer 200A, Hammond B3 with Leslie, Mellotron flute, Juno-60 pads, Prophet-5 leads, DX7 bell tones.
- Гитары: fingerpicked nylon guitar, jangly Rickenbacker 12-string, drop-D distorted single-coil, tape-echo baritone guitar, chorus-drenched clean strat, wah-driven funk chuck rhythm, shimmering reverb guitars.
> Для клубной электроники без просьбы о ретро — сначала `references/modern-sound.md`: модели машин (808, TR-808) и `analog`/`tape`/`vinyl` ниже применяй только к винтажным и акустическим референсам.

- Бас: warm upright double bass, round Fender P-bass, slap-style funk bass, sub-bass 808, moog synth bass, walking upright.
- Ударные: brushed snare with ghost notes, gated reverb snare, TR-808 hi-hats, live drum kit with swing, four-on-the-floor kick, Afrobeat groove, boom bap drums with vinyl crackle, mechanical post-punk drums.
- Оркестр: full live symphonic strings, brass fanfare, timpani, wordless female choir, tenor saxophone, cello counterpoint, flute countermelody.
- Прочее: tabla, cuica, tape delay, granular pads, singing bowls, field recordings.

## Вокал

Указывай пол, регистр, тембр, подачу, обработку:

- gender/register: female alto, male baritone, male tenor, female soprano, androgynous
- timbre: breathy, raspy, smooth, powerful, whispered, nasal, husky
- delivery: speech-like verse, restrained chorus without belt, anthemic soaring chorus, rhythmic near-spoken funk-rap flow, storytelling narrative, angular sprechgesang
- processing: close-mic, plate reverb, slap delay tails, tape saturation, no autotune, layered harmonies, octave-down doubling
- language: `Russian lyrics`, `French lyrics`, `English lyrics`, `wordless choir`
- инструментал: `no vocals` / `instrumental only`

## Продакшн / микс

analog warmth, tape saturation, vinyl crackle, plate reverb on vocal, gated reverb drums, wide stereo, dry front-of-mix vocal, sidechain-compressed pads, lo-fi bandwidth 4kHz cutoff, dusty sampler texture, 1970s Paris studio, 2020s bedroom home-studio.

## Structural cue

endless four-chord loop, loud-quiet-loud dynamics, single-verse form, verse–chorus–verse–reduction–coda, long instrumental break, dropout on second chorus, false ending, extended outro fade, gradual layered bloom over 6 minutes.

## Как передать «звук артиста» без имени

1. Определи слой, который делает артиста узнаваемым: часто это связка `vocal timbre + signature instrument + production trick + rhythm feel`.
2. Замени имя эпохой и сценой: `Michel Legrand` → `French romantic film-score tradition, late-1960s Parisian orchestral arrangement`.
3. Замени альбом годом и звуком студии: `Blood Sugar Sex Magik` → `early-1990s LA funk-rock, Rick-Rubin-adjacent dry drums`. Имя продюсера тоже уходит — оставляй только производственный признак: `dry front-of-mix drums, minimal reverb, tight funk arrangement`.
4. Голос — самый сильный якорь. Пиши `raspy male baritone, playful funk-rap cadence, occasional yelped ad-libs` вместо имени вокалиста.
5. Ритм — второй якорь. `Afrobeat drumming with brushed snare and swinging triplet hi-hat, kick barely felt` даёт узнавание без имён.

## Типовой Exclude по музыкальным ошибкам Suno

- Для акустических/винтажных референсов: `no synth leads, no drum machines, no autotune, no digital reverb sheen, no modern pop compression, no EDM drops`.
- Для рок/фанк-рок: `no trap hi-hats, no autotune, no rap-sung modern pop vocals, no acoustic folk arrangement`.
- Для downtempo/chamber pop: `no distorted electric guitars, no double kick, no shouted vocals, no english female pop belting`.
- Для лоу-фай/бумбапа: `no live rock band, no orchestral strings, no belting vocals, no EDM synths`.
- Для phonk/трэпа: `no acoustic guitar, no live drums, no clean pop vocals, no orchestral strings`.

Exclude — не шаблон, а точечный анти-паттерн под конкретный трек.
