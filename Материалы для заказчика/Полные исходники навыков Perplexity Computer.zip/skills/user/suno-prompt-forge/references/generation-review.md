# Разбор сгенерированного трека

Читай, когда пользователь прислал MP3 из Suno или жалуется на результат («не то», «детский сад», «ускорил»). Не правь промпт вслепую — сначала послушай результат.

## Порядок

1. `python3 scripts/compare_generation.py <gen.mp3> <preview оригинала>` — темп, громкость, доля низа по участкам.
2. `evaluate_audio` на весь сгенерированный файл с нейтральным промптом (не называй жанр, чтобы слушатель не подыгрывал): жанр и на что похоже, пианино/бас/вокал, карта аранжировки по таймингу, микс, «5 причин, почему это звучит любительски или не как коммерческий клубный хит».
3. Сведи расхождения с оригиналом в таблицу «оригинал → генерация → причина в промпте → правка».
4. Правь только слова-причины, остальное не трогай. Длина 2900–2990.
5. Темп и громкость, которые промпт не исправляет, доводи по готовому файлу (`scripts/fix_tempo_master.sh`) и отдавай пользователю исправленный MP3.

## Подтверждённые причины и правки

| Симптом в генерации | Слово-причина | Правка |
|---|---|---|
| Бродвей / госпел / баллада, вокал не замолкает | `powerful belting`, `diva`, `melismatic runs`, `strong vibrato` | `cool controlled soulful house vocal, rhythmic phrasing locked to the groove, light vibrato, full power only on the last chorus note`, запреты `no musical theatre no gospel choir no ballad singing no constant belting` |
| Рояль с педалью и арпеджио вместо хаус-пианино | просто `piano` | `1990s digital workstation house piano, short staccato stabs, no sustain pedal, played like a rhythm instrument, not an acoustic grand, no arpeggios` |
| Минута без бочки в начале | `piano intro`, `breakdown with piano and vocal` | `kick and bass from the very first bar, eight-bar drum and bass intro, no beatless intro` |
| Тихий мастер, пустой низ | нет требования к низу с первого такта | `heavy tight low end that hits from the first bar, very loud punchy club master` |
| Темп выше оригинала | `uplifting`, `euphoric`, `energetic` в начале | жанр без эмоциональных усилителей в первой фразе, точный BPM в первых 60 символах |
| Темп выше на 3–5 BPM даже при точном числе | Suno сам разгоняет хаус до 126–128 | `exactly <N> BPM, classic <эпоха> house pace` в первой фразе; сверяй `bar_lag_bpm`, а не грубый `bpm` |
| Темп стабильно выше даже после `exactly <N> BPM` | Suno держит house около 126 BPM и почти не реагирует на число (123 → 126–128, занижение до 120 → всё равно 126) | не гонись за темпом промптом; предложи пользователю доводку готового файла: `scripts/fix_tempo_master.sh gen.mp3 out.mp3 <bar_lag_bpm> <BPM оригинала>` — растяжение без смены высоты, смягчение верха, громкость −8…−9 LUFS; проверь результат замером и `evaluate_audio` на артефакты, затем отдай файл |
| Вокал звучит 75% трека при «about half» | Suno завышает долю вокала | проси `vocals on only one third of the song, instrumental sections longer than vocal sections`, в core — `vocal used sparingly` |
| Брейк без бочки повторяется даже при `kick never fully removed` | слово `break` само вызывает бесбитовый брейкдаун | убери `break` из аранжировки: `no breakdown, the beat runs continuously, snare roll and noise riser over the kick`; аутро — `drum outro` |
| Вступление и брейк без бочки вопреки указанию | `intro`, `break` трактуются как беcбитовые | `the song starts on beat one with kick clap and bass`, `no intro without drums`, `kick never fully removed`, `break with the kick low-passed but still playing` |
| Слабые дропы, тупая бочка, резкий верх | нет требований к ударам | `big crash and sub impact on every drop downbeat`, `kick with short tight tail and sharp click`, `smooth silky top end, no harsh hats`, `soft de-essed sibilance` |
| Темп ниже оригинала (100 → 96 BPM) | в Style было `slow heavy` — замедляющее слово | убери `slow`, оставь `heavy`; темп верни доводкой файла |
| Свинг/«раскачка» пропали, грув ровный по сетке | `swung` и `lurching` слишком слабы | `hard MPC-style sixteenth swing around 62 percent, drunk off-grid lurch, never straight or quantized`, `shuffled hats and shaker with heavy swing` |
| Вместо мягкого электропиано — яркое хаус-пиано 90-х, вокал — «дива» на крике | `electric piano chord stabs` + `soul` тянут к пиано-хаусу | `dull muted low-passed electric piano and organ stabs, never a bright house piano`, `relaxed and conversational, never belting, old soul acapella sample with tape hiss` |
| Бесбитовые брейки даже при `breakdown with filtered chords` | слово `breakdown` содержит `break` | `no beatless section, the kick runs continuously, a filtered section … over the kick` |
| Лозунги «I know my worth», «crown» в названии | в указании для текста было `knows her worth` | описывай ситуацию, а не лозунг: `calmly ending a game she has seen through, few words, no slogans, no royalty or crown images` |
| Инструменты «противные, искусственные, как из 90-х» | в Style модели машин и `analog`, `FM`, `saw`, `organ`, `vintage`, `tape`, `synthetic` | замены по `references/modern-sound.md`, в начало `polished modern 2020s production, high-fidelity natural-sounding instruments` |
| Смус-джаз/нью-эйдж 90-х: сопрано-сакс с вибрато и пассажами, фретлесс со слайдами, «детская» шкатулка, статичный бит | `jazz`, `noir`, `mournful expressive saxophone`, `music box`, `electric keys tremolo` | замены по `references/modern-sound.md` (сакс, шкатулка, бас, ударные, пэды) |
| Фретлесс, смус-джаз и шкатулка вернулись, хотя их запретили через `no …` | отрицания в поле «Стили» Suno читает как упоминание | не называй нежелательное; связку сакс + вокализы + эмбиент описывай по разделу «Опасная связка» в `references/modern-sound.md` |
| Инди-рок превратился в яркий синти-поп с оглядкой на 80-е: прямая бочка весь трек, синты громче гитар, ровная громкость без тихих частей, трек короче на минуту | `four-on-the-floor`, `danceable`, `sequenced/pulsing synth bass`, `bright air`, тихие части описаны без длительности | пиши `guitar-led`, `guitars louder than synths, synths only as soft background pads`, `huge dynamic contrast`, длительность тихих частей (`thirteen seconds of only…`, `one full minute of piano`, `forty seconds of solo piano`) и общую длину; `natural raw human voice with real pitch drift and breath` против автотюна в припевах |
| Атмосферный инди-поп с электроникой превратился в стадионный рок или поп-панк: громкое начало с акустикой, синт-лид в припевах, громкий финал с выкриком вместо тихой коды | `guitar-led`, `heavily overdriven`, `heavy crashes`, `belts`, `anthemic`, `punchy loud master`; длинный список частей, середину которого Suno не держит | жанр от звучания источника («indie pop with shimmering electronic textures»), `guitars are a texture, never the lead`, начало и конец описывай отдельно и жёстко (`the song opens very quietly and ends very quietly`, `the final minute is quiet piano only`), голос `never shouting`, `natural dynamics`; частей в середине не больше пяти |
| Две генерации подряд быстрее оригинала в одну сторону (+1,9%, +2,9%) | Suno систематически ускоряет этот стиль | в следующем промпте впиши BPM, уменьшенный на среднюю ошибку (115 → 112), и проверь новую генерацию; в паспорте объясни, что это поправка, а не новый темп |
| Инди-рок с электроникой превратился в кинематографичную поп-балладу на фортепиано без гитар | `dark atmospheric`, `cinematic piano`, `nocturnal`, `guitars are a texture`, длинные пояснения настроения вместо инструментов | опись инструментов строками `instrument: timbre, role, level, where` (см. SKILL.md), гитары и бас названы поимённо с ролью и частью трека |
| Опись инструментов сработала (акустика, перегруженные гитары, живые ударные, пианино в конце), но трек сократился до 3:20, ушёл в параллельный мажор, электронный первый куплет и тихая пауза пропали | длина и лад не заданы, программные ударные не противопоставлены живым | в начале Style `five-minute song`, `minor-key chords throughout`; у программных ударных `used instead of the live kit in …`; у тихих частей длительность (`one minute long`); если структура снова теряется — предложи режим Custom с тегами частей |
| Узкая стерео-картина, грязный низ | нет указаний по панораме и разделению | `piano spread wide with light chorus and ping-pong delay`, `bass notes placed between kicks, low end carved so kick and bass never mask` |
| Вокал с ИИ-артефактами | — | `a real human recording with natural breaths and micro dynamics, no synthetic warble` (полностью не устраняется) |
| Мультяшный звук | `donk`, `rubbery`, `bouncy`, `cowbell`, `summer hit` | `deep dark FM tech bass`, `rolling and heavy`, `not cute`, `no cartoon bounce no kids music` |


## Ловушка 4:3 при замере темпа

`bar_lag_bpm` ищет пик только рядом с грубой оценкой и может поймать побочный пик: три доли медленного трека = «такт» быстрого (95 × 4/3 = 126,6). Пример: трек 95 BPM с ломаным R&B-грувом был замерен как 126,6.
Перед выводом сравни силу автокорреляции на кандидатах `X`, `X × 3/4`, `X × 4/3` (полосы 30–150 Гц и 1,5–8 кГц): реальный темп даёт заметно более высокий пик. Если кандидаты близки — проверь нейтральным прослушиванием (без названных в вопросе вариантов темпа/жанра) и межударные интервалы бочки: доли, кратные 1/3 доли «быстрого» темпа, значат, что настоящий темп медленнее.
Не подсказывай вариантов в вопросе прослушивания («125 BPM house или 100 BPM R&B») — слушатель склоняется к первому названному.
