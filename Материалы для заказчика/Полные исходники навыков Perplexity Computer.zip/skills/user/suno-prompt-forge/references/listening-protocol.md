# Протокол прослушивания оригинала

Читай перед шагом «Прослушивание» в SKILL.md. Цель — описывать звук, который реально есть в записи, а не жанровый шаблон.

## 1. Получить аудио

```bash
pip show librosa >/dev/null 2>&1 || pip install -q librosa
python3 scripts/fetch_previews.py "<TITLE>" --artist "<ARTIST>" --max 4
```

- Источник — официальные 30-секундные превью iTunes и Deezer. Разные версии (radio, extended, remix) — это разные фрагменты трека; extended-превью обычно показывает интро.
- YouTube в песочнице отдаёт 403 — не пытайся повторять загрузку.
- Если пользователь прислал аудиофайл — слушай его в первую очередь.
- Если превью нет (классика, редкий трек) — найди официальное исполнение-эталон (например, `--artist` с именем исполнителя записи) или скажи пользователю, что слушать нечего, и пометь весь паспорт как «по источникам, без прослушивания».

## 2. Слушать

Для каждого MP3 из `report.json` вызывай `evaluate_audio` параллельно с одним и тем же промптом:

```text
You are a senior mix engineer and music producer. Listen carefully to this 30-second preview of a released commercial track. Describe ONLY what you actually hear, in English, as a detailed production breakdown. Cover, with timestamps where useful:
1) Genre/subgenre and closest reference sound (no artist names needed).
2) Tempo feel and groove (straight/swung, kick pattern, where claps/snares fall, hi-hat pattern, percussion types you hear).
3) Key/mode and harmony as heard (major/minor, chord movement, bass movement).
4) Every instrument and sound source you can identify: bass type (sub, reese, plucked, 808, FM, synth), synths (pads, plucks, leads, stabs), keys, guitars, horns, strings, organ, percussion, FX (risers, sweeps, sirens, vocal chops). For each: timbre, register, rhythm role, stereo placement.
5) Vocals: gender, language/accent, delivery (sung, toasted, chanted, rapped), sampled vs new, processing (pitch, chop, delay, reverb, saturation), lead vs backing.
6) Arrangement over the preview: what enters/leaves when, builds, drops, breaks.
7) Mix/master character: loudness, brightness, low-end weight, width, sidechain pumping, saturation, reverb depth, overall vibe.
8) The 5 most distinctive signature elements that make this track recognizable.
9) Lyric character without transcribing any words: how much text (none / one hook phrase / full verses), language, perspective, theme, tone, imagery level, rhyme density, repetition.
Say explicitly if something is uncertain. Do not invent elements you do not hear.
```

## 3. Свести три слоя данных

| Параметр | Главный источник | Проверка |
|---|---|---|
| BPM | базы (SongBPM, Tunebat, Beatport, Musicstax) + `bpm_estimate` | слушатель ошибается на ±5–10 BPM — его число не используй |
| Тональность | базы + `key_top3` | при `key_confidence_gap` < 0.05 лад спорный — пиши тонику и «minor-leaning»/«major-leaning» по описанию слушателя |
| Инструменты, тембры, вокал, обработка, аранжировка | только прослушивание | источники лишь уточняют модели оборудования и кредиты |
| Яркость, вес низа, громкость, ширина | прослушивание + метрики (`spectral_centroid_hz`, `low_end_share_below_150hz`, `rms_dbfs`, `stereo_side_to_mid`) | — |

Ориентиры метрик: `low_end_share` > 0.6 — тяжёлый, доминирующий низ; centroid > 3000 Hz — яркий микс; `rms_dbfs` около −10 и громче — громкий клубный мастер; `stereo_side_to_mid` < 0.2 — узкий, моно-ориентированный микс.

## 4. Правила для Style

- В Style идут только элементы, которые слушатель назвал хотя бы в одной версии. Нельзя добавлять инструменты «по жанру».
- То, что слушатель явно назвал отсутствующим («no pads», «no chords»), вынеси в отрицания в Style (`no pads no chord stabs`).
- Пять «signature elements» обязаны стоять в первой трети Style — Suno сильнее всего учитывает начало.
- Свободный объём до 2900–2990 символов заполняй деталями услышанного (паттерны, регистр, панорама, обработка, тайминг входов), а не жанровыми клише.
- Если слушатель в двух версиях противоречит сам себе — бери совпадающее, расхождение помечай в паспорте.
- **Если слушатели расходятся по темпу или жанру** (например, 174 drum and bass против 130 UK garage), не выбирай на слух: в дропе измерь интервалы ударов по полосам (бочка < 110 Гц, малый 180–1500 Гц, хэты > 7 кГц). Интервал между ударами малого на 2-ю и 4-ю доли равен двум долям, интервал хэтов — восьмой. Затем повтори прослушивание, указав измеренный темп и тип ритма.
- **Темп — нейтрально и точно.** Suno сильнее слушается жанровых тегов и слов-настроений, чем цифры BPM. Жанровые теги выбирай с типичным темпом, равным реальному (жанр бери из карточки Beatport/Traxsource; для 120–124 — afro house; не tech house 124–128, не bass house 126–128, не UK bassline/speed garage 130+, не drum and bass). Жанр сэмпла-первоисточника тоже не пиши тегом: «dancehall», «reggae», «dub» тянут к 70–95 BPM — описывай сэмпл как вокал («vintage Jamaican patois toasting vocal sample»), а не как жанр трека. Не ставь ни ускорители (aggressive, frantic, extreme, stutter), ни замедлители (laid-back, unhurried, half-time feel, «not 128») — пользователь подтвердил: первые ускоряют трек, вторые замедляют. Достаточно числа BPM и фразы `steady club pace, original tempo kept exactly`.
- **Развитие аранжировки по запросу** («от минимализма к полному звуку» и т. п.) расписывай по секциям: что звучит в каждой и какой слой добавляется; базу составляют услышанные элементы, добавленные ради полноты слои помечай в паспорте как добавленные по просьбе пользователя.

## Пример ошибки, которую протокол устраняет

Трек house-переработки dancehall-классики. Без прослушивания промпт описал offbeat-гитару, органные «баблы», маримбу, медь и пэды. Прослушивание показало: минималистичный tech/bass house, FM-«donk» бас с синкопами, нарезанный и питч-сдвинутый женский патуа-вокал как главный хук, 909-открытые хэты на офбитах, полое woodblock-перкуссионное остинато, экстремальный сайдчейн, никаких аккордовых инструментов, резкий дроп без билда после а-капелльного интро.

## Превью не показывает трек целиком

Если 30-секундное превью — только интро (нет ударных, баса, ведущего инструмента) или трек длиннее 5 минут, возьми полный трек с официальной страницы артиста на SoundCloud: `yt-dlp -q -x --audio-format mp3 -o "/tmp/suno_audio/<slug>/sc.%(ext)s" "<soundcloud URL>"`. YouTube из песочницы требует вход и не отдаёт аудио. Полный файл измерь по сегментам по 40 с и отдай слушателю целиком (до 20 МБ). Пример: превью «Who We Want to Be» оказалось интро с музыкальной шкатулкой, а полный трек — даунтемпо с саксофоном и ударными.

Ощущение half-time описывай расстановкой долей (`kick on one and the snare on three`), а не словом `half-time`: это слово замедляет. Если в полном треке сильны периоды 4:3 или 2:3 от основного (102 ↔ 136 ↔ 68), основным считай тот, что совпадает с базой и устойчив в середине трека. Остальные периоды — это пунктирные дилеи и триоли.

## Слушай по частям, а не целиком

Общий отчёт по полному треку может выдумать структуру. У «Keep Pretending» он описал гаражный рок 160 BPM и двухминутный эмбиент-аутро, а на деле трек на ~115 BPM с четырьмя сменами фактуры. Порядок:
1. Построй карту энергии по окнам 15 с (RMS, доля низа <150 Гц, центроид): спады и подъёмы задают границы частей.
2. Нарежь трек на фрагменты по ~42 с с шагом 40 с и отправь их параллельно с одинаковым нейтральным вопросом: инструменты и тембр, вокал, тип части и энергия 1–10, «эпоха звучания». Добавь требование писать «unsure».
3. Свяжи ответы с картой энергии и прими только то, что совпало. Противоречия (например, «живые» или «программные» ударные) решай по соседним фрагментам и по доле низа.
4. Спорный темп (периоды 4:3, как 115 ↔ 153) проверь кликами: наложи клики `librosa.clicks` на 30 с середины трека для каждого кандидата. Ответ «клики между долями» на половинном кандидате (76,6) подтверждает тот темп, в котором этот период равен полутора долям, то есть 115.
