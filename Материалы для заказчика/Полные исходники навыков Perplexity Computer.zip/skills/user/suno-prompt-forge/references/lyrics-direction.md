# Указание для текста (lyrics direction)

Читай перед сборкой Style. Фраза идёт в конце Style-абзаца, перед `, avoid these words in lyrics: …`. Объём 180–300 символов, английский. Описывай характер текста оригинала (пункт 9 прослушивания), а не сам текст. Строки оригинала не цитируй.

## Из чего собирать

1. Объём: `almost no lyrics` / `one short hook phrase` / `full verses and chorus`.
2. Язык и диалект: `Jamaican patois`, `plain conversational English`, `Russian`.
3. Голос и тон: `adult`, `confident`, `wry`, `world-weary`, `devotional`, `sensual`.
4. Тема и образность: конкретные образы из темы трека, а не общие слова.
5. Форма: плотность рифмы, повторы, длина строк.
6. Название: Suno берёт его из текста. Добавляй `title: …` — одно-два простых слова из образа трека, без сленга.
7. Запреты против шаблонов Suno: `no nursery rhymes`, `no love or party clichés`, `no generic motivational lines`, `no simple AABB rhymes`.

## Объём текста — по типу трека

Две крайности, обе подтверждены пользователем как плохие:
- «almost no lyrics, one hook repeated» → Suno повторяет одно слово весь трек («More! More! M-m-more!»);
- «a short song with real development, verse of four phrases…» → Suno пишет сплошной сюжетный текст, вокал не замолкает, танцевальная часть не раскрывается.

Золотая середина для клубных треков: около десяти коротких фраз на весь трек (3–6 слов), вокал меньше половины длительности, между вокальными секциями — инструментальные дропы по 16 тактов, куплет из двух фраз, хук из 2–4 слов не больше двух раз подряд, каждая вокальная секция приносит одну-две новые фразы, финальный хук изменён один раз, образно, без сюжетных деталей. Полные куплеты и бриджи — только для песенных жанров (поп, соул, фолк, рок, рэп).

## Запрет на этнический и жанровый сленг

Не пиши в указании «patois chant», «deejay toasting», «boastful», «hype» и подобное — Suno отвечает штампами сцены (shout-outs, «crown», «gyal», «wheel it», «big up») и делает из них название. Акцент и манеру исполнения описывай только в вокальной части Style («Jamaican accent female vocal sample»), а в указании для текста — нейтральные простые слова.

## Шаблоны

Клубный / танцевальный трек (house, afro house, garage, techno, EDM):
`, lyrics direction: dance track first, vocals on less than half of the song, long instrumental drops of sixteen bars with only chopped syllables between vocal sections, the groove and bass carry the track and the voice is an accent with space around every phrase, very few words in total, about ten short phrases of three to six words for the whole song, plain adult English, mood of <настроение>, impressionistic not narrative, no story details, structure: one intro phrase, drop, verse of two phrases, hook of three words sung twice, drop, second verse of two new phrases, hook, short break phrase, final drop with the hook changed once, instrumental outro, no long verses, no repeating one word for a whole section, no slang clichés, title: one plain word`

Авторская песня (соул, фолк, рок):
`, lyrics direction: adult literary songwriting, concrete physical imagery and dark wit, sensual and ironic devotion, varied line lengths, slant rhymes and internal rhyme instead of simple end rhymes, a chorus built on one striking metaphor, no nursery-rhyme phrasing no generic love clichés no motivational lines`

Поп-хит:
`, lyrics direction: sharp grown-up pop writing, one specific situation told in plain conversational language, a short catchy title hook repeated in the chorus, fresh specific details in verses, no childish rhymes no filler words no generic party or heartbreak clichés`

Хип-хоп / рэп:
`, lyrics direction: dense adult rap verses, multisyllabic internal rhymes, specific personal details and wordplay, confident delivery, short repeated hook, no childish rhymes no generic boasting clichés`

Инструментал с вокальными вставками:
`, lyrics direction: no lyrics, wordless vocal textures and short chopped vocal syllables only`

## Проверка

- Фраза стоит перед припиской стоп-слов, итоговая длина 2900–2990.
- Объём соответствует типу трека (для клубного — около десяти коротких фраз и инструментальные дропы), есть структура секций, лимит повторов хука, язык, тон, тема, `title: …` и минимум два запрета против шаблонов.
- В указании нет сленга сцены и слов, провоцирующих штампы (boastful, hype, chant, toasting).
- Нет строк оригинала, имён и названий.
- В самой фразе `lyrics direction` нет слов из списка стоп-слов (например, «empty city» → «deserted city»), иначе Suno получит противоречивое указание.
