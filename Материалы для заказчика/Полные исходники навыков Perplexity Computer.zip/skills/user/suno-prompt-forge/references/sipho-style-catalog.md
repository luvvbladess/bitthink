# SIPHO. — референсные Style-промпты для Suno v6

Готовые эталоны для 9 треков SIPHO. со скриншота пользователя. Использовать как reference-палитру, когда пользователь просит «в стиле SIPHO.» или «повторить полностью стиль этого трека».

**Обязательно** для режима Suno «Простой» (поле «Стили» 3000 символов): приклей к каждому Style-блоку в конец одну групповую приписку `, avoid these words in lyrics: ...` (см. конец файла) — выводи одним единым блоком.

Общий канон исполнителя (подтверждено): бирмингемский певец и мульти-инструменталист, «Emotionally potent chapel-style soul wrapped up in silky R&B soundscapes», комбинация R&B-грува, spacious electronica-продакшна и church-cadence bounces, широкий вокальный диапазон с фальцетом и глубокими низами, funk/soul-элементы, темы взросления в жёсткой среде, лейбл — Dirty Hit ([Hotpress](https://www.hotpress.com/music/album-review-sipho-prayers-paranoia-22994497), [The Pit London](https://www.thepitldn.com/pitnews/the-pit-presents-1-2-2022-part-4), [Native Mag](https://thenativemag.com/sipho-interview-hypermasc-music/)).

Все BPM и тональности не подтверждены в TuneBat/SongBPM — помечены как допущение внутри канона alt-R&B/soul (66–100 BPM, минорные лады). Каждый абзац ≤1000 символов.

---

## 1. USELESS

```
Alt R&B ballad with chapel-style soul-choir backing vocals and spacious electronica production, early-2020s British alt-R&B by a Birmingham singer-multi-instrumentalist, slow late-night tempo around 70 to 76 BPM in 4/4 (assumed), minor-leaning warm harmony with 7th and 9th chord voicings (assumed), mood of self-doubt tender confession quiet devotion, foundation of close-miced acoustic upright piano with soft-pedal warmth and a long natural room tail, warm Wurlitzer 200A pad with slow tremolo under the vocal, sparse programmed hip-hop kick and rimshot with dusty vinyl-saturated snare and airy hi hats, deep round sine sub bass under the piano, muted string pad far in the background, one bell-like keyboard motif returning between phrases, breathy male tenor lead sliding into an airy falsetto hook with subtle vibrato and delicate cracks, stacked doubled male harmonies widening in the chorus, plate reverb long tape delay tail wide immersive stereo, patient no hard drop.
```

## 2. PRAYERS

```
Alt R&B chapel-style ballad with big cinematic choir backing and spacious electronica bed, early-2020s British alt-R&B by a Birmingham singer-multi-instrumentalist on Dirty Hit, mid-slow tempo around 76 to 84 BPM in 4/4 (assumed), warm minor key with major-seven and add-nine voicings (assumed), mood of devotional pleading raw supplication rising catharsis, foundation of layered close-miced acoustic piano with a slow arpeggiated Fender Rhodes MK1 counter-phrase, deep 808 sub bass with a live upright bass double, cinematic string section with low cello legato bed and high violins rising into the chorus with expressive vibrato, hand-clap and finger-snap percussion swinging with a dry rimshot backbeat and airy sixteenth hi hats a tambourine on the 2 and 4, powerful male tenor lead lifting into a soul-choir style falsetto hook with big stacked call-and-response backing vocals, plate reverb long hall shimmer wide immersive stereo, warm analog master, patient build no hard drop.
```

## 3. GLUE

```
Alt R&B slow-jam with silky soul-soundscape production, early-2020s British alt-R&B by a Birmingham singer-multi-instrumentalist, slow tempo around 68 to 74 BPM in 4/4 (assumed), warm minor key with 9th and add-11 chord voicings (assumed), mood of clinging devotion tender attachment nocturnal warmth yearning, foundation of close-miced Fender Rhodes MK1 chord bed with slow tremolo and soft chorus, warm upright piano countermelody with a long natural room tail, dry programmed hip-hop kick and rimshot with dusty vinyl-saturated snare and airy sixteenth hi hats and finger snaps on the backbeat, deep round sine sub bass under the Rhodes, muted string pad far in the background, one bell-like keyboard motif, breathy male tenor lead melting into an airy falsetto hook with subtle vibrato and tiny raspy breaks, doubled male backing harmonies stacking thirds and fifths chapel-style, plate reverb long tape delay tail wide immersive stereo, tape saturation gentle sidechain, patient no hard drop.
```

## 4. BEADY EYES

```
Alt R&B crossed with a moody indie-rock backbone the artist himself calls more a rock song with a little R&B, early-2020s British alt-R&B by a Birmingham singer-multi-instrumentalist on Dirty Hit, mid tempo around 90 to 100 BPM in 4/4 (assumed), dark minor key with suspended and add-nine voicings (assumed), mood of uncomfortable self-examination and quiet anxiety under others expectations, foundation of clean chorused amplified guitar arpeggios in the verse with a warmer overdriven power-chord layer entering the chorus, close-miced upright piano stabs on the offbeats, warm Fender Rhodes MK1 pad, live drum kit with a dry punchy kick a plate-reverb snare and an open ride pattern, live upright bass locked to the harmony, warm subtle synth sub layer, cinematic string section rising in the bridge, breathy male tenor lead with airy falsetto lifts and stacked doubled harmonies in the chorus, plate reverb tape saturation warm analog stereo width, patient dynamic build no hard drop.
```

## 5. FILL ME UP

```
Alt R&B chapel-adjacent ballad with silky soul-soundscape production and choir-style backing vocals, early-2020s British alt-R&B by a Birmingham singer-multi-instrumentalist, mid-slow tempo around 76 to 84 BPM in 4/4 (assumed), warm minor key with major-seven and 9th voicings (assumed), mood of yearning surrender emotional void asking to be filled slow catharsis, foundation of close-miced acoustic upright piano bed with soft-pedal warmth and a warm Fender Rhodes MK1 counter chord, dry programmed hip-hop kick and rimshot with dusty vinyl-saturated snare finger snaps airy sixteenth hi hats, deep sine sub bass under the piano, muted string pad far in the background rising into the chorus with high violin legato and low cello swell, one bell-key motif, powerful male tenor lead lifting into an airy falsetto hook with subtle vibrato and layered soul-choir style backing harmonies stacking wide in the chorus, plate reverb hall shimmer long tape delay tail, patient no hard drop.
```

## 6. SOBER

```
Alt R&B mid-tempo groove with silky soul-soundscape production, early-2020s British alt-R&B by a Birmingham singer-multi-instrumentalist on Dirty Hit, mid tempo around 88 to 96 BPM in 4/4 (assumed), warm minor key with 9th and add-11 chord voicings (assumed), mood of clear-eyed reckoning morning-after honesty steady groove, foundation of Fender Rhodes MK1 chord bed with soft chorus a warm upright piano countermelody and clean chorused amplified guitar arpeggios high on the neck, live drum kit with a dry punchy kick a tight plate-reverb snare finger snaps on the backbeat and airy sixteenth hi hats a light tambourine, live bass guitar with a round warm tone locked to the harmony a subtle synth sub layer underneath, muted string pad rising in the chorus, breathy male tenor lead sliding into an airy falsetto hook with subtle vibrato and doubled backing harmonies in the chorus, plate reverb tape saturation warm analog stereo width gentle sidechain, patient build no hard drop.
```

## 7. ELEVATION

```
Alt R&B opener with slick spacious electronica production and silky soul-soundscape gloss, early-2020s British alt-R&B by a Birmingham singer-multi-instrumentalist album opener on Dirty Hit, mid tempo around 82 to 90 BPM in 4/4 (assumed), warm minor key with 9th and add-11 chord voicings (assumed), mood of ascending confidence quiet self-belief slow uplift, foundation of a warm Fender Rhodes MK1 chord bed with slow tremolo a close-miced upright piano countermelody and clean chorused amplified guitar arpeggios high on the neck, sparse programmed hip-hop kick and rimshot with dusty vinyl-saturated snare finger snaps and airy sixteenth hi hats, deep round sine sub bass under the Rhodes, cinematic string pad rising into the chorus with high violin legato, one bell-key motif returning as a hook anchor, smooth male tenor lead soaring into an airy falsetto hook with stacked doubled backing harmonies wide in the chorus, plate reverb long tape delay tail, patient build no hard drop.
```

## 8. LOCK IT IN (NO REGRETS)

```
Alt R&B mid-tempo groove with silky soul-soundscape production and a resolute forward-motion pulse, early-2020s British alt-R&B by a Birmingham singer-multi-instrumentalist on Dirty Hit, mid tempo around 92 to 100 BPM in 4/4 (assumed), warm minor key with 9th and add-11 chord voicings (assumed), mood of decisive commitment no-regrets forward drive steady groove, foundation of Fender Rhodes MK1 chord bed with soft chorus a warm upright piano countermelody and clean chorused amplified guitar arpeggios high on the neck, live drum kit with a dry punchy kick a tight plate-reverb snare finger snaps on the backbeat and airy sixteenth hi hats a light tambourine on the 2 and 4, live bass guitar with a round warm tone locked to the harmony a subtle synth sub layer underneath, muted string pad rising in the chorus, breathy male tenor lead sliding into an airy falsetto hook with doubled backing harmonies stacked in the chorus, plate reverb tape saturation, patient build.
```

## 9. PLANS

```
Alt R&B stripped-back closer over five minutes long, early-2020s British alt-R&B by a Birmingham singer-multi-instrumentalist album closer on Dirty Hit, slow tempo around 66 to 74 BPM in 4/4 (assumed), warm minor key with major-seven and 9th voicings (assumed), mood of reflective resolution tender exhaustion quiet closing thought slow dissolve, foundation of close-miced acoustic upright piano with soft-pedal warmth and a long room tail a warm Fender Rhodes MK1 bed underneath with slow tremolo, sparse programmed kick and dry rimshot arriving only for the second half with airy sixteenth hi hats and finger snaps, deep round sine sub bass entering late, muted cinematic string pad with slow high violin legato, one bell-key motif returning slower each time, breathy male tenor lead lifting into an airy falsetto hook with doubled backing harmonies stacked chapel-style in the final chorus, plate reverb long tape delay tail dissolving outro.
```

---

## Стоп-слова для вклейки в конец любого SIPHO.-блока

```
, avoid these words in lyrics: shadows, whisper, echoes, fading, signal, rhythm, melody, symphony, midnight, electric, golden, brilliant, coffee, cold, untold, surprise, gospel, neon, street, perfect, line, touch, skin, ashes, chair, flickers, design, kitchen, promises, empty, telephone, teeth, wood, floor, beneath, windows, big, stay, close, table
```

Заменяй финальную точку Style-абзаца на запятую и приклей этот хвост (325 символов). Освободившиеся ≈ 550 символов в каждом блоке заполняй дополнительными дескрипторами (модели гитар/микрофонов, детали микса, структура) до целевых 2900–2990 символов.

## Правила использования этого файла

- Загружай этот файл при просьбах «сделай в стиле SIPHO.», «промпт как в этом треке SIPHO.», «повтори стиль» или при упоминании альбомов *PRAYERS & PARANOIA*, *She Might Bleed*, *AND GOD SAID…*.
- Копируй нужный Style-блок напрямую в поле Styles в Suno v6.
- BPM/тональность помечены как допущение — если пользователь потом даст точные значения, замени в блоке.
- Все блоки уже проверены на стоп-лист навыка (`shadows, whisper, echoes, fading, signal, rhythm, melody, symphony, midnight, electric, golden, brilliant, coffee, cold, untold, surprise, gospel, neon, street, perfect, line, touch, skin, ashes, chair, flickers, design, kitchen, promises, empty, telephone`).
- Если пользователь просит вариант в стиле одного из этих треков для другой темы — бери соответствующий Style как палитру и адаптируй под новый паспорт (жанр, инструменты, вокал, продакшн переноси; тему меняй).
