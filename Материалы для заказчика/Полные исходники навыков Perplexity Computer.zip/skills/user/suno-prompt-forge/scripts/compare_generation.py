#!/usr/bin/env python3
"""Compare a Suno generation with the original preview(s).

Usage: python3 compare_generation.py GENERATED.mp3 ORIGINAL_PREVIEW.(mp3|wav) [--seg 30]
Prints whole-track and per-segment tempo (coarse beat-tracker bpm plus kick_period_bpm (~1.5 BPM bins) and bar_lag_bpm (one-bar kick autocorrelation, ~0.1 BPM — trust this one; use segments of 60 s+ with full beat);
librosa bpm jumps between bins like 123.0/129.2), loudness (RMS dBFS), low-end share (<150 Hz)
and spectral centroid, so you can see: wrong tempo, beatless intros/sections (low share
near 0), weak master (RMS far below original), missing bass, too dark/bright mix.
"""
import argparse, numpy as np, librosa

def stats(y, sr):
    oenv = librosa.onset.onset_strength(y=y, sr=sr)
    tempo = float(np.atleast_1d(librosa.beat.beat_track(onset_envelope=oenv, sr=sr)[0])[0])
    S = np.abs(librosa.stft(y)); f = librosa.fft_frequencies(sr=sr)
    low = float((S[f < 150] ** 2).sum() / max((S ** 2).sum(), 1e-12))
    rms = float(20 * np.log10(np.sqrt(np.mean(y ** 2)) + 1e-12))
    cen = float(librosa.feature.spectral_centroid(y=y, sr=sr).mean())
    Sk = np.abs(librosa.stft(y, n_fft=1024, hop_length=128)); fk = librosa.fft_frequencies(sr=sr, n_fft=1024)
    env = np.maximum(0, np.diff(np.log1p(Sk[(fk > 30) & (fk < 120)]).sum(0)))
    ac = librosa.autocorrelate(env); lags = np.arange(1, len(ac)); kb = 60 * sr / (128 * lags)
    m = (kb > 95) & (kb < 150)
    kick_bpm = round(float(60 * sr / (128 * lags[m][np.argmax(ac[1:][m])])), 1) if m.any() else None
    hk = 32; Sp = np.abs(librosa.stft(y, n_fft=1024, hop_length=hk)); fp = librosa.fft_frequencies(sr=sr, n_fft=1024)
    ep = np.maximum(0, np.diff(np.log1p(Sp[(fp > 30) & (fp < 150)]).sum(0))); ep -= ep.mean()
    acp = np.correlate(ep, ep, 'full')[len(ep) - 1:]; frp = sr / hk
    ref = kick_bpm or tempo  # search one-bar lag only near the coarse estimate (avoids 5-beat aliases)
    lo, hi = int(frp * 240 / (ref * 1.04)), int(frp * 240 / (ref * 0.96))
    precise = None
    if hi + 1 < len(acp):
        j = lo + int(np.argmax(acp[lo:hi])); a_, b_, c_ = acp[j - 1], acp[j], acp[j + 1]
        den = a_ - 2 * b_ + c_; dd = 0.5 * (a_ - c_) / den if den else 0.0
        precise = round(float(240 * frp / (j + dd)), 2)
    return dict(bpm=round(tempo, 1), kick_period_bpm=kick_bpm, bar_lag_bpm=precise, rms_dbfs=round(rms, 1), low_share=round(low, 2), centroid_hz=int(cen))

ap = argparse.ArgumentParser(); ap.add_argument("gen"); ap.add_argument("orig"); ap.add_argument("--seg", type=int, default=30)
a = ap.parse_args()
yg, sr = librosa.load(a.gen, sr=22050); yo, _ = librosa.load(a.orig, sr=22050)
print("ORIGINAL ", stats(yo, sr)); print("GENERATED", stats(yg, sr))
for s in range(0, int(len(yg) / sr), a.seg):
    seg = yg[s * sr:(s + a.seg) * sr]
    if len(seg) < 5 * sr: break
    print(f"  gen {s:4d}s", stats(seg, sr))
