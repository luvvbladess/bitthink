#!/usr/bin/env bash
# Post-fix a Suno generation: time-stretch to the original tempo (pitch preserved), tame harsh top, raise loudness.
# Usage: fix_tempo_master.sh IN.mp3 OUT.mp3 GEN_BPM TARGET_BPM [GAIN_DB=7]
# GEN_BPM: measure with compare_generation.py (kick_period_bpm). Check result: ffmpeg -i OUT.mp3 -af ebur128 -f null -  (aim -8..-9 LUFS),
# then re-run compare_generation.py and evaluate_audio for artifacts before sharing.
set -euo pipefail
IN="$1"; OUT="$2"; GEN="$3"; TGT="$4"; GAIN="${5:-7}"
RATIO=$(python3 -c "print(round($TGT/$GEN,6))")
ffmpeg -hide_banner -loglevel error -y -i "$IN" \
  -af "atempo=${RATIO},highshelf=f=7000:g=-1.5,volume=${GAIN}dB,alimiter=limit=0.891:attack=5:release=50:level=disabled" \
  -ar 44100 -c:a libmp3lame -b:a 320k "$OUT"
ffmpeg -hide_banner -i "$OUT" -af ebur128=peak=true -f null - 2>&1 | grep -E '^\s+(I:|Peak:)'
