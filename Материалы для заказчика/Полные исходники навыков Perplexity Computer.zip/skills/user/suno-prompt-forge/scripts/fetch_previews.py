#!/usr/bin/env python3
"""Download official 30-second previews of a track (iTunes + Deezer) and measure them.

Usage:
    python3 fetch_previews.py "TITLE" --artist "ARTIST" [--out /tmp/suno_audio/<slug>] [--max 4]

What it does:
  1. Searches the public iTunes Search API and Deezer API (no auth) for the query.
  2. Keeps up to --max distinct versions whose credited artist contains --artist and whose
     title contains the title words (covers/uploads by other accounts are dropped)
     (radio edit, extended mix, remix, live ... each preview is a different 30 s slice).
  3. Downloads each preview, converts to 192 kbps MP3 (for the listening model) and WAV.
  4. Measures with librosa: tempo (BPM), tempogram peaks (sanity check of the tempo;
     do not turn a half-tempo peak into slowing words in the prompt), key estimate with confidence, RMS loudness,
     spectral centroid (brightness), share of energy below 150 Hz (low-end weight),
     onset density, stereo width.
  5. Prints a JSON report and saves it as report.json in the output folder.

YouTube downloads are blocked in the sandbox (HTTP 403) - do not retry them.
Install librosa once per sandbox if missing: pip install -q librosa
"""
import json, os, re, subprocess, sys, urllib.parse, urllib.request
import argparse

def http_json(url):
    with urllib.request.urlopen(url, timeout=20) as r:
        return json.load(r)

def norm(s):
    return re.sub(r"[^a-z0-9 ]", " ", (s or "").lower())

def search(title, artist, limit):
    q = urllib.parse.quote(f"{artist} {title}")
    words = [w for w in norm(title).split() if len(w) > 1]
    awords = [w for w in norm(artist).split() if len(w) > 1]
    found, seen = [], set()
    sources = []
    try:
        d = http_json(f"https://itunes.apple.com/search?term={q}&entity=song&limit=15")
        for it in d.get("results", []):
            sources.append(("itunes", it.get("artistName"), it.get("trackName"), it.get("previewUrl")))
    except Exception as e:
        print(f"itunes error: {e}", file=sys.stderr)
    try:
        d = http_json(f"https://api.deezer.com/search?q={q}")
        for it in d.get("data", []):
            sources.append(("deezer", (it.get("artist") or {}).get("name"), it.get("title"), it.get("preview")))
    except Exception as e:
        print(f"deezer error: {e}", file=sys.stderr)
    for src, artist, title, url in sources:
        if not url:
            continue
        if not all(w in norm(artist).split() for w in awords):
            continue
        score = sum(w in norm(title).split() for w in words) / max(len(words), 1)
        key = norm(title).strip()
        if score < 0.6 or key in seen:
            continue
        seen.add(key)
        found.append({"source": src, "artist": artist, "title": title, "url": url, "match": round(score, 2)})
    found.sort(key=lambda x: -x["match"])
    return found[:limit]

KEYS = "C C# D D# E F F# G G# A A# B".split()
MAJ = [6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88]
MIN = [6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17]

def measure(wav):
    import numpy as np, librosa
    y, sr = librosa.load(wav, sr=22050, mono=False)
    stereo = y.ndim == 2
    mono = librosa.to_mono(y) if stereo else y
    oenv = librosa.onset.onset_strength(y=mono, sr=sr)
    tempo, _ = librosa.beat.beat_track(onset_envelope=oenv, sr=sr)
    tempo = float(np.atleast_1d(tempo)[0])
    tg = librosa.feature.tempogram(onset_envelope=oenv, sr=sr).mean(axis=1)
    tbpm = librosa.tempo_frequencies(len(tg), sr=sr)
    tpeaks = [round(float(tbpm[i]), 1) for i in np.argsort(tg)[::-1] if 50 < tbpm[i] < 200][:3]
    harm = librosa.effects.harmonic(mono)
    chroma = librosa.feature.chroma_cqt(y=harm, sr=sr).mean(axis=1)
    scores = []
    for i in range(12):
        scores.append((float(np.corrcoef(np.roll(MAJ, i), chroma)[0, 1]), f"{KEYS[i]} major"))
        scores.append((float(np.corrcoef(np.roll(MIN, i), chroma)[0, 1]), f"{KEYS[i]} minor"))
    scores.sort(reverse=True)
    S = np.abs(librosa.stft(mono)) ** 2
    freqs = librosa.fft_frequencies(sr=sr)
    low_share = float(S[freqs < 150].sum() / S.sum())
    centroid = float(librosa.feature.spectral_centroid(y=mono, sr=sr).mean())
    rms_db = float(20 * np.log10(np.sqrt(np.mean(mono ** 2)) + 1e-9))
    onsets = librosa.onset.onset_detect(y=mono, sr=sr)
    width = None
    if stereo:
        mid, side = (y[0] + y[1]) / 2, (y[0] - y[1]) / 2
        width = float(np.sqrt(np.mean(side ** 2)) / (np.sqrt(np.mean(mid ** 2)) + 1e-9))
    return {
        "bpm_estimate": round(tempo, 1),
        "tempogram_peaks": tpeaks,
        "key_top3": [{"key": k, "corr": round(c, 3)} for c, k in scores[:3]],
        "key_confidence_gap": round(scores[0][0] - scores[1][0], 3),
        "rms_dbfs": round(rms_db, 1),
        "spectral_centroid_hz": round(centroid),
        "low_end_share_below_150hz": round(low_share, 3),
        "onsets_per_sec": round(len(onsets) / (len(mono) / sr), 2),
        "stereo_side_to_mid": None if width is None else round(width, 3),
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("query", help="track title")
    ap.add_argument("--artist", required=True, help="credited artist")
    ap.add_argument("--out")
    ap.add_argument("--max", type=int, default=4)
    a = ap.parse_args()
    slug = re.sub(r"[^a-z0-9]+", "-", f"{a.artist} {a.query}".lower()).strip("-")[:60]
    out = a.out or f"/tmp/suno_audio/{slug}"
    os.makedirs(out, exist_ok=True)
    hits = search(a.query, a.artist, a.max)
    if not hits:
        print(json.dumps({"query": a.query, "error": "no previews found"}, ensure_ascii=False))
        return
    for i, h in enumerate(hits, 1):
        base = os.path.join(out, f"v{i}")
        raw = base + ".src"
        try:
            urllib.request.urlretrieve(h["url"], raw)
            subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", raw, "-b:a", "192k", base + ".mp3"], check=True)
            subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", raw, "-ac", "2", "-ar", "44100", base + ".wav"], check=True)
            h["mp3"] = base + ".mp3"
            h["metrics"] = measure(base + ".wav")
        except Exception as e:
            h["error"] = str(e)
        h.pop("url", None)
    report = {"query": a.query, "artist": a.artist, "folder": out, "versions": hits}
    with open(os.path.join(out, "report.json"), "w") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    print(json.dumps(report, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
