#!/usr/bin/env python3
"""Check a combined Suno Style prompt: length, stop-word tail, stop words in lyrics direction,
retro/vintage triggers, tempo-shifting words, break/cartoon triggers, and optional banned names.
Usage: lint_prompt.py FILE [--names "artist,title,..."] [--allow-retro]"""
import re, sys, argparse
TAIL = (", avoid these words in lyrics: shadows, whisper, echoes, fading, signal, rhythm, melody, symphony, "
        "midnight, electric, golden, brilliant, coffee, cold, untold, surprise, gospel, neon, street, perfect, line, "
        "touch, skin, ashes, chair, flickers, design, kitchen, promises, empty, telephone, teeth, wood, floor, "
        "beneath, windows, big, stay, close, table")
STOP = TAIL.split(": ", 1)[1].split(", ")
RETRO = [r"\b9\d9\b", r"\b808\b", r"\bTR-?\d+", r"\banalog(ue)?\b", r"\bvintage\b", r"\bretro\b", r"\bold-school\b",
         r"\bclassic\b", r"\bFM\b", r"\bsaw(tooth)?\b", r"\bsquare\b", r"\borgan\b", r"\btape\b", r"\bvinyl\b",
         r"\blo-?fi\b", r"\bdrum machine\b", r"\bsynthetic\b", r"\bM1\b", r"\b(80s|90s|1980s|1990s)\b", r"\bchiptune\b", r"\bjazz\b", r"\bnoir\b", r"\bmusic box\b", r"\bcelesta\b", r"\bfretless\b", r"\bnew age\b", r"\bsmooth jazz\b", r"\btremolo\b", r"\belectronica\b", r"\bfilm score\b", r"\bchoir-like\b", r"\booh and aah\b"]
TEMPO = [r"\bslow(ly|er)?\b", r"\bspeed", r"\bfaster\b", r"\blaid-back\b", r"\bhalf-time\b", r"\bfrantic\b", r"\baggressive\b"]
OTHER = [r"\bbreak", r"\bdonk\b", r"\brubbery\b", r"\bbouncy\b", r"\bcowbell\b", r"\bsummer hit\b"]
ap = argparse.ArgumentParser(); ap.add_argument("file"); ap.add_argument("--names", default="")
ap.add_argument("--allow-retro", action="store_true"); a = ap.parse_args()
c = open(a.file, encoding="utf-8").read().strip()
ok = True
def warn(msg):
    global ok; ok = False; print("WARN:", msg)
n = len(c); print("length:", n)
if not 2900 <= n <= 2990: warn("length outside 2900-2990")
if not c.endswith(TAIL): warn("stop-word tail missing or altered at the end")
if "lyrics direction:" not in c: warn("no lyrics direction")
else:
    d = c.split("lyrics direction:", 1)[1].split("avoid these words", 1)[0]
    bad = [w for w in STOP if re.search(r"\b%s\b" % re.escape(w), d, re.I)]
    if bad: warn("stop words inside lyrics direction: %s" % bad)
body = c.split("avoid these words", 1)[0]
for label, pats in (("retro trigger", [] if a.allow_retro else RETRO), ("tempo word", TEMPO), ("trigger", OTHER)):
    for p in pats:
        for m in re.finditer(p, body, re.I):
            warn("%s '%s' near: ...%s..." % (label, m.group(0), body[max(0, m.start()-30):m.end()+30]))
if re.search(r"saxophone", body, re.I) and re.search(r"ambient|downtempo|post-rock|wordless", body, re.I) and re.search(r"ooh|aah|choir|wordless", body, re.I):
    warn("risky cluster: saxophone + wordless vocals + ambient -> 90s new age; see modern-sound.md")
for nm in [x.strip() for x in a.names.split(",") if x.strip()]:
    if nm.lower() in c.lower(): warn("banned name present: %s" % nm)
print("OK" if ok else "FIX BEFORE DELIVERY")
