#!/usr/bin/env python3
"""Проверка единой правой границы текста в PDF (блокирующая QA-проверка right_edge).

Правило: у всех абзацев основного текста и пунктов списков, выровненных по ширине,
каждая строка, кроме последней строки абзаца, должна заканчиваться на правом краю
текстовой зоны: X = ширина страницы - правое поле (для A4 при полях 20/10 мм это 200 мм,
ширина зоны 180 мм). Одна и та же правая граница обязательна для абзацев в основном потоке
и абзацев внутри невидимых таблиц-обёрток (заголовок + первый абзац), а также для таблиц данных.

Проверяются строки длиной не менее 80 % ширины зоны, кроме последней строки каждого блока
pdftotext и подписей «Таблица N.»/«Рис. N.». Допуск по умолчанию 1,0 мм.

Использование:
  check_right_edge.py file.pdf [--left-margin 20] [--right-margin 10] [--tol 1.0]
Код выхода 1 — найдены отклонения; документ пользователю не выдаётся.
"""
import sys, re, subprocess, argparse
ap = argparse.ArgumentParser()
ap.add_argument('pdf'); ap.add_argument('--left-margin', type=float, default=20)
ap.add_argument('--right-margin', type=float, default=10); ap.add_argument('--tol', type=float, default=1.0)
a = ap.parse_args()
PT = 25.4 / 72
xml = subprocess.run(['pdftotext', '-bbox-layout', a.pdf, '-'], capture_output=True, text=True).stdout
LINE = re.compile(r'<line xMin="([\d.]+)" yMin="[\d.]+" xMax="([\d.]+)" yMax="[\d.]+">(.*?)</line>', re.S)
bad, checked = [], 0
for pi, (w, body) in enumerate(re.findall(r'<page width="([\d.]+)" height="[\d.]+">(.*?)</page>', xml, re.S), 1):
    if pi == 1:
        continue  # титульный лист
    right = float(w) * PT - a.right_margin; zone = right - a.left_margin
    for block in re.findall(r'<block[^>]*>(.*?)</block>', body, re.S):
        lines = LINE.findall(block)
        for i, (x0, x1, words) in enumerate(lines[:-1]):   # последняя строка блока не проверяется
            x0, x1 = float(x0) * PT, float(x1) * PT
            txt = ' '.join(re.findall(r'>([^<]+)</word>', words))
            nx0 = float(lines[i + 1][0]) * PT
            ntxt = ' '.join(re.findall(r'>([^<]+)</word>', lines[i + 1][2]))
            # следующая строка начинает новый абзац (красная строка) или новый пункт списка:
            # текущая строка — последняя строка своего абзаца, она не обязана доходить до края
            if nx0 > x0 + 3 or ntxt.startswith(('–', '—', '-', '•')):
                continue
            if x1 - x0 < 0.80 * zone or re.match(r'(Таблица|Рис\.)\s*\d', txt):
                continue
            checked += 1
            if abs(x1 - right) > a.tol:
                bad.append((pi, x1 - right, txt[:70]))
for pi, d, t in bad:
    print(f'стр. {pi}: правый край {d:+.1f} мм от границы зоны: «{t}»')
print(f'Проверено строк: {checked}; отклонений: {len(bad)}')
sys.exit(1 if bad else 0)
