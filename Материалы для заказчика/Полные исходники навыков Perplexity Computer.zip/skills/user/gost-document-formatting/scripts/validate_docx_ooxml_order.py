#!/usr/bin/env python3
"""Fail-fast checks for DOCX structures that caused real cross-renderer failures."""

from __future__ import annotations

import sys
import zipfile
from pathlib import Path

from lxml import etree


W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
NS = {"w": W}
Q = lambda name: f"{{{W}}}{name}"


def positions(parent: etree._Element) -> dict[str, int]:
    return {child.tag: index for index, child in enumerate(parent)}


def validate(path: Path) -> list[str]:
    errors: list[str] = []
    with zipfile.ZipFile(path) as archive:
        xml_parts = {
            name: etree.fromstring(archive.read(name))
            for name in archive.namelist()
            if name.startswith("word/") and name.endswith(".xml")
        }

    document = xml_parts.get("word/document.xml")
    if document is None:
        return ["word/document.xml отсутствует"]

    for number, pg_mar in enumerate(document.xpath(".//w:pgMar", namespaces=NS), 1):
        if pg_mar.get(Q("gutter")) is None:
            errors.append(f"pgMar #{number}: отсутствует w:gutter")

    for part_name, root in xml_parts.items():
        for number, tbl_pr in enumerate(root.xpath(".//w:tblPr", namespaces=NS), 1):
            order = positions(tbl_pr)
            layout = order.get(Q("tblLayout"))
            look = order.get(Q("tblLook"))
            if layout is not None and look is not None and layout > look:
                errors.append(
                    f"{part_name}, tblPr #{number}: w:tblLayout стоит после w:tblLook"
                )

    styles = xml_parts.get("word/styles.xml")
    if styles is not None:
        for style in styles.xpath(".//w:style[@w:type='table']", namespaces=NS):
            style_id = style.get(Q("styleId"), "(без styleId)")
            order = positions(style)
            r_pr = order.get(Q("rPr"))
            if r_pr is None:
                continue
            for later_name in ("tblPr", "tblStylePr"):
                later = order.get(Q(later_name))
                if later is not None and r_pr > later:
                    errors.append(
                        f"style {style_id}: w:rPr стоит после w:{later_name}"
                    )

    return errors


def main() -> int:
    if len(sys.argv) != 2:
        print("Использование: validate_docx_ooxml_order.py <document.docx>")
        return 2

    path = Path(sys.argv[1])
    if not path.is_file():
        print(f"FAIL: файл не найден: {path}")
        return 2

    try:
        errors = validate(path)
    except (zipfile.BadZipFile, etree.XMLSyntaxError, OSError) as exc:
        print(f"FAIL: DOCX не прочитан: {exc}")
        return 2

    if errors:
        print("FAIL")
        for error in errors:
            print(f"- {error}")
        return 1

    print("PASS: обязательные структурные проверки OOXML пройдены")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
